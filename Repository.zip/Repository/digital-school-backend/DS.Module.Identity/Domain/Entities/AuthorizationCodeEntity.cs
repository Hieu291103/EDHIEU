using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;
using MongoDB.Bson.Serialization.Attributes;

namespace DS.Module.Identity.Domain.Entities
{
    /// <summary>
    /// Authorization Code trong OAuth2 (hỗ trợ PKCE)
    /// </summary>
    [BsonCollection("identityAuthorizationCodes")]
    public class AuthorizationCodeEntity : BaseTenantEntity, IAdminEntity
    {
        /// <summary>
        /// Giá trị authorization code
        /// </summary>
        public required string Code { get; set; }

        /// <summary>
        /// Người dùng (subject)
        /// </summary>
        [BsonObjectId]
        public required string UserId { get; set; }

        /// <summary>
        /// Client ID
        /// </summary>
        public required string ClientId { get; set; }

        public required string RedirectUri { get; set; }
        public List<string> Scopes { get; set; } = new();
        public string? CodeChallenge { get; set; }
        public string? CodeChallengeMethod { get; set; }
        public DateTime ExpiresAt { get; set; }
        public bool IsUsed { get; set; } = false;
        public DateTime? UsedAt { get; set; }

        /// <summary>
        /// Nhà cung cấp định danh được sử dụng trong phiên cấp code
        /// </summary>
        public string? IdentityProviderCode { get; set; }
    }
}
