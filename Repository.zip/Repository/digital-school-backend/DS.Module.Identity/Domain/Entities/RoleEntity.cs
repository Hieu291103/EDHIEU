using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.Identity.Domain.Entities
{
    /// <summary>
    /// Vai trò (Role) theo mô hình RBAC, được phân phạm vi theo ứng dụng (Client).
    /// </summary>
    [BsonCollection("identityRoles")]
    public class RoleEntity : BaseTenantEntity, IAdminEntity
    {
        /// <summary>
        /// ClientId của ứng dụng sở hữu role này (UUID).
        /// </summary>
        public required string ClientId { get; set; }

        /// <summary>
        /// Tên hiển thị.
        /// </summary>
        public required string Name { get; set; }

        /// <summary>
        /// Mô tả (tuỳ chọn).
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// Danh sách mã quyền (permission) mà role này cấp.
        /// </summary>
        public List<string> PermissionCodes { get; set; } = new();

        /// <summary>
        /// Role hệ thống (built-in) hay do người dùng tạo.
        /// </summary>
        public bool IsSystem { get; set; } = false;
    }
}
