using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;
using MongoDB.Bson.Serialization.Attributes;

namespace DS.Module.Identity.Domain.Entities
{
    /// <summary>
    /// Gán vai trò (role) RBAC cho user theo ứng dụng (client) và (tuỳ chọn) theo tenant.
    /// </summary>
    [BsonCollection("identityUserRoleAssignments")]
    public class UserRoleAssignmentEntity : BaseAuditableEntity, IAdminEntity
    {
        /// <summary>
        /// User ID
        /// </summary>
        [BsonObjectId]
        public required string UserId { get; set; }

        /// <summary>
        /// ClientId của ứng dụng.
        /// </summary>
        public required string ClientId { get; set; }

        /// <summary>
        /// Danh sách tenant được phép truy câp
        /// </summary>
        [BsonObjectId]
        public List<string> TenantIds { get; set; } = new();
        public bool IsAllTenants { get; set; } = true;

        /// <summary>
        /// Danh sách mã role. Lưu mã để phát hành token nhanh, không cần join DB.
        /// </summary>
        [BsonObjectId]
        public List<string> RoleIds { get; set; } = new();

        /// <summary>
        /// Mapping hiện tại (active) hay không.
        /// </summary>
        public bool IsActive { get; set; } = true;

        /// <summary>
        /// Ngày bắt đầu.
        /// </summary>
        public DateTime StartDate { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// Ngày kết thúc (null = hiện tại vẫn còn).
        /// </summary>
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Lý do kết thúc.
        /// </summary>
        public string? EndReason { get; set; }
    }
}
