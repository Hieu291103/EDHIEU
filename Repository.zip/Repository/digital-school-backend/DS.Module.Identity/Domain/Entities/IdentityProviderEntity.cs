using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.Identity.Domain.Entities
{
    /// <summary>
    /// Cấu hình nhà cung cấp định danh (IdP) cho định tuyến SSO (OIDC/OAuth2)
    /// </summary>
    [BsonCollection("identityProviders")]
    public class IdentityProviderEntity : BaseSoftDeleteEntity, IAdminEntity
    {
        /// <summary>
        /// Mã IdP (local, azuread, google,...)
        /// </summary>
        public required string Code { get; set; }

        /// <summary>
        /// Tên hiển thị
        /// </summary>
        public required string Name { get; set; }

        public string? DisplayName { get; set; }

        /// <summary>
        /// Authority/issuer URL
        /// </summary>
        public string? Authority { get; set; }

        /// <summary>
        /// Thông tin client để giao tiếp IdP (nếu cần)
        /// </summary>
        public string? ClientId { get; set; }
        public string? ClientSecret { get; set; }

        /// <summary>
        /// Redirect URLs khi khởi tạo đăng nhập IdP
        /// </summary>
        public List<string> RedirectUris { get; set; } = new();
        public List<string> PostLogoutRedirectUris { get; set; } = new();

        /// <summary>
        /// Scopes yêu cầu khi đăng nhập với IdP
        /// </summary>
        public List<string> Scopes { get; set; } = new();

        /// <summary>
        /// Danh sách domain/suffix dùng làm login hint để route IdP
        /// </summary>
        public List<string> LoginHintDomains { get; set; } = new();

        /// <summary>
        /// IdP mặc định khi không match hint
        /// </summary>
        public bool IsDefault { get; set; } = false;

        /// <summary>
        /// Bật/tắt IdP
        /// </summary>
        public bool IsEnabled { get; set; } = true;

        public Dictionary<string, string>? Metadata { get; set; }
    }
}
