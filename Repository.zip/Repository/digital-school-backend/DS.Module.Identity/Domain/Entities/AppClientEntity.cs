using DS.Shared.Core.Common.Constants;
using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.Identity.Domain.Entities
{
    /// <summary>
    /// Ứng dụng khách OAuth2
    /// </summary>
    [BsonCollection("identityAppClients")]
    public class AppClientEntity : BaseSoftDeleteEntity, IAdminEntity
    {
        /// <summary>
        /// Client ID (kiểu UUID)/ sử dụng domain làm Client ID cũng được
        /// </summary>
        public required string ClientId { get; set; }

        /// <summary>
        /// Client Secret (đã băm)
        /// </summary>
        public required string ClientSecret { get; set; }

        /// <summary>
        /// Tên ứng dụng
        /// </summary>
        public required string ClientName { get; set; }

        /// <summary>
        /// Mô tả
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// Loại client (confidential, public, native)
        /// </summary>
        public string ClientType { get; set; } = "confidential";

        /// <summary>
        /// Các grant type cho phép (authorization_code, client_credentials,...)
        /// </summary>
        public List<string> AllowedGrantTypes { get; set; } = new();

        /// <summary>
        /// Danh sách redirect URI
        /// </summary>
        public List<string> RedirectUris { get; set; } = new();

        /// <summary>
        /// Danh sách post-logout redirect URI
        /// </summary>
        public List<string> PostLogoutRedirectUris { get; set; } = new();

        /// <summary>
        /// CORS origins cho phép
        /// </summary>
        public List<string> AllowedCorsOrigins { get; set; } = new();

        /// <summary>
        /// Scopes cho phép
        /// </summary>
        public List<string> AllowedScopes { get; set; } = new();

        /// <summary>
        /// Các IdP mà client được phép dùng (local, azuread, google,...)
        /// </summary>
        public List<string> AllowedIdentityProviders { get; set; } = new();

        /// <summary>
        /// IdP mặc định khi không xác định login hint
        /// </summary>
        public string? DefaultIdentityProvider { get; set; } = IdentityProviderCodes.Local;

        /// <summary>
        /// Thời gian sống Access Token (giây)
        /// </summary>
        public int? AccessTokenLifetime { get; set; } = 3600;

        /// <summary>
        /// Thời gian sống Refresh Token (giây)
        /// </summary>
        public int? RefreshTokenLifetime { get; set; } = 2592000;

        /// <summary>
        /// Cho phép offline access (refresh token)
        /// </summary>
        public bool AllowOfflineAccess { get; set; } = true;

        /// <summary>
        /// Bắt buộc PKCE
        /// </summary>
        public bool RequirePkce { get; set; } = false;

        /// <summary>
        /// Cho phép PKCE plain text
        /// </summary>
        public bool AllowPlainTextPkce { get; set; } = true;

        /// <summary>
        /// Yêu cầu màn hình consent
        /// </summary>
        public bool RequireConsent { get; set; } = false;

        /// <summary>
        /// Là client hệ thống (built-in) hay do người dùng tạo
        /// </summary>
        public bool IsSystemClient { get; set; } = false;

        /// <summary>
        /// Claims gán cho client
        /// </summary>
        public Dictionary<string, string>? Claims { get; set; }
    }
}
