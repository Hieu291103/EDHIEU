using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.Identity.Domain.Entities
{
    /// <summary>
    /// Quyền (Permission) theo mô hình RBAC, được phân phạm vi theo ứng dụng (Client).
    /// </summary>
    [BsonCollection("identityPermissions")]
    public class PermissionEntity : BaseAuditableEntity, IAdminEntity
    {
        /// <summary>
        /// ClientId của ứng dụng sở hữu permission này (UUID).
        /// </summary>
        public required string ClientId { get; set; }

        /// <summary>
        /// Mã quyền (duy nhất trong phạm vi một client). Ví dụ: EVENT:ONLINE_CLASS:VIEW.
        /// </summary>
        public required string Code { get; set; }

        /// <summary>
        /// Tên hiển thị.
        /// </summary>
        public required string Name { get; set; }

        /// <summary>
        /// Mô tả (tuỳ chọn).
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// Nhóm/Module để phục vụ hiển thị UI (tuỳ chọn).
        /// </summary>
        public string? Module { get; set; }

        /// <summary>
        /// Tính năng/Feature để phục vụ hiển thị UI (tuỳ chọn).
        /// </summary>
        public string? Feature { get; set; }

        /// <summary>
        /// Hành động
        /// </summary>
        public string? Action { get; set; }
    }
}
