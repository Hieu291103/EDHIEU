using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;
using MongoDB.Bson.Serialization.Attributes;

namespace DS.Module.Identity.Domain.Entities
{
    /// <summary>
    /// Refresh Token trong OAuth2
    /// </summary>
    [BsonCollection("identityRefreshTokens")]
    public class RefreshTokenEntity : BaseTenantEntity, IAdminEntity
    {
        [BsonObjectId]
        public required string UserId { get; set; }

        /// <summary>
        /// Client đã phát hành refresh token
        /// </summary>
        public required string ClientId { get; set; }

        /// <summary>
        /// Giá trị refresh token (có thể băm)
        /// </summary>
        public required string Token { get; set; }

        /// <summary>
        /// JTI của access token để phục vụ thu hồi
        /// </summary>
        public required string Jti { get; set; }

        /// <summary>
        /// Nhà cung cấp định danh gắn với phiên đăng nhập
        /// </summary>
        public string? IdentityProviderCode { get; set; }

        public DateTime ExpiresAt { get; set; }
        public string? CreatedByIp { get; set; }
    }
}
