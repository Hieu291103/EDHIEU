using DS.Shared.Core.Common.Constants;
using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Enums;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.Identity.Domain.Entities
{
    /// <summary>
    /// Người dùng cho module Identity - OAuth2/SSO
    /// </summary>
    [BsonCollection("identityUsers")]
    public class UserEntity : BaseSoftDeleteEntity, IAdminEntity
    {
        /// <summary>
        /// Tên đăng nhập
        /// </summary>
        public required string Username { get; set; }

        /// <summary>
        /// Mã từ CSDL Ngành
        /// </summary>
        public string? EducationCode { get; set; }

        /// <summary>
        /// Địa chỉ email
        /// </summary>
        public string? Email { get; set; }

        /// <summary>
        /// Trạng thái email đã xác thực
        /// </summary>
        public bool EmailVerified { get; set; } = false;

        /// <summary>
        /// Số điện thoại
        /// </summary>
        public string? PhoneNumber { get; set; }

        /// <summary>
        /// Trạng thái số điện thoại đã xác thực
        /// </summary>
        public bool PhoneNumberVerified { get; set; } = false;

        /// <summary>
        /// Mật khẩu đã băm
        /// </summary>
        public required string PasswordHash { get; set; }

        /// <summary>
        /// Đăng nhập bằng nhà cung cấp định danh ngoài (không phải local/localOnluyen)
        /// </summary>
        public required bool UseProvider { get; set; } = false;

        /// <summary>
        /// Dấu bảo mật để vô hiệu hóa token
        /// </summary>
        public string SecurityStamp { get; set; } = Guid.NewGuid().ToString();

        /// <summary>
        /// Họ tên đầy đủ
        /// </summary>
        public string? FullName { get; set; }

        /// <summary>
        /// Họ
        /// </summary>
        public string? FirstName { get; set; }

        /// <summary>
        /// Tên
        /// </summary>
        public string? LastName { get; set; }

        /// <summary>
        /// Chức danh / công việc
        /// </summary>
        public string? Title { get; set; }

        /// <summary>
        /// Ngày sinh
        /// </summary>
        public DateTime? DateOfBirth { get; set; }

        /// <summary>
        /// Ảnh đại diện
        /// </summary>
        public string? AvatarUrl { get; set; }

        /// <summary>
        /// Nhà cung cấp định danh sở hữu tài khoản (local,localOnLuyen, onluyen, azuread, google,...)
        /// </summary>
        public string IdentityProviderCode { get; set; } = IdentityProviderCodes.Local;

        /// <summary>
        /// Subject/ID trả về từ IdP bên ngoài
        /// </summary>
        public string? ProviderSubjectId { get; set; }

        /// <summary>
        /// Gợi ý đăng nhập (domain/alias) để định tuyến IdP
        /// </summary>
        public string? LoginHint { get; set; }

        /// <summary>
        /// Phân loại người dùng (SuperAdmin, Admin, Teacher, ...)
        /// </summary>
        public UserType UserType { get; set; } = UserType.None;

        /// <summary>
        /// Bật xác thực hai lớp
        /// </summary>
        public bool TwoFactorEnabled { get; set; } = false;

        /// <summary>
        /// Cho phép khóa tài khoản
        /// </summary>
        public bool LockoutEnabled { get; set; } = true;

        /// <summary>
        /// Thời điểm hết khóa
        /// </summary>
        public DateTime? LockoutEnd { get; set; }

        /// <summary>
        /// Số lần đăng nhập thất bại
        /// </summary>
        public int AccessFailedCount { get; set; } = 0;

        /// <summary>
        /// Lần đăng nhập gần nhất
        /// </summary>
        public DateTime? LastLoginAt { get; set; }

        /// <summary>
        /// IP đăng nhập gần nhất
        /// </summary>
        public string? LastLoginIp { get; set; }

        /// <summary>
        /// Danh sách IdP ngoài đã liên kết (Google, Microsoft,...)
        /// </summary>
        public List<ExternalLoginInfoEntity>? ExternalLogins { get; set; }

        /// <summary>
        /// Danh sách vai trò
        /// </summary>
        public List<string>? Roles { get; set; }

        /// <summary>
        /// Các claim bổ sung
        /// </summary>
        public Dictionary<string, string>? Claims { get; set; }

        /// <summary>
        /// Helper: Kiểm tra user có dùng external provider không
        /// </summary>
        public bool IsExternalProvider()
        {
            return UseProvider && IdentityProviderCode != IdentityProviderCodes.Local;
        }

        /// <summary>
        /// Helper: Cập nhật provider khi user được redirect từ login hint
        /// </summary>
        public void SetIdentityProvider(string providerCode)
        {
            if (!string.IsNullOrWhiteSpace(providerCode))
            {
                IdentityProviderCode = providerCode;
            }
        }
    }

    /// <summary>
    /// Thông tin liên kết IdP ngoài
    /// </summary>
    public class ExternalLoginInfoEntity
    {
        /// <summary>
        /// Mã nhà cung cấp định danh (google, microsoft, facebook,...)
        /// </summary>
        public required string Provider { get; set; }
        /// <summary>
        /// Khóa định danh từ nhà cung cấp
        /// </summary>
        public required string ProviderKey { get; set; }
        /// <summary>
        /// Tên hiển thị của nhà cung cấp
        /// </summary>
        public string? ProviderDisplayName { get; set; }
        /// <summary>
        /// Thời điểm liên kết
        /// </summary>
        public DateTime LinkedAt { get; set; } = DateTime.UtcNow;
    }
}
