using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;
using MongoDB.Bson.Serialization.Attributes;

namespace DS.Module.Identity.Domain.Entities
{
    /// <summary>
    /// Thông tin phiên làm việc của người dùng
    /// </summary>
    [BsonCollection("identityUserSessions")]
    public class UserSessionEntity : BaseTenantEntity, IAdminEntity
    {
        [BsonObjectId]
        public required string UserId { get; set; }
        public required string SessionKey { get; set; }
        public string? IdentityProviderCode { get; set; }
        public string? DeviceInfo { get; set; }
        public string? IpAddress { get; set; }
        public string? UserAgent { get; set; }
        public DateTime LastAccessedAt { get; set; } = DateTime.UtcNow;
        public DateTime ExpiresAt { get; set; }
        public bool IsActive { get; set; } = true;
    }
}
