using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.Identity.Domain.Entities
{
    /// <summary>
    /// BasicAuth Credential cho external API integration
    /// </summary>
    [BsonCollection("identityBasicAuthCredentials")]
    public class BasicAuthCredentialEntity : BaseEntity, IAdminEntity
    {
        /// <summary>
        /// Username cho Basic Authentication
        /// </summary>
        public required string Username { get; set; }

        /// <summary>
        /// Password hash (SHA256)
        /// </summary>
        public required string PasswordHash { get; set; }

        /// <summary>
        /// Mô tả credential (e.g., "Report API for external system")
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// API Key reference
        /// </summary>
        public string? ApiKey { get; set; }

        /// <summary>
        /// Trạng thái hoạt động
        /// </summary>
        public bool IsActive { get; set; } = true;

        /// <summary>
        /// Ngày hết hạn (null = không hết hạn)
        /// </summary>
        public DateTime? ExpiresAt { get; set; }
    }
}
