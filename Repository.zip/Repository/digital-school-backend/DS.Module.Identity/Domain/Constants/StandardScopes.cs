namespace DS.Module.Identity.Domain.Constants
{
    /// <summary>
    /// Standard OAuth2/OIDC scopes
    /// </summary>
    public static class StandardScopes
    {
        // OIDC scopes
        public const string OpenId = "openid";              // Bắt buộc để lấy id_token
        public const string Profile = "profile";            // id, name, given_name, family_name, username, ...
        public const string Email = "email";                // email, email_verified
        public const string Phone = "phone";                // phone_number, phone_number_verified
        public const string Address = "address";            // address, ...

        // OAuth2 scopes
        public const string OfflineAccess = "offline_access"; // Refresh token

        // Custom scopes
        public const string SchoolAccess = "school:read";   // Đọc thông tin trường
        public const string ClassAccess = "class:read";     // Đọc thông tin lớp

        public static readonly List<string> StandardOpenIdScopes = new()
        {
            OpenId,
            Profile,
            Email,
            OfflineAccess
        };

        public static readonly List<string> AllScopes = new()
        {
            OpenId,
            Profile,
            Email,
            Phone,
            Address,
            OfflineAccess,
            SchoolAccess,
            ClassAccess
        };
    }
}
