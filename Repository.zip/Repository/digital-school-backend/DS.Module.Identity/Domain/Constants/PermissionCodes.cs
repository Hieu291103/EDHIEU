namespace DS.Module.Identity.Domain.Constants
{
    /// <summary>
    /// Định nghĩa tất cả Permission Codes theo structure: MODULE:FEATURE:ACTION
    /// Ví dụ: EVENT:ONLINE_CLASS:VIEW, EVENT:ONLINE_CLASS:CREATE
    /// </summary>
    public static class PermissionCodes
    {
        /// <summary>
        /// Modules cho DigitalSchool Client
        /// </summary>
        public static class DigitalSchool
        {
            public const string MODULE_OVEVIEW = "OVEVIEW";
            public const string MODULE_EVENT = "EVENT";
            public const string MODULE_ATTENDANCE = "ATTENDANCE";
            public const string MODULE_INFO_MANAGEMENT = "INFO_MANAGEMENT";
            public const string MODULE_SETIING = "SETTING";

            /// <summary>
            /// Feature codes cho MODULE_EVENT
            /// </summary>
            public static class Event
            {
                public const string FEATURE_CLASS_SCHEDULE = "CLASS_SCHEDULE";
                public const string FEATURE_ONLINE_CLASS = "ONLINE_CLASS";
            }

            /// <summary>
            /// Feature codes cho MODULE_ATTENDANCE
            /// </summary>
            public static class Attendance
            {
                public const string FEATURE_ATTENDANCE_INFO = "ATTENDANCE_INFO";
                public const string FEATURE_ATTENDANCE_STATISTIC = "ATTENDANCE_STATISTIC";
            }

            /// <summary>
            /// Feature codes cho MODULE_INFO_MANAGEMENT
            /// </summary>
            public static class InfomationManagement
            {
                public const string FEATURE_CLASS = "CLASS";
                public const string FEATURE_TEACHER = "TEACHER";
                public const string FEATURE_STUDENT = "STUDENT";
                public const string FEATURE_OBJECT = "OBJECT";
                public const string FEATURE_STAFF = "STAFF";
            }

            /// <summary>
            /// Feature codes cho MODULE_SETIING
            /// </summary>
            public static class Setting
            {
                public const string FEATURE_CONFIG = "CONFIG";
                public const string FEATURE_CONFIG_YEAR = "CONFIG_YEAR";
            }
        }

        /// <summary>
        /// Modules cho AdminCRM Client
        /// </summary>
        public static class AdminCRM
        {
            public const string MODULE_TENANT = "TENANT";
            public const string MODULE_USER = "USERT";
            public const string MODULE_ROLE = "ROLE";
            public const string MODULE_ONLINE_CLASS = "ONLINE_CLASS";
            public const string MODULE_SETIING = "SETTING";

            /// <summary>
            /// Feature codes cho MODULE_TENANT
            /// </summary>
            public static class Tenant
            {
                public const string FEATURE_TENANT = "TENANT";
                public const string FEATURE_LICENSE = "LICENSE";
            }

            /// <summary>
            /// Feature codes cho MODULE_USER
            /// </summary>
            public static class User
            {
                public const string FEATURE_USER = "USER";
                public const string FEATURE_USER_ROLE = "USER_ROLE";
                public const string FEATURE_ROLE = "ROLE";
                public const string FEATURE_PERMISSION = "PERMISSION";
            }

            /// <summary>
            /// Feature codes cho MODULE_ONLINE_CLASS
            /// </summary>
            public static class OnlineClass
            {
                public const string FEATURE_ONLINE_CLASS_INFO = "ONLINE_CLASS_INFO";
            }

            /// <summary>
            /// Feature codes cho MODULE_SETIING
            /// </summary>
            public static class Setting
            {
                public const string FEATURE_CONFIG = "CONFIG";
                public const string FEATURE_CONFIG_YEAR = "CONFIG_YEAR";
            }
        }
    }
}
