namespace DS.Module.Identity.Domain.Constants
{
    /// <summary>
    /// Định nghĩa tất cả Role Codes và Display Names theo structure: MODULE:ROLE_NAME
    /// Ví dụ: ADMIN:SUPER_ADMIN, ADMIN:ADMIN, ADMIN:VIEWER
    /// </summary>
    public static class RoleCodes
    {
        /// <summary>
        /// Role codes cho DigitalSchool Client
        /// </summary>
        public static class DigitalSchool
        {
            public const string ROLE_TEACHER = "TEACHER";
            public const string ROLE_STUDENT = "STUDENT";
            public const string ROLE_PARENT = "PARENT";
            public const string ROLE_STAFF = "STAFF";
        }

        /// <summary>
        /// Role codes cho AdminCRM Client
        /// </summary>
        public static class AdminCRM
        {
            public const string ROLE_SUPER_ADMIN = "SUPER_ADMIN";
            public const string ROLE_ADMIN = "ADMIN";
            public const string ROLE_TENANT_ADMIN = "TENANT_ADMIN";
            public const string ROLE_MANAGER = "MANAGER";
            public const string ROLE_VIEWER = "VIEWER";
        }
    }

    /// <summary>
    /// Định nghĩa Role Display Names cho UI
    /// </summary>
    public static class RoleNames
    {
        /// <summary>
        /// DigitalSchool - Role display names
        /// </summary>
        public static class DigitalSchool
        {
            public static readonly Dictionary<string, string> Roles = new()
            {
                [RoleCodes.DigitalSchool.ROLE_TEACHER] = "Giáo viên",
                [RoleCodes.DigitalSchool.ROLE_STUDENT] = "Học sinh",
                [RoleCodes.DigitalSchool.ROLE_PARENT] = "Phụ huynh",
                [RoleCodes.DigitalSchool.ROLE_STAFF] = "Nhân viên",
            };
        }

        /// <summary>
        /// AdminCRM - Role display names
        /// </summary>
        public static class AdminCRM
        {
            public static readonly Dictionary<string, string> Roles = new()
            {
                [RoleCodes.AdminCRM.ROLE_SUPER_ADMIN] = "Quản trị viên toàn hệ thống",
                [RoleCodes.AdminCRM.ROLE_ADMIN] = "Quản trị viên",
                [RoleCodes.AdminCRM.ROLE_TENANT_ADMIN] = "Quản trị viên Tenant",
                [RoleCodes.AdminCRM.ROLE_MANAGER] = "Quản lý",
                [RoleCodes.AdminCRM.ROLE_VIEWER] = "Người xem",
            };
        }
    }
}
