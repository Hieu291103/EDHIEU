namespace DS.Module.Identity.Domain.Constants
{
    /// <summary>
    /// Định nghĩa Module → Feature → Display Names cho từng Client
    /// Gọn gàng, chỉ Tiếng Việt
    /// </summary>
    public static class PermissionNames
    {
        /// <summary>
        /// DigitalSchool - Module & Feature names
        /// </summary>
        public static class DigitalSchool
        {
            public static readonly Dictionary<string, string> Modules = new()
            {
                [PermissionCodes.DigitalSchool.MODULE_OVEVIEW] = "Tổng quan",
                [PermissionCodes.DigitalSchool.MODULE_EVENT] = "Lịch học & Sự kiện",
                [PermissionCodes.DigitalSchool.MODULE_ATTENDANCE] = "Điểm danh",
                [PermissionCodes.DigitalSchool.MODULE_INFO_MANAGEMENT] = "Quản lý thông tin",
                [PermissionCodes.DigitalSchool.MODULE_SETIING] = "Cài đặt"
            };

            public static readonly Dictionary<string, string> Features = new()
            {
                // OVERVIEW features
                // (không có feature nào định nghĩa)

                // EVENT features
                [PermissionCodes.DigitalSchool.Event.FEATURE_CLASS_SCHEDULE] = "Lịch học",
                [PermissionCodes.DigitalSchool.Event.FEATURE_ONLINE_CLASS] = "Lớp học trực tuyến",

                // ATTENDANCE features
                [PermissionCodes.DigitalSchool.Attendance.FEATURE_ATTENDANCE_INFO] = "Thông tin điểm danh",
                [PermissionCodes.DigitalSchool.Attendance.FEATURE_ATTENDANCE_STATISTIC] = "Thống kê điểm danh",

                // INFO_MANAGEMENT features
                [PermissionCodes.DigitalSchool.InfomationManagement.FEATURE_CLASS] = "Lớp học",
                [PermissionCodes.DigitalSchool.InfomationManagement.FEATURE_TEACHER] = "Giáo viên",
                [PermissionCodes.DigitalSchool.InfomationManagement.FEATURE_STUDENT] = "Học sinh",
                [PermissionCodes.DigitalSchool.InfomationManagement.FEATURE_OBJECT] = "Đối tượng",
                [PermissionCodes.DigitalSchool.InfomationManagement.FEATURE_STAFF] = "Nhân viên",

                // SETTING features
                [PermissionCodes.DigitalSchool.Setting.FEATURE_CONFIG] = "Cấu hình chung",
                [PermissionCodes.DigitalSchool.Setting.FEATURE_CONFIG_YEAR] = "Cấu hình năm học"
            };

            /// <summary>
            /// Cấu trúc Module → Features
            /// </summary>
            public static readonly Dictionary<string, List<string>> Structure = new()
            {
                [PermissionCodes.DigitalSchool.MODULE_OVEVIEW] = new() { },
                [PermissionCodes.DigitalSchool.MODULE_EVENT] = new()
                {
                    PermissionCodes.DigitalSchool.Event.FEATURE_CLASS_SCHEDULE,
                    PermissionCodes.DigitalSchool.Event.FEATURE_ONLINE_CLASS
                },
                [PermissionCodes.DigitalSchool.MODULE_ATTENDANCE] = new()
                {
                    PermissionCodes.DigitalSchool.Attendance.FEATURE_ATTENDANCE_INFO,
                    PermissionCodes.DigitalSchool.Attendance.FEATURE_ATTENDANCE_STATISTIC
                },
                [PermissionCodes.DigitalSchool.MODULE_INFO_MANAGEMENT] = new()
                {
                    PermissionCodes.DigitalSchool.InfomationManagement.FEATURE_CLASS,
                    PermissionCodes.DigitalSchool.InfomationManagement.FEATURE_TEACHER,
                    PermissionCodes.DigitalSchool.InfomationManagement.FEATURE_STUDENT,
                    PermissionCodes.DigitalSchool.InfomationManagement.FEATURE_OBJECT,
                    PermissionCodes.DigitalSchool.InfomationManagement.FEATURE_STAFF
                },
                [PermissionCodes.DigitalSchool.MODULE_SETIING] = new()
                {
                    PermissionCodes.DigitalSchool.Setting.FEATURE_CONFIG,
                    PermissionCodes.DigitalSchool.Setting.FEATURE_CONFIG_YEAR
                }
            };
        }

        /// <summary>
        /// AdminCRM - Module & Feature names
        /// </summary>
        public static class AdminCRM
        {
            public static readonly Dictionary<string, string> Modules = new()
            {
                [PermissionCodes.AdminCRM.MODULE_TENANT] = "Trường học",
                [PermissionCodes.AdminCRM.MODULE_USER] = "Quản lý người dùng",
                [PermissionCodes.AdminCRM.MODULE_ROLE] = "Quản lý vai trò",
                [PermissionCodes.AdminCRM.MODULE_ONLINE_CLASS] = "Lớp học trực tuyến",
                [PermissionCodes.AdminCRM.MODULE_SETIING] = "Cài đặt"
            };

            public static readonly Dictionary<string, string> Features = new()
            {
                // TENANT features
                [PermissionCodes.AdminCRM.Tenant.FEATURE_TENANT] = "Trường học",
                [PermissionCodes.AdminCRM.Tenant.FEATURE_LICENSE] = "Giấy phép",

                // USER features
                [PermissionCodes.AdminCRM.User.FEATURE_USER] = "Người dùng",
                [PermissionCodes.AdminCRM.User.FEATURE_USER_ROLE] = "Vai trò người dùng",
                [PermissionCodes.AdminCRM.User.FEATURE_ROLE] = "Vai trò",
                [PermissionCodes.AdminCRM.User.FEATURE_PERMISSION] = "Quyền",

                // ONLINE_CLASS features
                [PermissionCodes.AdminCRM.OnlineClass.FEATURE_ONLINE_CLASS_INFO] = "Thông tin lớp học trực tuyến",

                // SETTING features
                [PermissionCodes.AdminCRM.Setting.FEATURE_CONFIG] = "Cấu hình chung",
                [PermissionCodes.AdminCRM.Setting.FEATURE_CONFIG_YEAR] = "Cấu hình năm học"
            };

            /// <summary>
            /// Cấu trúc Module → Features
            /// </summary>
            public static readonly Dictionary<string, List<string>> Structure = new()
            {
                [PermissionCodes.AdminCRM.MODULE_TENANT] = new()
                {
                    PermissionCodes.AdminCRM.Tenant.FEATURE_TENANT,
                    PermissionCodes.AdminCRM.Tenant.FEATURE_LICENSE
                },
                [PermissionCodes.AdminCRM.MODULE_USER] = new()
                {
                    PermissionCodes.AdminCRM.User.FEATURE_USER,
                    PermissionCodes.AdminCRM.User.FEATURE_USER_ROLE,
                    PermissionCodes.AdminCRM.User.FEATURE_ROLE,
                    PermissionCodes.AdminCRM.User.FEATURE_PERMISSION
                },
                [PermissionCodes.AdminCRM.MODULE_ONLINE_CLASS] = new()
                {
                    PermissionCodes.AdminCRM.OnlineClass.FEATURE_ONLINE_CLASS_INFO
                },
                [PermissionCodes.AdminCRM.MODULE_SETIING] = new()
                {
                    PermissionCodes.AdminCRM.Setting.FEATURE_CONFIG,
                    PermissionCodes.AdminCRM.Setting.FEATURE_CONFIG_YEAR
                }
            };
        }
    }
}
