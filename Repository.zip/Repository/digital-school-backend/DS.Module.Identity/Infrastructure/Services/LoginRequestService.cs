using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Common.Constants;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.Core.Infrastructure.Persistence.Redis;
using Microsoft.Extensions.Caching.Distributed;
using System.Text.Json;

namespace DS.Module.Identity.Infrastructure.Services
{
    public class LoginRequestService : ILoginRequestService
    {
        private readonly IDistributedCache _cache;
        private readonly IAppClientCache _appClientCache;
        private readonly IAdminReadRepository<UserEntity> _userRepository;
        private static readonly TimeSpan DefaultExpiration = TimeSpan.FromMinutes(30);

        public LoginRequestService(
            IDistributedCache cache,
            IAppClientCache appClientCache,
            IAdminReadRepository<UserEntity> userRepository)
        {
            _cache = cache;
            _appClientCache = appClientCache;
            _userRepository = userRepository;
        }

        /// <summary>
        ///  Lưu Login Request vào Redis và trả về RequestId để theo dõi.
        /// </summary>
        /// <param name="clientId"></param>
        /// <param name="redirectUri"></param>
        /// <param name="responseType"></param>
        /// <param name="scope"></param>
        /// <param name="state"></param>
        /// <param name="codeChallenge"></param>
        /// <param name="codeChallengeMethod"></param>
        /// <param name="nonce"></param>
        /// <param name="loginHint"></param>
        /// <param name="identityProvider"></param>
        /// <param name="prompt"></param>
        /// <param name="additionalData"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        /// <exception cref="DSException"></exception>
        public async Task<(string RequestId, DateTime ExpiresAt)> CreateAsync(
            string clientId,
            string redirectUri,
            string? responseType = "code",
            string? scope = null,
            string? state = null,
            string? codeChallenge = null,
            string? codeChallengeMethod = null,
            string? nonce = null,
            string? loginHint = null,
            string? identityProvider = null,
            string? prompt = null,
            Dictionary<string, string>? additionalData = null,
            CancellationToken cancellationToken = default)
        {
            // 1. Validate client exists (with caching)
            var client = await _appClientCache.GetCachedClientAsync(clientId, cancellationToken);
            if (client == null)
            {
                throw new DSException("ClientNotFound");
            }

            // 2. Validate redirect_uri
            if (!client.RedirectUris.Contains(redirectUri))
            {
                throw DSException.WithParams("InvalidRedirectUri", redirectUri, clientId);
            }

            // 3. Validate scopes
            var requestedScopes = scope?.Split(OAuthQueryParameters.ScopeSeparator, StringSplitOptions.RemoveEmptyEntries).ToList() ?? new List<string>();
            var invalidScopes = requestedScopes.Except(client.AllowedScopes).ToList();
            if (invalidScopes.Any())
            {
                throw DSException.WithParam("InvalidScope", string.Join(", ", invalidScopes));
            }

            // 4. Validate PKCE
            if (client.RequirePkce && string.IsNullOrEmpty(codeChallenge))
            {
                throw new DSException("PkceRequired");
            }

            if (!string.IsNullOrEmpty(codeChallenge) && !client.AllowPlainTextPkce && codeChallengeMethod == "plain")
            {
                throw new DSException("PlainTextPkceNotAllowed");
            }

            // 5. Create DTO and save to Redis with auto-expiration
            var requestId = Guid.NewGuid().ToString("N");
            var createdAt = DateTime.UtcNow;
            var expiresAt = createdAt.Add(DefaultExpiration);

            var dto = new LoginRequestDto
            {
                ClientId = clientId,
                RedirectUri = redirectUri,
                ResponseType = responseType,
                Scopes = requestedScopes,
                State = state,
                Nonce = nonce,
                CodeChallenge = codeChallenge,
                CodeChallengeMethod = codeChallengeMethod,
                LoginHint = loginHint,
                IdentityProvider = identityProvider ?? client.DefaultIdentityProvider,
                Prompt = prompt,
                CreatedAt = createdAt,
                AdditionalData = additionalData
            };

            var json = JsonSerializer.Serialize(dto);
            var key = RedisKeys.Identity.LoginRequest(requestId);

            await _cache.SetStringAsync(
                key,
                json,
                new DistributedCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = DefaultExpiration // Redis auto-delete after 10 minutes!
                },
                cancellationToken);

            return (requestId, expiresAt);
        }

        public async Task<LoginRequestDto?> GetByRequestIdAsync(string requestId, CancellationToken cancellationToken = default)
        {
            var key = RedisKeys.Identity.LoginRequest(requestId);
            var json = await _cache.GetStringAsync(key, cancellationToken);

            if (string.IsNullOrEmpty(json))
            {
                return null;
            }

            return JsonSerializer.Deserialize<LoginRequestDto>(json);
        }

        public async Task UpdateValidatedUsernameAsync(string requestId, string username, CancellationToken cancellationToken = default)
        {
            var dto = await GetByRequestIdAsync(requestId, cancellationToken);
            if (dto == null)
            {
                throw new DSException("InvalidLoginRequest");
            }

            // Normalize username for case-insensitive storage
            dto.ValidatedUsername = StringHelper.NormalizeUsername(username);

            var json = JsonSerializer.Serialize(dto);
            var key = RedisKeys.Identity.LoginRequest(requestId);

            await _cache.SetStringAsync(
                key,
                json,
                new DistributedCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = DefaultExpiration
                },
                cancellationToken);
        }

        public async Task MarkAsAuthenticatedAsync(
            string requestId,
            string userId,
            string? sessionId = null,
            CancellationToken cancellationToken = default)
        {
            var dto = await GetByRequestIdAsync(requestId, cancellationToken);
            if (dto == null)
            {
                throw new DSException("InvalidLoginRequest");
            }

            dto.IsAuthenticated = true;
            dto.AuthenticatedUserId = userId;
            dto.AdditionalData ??= new Dictionary<string, string>();

            if (!string.IsNullOrEmpty(sessionId))
            {
                dto.AdditionalData["SessionId"] = sessionId;
            }

            var json = JsonSerializer.Serialize(dto);
            var key = RedisKeys.Identity.LoginRequest(requestId);

            await _cache.SetStringAsync(
                key,
                json,
                new DistributedCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = DefaultExpiration
                },
                cancellationToken);
        }

        public async Task MarkAsConsumedAsync(string requestId, CancellationToken cancellationToken = default)
        {
            var key = RedisKeys.Identity.LoginRequest(requestId);
            await _cache.RemoveAsync(key, cancellationToken);
        }

        public Task CleanupExpiredAsync(CancellationToken cancellationToken = default)
        {
            return Task.CompletedTask;
        }

        public async Task<UserEntity?> FindByUsernameOrEmailAsync(string usernameOrEmail, CancellationToken cancellationToken = default)
        {
            // Normalize username for case-insensitive comparison
            var normalizedUsername = StringHelper.NormalizeUsername(usernameOrEmail);

            var users = await _userRepository.FilterAsync(
                u => (u.Username == normalizedUsername || u.Email == usernameOrEmail) && !u.IsDeleted,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken: cancellationToken);

            return users.FirstOrDefault();
        }
    }
}
