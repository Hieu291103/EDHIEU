namespace DS.Module.Identity.Infrastructure.Services
{
    /// <summary>
    /// Service quản lý user sessions (SSO)
    /// </summary>
    public interface IUserSessionService
    {
        /// <summary>
        /// Tạo hoặc cập nhật session
        /// </summary>
        Task<string> CreateOrUpdateSessionAsync(
            string userId,
            string? identityProviderCode = null,
            string? deviceInfo = null,
            string? ipAddress = null,
            string? userAgent = null,
            int lifetimeSeconds = 1800,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Lấy session theo session key
        /// </summary>
        Task<Domain.Entities.UserSessionEntity?> GetSessionAsync(
            string sessionKey,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Cập nhật last accessed time
        /// </summary>
        Task UpdateLastAccessedAsync(
            string sessionKey,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Revoke session
        /// </summary>
        Task RevokeSessionAsync(
            string sessionKey,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Revoke tất cả sessions của user
        /// </summary>
        Task RevokeAllSessionsAsync(
            string userId,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Lấy user ID từ session key (để check SSO)
        /// </summary>
        Task<string?> GetUserIdFromSessionAsync(
            string sessionKey,
            CancellationToken cancellationToken = default);
    }
}
