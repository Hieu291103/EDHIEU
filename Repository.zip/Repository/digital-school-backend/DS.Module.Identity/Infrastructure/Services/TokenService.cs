using DS.Module.Identity.Domain.Entities;
using DS.Module.Tenant.Domain.Entities;
using DS.Shared.Core.Common.Constants;
using DS.Shared.Core.Infrastructure.Configuration;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text.Json;

namespace DS.Module.Identity.Infrastructure.Services
{
    public class TokenService : ITokenService
    {
        private readonly JwtSettings _jwtSettings;
        private readonly IJwtKeyService _jwtKeyService;
        private readonly IAdminReadRepository<UserEntity> _userReadRepository;
        private readonly IAdminWriteRepository<RefreshTokenEntity> _refreshTokenWriteRepository;
        private readonly IAdminReadRepository<RefreshTokenEntity> _refreshTokenReadRepository;
        private readonly IAdminReadRepository<AppClientEntity> _clientReadRepository;
        private readonly IAdminReadRepository<TenantUserMappingEntity> _userTenantMappingReadRepository;
        private readonly IAdminReadRepository<UserRoleAssignmentEntity> _userRoleAssignmentReadRepository;

        public TokenService(
            IOptions<JwtSettings> jwtOptions,
            IJwtKeyService jwtKeyService,
            IAdminReadRepository<UserEntity> userReadRepository,
            IAdminWriteRepository<RefreshTokenEntity> refreshTokenWriteRepository,
            IAdminReadRepository<RefreshTokenEntity> refreshTokenReadRepository,
            IAdminReadRepository<AppClientEntity> clientReadRepository,
            IAdminReadRepository<TenantUserMappingEntity> userTenantMappingReadRepository,
            IAdminReadRepository<UserRoleAssignmentEntity> userRoleAssignmentReadRepository)
        {
            _jwtSettings = jwtOptions.Value;
            _jwtKeyService = jwtKeyService;
            _userReadRepository = userReadRepository;
            _refreshTokenWriteRepository = refreshTokenWriteRepository;
            _refreshTokenReadRepository = refreshTokenReadRepository;
            _clientReadRepository = clientReadRepository;
            _userTenantMappingReadRepository = userTenantMappingReadRepository;
            _userRoleAssignmentReadRepository = userRoleAssignmentReadRepository;
        }

        public async Task<string> CreateAccessTokenAsync(
            string userId,
            string clientId,
            List<string> scopes,
            int lifetimeSeconds,
            string? identityProviderCode = null,
            Dictionary<string, string>? additionalClaims = null,
            CancellationToken cancellationToken = default)
        {
            var users = await _userReadRepository.FilterAsync(
                u => u.Id == userId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            var user = users.FirstOrDefault();
            if (user == null)
            {
                throw new DSException("UserNotFound");
            }

            var now = DateTime.UtcNow;
            var expires = now.AddSeconds(lifetimeSeconds);

            var jwtId = Guid.NewGuid().ToString();

            additionalClaims ??= new Dictionary<string, string>();

            var tenantId = await GetActiveTenantIdAsync(userId, cancellationToken);
            if (!string.IsNullOrWhiteSpace(tenantId)) additionalClaims["tenantId"] = tenantId;

            var claims = new List<Claim>
            {
                new(JwtRegisteredClaimNames.Sub, userId),
                new(JwtRegisteredClaimNames.Jti, jwtId),
                new(TokenClaimTypes.UserId, userId),
                new(TokenClaimTypes.ClientId, clientId),
                new(TokenClaimTypes.UserName, user.Username ?? string.Empty),
                new(TokenClaimTypes.UserType, user.UserType.ToString()),
                new(TokenClaimTypes.FullName, user.FullName ?? string.Empty),
                new(TokenClaimTypes.Avatar, user.AvatarUrl ?? string.Empty),
            };

            if (!string.IsNullOrWhiteSpace(user.Email))
            {
                claims.Add(new Claim(TokenClaimTypes.Email, user.Email));
            }

            if (!string.IsNullOrWhiteSpace(identityProviderCode))
                claims.Add(new Claim(TokenClaimTypes.IdentityProviderCode, identityProviderCode));

            //if (scopes is { Count: > 0 })
            //{
            //    // OAuth typical: scope is a space-separated string
            //    claims.Add(new Claim(TokenClaimTypes.Scope, string.Join(' ', scopes)));
            //}

            // Get roles from UserRoleAssignment based on clientId
            var roleAssignments = await _userRoleAssignmentReadRepository.FilterAsync(
                r => r.UserId == userId && r.ClientId == clientId && r.IsActive,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            var roleAssignment = roleAssignments.FirstOrDefault();
            if (roleAssignment?.RoleIds is { Count: > 0 })
            {
                var roles = roleAssignment.RoleIds
                    .Where(r => !string.IsNullOrWhiteSpace(r))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToArray();

                if (roles.Length > 0)
                {
                    // For client: roles as JSON array
                    claims.Add(new Claim(TokenClaimTypes.Roles, JsonSerializer.Serialize(roles), JsonClaimValueTypes.JsonArray));
                }
            }

            if (additionalClaims is { Count: > 0 })
            {
                foreach (var kv in additionalClaims)
                {
                    if (string.IsNullOrWhiteSpace(kv.Key) || kv.Value == null)
                        continue;

                    claims.Add(new Claim(kv.Key, kv.Value));
                }
            }

            var token = CreateJwtToken(
                claims,
                audience: _jwtSettings.Audience,
                issuer: _jwtSettings.Issuer,
                notBefore: now,
                expires: expires);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public async Task<string?> GetActiveTenantIdAsync(string userId, CancellationToken cancellationToken = default)
        {
            var mappings = await _userTenantMappingReadRepository.FilterAsync(
                m => m.UserId == userId && m.IsActive,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            return mappings.FirstOrDefault()?.TenantId;
        }

        public async Task<string> CreateRefreshTokenAsync(
            string userId,
            string clientId,
            string jti,
            int lifetimeSeconds,
            string? identityProviderCode = null,
            string? ipAddress = null,
            CancellationToken cancellationToken = default)
        {
            var tokenValue = GenerateRefreshToken();
            var expiresAt = DateTime.UtcNow.AddSeconds(lifetimeSeconds);

            var refreshToken = new RefreshTokenEntity
            {
                UserId = userId,
                ClientId = clientId,
                Token = tokenValue,
                Jti = jti,
                IdentityProviderCode = identityProviderCode,
                ExpiresAt = expiresAt,
                CreatedByIp = ipAddress,
            };

            await _refreshTokenWriteRepository.InsertAsync(refreshToken, cancellationToken);

            return tokenValue;
        }

        public Task<ClaimsPrincipal?> ValidateAccessTokenAsync(
            string token,
            CancellationToken cancellationToken = default)
        {
            try
            {
                var handler = new JwtSecurityTokenHandler();

                if (!handler.CanReadToken(token))
                    return Task.FromResult<ClaimsPrincipal?>(null);

                var parameters = CreateTokenValidationParameters(
                    validIssuer: _jwtSettings.Issuer,
                    validAudience: _jwtSettings.Audience);

                var principal = handler.ValidateToken(token, parameters, out _);
                return Task.FromResult<ClaimsPrincipal?>(principal);
            }
            catch
            {
                return Task.FromResult<ClaimsPrincipal?>(null);
            }
        }

        public async Task<RefreshTokenValidationResult?> ValidateAndConsumeRefreshTokenAsync(
            string refreshToken,
            string clientId,
            string? ipAddress = null,
            CancellationToken cancellationToken = default)
        {
            var tokens = await _refreshTokenReadRepository.FilterAsync(
                t => t.Token == refreshToken,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            var token = tokens.FirstOrDefault();

            if (token == null)
            {
                throw new DSException("InvalidRefreshToken");
            }

            if (token.ExpiresAt < DateTime.UtcNow)
            {
                throw new DSException("RefreshTokenExpired");
            }

            if (token.ClientId != clientId)
            {
                throw new DSException("InvalidClient");
            }

            // Generate new refresh token (token rotation)
            var newRefreshToken = GenerateRefreshToken();

            // Delete old token to avoid accumulating revoked tokens
            await _refreshTokenWriteRepository.DeleteAsync(token.Id, tenantId: null, cancellationToken);

            // Create new refresh token entry
            var newToken = new RefreshTokenEntity
            {
                UserId = token.UserId,
                ClientId = token.ClientId,
                Token = newRefreshToken,
                Jti = Guid.NewGuid().ToString(),
                IdentityProviderCode = token.IdentityProviderCode,
                ExpiresAt = DateTime.UtcNow.AddSeconds(CookieConstants.RefreshTokenExpirationSeconds),
                CreatedByIp = ipAddress,
            };

            await _refreshTokenWriteRepository.InsertAsync(newToken, cancellationToken);

            return new RefreshTokenValidationResult
            {
                UserId = token.UserId,
                ClientId = token.ClientId,
                NewRefreshToken = newRefreshToken,
                IdentityProviderCode = token.IdentityProviderCode
            };
        }

        public async Task RevokeRefreshTokenAsync(
            string refreshToken,
            string? ipAddress = null,
            CancellationToken cancellationToken = default)
        {
            var tokens = await _refreshTokenReadRepository.FilterAsync(
                t => t.Token == refreshToken,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            var token = tokens.FirstOrDefault();
            if (token != null)
            {
                await _refreshTokenWriteRepository.DeleteAsync(token.Id, tenantId: null, cancellationToken);
            }
        }

        public async Task RevokeAllRefreshTokensAsync(
            string userId,
            CancellationToken cancellationToken = default)
        {
            var tokens = await _refreshTokenReadRepository.FilterAsync(
                t => t.UserId == userId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            foreach (var token in tokens)
            {
                await _refreshTokenWriteRepository.DeleteAsync(token.Id, tenantId: null, cancellationToken);
            }
        }

        private JwtSecurityToken CreateJwtToken(
            IEnumerable<Claim> claims,
            string? audience,
            string? issuer,
            DateTime notBefore,
            DateTime expires)
        {
            var key = GetSigningKey();

            var credentials = new SigningCredentials(key, SecurityAlgorithms.RsaSha256);

            return new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: claims,
                notBefore: notBefore,
                expires: expires,
                signingCredentials: credentials);
        }

        private TokenValidationParameters CreateTokenValidationParameters(string? validIssuer, string? validAudience)
        {
            return new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = GetSigningKey(),

                ValidateIssuer = !string.IsNullOrWhiteSpace(validIssuer),
                ValidIssuer = validIssuer,

                ValidateAudience = !string.IsNullOrWhiteSpace(validAudience),
                ValidAudience = validAudience,

                ValidateLifetime = true,
                ClockSkew = TimeSpan.FromSeconds(30)
            };
        }

        private RsaSecurityKey GetSigningKey()
        {
            return _jwtKeyService.GetSigningKey();
        }

        private static string GenerateRefreshToken()
        {
            var bytes = RandomNumberGenerator.GetBytes(64);
            return Convert.ToBase64String(bytes);
        }
    }
}
