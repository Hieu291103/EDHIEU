using DS.Module.Identity.Domain.Constants;

namespace DS.Module.Identity.Infrastructure.Services
{
    /// <summary>
    /// Service hỗ trợ quản lý Permission Module/Feature
    /// Gọn gàng, chỉ Tiếng Việt, không locale
    /// </summary>
    public interface IPermissionHelper
    {
        /// <summary>
        /// Lấy display name của Module
        /// </summary>
        string? GetModuleDisplayName(string moduleCode);

        /// <summary>
        /// Lấy display name của Feature
        /// </summary>
        string? GetFeatureDisplayName(string featureCode);

        /// <summary>
        /// Lấy danh sách features của một module
        /// </summary>
        List<string> GetFeaturesForModule(string clientCode, string moduleCode);

        /// <summary>
        /// Validate permission code format (MODULE:FEATURE:ACTION)
        /// </summary>
        bool ValidatePermissionCodeFormat(string permissionCode);

        /// <summary>
        /// Extract module code từ permission code
        /// Ví dụ: "EVENT:CLASS_SCHEDULE:VIEW" → "EVENT"
        /// </summary>
        string? ExtractModuleCode(string permissionCode);

        /// <summary>
        /// Extract feature code từ permission code
        /// Ví dụ: "EVENT:CLASS_SCHEDULE:VIEW" → "CLASS_SCHEDULE"
        /// </summary>
        string? ExtractFeatureCode(string permissionCode);

        /// <summary>
        /// Extract action từ permission code
        /// Ví dụ: "EVENT:CLASS_SCHEDULE:VIEW" → "VIEW"
        /// </summary>
        string? ExtractAction(string permissionCode);

        /// <summary>
        /// Kiểm tra permission code có hợp lệ cho client
        /// </summary>
        bool IsValidPermissionForClient(string clientCode, string permissionCode);

        /// <summary>
        /// Lấy danh sách modules cho client
        /// </summary>
        List<string> GetModulesForClient(string clientCode);
    }

    /// <summary>
    /// Implementation của IPermissionHelper
    /// </summary>
    public class PermissionHelper : IPermissionHelper
    {
        private const char PERMISSION_CODE_SEPARATOR = ':';

        public string? GetModuleDisplayName(string moduleCode)
        {
            if (string.IsNullOrWhiteSpace(moduleCode))
                return null;

            if (PermissionNames.DigitalSchool.Modules.TryGetValue(moduleCode, out var name))
                return name;

            if (PermissionNames.AdminCRM.Modules.TryGetValue(moduleCode, out var adminName))
                return adminName;

            return null;
        }

        public string? GetFeatureDisplayName(string featureCode)
        {
            if (string.IsNullOrWhiteSpace(featureCode))
                return null;

            if (PermissionNames.DigitalSchool.Features.TryGetValue(featureCode, out var name))
                return name;

            if (PermissionNames.AdminCRM.Features.TryGetValue(featureCode, out var adminName))
                return adminName;

            return null;
        }

        public List<string> GetFeaturesForModule(string clientCode, string moduleCode)
        {
            if (string.IsNullOrWhiteSpace(clientCode) || string.IsNullOrWhiteSpace(moduleCode))
                return new List<string>();

            var structure = clientCode.ToUpper() == "DIGITALSCHOOL"
                ? PermissionNames.DigitalSchool.Structure
                : clientCode.ToUpper() == "ADMINCRM"
                    ? PermissionNames.AdminCRM.Structure
                    : new Dictionary<string, List<string>>();

            return structure.TryGetValue(moduleCode, out var features) ? features : new List<string>();
        }

        public bool ValidatePermissionCodeFormat(string permissionCode)
        {
            if (string.IsNullOrWhiteSpace(permissionCode))
                return false;

            var parts = permissionCode.Split(PERMISSION_CODE_SEPARATOR);

            // Permission code must have exactly 3 parts: MODULE:FEATURE:ACTION
            if (parts.Length != 3)
                return false;

            // Each part must be non-empty
            return parts.All(part => !string.IsNullOrWhiteSpace(part));
        }

        public string? ExtractModuleCode(string permissionCode)
        {
            if (!ValidatePermissionCodeFormat(permissionCode))
                return null;

            var parts = permissionCode.Split(PERMISSION_CODE_SEPARATOR);
            return parts[0];
        }

        public string? ExtractFeatureCode(string permissionCode)
        {
            if (!ValidatePermissionCodeFormat(permissionCode))
                return null;

            var parts = permissionCode.Split(PERMISSION_CODE_SEPARATOR);
            return parts[1];
        }

        public string? ExtractAction(string permissionCode)
        {
            if (!ValidatePermissionCodeFormat(permissionCode))
                return null;

            var parts = permissionCode.Split(PERMISSION_CODE_SEPARATOR);
            return parts[2];
        }

        public bool IsValidPermissionForClient(string clientCode, string permissionCode)
        {
            if (!ValidatePermissionCodeFormat(permissionCode))
                return false;

            var moduleCode = ExtractModuleCode(permissionCode);
            if (string.IsNullOrWhiteSpace(moduleCode))
                return false;

            var structure = clientCode.ToUpper() == "DIGITALSCHOOL"
                ? PermissionNames.DigitalSchool.Structure
                : clientCode.ToUpper() == "ADMINCRM"
                    ? PermissionNames.AdminCRM.Structure
                    : new Dictionary<string, List<string>>();

            // Check if module exists for this client
            return structure.ContainsKey(moduleCode);
        }

        public List<string> GetModulesForClient(string clientCode)
        {
            if (string.IsNullOrWhiteSpace(clientCode))
                return new List<string>();

            var modules = clientCode.ToUpper() == "DIGITALSCHOOL"
                ? PermissionNames.DigitalSchool.Modules
                : clientCode.ToUpper() == "ADMINCRM"
                    ? PermissionNames.AdminCRM.Modules
                    : new Dictionary<string, string>();

            return modules.Keys.ToList();
        }
    }
}
