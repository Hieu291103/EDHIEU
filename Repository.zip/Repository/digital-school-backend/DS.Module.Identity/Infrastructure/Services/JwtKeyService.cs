using DS.Shared.Core.Infrastructure.Configuration;
using DS.Shared.Core.Infrastructure.Exceptions;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.Security.Cryptography;
using System.Text;

namespace DS.Module.Identity.Infrastructure.Services
{
    public interface IJwtKeyService
    {
        RsaSecurityKey GetSigningKey();
        JsonWebKey GetJsonWebKey();
    }

    public sealed class JwtKeyService : IJwtKeyService
    {
        private readonly JwtSettings _settings;
        private readonly Lazy<RsaSecurityKey> _signingKey;
        private readonly Lazy<JsonWebKey> _jsonWebKey;

        public JwtKeyService(IOptions<JwtSettings> options)
        {
            _settings = options.Value;
            _signingKey = new Lazy<RsaSecurityKey>(CreateSigningKey);
            _jsonWebKey = new Lazy<JsonWebKey>(CreateJsonWebKey);
        }

        public RsaSecurityKey GetSigningKey() => _signingKey.Value;

        public JsonWebKey GetJsonWebKey() => _jsonWebKey.Value;

        private RsaSecurityKey CreateSigningKey()
        {
            if (string.IsNullOrWhiteSpace(_settings.PrivateKey))
            {
                throw new DSException("JwtPrivateKeyMissing");
            }

            var pem = Encoding.UTF8.GetString(Convert.FromBase64String(_settings.PrivateKey));
            var rsa = RSA.Create();
            rsa.ImportFromPem(pem);

            return new RsaSecurityKey(rsa)
            {
                KeyId = _settings.KeyId
            };
        }

        private JsonWebKey CreateJsonWebKey()
        {
            var signingKey = GetSigningKey();
            var rsa = signingKey.Rsa;
            if (rsa == null)
            {
                throw new DSException("JwtPrivateKeyInvalid");
            }

            var publicRsa = RSA.Create();
            publicRsa.ImportParameters(rsa.ExportParameters(false));

            var publicKey = new RsaSecurityKey(publicRsa)
            {
                KeyId = signingKey.KeyId
            };

            var jwk = JsonWebKeyConverter.ConvertFromRSASecurityKey(publicKey);
            jwk.Alg = SecurityAlgorithms.RsaSha256;
            jwk.Use = "sig";
            if (!string.IsNullOrWhiteSpace(publicKey.KeyId))
            {
                jwk.Kid = publicKey.KeyId;
            }

            return jwk;
        }
    }
}
