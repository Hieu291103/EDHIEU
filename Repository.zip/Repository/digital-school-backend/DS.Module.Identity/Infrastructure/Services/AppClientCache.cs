using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.Core.Infrastructure.Persistence.Redis;
using Microsoft.Extensions.Caching.Distributed;
using System.Text.Json;

namespace DS.Module.Identity.Infrastructure.Services
{
    public class AppClientCache : IAppClientCache
    {
        private readonly IDistributedCache _cache;
        private readonly IAdminReadRepository<AppClientEntity> _clientRepository;
        private static readonly TimeSpan AppClientCacheDuration = TimeSpan.FromMinutes(60);

        public AppClientCache(
            IDistributedCache cache,
            IAdminReadRepository<AppClientEntity> clientRepository)
        {
            _cache = cache;
            _clientRepository = clientRepository;
        }

        public async Task<AppClientEntity?> GetCachedClientAsync(string clientId, CancellationToken cancellationToken = default)
        {
            var cacheKey = RedisKeys.Cache.OAuthClient(clientId);

            var cachedJson = await _cache.GetStringAsync(cacheKey, cancellationToken);
            if (!string.IsNullOrEmpty(cachedJson))
            {
                return JsonSerializer.Deserialize<AppClientEntity>(cachedJson);
            }

            var clients = await _clientRepository.FilterAsync(
                c => c.ClientId == clientId && c.IsActive,
                tenantId: null,
                includeSoftDeleted: true,
                cancellationToken);

            var client = clients.FirstOrDefault();

            if (client != null)
            {
                var json = JsonSerializer.Serialize(client);
                await _cache.SetStringAsync(
                    cacheKey,
                    json,
                    new DistributedCacheEntryOptions
                    {
                        AbsoluteExpirationRelativeToNow = AppClientCacheDuration
                    },
                    cancellationToken);
            }

            return client;
        }
    }
}
