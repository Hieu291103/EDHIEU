using System.Security.Claims;

namespace DS.Module.Identity.Infrastructure.Services
{
    /// <summary>
    /// Service tạo và validate JWT tokens
    /// </summary>
    public interface ITokenService
    {
        /// <summary>
        /// Tạo access token (JWT)
        /// </summary>
        Task<string> CreateAccessTokenAsync(
            string userId,
            string clientId,
            List<string> scopes,
            int lifetimeSeconds,
            string? identityProviderCode = null,
            Dictionary<string, string>? additionalClaims = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Tạo refresh token
        /// </summary>
        Task<string> CreateRefreshTokenAsync(
            string userId,
            string clientId,
            string jti,
            int lifetimeSeconds,
            string? identityProviderCode = null,
            string? ipAddress = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Validate access token
        /// </summary>
        Task<ClaimsPrincipal?> ValidateAccessTokenAsync(
            string token,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Validate và consume refresh token
        /// </summary>
        Task<RefreshTokenValidationResult?> ValidateAndConsumeRefreshTokenAsync(
            string refreshToken,
            string clientId,
            string? ipAddress = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Revoke refresh token
        /// </summary>
        Task RevokeRefreshTokenAsync(
            string refreshToken,
            string? ipAddress = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Revoke tất cả refresh tokens của user
        /// </summary>
        Task RevokeAllRefreshTokensAsync(
            string userId,
            CancellationToken cancellationToken = default);
    }

    public class RefreshTokenValidationResult
    {
        public required string UserId { get; set; }
        public required string ClientId { get; set; }
        public required string NewRefreshToken { get; set; }
        public string? IdentityProviderCode { get; set; }
    }
}
