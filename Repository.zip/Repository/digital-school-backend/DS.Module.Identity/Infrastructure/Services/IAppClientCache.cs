using DS.Module.Identity.Domain.Entities;

namespace DS.Module.Identity.Infrastructure.Services
{
    public interface IAppClientCache
    {
        Task<AppClientEntity?> GetCachedClientAsync(string clientId, CancellationToken cancellationToken = default);
    }
}
