using DS.Module.Identity.Domain.Entities;

namespace DS.Module.Identity.Infrastructure.Services
{
    /// <summary>
    /// Service quản lý BasicAuth credentials
    /// </summary>
    public interface IBasicAuthCredentialService
    {
        /// <summary>
        /// Validate credentials từ username và password
        /// </summary>
        Task<bool> ValidateCredentialsAsync(string username, string password, CancellationToken cancellationToken = default);

        /// <summary>
        /// Lấy credential theo username
        /// </summary>
        Task<BasicAuthCredentialEntity?> GetCredentialByUsernameAsync(string username, CancellationToken cancellationToken = default);

        /// <summary>
        /// Tạo credential mới
        /// </summary>
        Task<BasicAuthCredentialEntity> CreateCredentialAsync(
            string username,
            string password,
            string? description = null,
            DateTime? expiresAt = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Cập nhật credential
        /// </summary>
        Task<BasicAuthCredentialEntity?> UpdateCredentialAsync(
            string username,
            string? newPassword = null,
            string? description = null,
            bool? isActive = null,
            DateTime? expiresAt = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Xóa credential
        /// </summary>
        Task<bool> DeleteCredentialAsync(string username, CancellationToken cancellationToken = default);

        /// <summary>
        /// Lấy danh sách tất cả credentials (không lấy password hash)
        /// </summary>
        Task<IEnumerable<BasicAuthCredentialEntity>> GetAllCredentialsAsync(CancellationToken cancellationToken = default);
    }
}
