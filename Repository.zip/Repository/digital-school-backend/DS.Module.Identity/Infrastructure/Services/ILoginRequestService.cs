using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Entities;

namespace DS.Module.Identity.Infrastructure.Services
{
    /// <summary>
    /// Service quản lý OAuth2/OIDC login request context
    /// </summary>
    public interface ILoginRequestService
    {
        /// <summary>
        /// Tạo login request mới từ OAuth parameters
        /// Validate client, redirect_uri, scopes
        /// Returns requestId and expiration time
        /// </summary>
        Task<(string RequestId, DateTime ExpiresAt)> CreateAsync(
            string clientId,
            string redirectUri,
            string? responseType = "code",
            string? scope = null,
            string? state = null,
            string? codeChallenge = null,
            string? codeChallengeMethod = null,
            string? nonce = null,
            string? loginHint = null,
            string? identityProvider = null,
            string? prompt = null,
            Dictionary<string, string>? additionalData = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Lấy login request theo RequestId
        /// </summary>
        Task<LoginRequestDto?> GetByRequestIdAsync(string requestId, CancellationToken cancellationToken = default);

        /// <summary>
        /// Cập nhật username đã validate (sau bước CheckUser)
        /// </summary>
        Task UpdateValidatedUsernameAsync(string requestId, string username, CancellationToken cancellationToken = default);

        /// <summary>
        /// Đánh dấu đã authenticate thành công
        /// </summary>
        Task MarkAsAuthenticatedAsync(
            string requestId,
            string userId,
            string? sessionId = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Đánh dấu đã consume (đã dùng để generate auth code)
        /// </summary>
        Task MarkAsConsumedAsync(string requestId, CancellationToken cancellationToken = default);

        /// <summary>
        /// Xóa các request đã hết hạn (không cần cho Redis - auto expire)
        /// </summary>
        Task CleanupExpiredAsync(CancellationToken cancellationToken = default);

        /// <summary>
        /// Tìm user theo username hoặc email
        /// </summary>
        Task<UserEntity?> FindByUsernameOrEmailAsync(string usernameOrEmail, CancellationToken cancellationToken = default);
    }
}
