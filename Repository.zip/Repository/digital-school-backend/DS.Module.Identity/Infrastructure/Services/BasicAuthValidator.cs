using DS.Shared.Core.Presentation.Authentication;

namespace DS.Module.Identity.Infrastructure.Services
{
    /// <summary>
    /// Adapter to expose BasicAuthCredentialService as IBasicAuthValidator for authentication
    /// </summary>
    public class BasicAuthValidator : IBasicAuthValidator
    {
        private readonly IBasicAuthCredentialService _credentialService;

        public BasicAuthValidator(IBasicAuthCredentialService credentialService)
        {
            _credentialService = credentialService;
        }

        public async Task<bool> ValidateAsync(string username, string password, CancellationToken cancellationToken = default)
        {
            return await _credentialService.ValidateCredentialsAsync(username, password, cancellationToken);
        }
    }
}
