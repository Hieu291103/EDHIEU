using DS.Module.Identity.Application.DTOs;

namespace DS.Module.Identity.Infrastructure.Services
{
    /// <summary>
    /// Service quản lý Authorization Code
    /// </summary>
    public interface IAuthorizationCodeService
    {
        /// <summary>
        /// Tạo authorization code mới
        /// </summary>
        Task<string> CreateAsync(
            string userId,
            string clientId,
            string redirectUri,
            List<string> scopes,
            string? codeChallenge = null,
            string? codeChallengeMethod = null,
            string? identityProviderCode = null,
            string? nonce = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Validate và consume authorization code
        /// </summary>
        Task<AuthorizationCodeValidationResult?> ValidateAndConsumeAsync(
            string code,
            string clientId,
            string redirectUri,
            string? codeVerifier = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Xóa authorization code
        /// </summary>
        Task RevokeAsync(string code, CancellationToken cancellationToken = default);

        /// <summary>
        /// Xóa tất cả authorization codes của user
        /// </summary>
        Task RevokeByUserAsync(string userId, CancellationToken cancellationToken = default);
    }

    public class AuthorizationCodeValidationResult
    {
        public required string UserId { get; set; }
        public required string ClientId { get; set; }
        public required List<string> Scopes { get; set; }
        public string? IdentityProviderCode { get; set; }
        public string? Nonce { get; set; }
    }
}
