using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using Microsoft.Extensions.Caching.Distributed;
using MongoDB.Driver;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace DS.Module.Identity.Infrastructure.Services
{
    /// <summary>
    /// Implementation của BasicAuthCredentialService
    /// </summary>
    public class BasicAuthCredentialService : IBasicAuthCredentialService
    {
        private readonly IAdminReadRepository<BasicAuthCredentialEntity> _readRepository;
        private readonly IAdminWriteRepository<BasicAuthCredentialEntity> _writeRepository;
        private readonly IDistributedCache _cache;
        private const string CacheKeyPrefix = "basic_auth:";
        private const int CacheDurationMinutes = 60;

        public BasicAuthCredentialService(
            IAdminReadRepository<BasicAuthCredentialEntity> readRepository,
            IAdminWriteRepository<BasicAuthCredentialEntity> writeRepository,
            IDistributedCache cache)
        {
            _readRepository = readRepository;
            _writeRepository = writeRepository;
            _cache = cache;
        }

        public async Task<bool> ValidateCredentialsAsync(string username, string password, CancellationToken cancellationToken = default)
        {
            var credential = await GetCredentialByUsernameAsync(username, cancellationToken);

            if (credential == null || !credential.IsActive)
                return false;

            // Kiểm tra expiration
            if (credential.ExpiresAt.HasValue && credential.ExpiresAt < DateTime.UtcNow)
                return false;

            return VerifyPassword(password, credential.PasswordHash);
        }

        public async Task<BasicAuthCredentialEntity?> GetCredentialByUsernameAsync(string username, CancellationToken cancellationToken = default)
        {
            var cacheKey = $"{CacheKeyPrefix}{username}";

            // Try get from cache first
            var cachedData = await _cache.GetStringAsync(cacheKey, cancellationToken);
            if (!string.IsNullOrWhiteSpace(cachedData))
            {
                try
                {
                    return JsonSerializer.Deserialize<BasicAuthCredentialEntity>(cachedData);
                }
                catch
                {
                    // Cache data invalid, continue to database
                }
            }

            // Get from MongoDB
            var credentials = await _readRepository.FilterAsync(x => x.Username == username, includeSoftDeleted: false, cancellationToken: cancellationToken);
            var credential = credentials.FirstOrDefault();

            if (credential != null)
            {
                // Cache for future requests
                try
                {
                    var jsonData = JsonSerializer.Serialize(credential);
                    await _cache.SetStringAsync(
                        cacheKey,
                        jsonData,
                        new DistributedCacheEntryOptions
                        {
                            AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(CacheDurationMinutes)
                        },
                        cancellationToken);
                }
                catch
                {
                    // Cache failure, continue without caching
                }
            }

            return credential;
        }

        public async Task<BasicAuthCredentialEntity> CreateCredentialAsync(
            string username,
            string password,
            string? description = null,
            DateTime? expiresAt = null,
            CancellationToken cancellationToken = default)
        {
            var credential = new BasicAuthCredentialEntity
            {
                Username = username,
                PasswordHash = HashPassword(password),
                Description = description,
                ApiKey = Guid.NewGuid().ToString("N"),
                IsActive = true,
                ExpiresAt = expiresAt ?? DateTime.UtcNow.AddYears(1),
            };

            await _writeRepository.InsertAsync(credential, cancellationToken);

            // Clear cache
            await _cache.RemoveAsync($"{CacheKeyPrefix}{username}", cancellationToken);

            return credential;
        }

        public async Task<BasicAuthCredentialEntity?> UpdateCredentialAsync(
            string username,
            string? newPassword = null,
            string? description = null,
            bool? isActive = null,
            DateTime? expiresAt = null,
            CancellationToken cancellationToken = default)
        {
            var credentials = await _readRepository.FilterAsync(x => x.Username == username, includeSoftDeleted: false, cancellationToken: cancellationToken);
            var credential = credentials.FirstOrDefault();

            if (credential == null)
                return null;

            if (!string.IsNullOrWhiteSpace(newPassword))
            {
                credential.PasswordHash = HashPassword(newPassword);
            }

            if (description != null)
            {
                credential.Description = description;
            }

            if (isActive.HasValue)
            {
                credential.IsActive = isActive.Value;
            }

            if (expiresAt.HasValue)
            {
                credential.ExpiresAt = expiresAt.Value;
            }

            await _writeRepository.UpdateAsync(credential, cancellationToken: cancellationToken);

            // Clear cache
            await _cache.RemoveAsync($"{CacheKeyPrefix}{username}", cancellationToken);

            return credential;
        }

        public async Task<bool> DeleteCredentialAsync(string username, CancellationToken cancellationToken = default)
        {
            var credentials = await _readRepository.FilterAsync(x => x.Username == username, includeSoftDeleted: false, cancellationToken: cancellationToken);
            var credential = credentials.FirstOrDefault();

            if (credential == null)
                return false;

            await _writeRepository.SoftDeleteAsync(credential.Id, cancellationToken: cancellationToken);

            // Clear cache
            await _cache.RemoveAsync($"{CacheKeyPrefix}{username}", cancellationToken);

            return true;
        }

        public async Task<IEnumerable<BasicAuthCredentialEntity>> GetAllCredentialsAsync(CancellationToken cancellationToken = default)
        {
            var credentials = await _readRepository.FilterAsync(x => x.IsActive, includeSoftDeleted: false, cancellationToken: cancellationToken);
            return credentials;
        }

        private static string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }

        private static bool VerifyPassword(string password, string hash)
        {
            var hashOfInput = Convert.ToBase64String(
                SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(password)));
            return hashOfInput == hash;
        }
    }
}
