using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using Microsoft.Extensions.Caching.Distributed;
using System.Text.Json;

namespace DS.Module.Identity.Infrastructure.Services
{
    /// <summary>
    /// Service quản lý Identity Provider configuration
    /// - Lấy từ database (trực tiếp query)
    /// - Cache để tránh query nhiều
    /// - Auto-invalidate cache khi config thay đổi
    /// </summary>
    public interface IIdentityProviderService
    {
        /// <summary>
        /// Lấy provider theo code (có cache)
        /// </summary>
        Task<IdentityProviderEntity?> GetProviderByCodeAsync(string code);

        /// <summary>
        /// Lấy danh sách provider được bật (có cache)
        /// </summary>
        Task<List<IdentityProviderEntity>> GetEnabledProvidersAsync();

        /// <summary>
        /// Lấy provider mặc định (có cache)
        /// </summary>
        Task<IdentityProviderEntity?> GetDefaultProviderAsync();

        /// <summary>
        /// Tìm provider theo login hint (domain matching)
        /// </summary>
        Task<IdentityProviderEntity?> FindProviderByLoginHintAsync(string loginHint);

        /// <summary>
        /// Refresh cache (gọi khi config thay đổi)
        /// </summary>
        Task InvalidateCacheAsync();
    }

    /// <summary>
    /// Implementation của IdentityProviderService
    /// Query trực tiếp MongoDB mà không cần Repository layer
    /// </summary>
    public class IdentityProviderService : IIdentityProviderService
    {
        private readonly IAdminReadRepository<IdentityProviderEntity> _repository;
        private readonly IDistributedCache _cache;
        private const string PROVIDERS_CACHE_KEY = "identity:providers";
        private const string PROVIDER_CACHE_KEY = "identity:provider:{0}";
        private const string DEFAULT_PROVIDER_CACHE_KEY = "identity:provider:default";
        private const int CACHE_DURATION_SECONDS = 3600; // 1 hour

        public IdentityProviderService(
            IAdminReadRepository<IdentityProviderEntity> repository,
            IDistributedCache cache)
        {
            _repository = repository;
            _cache = cache;
        }

        /// <summary>
        /// Lấy provider theo code với caching
        /// </summary>
        public async Task<IdentityProviderEntity?> GetProviderByCodeAsync(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
                return null;

            var cacheKey = string.Format(PROVIDER_CACHE_KEY, code.ToLower());

            // Cố gắng lấy từ cache
            var cachedJson = await _cache.GetStringAsync(cacheKey);
            if (!string.IsNullOrEmpty(cachedJson))
            {
                try
                {
                    return JsonSerializer.Deserialize<IdentityProviderEntity>(cachedJson);
                }
                catch { }
            }

            // Query trực tiếp từ MongoDB
            var results = await _repository.FilterAsync(p =>
                p.Code.ToLower() == code.ToLower(),
                includeSoftDeleted: true
            );

            var provider = results.FirstOrDefault();

            // Lưu vào cache nếu tìm thấy
            if (provider != null)
            {
                var json = JsonSerializer.Serialize(provider);
                await _cache.SetStringAsync(cacheKey, json, new DistributedCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(CACHE_DURATION_SECONDS)
                });
            }

            return provider;
        }

        /// <summary>
        /// Lấy danh sách provider được bật với caching
        /// </summary>
        public async Task<List<IdentityProviderEntity>> GetEnabledProvidersAsync()
        {
            // Cố gắng lấy từ cache
            var cachedJson = await _cache.GetStringAsync(PROVIDERS_CACHE_KEY);
            if (!string.IsNullOrEmpty(cachedJson))
            {
                try
                {
                    var cached = JsonSerializer.Deserialize<List<IdentityProviderEntity>>(cachedJson);
                    if (cached != null && cached.Count > 0)
                        return cached;
                }
                catch { }
            }

            // Query trực tiếp từ MongoDB
            var results = await _repository.FilterAsync(p =>
                p.IsEnabled,
                includeSoftDeleted: true
            );

            var providers = results.OrderByDescending(p => p.CreatedAt).ToList();

            // Lưu vào cache
            if (providers.Count > 0)
            {
                var json = JsonSerializer.Serialize(providers);
                await _cache.SetStringAsync(PROVIDERS_CACHE_KEY, json, new DistributedCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(CACHE_DURATION_SECONDS)
                });
            }

            return providers;
        }

        /// <summary>
        /// Lấy provider mặc định
        /// </summary>
        public async Task<IdentityProviderEntity?> GetDefaultProviderAsync()
        {
            // Cố gắng lấy từ cache
            var cachedJson = await _cache.GetStringAsync(DEFAULT_PROVIDER_CACHE_KEY);
            if (!string.IsNullOrEmpty(cachedJson))
            {
                try
                {
                    return JsonSerializer.Deserialize<IdentityProviderEntity>(cachedJson);
                }
                catch { }
            }

            // Query trực tiếp từ MongoDB
            var results = await _repository.FilterAsync(p =>
                p.IsDefault && p.IsEnabled,
                includeSoftDeleted: true
            );

            var provider = results.FirstOrDefault();

            // Lưu vào cache
            if (provider != null)
            {
                var json = JsonSerializer.Serialize(provider);
                await _cache.SetStringAsync(DEFAULT_PROVIDER_CACHE_KEY, json, new DistributedCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(CACHE_DURATION_SECONDS)
                });
            }

            return provider;
        }

        /// <summary>
        /// Tìm provider theo login hint (domain matching)
        /// VD: email = "user@company.com" -> tìm provider có loginHintDomains chứa "company.com"
        /// </summary>
        public async Task<IdentityProviderEntity?> FindProviderByLoginHintAsync(string loginHint)
        {
            if (string.IsNullOrWhiteSpace(loginHint))
                return await GetDefaultProviderAsync();

            // Lấy danh sách enabled providers từ cache
            var providers = await GetEnabledProvidersAsync();

            // Extract domain từ email (nếu là email)
            var domain = ExtractDomain(loginHint);
            if (string.IsNullOrEmpty(domain))
                return await GetDefaultProviderAsync();

            // Tìm provider match với domain
            var provider = providers.FirstOrDefault(p =>
                p.LoginHintDomains != null && p.LoginHintDomains.Count > 0 &&
                p.LoginHintDomains.Any(d => d.Equals(domain, StringComparison.OrdinalIgnoreCase))
            );

            return provider ?? await GetDefaultProviderAsync();
        }

        /// <summary>
        /// Invalidate cache (gọi sau khi update provider)
        /// </summary>
        public async Task InvalidateCacheAsync()
        {
            await _cache.RemoveAsync(PROVIDERS_CACHE_KEY);
            await _cache.RemoveAsync(DEFAULT_PROVIDER_CACHE_KEY);
            // Note: Individual provider caches sẽ expire theo timeout
        }

        /// <summary>
        /// Extract domain từ email hoặc string
        /// "user@company.com" -> "company.com"
        /// "company.com" -> "company.com"
        /// </summary>
        private string? ExtractDomain(string hint)
        {
            if (hint.Contains("@"))
            {
                var parts = hint.Split("@");
                return parts.Length > 1 ? parts[1] : null;
            }
            return hint;
        }
    }
}
