using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using System.Security.Cryptography;
using System.Text;

namespace DS.Module.Identity.Infrastructure.Services
{
    public class AuthorizationCodeService : IAuthorizationCodeService
    {
        private readonly IAdminWriteRepository<AuthorizationCodeEntity> _writeRepository;
        private readonly IAdminReadRepository<AuthorizationCodeEntity> _readRepository;
        private static readonly TimeSpan CodeLifetime = TimeSpan.FromMinutes(5);

        public AuthorizationCodeService(
            IAdminWriteRepository<AuthorizationCodeEntity> writeRepository,
            IAdminReadRepository<AuthorizationCodeEntity> readRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
        }

        public async Task<string> CreateAsync(
            string userId,
            string clientId,
            string redirectUri,
            List<string> scopes,
            string? codeChallenge = null,
            string? codeChallengeMethod = null,
            string? identityProviderCode = null,
            string? nonce = null,
            CancellationToken cancellationToken = default)
        {
            var code = GenerateAuthorizationCode();
            var expiresAt = DateTime.UtcNow.Add(CodeLifetime);

            var authCode = new AuthorizationCodeEntity
            {
                Code = code,
                UserId = userId,
                ClientId = clientId,
                RedirectUri = redirectUri,
                Scopes = scopes,
                CodeChallenge = codeChallenge,
                CodeChallengeMethod = codeChallengeMethod,
                IdentityProviderCode = identityProviderCode,
                ExpiresAt = expiresAt,
                IsUsed = false
            };

            await _writeRepository.InsertAsync(authCode, cancellationToken);

            return code;
        }

        public async Task<AuthorizationCodeValidationResult?> ValidateAndConsumeAsync(
            string code,
            string clientId,
            string redirectUri,
            string? codeVerifier = null,
            CancellationToken cancellationToken = default)
        {
            var authCodes = await _readRepository.FilterAsync(
                c => c.Code == code,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            var authCode = authCodes.FirstOrDefault();

            if (authCode == null)
            {
                throw new DSException("InvalidAuthorizationCode");
            }

            // Check if expired
            if (authCode.ExpiresAt < DateTime.UtcNow)
            {
                throw new DSException("AuthorizationCodeExpired");
            }

            // Check if already used
            if (authCode.IsUsed)
            {
                throw new DSException("AuthorizationCodeAlreadyUsed");
            }

            // Validate client
            if (authCode.ClientId != clientId)
            {
                throw new DSException("InvalidClient");
            }

            // Validate redirect URI
            if (authCode.RedirectUri != redirectUri)
            {
                throw DSException.WithParam("InvalidRedirectUri", redirectUri);
            }

            // Validate PKCE
            if (!string.IsNullOrEmpty(authCode.CodeChallenge))
            {
                if (string.IsNullOrEmpty(codeVerifier))
                {
                    throw new DSException("CodeVerifierRequired");
                }

                var isValid = ValidatePkce(codeVerifier, authCode.CodeChallenge, authCode.CodeChallengeMethod);
                if (!isValid)
                {
                    throw new DSException("InvalidCodeVerifier");
                }
            }

            // Mark as used
            authCode.IsUsed = true;
            authCode.UsedAt = DateTime.UtcNow;
            await _writeRepository.UpdateAsync(authCode, tenantId: null, cancellationToken);

            return new AuthorizationCodeValidationResult
            {
                UserId = authCode.UserId,
                ClientId = authCode.ClientId,
                Scopes = authCode.Scopes,
                IdentityProviderCode = authCode.IdentityProviderCode,
                Nonce = null // Nonce should be stored separately if needed
            };
        }

        public async Task RevokeAsync(string code, CancellationToken cancellationToken = default)
        {
            var authCodes = await _readRepository.FilterAsync(
                c => c.Code == code,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            var authCode = authCodes.FirstOrDefault();
            if (authCode != null)
            {
                await _writeRepository.DeleteAsync(authCode.Id, tenantId: null, cancellationToken);
            }
        }

        public async Task RevokeByUserAsync(string userId, CancellationToken cancellationToken = default)
        {
            var authCodes = await _readRepository.FilterAsync(
                c => c.UserId == userId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            foreach (var authCode in authCodes)
            {
                await _writeRepository.DeleteAsync(authCode.Id, tenantId: null, cancellationToken);
            }
        }

        private static string GenerateAuthorizationCode()
        {
            var bytes = RandomNumberGenerator.GetBytes(32);
            return Convert.ToBase64String(bytes)
                .Replace("+", "-")
                .Replace("/", "_")
                .Replace("=", "");
        }

        private static bool ValidatePkce(string codeVerifier, string codeChallenge, string? codeChallengeMethod)
        {
            if (codeChallengeMethod == "plain")
            {
                return codeVerifier == codeChallenge;
            }

            // S256
            using var sha256 = SHA256.Create();
            var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(codeVerifier));
            var computedChallenge = Convert.ToBase64String(hash)
                .Replace("+", "-")
                .Replace("/", "_")
                .Replace("=", "");

            return computedChallenge == codeChallenge;
        }
    }
}
