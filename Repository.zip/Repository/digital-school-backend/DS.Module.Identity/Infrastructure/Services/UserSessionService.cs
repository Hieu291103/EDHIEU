using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using System.Security.Cryptography;

namespace DS.Module.Identity.Infrastructure.Services
{
    public class UserSessionService : IUserSessionService
    {
        private readonly IAdminWriteRepository<UserSessionEntity> _writeRepository;
        private readonly IAdminReadRepository<UserSessionEntity> _readRepository;

        public UserSessionService(
            IAdminWriteRepository<UserSessionEntity> writeRepository,
            IAdminReadRepository<UserSessionEntity> readRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
        }

        public async Task<string> CreateOrUpdateSessionAsync(
            string userId,
            string? identityProviderCode = null,
            string? deviceInfo = null,
            string? ipAddress = null,
            string? userAgent = null,
            int lifetimeSeconds = 1800,
            CancellationToken cancellationToken = default)
        {
            // Check if user already has an active session
            var existingSessions = await _readRepository.FilterAsync(
                s => s.UserId == userId && s.IsActive && s.ExpiresAt > DateTime.UtcNow,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            var existingSession = existingSessions.FirstOrDefault();

            if (existingSession != null)
            {
                // Update existing session
                existingSession.LastAccessedAt = DateTime.UtcNow;
                existingSession.ExpiresAt = DateTime.UtcNow.AddSeconds(lifetimeSeconds);
                existingSession.IpAddress = ipAddress;
                existingSession.UserAgent = userAgent;

                await _writeRepository.UpdateAsync(existingSession, tenantId: null, cancellationToken);
                return existingSession.SessionKey;
            }

            // Create new session
            var sessionKey = GenerateSessionKey();
            var session = new UserSessionEntity
            {
                UserId = userId,
                SessionKey = sessionKey,
                IdentityProviderCode = identityProviderCode,
                DeviceInfo = deviceInfo,
                IpAddress = ipAddress,
                UserAgent = userAgent,
                LastAccessedAt = DateTime.UtcNow,
                ExpiresAt = DateTime.UtcNow.AddSeconds(lifetimeSeconds),
                IsActive = true
            };

            await _writeRepository.InsertAsync(session, cancellationToken);
            return sessionKey;
        }

        public async Task<UserSessionEntity?> GetSessionAsync(
            string sessionKey,
            CancellationToken cancellationToken = default)
        {
            var sessions = await _readRepository.FilterAsync(
                s => s.SessionKey == sessionKey && s.IsActive && s.ExpiresAt > DateTime.UtcNow,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            return sessions.FirstOrDefault();
        }

        public async Task UpdateLastAccessedAsync(
            string sessionKey,
            CancellationToken cancellationToken = default)
        {
            var session = await GetSessionAsync(sessionKey, cancellationToken);
            if (session != null)
            {
                session.LastAccessedAt = DateTime.UtcNow;
                await _writeRepository.UpdateAsync(session, tenantId: null, cancellationToken);
            }
        }

        public async Task RevokeSessionAsync(
            string sessionKey,
            CancellationToken cancellationToken = default)
        {
            var sessions = await _readRepository.FilterAsync(
                s => s.SessionKey == sessionKey,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            var session = sessions.FirstOrDefault();
            if (session != null)
            {
                session.IsActive = false;
                await _writeRepository.UpdateAsync(session, tenantId: null, cancellationToken);
            }
        }

        public async Task RevokeAllSessionsAsync(
            string userId,
            CancellationToken cancellationToken = default)
        {
            var sessions = await _readRepository.FilterAsync(
                s => s.UserId == userId && s.IsActive,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            foreach (var session in sessions)
            {
                session.IsActive = false;
                await _writeRepository.UpdateAsync(session, tenantId: null, cancellationToken);
            }
        }

        public async Task<string?> GetUserIdFromSessionAsync(
            string sessionKey,
            CancellationToken cancellationToken = default)
        {
            var session = await GetSessionAsync(sessionKey, cancellationToken);
            return session?.UserId;
        }

        private static string GenerateSessionKey()
        {
            var bytes = RandomNumberGenerator.GetBytes(32);
            return Convert.ToBase64String(bytes)
                .Replace("+", "-")
                .Replace("/", "_")
                .Replace("=", "");
        }
    }
}
