using DS.Shared.Core.Application.Abstractions.Localization;

namespace DS.Module.Identity.Infrastructure.Localization
{
    /// <summary>
    /// Localization provider cho Identity module
    /// Priority = 100 để override Core messages
    /// </summary>
    public class IdentityLocalizationProvider : ILocalizationProvider
    {
        public int Priority => 100;

        private static readonly Dictionary<string, Dictionary<string, string>> Messages = new()
        {
            ["vi"] = new Dictionary<string, string>
            {
                // User management errors
                ["UserNotFound"] = "Không tìm thấy người dùng",
                ["UserAlreadyExists"] = "Người dùng đã tồn tại",
                ["UsernameAlreadyExists"] = "Tên đăng nhập '{0}' đã tồn tại",
                ["EmailAlreadyExists"] = "Email '{0}' đã tồn tại",

                // Authentication errors
                ["InvalidCredentials"] = "Tên đăng nhập hoặc mật khẩu không đúng",
                ["InvalidUsername"] = "Tên đăng nhập không tồn tại",
                ["InvalidPassword"] = "Mật khẩu không đúng",
                ["AccountLocked"] = "Tài khoản đã bị khóa. Vui lòng thử lại sau",
                ["TooManyFailedAttempts"] = "Nhập sai mật khẩu nhiều lần. Tài khoản sẽ bị khóa sau {0} lần nữa",
                ["AccountLockedDuration"] = "Tài khoản bị khóa trong {0} phút. Vui lòng thử lại sau",
                ["EmailNotVerified"] = "Email chưa được xác thực",

                // Password errors
                ["PasswordRequired"] = "Mật khẩu là bắt buộc",
                ["WeakPassword"] = "Mật khẩu không đủ mạnh: {0}",
                ["PasswordTooShort"] = "Mật khẩu phải có ít nhất {0} ký tự",
                ["PasswordRequiresUppercase"] = "Mật khẩu phải có ít nhất một chữ hoa",
                ["PasswordRequiresLowercase"] = "Mật khẩu phải có ít nhất một chữ thường",
                ["PasswordRequiresDigit"] = "Mật khẩu phải có ít nhất một chữ số",
                ["PasswordRequiresSpecialChar"] = "Mật khẩu nên có ít nhất một ký tự đặc biệt",

                // OAuth/Token errors
                ["InvalidToken"] = "Token không hợp lệ",
                ["ExpiredToken"] = "Token đã hết hạn",
                ["RevokedToken"] = "Token đã bị thu hồi",
                ["InvalidAccessToken"] = "Access token không hợp lệ",
                ["InvalidRefreshToken"] = "Refresh token không hợp lệ",
                ["RefreshTokenExpired"] = "Refresh token đã hết hạn",
                ["RefreshTokenRevoked"] = "Refresh token đã bị thu hồi",
                ["InvalidAuthorizationCode"] = "Authorization code không hợp lệ",
                ["AuthorizationCodeExpired"] = "Authorization code đã hết hạn",
                ["AuthorizationCodeAlreadyUsed"] = "Authorization code đã được sử dụng",
                ["CodeVerifierRequired"] = "Code verifier là bắt buộc",
                ["InvalidCodeVerifier"] = "Code verifier không hợp lệ",

                // Client errors
                ["ClientNotFound"] = "Không tìm thấy ứng dụng client",
                ["ClientInactive"] = "Ứng dụng client không hoạt động",
                ["InvalidClient"] = "Client không hợp lệ",
                ["ClientSecretRequired"] = "Client secret là bắt buộc",
                ["InvalidClientSecret"] = "Client secret không đúng",
                ["InvalidRedirectUri"] = "Redirect URI '{0}' không được phép cho client '{1}'",
                ["InvalidScope"] = "Scope không hợp lệ: {0}",
                ["PkceRequired"] = "PKCE code_challenge là bắt buộc cho client này",
                ["PlainTextPkceNotAllowed"] = "PKCE dạng plain text không được phép cho client này",
                ["InvalidLoginRequest"] = "Yêu cầu đăng nhập không hợp lệ hoặc đã hết hạn",
                ["InvalidRequest"] = "Yêu cầu không hợp lệ",
                ["UnsupportedGrantType"] = "Grant type không được hỗ trợ",

                // Permission management errors
                ["PermissionNotFound"] = "Không tìm thấy quyền",
                ["PermissionCodeAlreadyExists"] = "Mã quyền '{0}' đã tồn tại cho ứng dụng này",

                // Role management errors
                ["RoleNotFound"] = "Không tìm thấy vai trò",
                ["RoleNameAlreadyExists"] = "Tên vai trò '{0}' đã tồn tại cho ứng dụng này",
                ["CannotModifySystemRole"] = "Không thể chỉnh sửa vai trò hệ thống",
                ["CannotDeleteSystemRole"] = "Không thể xóa vai trò hệ thống",
                ["PermissionCodesCannotBeEmpty"] = "Mã quyền không được trống",
                ["InvalidTenantIdFormat"] = "ID Tenant không hợp lệ",
            },
            ["en"] = new Dictionary<string, string>
            {
                // User management errors
                ["UserNotFound"] = "User not found",
                ["UserAlreadyExists"] = "User already exists",
                ["UsernameAlreadyExists"] = "Username '{0}' already exists",
                ["EmailAlreadyExists"] = "Email '{0}' already exists",

                // Authentication errors
                ["InvalidCredentials"] = "Invalid username or password",
                ["InvalidUsername"] = "Username does not exist",
                ["InvalidPassword"] = "Invalid password",
                ["AccountLocked"] = "Account is locked. Please try again later",
                ["TooManyFailedAttempts"] = "Too many failed attempts. Account will be locked after {0} more attempts",
                ["AccountLockedDuration"] = "Account is locked for {0} minutes. Please try again later",
                ["EmailNotVerified"] = "Email has not been verified",

                // Password errors
                ["PasswordRequired"] = "Password is required",
                ["WeakPassword"] = "Password is not strong enough: {0}",
                ["PasswordTooShort"] = "Password must be at least {0} characters",
                ["PasswordRequiresUppercase"] = "Password must contain at least one uppercase letter",
                ["PasswordRequiresLowercase"] = "Password must contain at least one lowercase letter",
                ["PasswordRequiresDigit"] = "Password must contain at least one digit",
                ["PasswordRequiresSpecialChar"] = "Password should contain at least one special character",

                // OAuth/Token errors
                ["InvalidToken"] = "Invalid token",
                ["ExpiredToken"] = "Token has expired",
                ["RevokedToken"] = "Token has been revoked",
                ["InvalidAccessToken"] = "Invalid access token",
                ["InvalidRefreshToken"] = "Invalid refresh token",
                ["RefreshTokenExpired"] = "Refresh token has expired",
                ["RefreshTokenRevoked"] = "Refresh token has been revoked",
                ["InvalidAuthorizationCode"] = "Invalid authorization code",
                ["AuthorizationCodeExpired"] = "Authorization code has expired",
                ["AuthorizationCodeAlreadyUsed"] = "Authorization code has already been used",
                ["CodeVerifierRequired"] = "Code verifier is required",
                ["InvalidCodeVerifier"] = "Invalid code verifier",

                // Client errors
                ["ClientNotFound"] = "Client application not found",
                ["ClientInactive"] = "Client application is inactive",
                ["InvalidClient"] = "Invalid client",
                ["ClientSecretRequired"] = "Client secret is required",
                ["InvalidClientSecret"] = "Invalid client secret",
                ["InvalidRedirectUri"] = "Redirect URI '{0}' is not allowed for client '{1}'",
                ["InvalidScope"] = "Invalid scopes: {0}",
                ["PkceRequired"] = "PKCE code_challenge is required for this client",
                ["PlainTextPkceNotAllowed"] = "Plain text PKCE is not allowed for this client",
                ["InvalidLoginRequest"] = "Invalid or expired login request",
                ["InvalidRequest"] = "Invalid request",
                ["UnsupportedGrantType"] = "Unsupported grant type",



                // Permission management errors
                ["PermissionNotFound"] = "Permission not found",
                ["PermissionCodeAlreadyExists"] = "Permission code '{0}' already exists for this application",

                // Role management errors
                ["RoleNotFound"] = "Role not found",
                ["RoleNameAlreadyExists"] = "Role name '{0}' already exists for this application",
                ["CannotModifySystemRole"] = "Cannot modify system role",
                ["CannotDeleteSystemRole"] = "Cannot delete system role",
                ["PermissionCodesCannotBeEmpty"] = "Permission codes cannot be empty",
                ["InvalidTenantIdFormat"] = "Invalid Tenant ID format"
            }
        };

        private static readonly Dictionary<string, Dictionary<string, string>> PropertyNames = new()
        {
            ["vi"] = new Dictionary<string, string>
            {
                // User properties
                ["Email"] = "Email",
                ["Password"] = "Mật khẩu",
                ["Username"] = "Tên đăng nhập",
                ["FullName"] = "Họ và tên",
                ["PhoneNumber"] = "Số điện thoại",
                ["DateOfBirth"] = "Ngày sinh",
                ["CurrentPassword"] = "Mật khẩu hiện tại",
                ["NewPassword"] = "Mật khẩu mới",
                ["UserId"] = "ID người dùng",
                ["AvatarUrl"] = "Ảnh đại diện",
            },
            ["en"] = new Dictionary<string, string>
            {
                // User properties
                ["Email"] = "Email",
                ["Password"] = "Password",
                ["Username"] = "Username",
                ["FullName"] = "Full name",
                ["PhoneNumber"] = "Phone number",
                ["DateOfBirth"] = "Date of birth",
                ["CurrentPassword"] = "Current password",
                ["NewPassword"] = "New password",
                ["UserId"] = "User ID",
                ["AvatarUrl"] = "Avatar URL",
            }
        };

        public string? GetMessage(string key, string languageCode)
        {
            return Messages.GetValueOrDefault(languageCode)?.GetValueOrDefault(key);
        }

        public string? GetPropertyName(string propertyName, string languageCode)
        {
            return PropertyNames.GetValueOrDefault(languageCode)?.GetValueOrDefault(propertyName);
        }

        public string? GetValidationMessage(string errorCode, string languageCode)
        {
            // Identity module không override validation messages
            // Sử dụng default từ Core
            return null;
        }
    }
}
