using DS.Module.Identity.Infrastructure.Indexing;
using DS.Module.Identity.Infrastructure.Localization;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Infrastructure.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Context;
using DS.Shared.Core.Presentation.Authentication;
using Microsoft.Extensions.DependencyInjection;

namespace DS.Module.Identity.Infrastructure.Extensions
{
    /// <summary>
    /// Extension methods để đăng ký Identity module services
    /// Tất cả dependencies của module được đăng ký tập trung ở đây
    /// </summary>
    public static class IdentityServiceCollectionExtensions
    {
        /// <summary>
        /// Đăng ký Identity module services bao gồm localization và application services
        /// </summary>
        public static IServiceCollection AddIdentityModule(this IServiceCollection services)
        {
            // 1. Localization Provider
            services.AddLocalizationProvider<IdentityLocalizationProvider>();
            services.AddMongoIndexRegistry<IdentityIndexRegistry>();

            // 2. Application Services (non-CQRS)
            services.AddScoped<ILoginRequestService, LoginRequestService>();
            services.AddScoped<IAppClientCache, AppClientCache>();
            services.AddScoped<IAuthorizationCodeService, AuthorizationCodeService>();
            services.AddSingleton<IJwtKeyService, JwtKeyService>();
            services.AddScoped<ITokenService, TokenService>();
            services.AddScoped<IUserSessionService, UserSessionService>();

            // 3. Permission Helper Service
            services.AddScoped<IPermissionHelper, PermissionHelper>();

            // 4. Identity Provider Service (query trực tiếp MongoDB, không cần Repository layer)
            services.AddScoped<IIdentityProviderService, IdentityProviderService>();

            // 5. BasicAuth Credential Service
            services.AddScoped<IBasicAuthCredentialService, BasicAuthCredentialService>();
            services.AddScoped<IBasicAuthValidator, BasicAuthValidator>();

            return services;
        }

        /// <summary>
        /// Khởi tạo MongoDB indexes cho Identity module
        /// Gọi từ Program.cs sau khi build WebApplication
        /// Sử dụng context helper method GetCollectionForEntity<T>() để lấy collection
        /// </summary>
        public static async Task InitializeIdentityIndexesAsync(this IServiceProvider serviceProvider)
        {
            await serviceProvider.InitializeMongoIndexesAsync<IAdminMongoDbContext>();
        }
    }
}
