using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Context;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Indexing;
using MongoDB.Driver;

namespace DS.Module.Identity.Infrastructure.Indexing
{
    public class IdentityIndexRegistry : BaseIndexRegistry<IAdminMongoDbContext>
    {
        protected override void ConfigureIndexes()
        {
            Register(
                new CreateIndexModel<UserEntity>(
                    Builders<UserEntity>.IndexKeys.Ascending(u => u.Username),
                    new CreateIndexOptions { Unique = true, Name = "Username_Unique" }),
                new CreateIndexModel<UserEntity>(
                    Builders<UserEntity>.IndexKeys.Ascending(u => u.Email),
                    new CreateIndexOptions { Name = "Email" }),
                new CreateIndexModel<UserEntity>(
                    Builders<UserEntity>.IndexKeys.Ascending(u => u.IsDeleted),
                    new CreateIndexOptions { Name = "IsDeleted_1" }),
                new CreateIndexModel<UserEntity>(
                    Builders<UserEntity>.IndexKeys.Combine(
                        Builders<UserEntity>.IndexKeys.Ascending(u => u.Username),
                        Builders<UserEntity>.IndexKeys.Ascending(u => u.IsDeleted)),
                    new CreateIndexOptions { Name = "Username_IsDeleted_1" }),
                new CreateIndexModel<UserEntity>(
                    Builders<UserEntity>.IndexKeys.Combine(
                        Builders<UserEntity>.IndexKeys.Ascending(u => u.Email),
                        Builders<UserEntity>.IndexKeys.Ascending(u => u.IsDeleted)),
                    new CreateIndexOptions { Name = "Email_IsDeleted_1" }),
                new CreateIndexModel<UserEntity>(
                    Builders<UserEntity>.IndexKeys.Descending(u => u.LastLoginAt),
                    new CreateIndexOptions { Name = "LastLoginAt_Desc" }),
                new CreateIndexModel<UserEntity>(
                    Builders<UserEntity>.IndexKeys.Ascending(u => u.LockoutEnd),
                    new CreateIndexOptions { Name = "LockoutEnd_1" }));

            Register(
                new CreateIndexModel<UserSessionEntity>(
                    Builders<UserSessionEntity>.IndexKeys.Ascending(u => u.SessionKey),
                    new CreateIndexOptions { Unique = true, Name = "SessionKey_Unique" }),
                new CreateIndexModel<UserSessionEntity>(
                    Builders<UserSessionEntity>.IndexKeys.Ascending(u => u.UserId),
                    new CreateIndexOptions { Name = "UserId_1" }),
                new CreateIndexModel<UserSessionEntity>(
                    Builders<UserSessionEntity>.IndexKeys.Ascending(u => u.CreatedAt),
                    new CreateIndexOptions
                    {
                        ExpireAfter = TimeSpan.FromDays(240),
                        Name = "CreatedAt_TTL_240d"
                    }),
                new CreateIndexModel<UserSessionEntity>(
                    Builders<UserSessionEntity>.IndexKeys.Combine(
                        Builders<UserSessionEntity>.IndexKeys.Ascending(u => u.UserId),
                        Builders<UserSessionEntity>.IndexKeys.Ascending(u => u.IsActive)),
                    new CreateIndexOptions { Name = "UserId_IsActive_1" }),
                new CreateIndexModel<UserSessionEntity>(
                    Builders<UserSessionEntity>.IndexKeys.Ascending(u => u.IsActive),
                    new CreateIndexOptions { Name = "IsActive_1" }));

            Register(
                new CreateIndexModel<AuthorizationCodeEntity>(
                    Builders<AuthorizationCodeEntity>.IndexKeys.Ascending(a => a.Code),
                    new CreateIndexOptions { Unique = true, Name = "Code_Unique" }),
                new CreateIndexModel<AuthorizationCodeEntity>(
                    Builders<AuthorizationCodeEntity>.IndexKeys.Ascending(a => a.UserId),
                    new CreateIndexOptions { Name = "UserId_1" }),
                new CreateIndexModel<AuthorizationCodeEntity>(
                    Builders<AuthorizationCodeEntity>.IndexKeys.Ascending(a => a.CreatedAt),
                    new CreateIndexOptions
                    {
                        ExpireAfter = TimeSpan.FromMinutes(5),
                        Name = "CreatedAt_TTL_5m"
                    }),
                new CreateIndexModel<AuthorizationCodeEntity>(
                    Builders<AuthorizationCodeEntity>.IndexKeys.Combine(
                        Builders<AuthorizationCodeEntity>.IndexKeys.Ascending(a => a.UserId),
                        Builders<AuthorizationCodeEntity>.IndexKeys.Ascending(a => a.ClientId)),
                    new CreateIndexOptions { Name = "UserId_ClientId_1" }));

            Register(
                new CreateIndexModel<AppClientEntity>(
                    Builders<AppClientEntity>.IndexKeys.Ascending(a => a.ClientId),
                    new CreateIndexOptions { Unique = true, Name = "ClientId_Unique" }),
                new CreateIndexModel<AppClientEntity>(
                    Builders<AppClientEntity>.IndexKeys.Ascending(a => a.IsActive),
                    new CreateIndexOptions { Name = "IsActive_1" }),
                new CreateIndexModel<AppClientEntity>(
                    Builders<AppClientEntity>.IndexKeys.Combine(
                        Builders<AppClientEntity>.IndexKeys.Ascending(a => a.ClientId),
                        Builders<AppClientEntity>.IndexKeys.Ascending(a => a.IsActive)),
                    new CreateIndexOptions { Name = "ClientId_IsActive_1" }));

            Register(
                new CreateIndexModel<RefreshTokenEntity>(
                    Builders<RefreshTokenEntity>.IndexKeys.Ascending(r => r.Token),
                    new CreateIndexOptions { Unique = true, Name = "Token_Unique" }),
                new CreateIndexModel<RefreshTokenEntity>(
                    Builders<RefreshTokenEntity>.IndexKeys.Ascending(r => r.UserId),
                    new CreateIndexOptions { Name = "UserId_1" }),
                new CreateIndexModel<RefreshTokenEntity>(
                    Builders<RefreshTokenEntity>.IndexKeys.Ascending(r => r.CreatedAt),
                    new CreateIndexOptions
                    {
                        ExpireAfter = TimeSpan.FromDays(30),
                        Name = "CreatedAt_TTL_30d"
                    }),
                new CreateIndexModel<RefreshTokenEntity>(
                    Builders<RefreshTokenEntity>.IndexKeys.Combine(
                        Builders<RefreshTokenEntity>.IndexKeys.Ascending(r => r.UserId),
                        Builders<RefreshTokenEntity>.IndexKeys.Ascending(r => r.ClientId)),
                    new CreateIndexOptions { Name = "UserId_ClientId_1" }));

            Register(
                new CreateIndexModel<PermissionEntity>(
                    Builders<PermissionEntity>.IndexKeys.Ascending(p => p.ClientId),
                    new CreateIndexOptions { Name = "ClientId_1" }),
                new CreateIndexModel<PermissionEntity>(
                    Builders<PermissionEntity>.IndexKeys.Combine(
                        Builders<PermissionEntity>.IndexKeys.Ascending(p => p.ClientId),
                        Builders<PermissionEntity>.IndexKeys.Ascending(p => p.Module)),
                    new CreateIndexOptions { Name = "ClientId_Module_1" }),
                new CreateIndexModel<PermissionEntity>(
                    Builders<PermissionEntity>.IndexKeys.Combine(
                        Builders<PermissionEntity>.IndexKeys.Ascending(p => p.ClientId),
                        Builders<PermissionEntity>.IndexKeys.Ascending(p => p.Feature)),
                    new CreateIndexOptions { Name = "ClientId_Feature_1" }),
                new CreateIndexModel<PermissionEntity>(
                    Builders<PermissionEntity>.IndexKeys.Combine(
                        Builders<PermissionEntity>.IndexKeys.Ascending(p => p.ClientId),
                        Builders<PermissionEntity>.IndexKeys.Ascending(p => p.Code)),
                    new CreateIndexOptions { Unique = true, Name = "ClientId_Code_Unique" }));
        }
    }
}
