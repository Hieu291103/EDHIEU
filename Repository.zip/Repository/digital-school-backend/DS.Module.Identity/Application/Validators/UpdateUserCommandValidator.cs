using FluentValidation;
using System.Text.RegularExpressions;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Validator cho UpdateUserCommand
    /// </summary>
    public class UpdateUserCommandValidator : AbstractValidator<UpdateUserCommand>
    {
        public UpdateUserCommandValidator()
        {
            RuleFor(x => x.UserId)
                .NotEmpty();

            // Username: email hoặc alphanumeric với underscore
            RuleFor(x => x.Username)
                .MinimumLength(3)
                .MaximumLength(100)
                .Matches(@"^([a-zA-Z0-9_]+|[^\s@]+@[^\s@]+\.[^\s@]+)$", RegexOptions.IgnoreCase)
                .When(x => !string.IsNullOrEmpty(x.Username));

            RuleFor(x => x.Email)
                .EmailAddress()
                .MaximumLength(100)
                .When(x => !string.IsNullOrEmpty(x.Email));

            RuleFor(x => x.FullName)
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.FullName));

            RuleFor(x => x.Title)
                .MaximumLength(255)
                .When(x => !string.IsNullOrEmpty(x.Title));

            RuleFor(x => x.DateOfBirth)
                .LessThanOrEqualTo(DateTime.UtcNow.Date)
                .When(x => x.DateOfBirth.HasValue);

            // PhoneNumber: số Việt Nam (0xxxxxxxxx) hoặc quốc tế (+xxxxxxxxx)
            RuleFor(x => x.PhoneNumber)
                .Matches(@"^(0[0-9]{9}|\+[1-9]\d{1,14})$")
                .When(x => !string.IsNullOrEmpty(x.PhoneNumber));

            RuleFor(x => x.LoginHint)
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.LoginHint));
        }
    }
}
