using FluentValidation;

namespace DS.Module.Identity.Application.Commands.Roles
{
    /// <summary>
    /// Validator cho CreateRoleCommand
    /// </summary>
    public class CreateRoleCommandValidator : AbstractValidator<CreateRoleCommand>
    {
        public CreateRoleCommandValidator()
        {
            RuleFor(x => x.ClientId)
                .NotEmpty()
                .Length(36); // UUID format

            RuleFor(x => x.Name)
                .NotEmpty()
                .MinimumLength(2)
                .MaximumLength(200);

            RuleFor(x => x.Description)
                .MaximumLength(500)
                .When(x => !string.IsNullOrEmpty(x.Description));

            RuleFor(x => x.PermissionCodes)
                .NotNull()
                .Must(codes => codes != null && codes.All(c => !string.IsNullOrEmpty(c)))
                .WithMessage("PermissionCodesCannotBeEmpty");

            // TenantId validation - ObjectId format (24 hex characters)
            RuleFor(x => x.TenantId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTenantIdFormat")
                .When(x => !string.IsNullOrEmpty(x.TenantId));
        }
    }
}
