using FluentValidation;

namespace DS.Module.Identity.Application.Commands.Roles
{
    /// <summary>
    /// Validator cho DeleteRoleCommand
    /// </summary>
    public class DeleteRoleCommandValidator : AbstractValidator<DeleteRoleCommand>
    {
        public DeleteRoleCommandValidator()
        {
            RuleFor(x => x.RoleId)
                .NotEmpty();

            // TenantId validation - ObjectId format (24 hex characters)
            RuleFor(x => x.TenantId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTenantIdFormat")
                .When(x => !string.IsNullOrEmpty(x.TenantId));
        }
    }
}
