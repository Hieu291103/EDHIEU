using FluentValidation;
using System.Text.RegularExpressions;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Validator cho CreateUserCommand
    /// - Default validators: Sử dụng messages từ DefaultValidationMessageLocalization
    /// - Custom validators: Sử dụng error codes từ IdentityLocalizationProvider
    /// </summary>
    public class CreateUserCommandValidator : AbstractValidator<CreateUserCommand>
    {
        public CreateUserCommandValidator()
        {
            // Username: email hoặc alphanumeric với underscore
            RuleFor(x => x.Username)
                .NotEmpty()
                .MinimumLength(3)
                .MaximumLength(100)
                .Matches(@"^([a-zA-Z0-9_]+|[^\s@]+@[^\s@]+\.[^\s@]+)$", RegexOptions.IgnoreCase);

            RuleFor(x => x.Email)
                .NotEmpty()
                .EmailAddress()
                .MaximumLength(100);

            // Password validation với custom error codes
            RuleFor(x => x.Password)
                .NotEmpty()
                .MinimumLength(6);
            //.Matches("[A-Z]").WithMessage("PasswordRequiresUppercase")
            //.Matches("[a-z]").WithMessage("PasswordRequiresLowercase")
            //.Matches("[0-9]").WithMessage("PasswordRequiresDigit");

            RuleFor(x => x.FullName)
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.FullName));

            RuleFor(x => x.Title)
                .MaximumLength(255)
                .When(x => !string.IsNullOrEmpty(x.Title));

            RuleFor(x => x.DateOfBirth)
                .LessThanOrEqualTo(DateTime.UtcNow.Date)
                .When(x => x.DateOfBirth.HasValue);

            // PhoneNumber: số Việt Nam (0xxxxxxxxx) hoặc quốc tế (+xxxxxxxxx)
            RuleFor(x => x.PhoneNumber)
                .Matches(@"^(0[0-9]{9}|\+[1-9]\d{1,14})$")
                .When(x => !string.IsNullOrEmpty(x.PhoneNumber));

            RuleFor(x => x.LoginHint)
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.LoginHint));
        }
    }
}
