using FluentValidation;

namespace DS.Module.Identity.Application.Commands.Permissions
{
    /// <summary>
    /// Validator cho DeletePermissionCommand
    /// </summary>
    public class DeletePermissionCommandValidator : AbstractValidator<DeletePermissionCommand>
    {
        public DeletePermissionCommandValidator()
        {
            RuleFor(x => x.PermissionId)
                .NotEmpty();
        }
    }
}
