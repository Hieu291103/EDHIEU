using FluentValidation;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Validator cho AssignUserRoleCommand
    /// </summary>
    public class AssignUserRoleCommandValidator : AbstractValidator<AssignUserRoleCommand>
    {
        public AssignUserRoleCommandValidator()
        {
            RuleFor(x => x.UserId)
                .NotEmpty()
                .WithMessage("UserIdRequired");

            RuleFor(x => x.ClientId)
                .NotEmpty()
                .WithMessage("ClientIdRequired");

            RuleFor(x => x.RoleIds)
                .NotEmpty()
                .WithMessage("AtLeastOneRoleRequired");

            RuleFor(x => x.RoleIds)
                .Must(roles => roles.All(r => !string.IsNullOrEmpty(r)))
                .When(x => x.RoleIds != null && x.RoleIds.Any())
                .WithMessage("InvalidRoleIds");

            RuleFor(x => x.StartDate)
                .LessThan(x => x.EndDate)
                .When(x => x.StartDate.HasValue && x.EndDate.HasValue)
                .WithMessage("StartDateMustBeBeforeEndDate");

            RuleFor(x => x.TenantIds)
                .Must(tenants => tenants.All(t => !string.IsNullOrEmpty(t)))
                .When(x => x.TenantIds != null && x.TenantIds.Any())
                .WithMessage("InvalidTenantIds");
        }
    }
}
