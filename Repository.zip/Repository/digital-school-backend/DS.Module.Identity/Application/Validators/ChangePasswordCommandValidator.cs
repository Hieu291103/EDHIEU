using FluentValidation;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Validator cho ChangePasswordCommand
    /// - Default validators: Sử dụng messages từ DefaultValidationMessageLocalization
    /// - Custom validators: Sử dụng error codes từ IdentityLocalizationProvider
    /// </summary>
    public class ChangePasswordCommandValidator : AbstractValidator<ChangePasswordCommand>
    {
        public ChangePasswordCommandValidator()
        {
            RuleFor(x => x.UserId)
                .NotEmpty();

            RuleFor(x => x.CurrentPassword)
                .NotEmpty();

            // New password validation với custom error codes
            RuleFor(x => x.NewPassword)
                .NotEmpty()
                .MinimumLength(6);
            //.Matches("[A-Z]").WithMessage("PasswordRequiresUppercase")
            //.Matches("[a-z]").WithMessage("PasswordRequiresLowercase")
            //.Matches("[0-9]").WithMessage("PasswordRequiresDigit");

            RuleFor(x => x.NewPassword)
                .NotEqual(x => x.CurrentPassword);
        }
    }
}
