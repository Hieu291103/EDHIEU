using FluentValidation;

namespace DS.Module.Identity.Application.Commands.Users
{
    public class AdminResetPasswordCommandValidator : AbstractValidator<AdminResetPasswordCommand>
    {
        public AdminResetPasswordCommandValidator()
        {
            RuleFor(x => x.UserId).NotEmpty();

            RuleFor(x => x.NewPassword)
                .NotEmpty()
                .MinimumLength(6);
        }
    }
}
