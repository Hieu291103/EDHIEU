using FluentValidation;

namespace DS.Module.Identity.Application.Commands.Roles
{
    /// <summary>
    /// Validator cho UpdateRoleCommand
    /// </summary>
    public class UpdateRoleCommandValidator : AbstractValidator<UpdateRoleCommand>
    {
        public UpdateRoleCommandValidator()
        {
            RuleFor(x => x.RoleId)
                .NotEmpty();

            RuleFor(x => x.Name)
                .MinimumLength(2)
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.Name));

            RuleFor(x => x.Description)
                .MaximumLength(500)
                .When(x => !string.IsNullOrEmpty(x.Description));

            RuleFor(x => x.PermissionCodes)
                .Must(codes => codes == null || codes.All(c => !string.IsNullOrEmpty(c)))
                .WithMessage("PermissionCodesCannotBeEmpty")
                .When(x => x.PermissionCodes != null);

            // TenantId validation - ObjectId format (24 hex characters)
            RuleFor(x => x.TenantId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTenantIdFormat")
                .When(x => !string.IsNullOrEmpty(x.TenantId));
        }
    }
}
