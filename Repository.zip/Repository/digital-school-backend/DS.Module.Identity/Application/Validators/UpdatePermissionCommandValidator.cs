using FluentValidation;

namespace DS.Module.Identity.Application.Commands.Permissions
{
    /// <summary>
    /// Validator cho UpdatePermissionCommand
    /// </summary>
    public class UpdatePermissionCommandValidator : AbstractValidator<UpdatePermissionCommand>
    {
        public UpdatePermissionCommandValidator()
        {
            RuleFor(x => x.PermissionId)
                .NotEmpty();

            RuleFor(x => x.Name)
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.Name));

            RuleFor(x => x.Description)
                .MaximumLength(500)
                .When(x => !string.IsNullOrEmpty(x.Description));

            RuleFor(x => x.Module)
                .MaximumLength(100)
                .When(x => !string.IsNullOrEmpty(x.Module));

            RuleFor(x => x.Feature)
                .MaximumLength(100)
                .When(x => !string.IsNullOrEmpty(x.Feature));

            RuleFor(x => x.Action)
                .MaximumLength(100)
                .When(x => !string.IsNullOrEmpty(x.Action));
        }
    }
}
