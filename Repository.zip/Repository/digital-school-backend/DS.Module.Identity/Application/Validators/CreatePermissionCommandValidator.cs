using FluentValidation;

namespace DS.Module.Identity.Application.Commands.Permissions
{
    /// <summary>
    /// Validator cho CreatePermissionCommand
    /// </summary>
    public class CreatePermissionCommandValidator : AbstractValidator<CreatePermissionCommand>
    {
        public CreatePermissionCommandValidator()
        {
            RuleFor(x => x.ClientId)
                .NotEmpty()
                .Length(36); // UUID format

            RuleFor(x => x.Code)
                .NotEmpty()
                .MinimumLength(3)
                .MaximumLength(100)
                .Matches(@"^[A-Z0-9:_]+$"); // Permission codes use uppercase and colon

            RuleFor(x => x.Name)
                .NotEmpty()
                .MaximumLength(200);

            RuleFor(x => x.Description)
                .MaximumLength(500)
                .When(x => !string.IsNullOrEmpty(x.Description));

            RuleFor(x => x.Module)
                .MaximumLength(100)
                .When(x => !string.IsNullOrEmpty(x.Module));

            RuleFor(x => x.Feature)
                .MaximumLength(100)
                .When(x => !string.IsNullOrEmpty(x.Feature));

            RuleFor(x => x.Action)
                .MaximumLength(100)
                .When(x => !string.IsNullOrEmpty(x.Action));
        }
    }
}
