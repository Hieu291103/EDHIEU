using AutoMapper;
using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Entities;

namespace DS.Module.Identity.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho Permission entity
    /// </summary>
    public class PermissionMappingProfile : Profile
    {
        public PermissionMappingProfile()
        {
            CreateMap<PermissionEntity, PermissionDto>();
        }
    }
}
