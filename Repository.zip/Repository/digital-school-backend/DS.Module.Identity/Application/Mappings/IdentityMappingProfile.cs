using AutoMapper;

namespace DS.Module.Identity.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho Identity module - chứa non-entity mappings
    /// Entity mappings được tách vào các profile riêng (PermissionMappingProfile, etc)
    /// </summary>
    public class IdentityMappingProfile : Profile
    {
        public IdentityMappingProfile()
        {
            // Entity mappings được định nghĩa ở các profile riêng
        }
    }
}
