using AutoMapper;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.CQRS.DTOs.Users;

namespace DS.Module.Identity.Application.Mappings
{
    /// <summary>
    /// AutoMapper profile cho User entity mappings
    /// </summary>
    public class UserMappingProfile : Profile
    {
        public UserMappingProfile()
        {
            CreateMap<UserEntity, UserDto>().ReverseMap();
            CreateMap<UserEntity, UserListDto>();
        }
    }
}
