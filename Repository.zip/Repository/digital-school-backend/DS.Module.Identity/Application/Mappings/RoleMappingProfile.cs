using AutoMapper;
using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Entities;

namespace DS.Module.Identity.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho Role entity
    /// </summary>
    public class RoleMappingProfile : Profile
    {
        public RoleMappingProfile()
        {
            CreateMap<RoleEntity, RoleDto>();
        }
    }
}
