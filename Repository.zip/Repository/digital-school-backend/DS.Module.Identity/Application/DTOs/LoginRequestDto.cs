namespace DS.Module.Identity.Application.DTOs
{
    /// <summary>
    /// DTO lưu OAuth2/OIDC login context trong Redis
    /// </summary>
    public class LoginRequestDto
    {
        public required string ClientId { get; set; }
        public required string RedirectUri { get; set; }
        public string? ResponseType { get; set; }
        public List<string> Scopes { get; set; } = new();
        public string? State { get; set; }
        public string? Nonce { get; set; }
        public string? CodeChallenge { get; set; }
        public string? CodeChallengeMethod { get; set; }
        public string? LoginHint { get; set; }
        public string? IdentityProvider { get; set; }
        public string? Prompt { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public string? ValidatedUsername { get; set; }
        public bool IsAuthenticated { get; set; }
        public string? AuthenticatedUserId { get; set; }
        public Dictionary<string, string>? AdditionalData { get; set; }
    }
}
