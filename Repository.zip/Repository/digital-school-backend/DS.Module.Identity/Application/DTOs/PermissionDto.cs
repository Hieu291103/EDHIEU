namespace DS.Module.Identity.Application.DTOs
{
    /// <summary>
    /// DTO response cho Permission entity
    /// </summary>
    public class PermissionDto
    {
        public string Id { get; set; } = string.Empty;
        public string ClientId { get; set; } = string.Empty;
        public string Code { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string? Module { get; set; }
        public string? Feature { get; set; }
        public string? Action { get; set; }
        public DateTime CreatedAt { get; set; }
        public string? CreatedByDisplay { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string? UpdatedByDisplay { get; set; }
    }
}
