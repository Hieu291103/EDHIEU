namespace DS.Module.Identity.Application.DTOs
{
    /// <summary>
    /// OAuth2 Token Response (RFC 6749)
    /// </summary>
    public class TokenResponseDto
    {
        public required string AccessToken { get; set; }

        public string TokenType { get; set; } = "Bearer";

        public int ExpiresIn { get; set; }

        public string? RefreshToken { get; set; }

    }
}
