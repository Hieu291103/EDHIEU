namespace DS.Module.Identity.Application.DTOs
{
    /// <summary>
    /// UserInfo Response (OIDC)
    /// </summary>
    public class UserInfoDto
    {
        public required string Sub { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public bool? EmailVerified { get; set; }
        public string? Title { get; set; }
        public string? TenantId { get; set; }
        public string? PhoneNumber { get; set; }
        public bool? PhoneNumberVerified { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string? EducationCode { get; set; }
        public string? Picture { get; set; }
        public string? PreferredUsername { get; set; }
        public Dictionary<string, string>? AdditionalClaims { get; set; }
    }
}
