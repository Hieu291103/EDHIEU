namespace DS.Module.Identity.Application.DTOs
{
    /// <summary>
    /// OAuth2 Authorize Callback Response
    /// </summary>
    public class AuthorizeCallbackDto
    {
        public required string Code { get; set; }
        public required string RedirectUri { get; set; }
        public string? State { get; set; }
    }
}
