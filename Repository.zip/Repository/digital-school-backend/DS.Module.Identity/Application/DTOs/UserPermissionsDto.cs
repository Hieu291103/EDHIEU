using System.Text.Json.Serialization;

namespace DS.Module.Identity.Application.DTOs
{
    /// <summary>
    /// DTO chứa danh sách quyền (permissions) của user cho một client cụ thể
    /// Được tổ chức theo Module -> Feature -> Permission để dễ hiển thị UI
    /// </summary>
    public class UserPermissionsDto
    {
        /// <summary>
        /// User ID
        /// </summary>
        [JsonPropertyName("userId")]
        public required string UserId { get; set; }

        /// <summary>
        /// Client ID
        /// </summary>
        [JsonPropertyName("clientId")]
        public required string ClientId { get; set; }

        /// <summary>
        /// Danh sách permission codes mà user có quyền (flat list để check nhanh)
        /// Ví dụ: ["EVENT:ONLINE_CLASS:VIEW", "EVENT:CLASS_SCHEDULE:CREATE"]
        /// </summary>
        [JsonPropertyName("permissionCodes")]
        public List<string> PermissionCodes { get; set; } = new();

        /// <summary>
        /// Danh sách permissions được tổ chức theo cấu trúc Module -> Feature -> Permission
        /// Dùng để hiển thị UI
        /// </summary>
        [JsonPropertyName("modules")]
        public List<ModuleDisplayDto> Modules { get; set; } = new();

        /// <summary>
        /// Danh sách Role IDs của user cho client này
        /// </summary>
        [JsonPropertyName("roleIds")]
        public List<string> RoleIds { get; set; } = new();

        /// <summary>
        /// Danh sách Tenant IDs mà user có quyền truy cập
        /// </summary>
        [JsonPropertyName("tenantIds")]
        public List<string> TenantIds { get; set; } = new();

        [JsonPropertyName("isAllTenants")]
        public bool IsAllTenants { get; set; } = false;
    }
}
