using System.Text.Json.Serialization;

namespace DS.Module.Identity.Application.DTOs
{
    /// <summary>
    /// DTO hiển thị thông tin Module
    /// </summary>
    public class ModuleDisplayDto
    {
        [JsonPropertyName("code")]
        public required string Code { get; set; }
        [JsonPropertyName("name")]
        public required string Name { get; set; }
        [JsonPropertyName("features")]
        public List<FeatureDisplayDto> Features { get; set; } = new();
    }

    /// <summary>
    /// DTO hiển thị thông tin Feature
    /// </summary>
    public class FeatureDisplayDto
    {
        [JsonPropertyName("code")]
        public required string Code { get; set; }
        [JsonPropertyName("name")]
        public required string Name { get; set; }
        [JsonPropertyName("permissions")]
        public List<PermissionItemDto> Permissions { get; set; } = new();
    }

    /// <summary>
    /// DTO hiển thị một Permission đơn
    /// </summary>
    public class PermissionItemDto
    {
        [JsonPropertyName("code")]
        public required string Code { get; set; }
        [JsonPropertyName("name")]
        public required string Name { get; set; }

        [JsonPropertyName("description")]
        public string? Description { get; set; }

        [JsonPropertyName("action")]
        public string? Action { get; set; }
    }

    /// <summary>
    /// DTO response khi lấy danh sách modules/features/permissions
    /// </summary>
    public class PermissionCatalogDto
    {
        [JsonPropertyName("clientCode")]
        public required string ClientCode { get; set; }
        [JsonPropertyName("modules")]
        public List<ModuleDisplayDto> Modules { get; set; } = new();
    }
}
