namespace DS.Module.Identity.Application.DTOs
{
    /// <summary>
    /// DTO đại diện cho Permission trong cây phân cấp
    /// </summary>
    public class PermissionTreeItemDto
    {
        public string Id { get; set; } = string.Empty;
        public string Code { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string? Action { get; set; }
    }

    /// <summary>
    /// DTO đại diện cho Feature chứa danh sách Permission
    /// </summary>
    public class FeatureTreeDto
    {
        public string Name { get; set; } = string.Empty;
        public List<PermissionTreeItemDto> Permissions { get; set; } = new();
    }

    /// <summary>
    /// DTO đại diện cho Module chứa danh sách Feature
    /// </summary>
    public class ModuleTreeDto
    {
        public string Name { get; set; } = string.Empty;
        public List<FeatureTreeDto> Features { get; set; } = new();
    }

    /// <summary>
    /// DTO gốc chứa danh sách Module
    /// </summary>
    public class PermissionTreeResponseDto
    {
        public List<ModuleTreeDto> Modules { get; set; } = new();
    }
}
