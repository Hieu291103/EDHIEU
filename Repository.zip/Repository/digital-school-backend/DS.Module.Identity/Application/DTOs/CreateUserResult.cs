namespace DS.Module.Identity.Application.DTOs
{

    /// <summary>
    /// Result khi tạo user mới
    /// </summary>
    public class CreateUserResult
    {
        public string UserId { get; set; } = string.Empty;
        public string Username { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }

}
