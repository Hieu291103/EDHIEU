namespace DS.Module.Identity.Application.DTOs
{
    /// <summary>
    /// DTO response cho Role entity
    /// </summary>
    public class RoleDto
    {
        public string Id { get; set; } = string.Empty;
        public string ClientId { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public List<string> PermissionCodes { get; set; } = new();
        public bool IsSystem { get; set; }
        public DateTime CreatedAt { get; set; }
        public string? CreatedByDisplay { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string? UpdatedByDisplay { get; set; }
    }
}
