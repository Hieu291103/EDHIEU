namespace DS.Module.Identity.Application.DTOs
{
    public class UserRoleDto
    {
        public string UserId { get; set; } = string.Empty;
        public string ClientId { get; set; } = string.Empty;
        public string ClientName { get; set; } = string.Empty;

        /// <summary>
        /// Danh sách ID của các role cần gán
        /// </summary>
        public List<string> RoleIds { get; set; } = new();

        /// <summary>
        /// Danh sách tenant ID. Nếu rỗng, mặc định có quyền truy cập tất cả tenant
        /// </summary>
        public List<string> TenantIds { get; set; } = new();

        /// <summary>
        /// Có quyền truy cập tất cả tenant hay không
        /// </summary>
        public bool IsAllTenants { get; set; } = true;
        /// <summary>
        /// Danh sách role được phép gán cho user
        /// </summary>
        public List<RoleDataDto> RoleList { get; set; } = new();
    }

    public class RoleDataDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public bool IsSystem { get; set; }
    }
}
