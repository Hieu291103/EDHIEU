using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using DS.Module.Identity.Infrastructure.Services;

namespace DS.Module.Identity.Application.Commands.IdentityProviders
{
    /// <summary>
    /// Command cập nhật Identity Provider
    /// </summary>
    public class UpdateIdentityProviderCommand : ICommand<bool>
    {
        public required string Id { get; set; }
        public required string Code { get; set; }
        public required string Name { get; set; }
        public string? Authority { get; set; }
        public string? ClientId { get; set; }
        public string? ClientSecret { get; set; }
        public List<string>? RedirectUris { get; set; }
        public List<string>? LoginHintDomains { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDefault { get; set; }
    }

    /// <summary>
    /// Handler cho UpdateIdentityProviderCommand
    /// AuditingBehavior sẽ tự động set UpdatedBy + UpdatedByDisplay
    /// </summary>
    public class UpdateIdentityProviderCommandHandler : IRequestHandler<UpdateIdentityProviderCommand, bool>
    {
        private readonly IAdminReadRepository<IdentityProviderEntity> _readRepository;
        private readonly IAdminWriteRepository<IdentityProviderEntity> _writeRepository;
        private readonly IIdentityProviderService _providerService;

        public UpdateIdentityProviderCommandHandler(
            IAdminReadRepository<IdentityProviderEntity> readRepository,
            IAdminWriteRepository<IdentityProviderEntity> writeRepository,
            IIdentityProviderService providerService)
        {
            _readRepository = readRepository;
            _writeRepository = writeRepository;
            _providerService = providerService;
        }

        public async Task<bool> Handle(UpdateIdentityProviderCommand request, CancellationToken cancellationToken)
        {
            var providers = await _readRepository.FilterAsync(p => p.Id == request.Id);
            var provider = providers.FirstOrDefault();

            if (provider == null)
                throw new KeyNotFoundException($"Provider {request.Id} not found");

            provider.Code = request.Code;
            provider.Name = request.Name;
            provider.Authority = request.Authority;
            provider.ClientId = request.ClientId;
            provider.ClientSecret = request.ClientSecret;
            provider.RedirectUris = request.RedirectUris ?? new();
            provider.LoginHintDomains = request.LoginHintDomains ?? new();
            provider.IsEnabled = request.IsEnabled;
            provider.IsDefault = request.IsDefault;
            // UpdatedBy, UpdatedByDisplay được set bởi AuditingBehavior

            await _writeRepository.UpdateAsync(provider);

            // Invalidate cache sau khi update
            await _providerService.InvalidateCacheAsync();

            return true;
        }
    }
}
