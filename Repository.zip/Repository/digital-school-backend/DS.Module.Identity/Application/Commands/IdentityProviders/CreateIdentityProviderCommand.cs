using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;

namespace DS.Module.Identity.Application.Commands.IdentityProviders
{
    /// <summary>
    /// Command tạo Identity Provider mới
    /// </summary>
    public class CreateIdentityProviderCommand : ICommand<string>
    {
        public required string Code { get; set; }
        public required string Name { get; set; }
        public string? Authority { get; set; }
        public string? ClientId { get; set; }
        public string? ClientSecret { get; set; }
        public List<string>? RedirectUris { get; set; }
        public List<string>? LoginHintDomains { get; set; }
        public bool IsEnabled { get; set; } = true;
        public bool IsDefault { get; set; }
    }

    /// <summary>
    /// Handler cho CreateIdentityProviderCommand
    /// AuditingBehavior sẽ tự động set CreatedBy + CreatedByDisplay
    /// </summary>
    public class CreateIdentityProviderCommandHandler : IRequestHandler<CreateIdentityProviderCommand, string>
    {
        private readonly IAdminWriteRepository<IdentityProviderEntity> _repository;

        public CreateIdentityProviderCommandHandler(IAdminWriteRepository<IdentityProviderEntity> repository)
        {
            _repository = repository;
        }

        public async Task<string> Handle(CreateIdentityProviderCommand request, CancellationToken cancellationToken)
        {
            var provider = new IdentityProviderEntity
            {
                Code = request.Code,
                Name = request.Name,
                Authority = request.Authority,
                ClientId = request.ClientId,
                ClientSecret = request.ClientSecret,
                RedirectUris = request.RedirectUris ?? new(),
                LoginHintDomains = request.LoginHintDomains ?? new(),
                IsEnabled = request.IsEnabled,
                IsDefault = request.IsDefault
                // CreatedBy, CreatedByDisplay được set bởi AuditingBehavior
            };

            await _repository.InsertAsync(provider, cancellationToken);
            return provider.Id;
        }
    }
}
