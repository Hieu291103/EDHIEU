using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using DS.Module.Identity.Infrastructure.Services;

namespace DS.Module.Identity.Application.Commands.IdentityProviders
{
    /// <summary>
    /// Command xóa mềm Identity Provider
    /// </summary>
    public class DeleteIdentityProviderCommand : ICommand<bool>
    {
        public required string Id { get; set; }
    }

    /// <summary>
    /// Handler cho DeleteIdentityProviderCommand
    /// SoftDeleteAsync sẽ tự động set DeletedBy + DeletedByDisplay
    /// </summary>
    public class DeleteIdentityProviderCommandHandler : IRequestHandler<DeleteIdentityProviderCommand, bool>
    {
        private readonly IAdminWriteRepository<IdentityProviderEntity> _writeRepository;
        private readonly IIdentityProviderService _providerService;

        public DeleteIdentityProviderCommandHandler(
            IAdminWriteRepository<IdentityProviderEntity> writeRepository,
            IIdentityProviderService providerService)
        {
            _writeRepository = writeRepository;
            _providerService = providerService;
        }

        public async Task<bool> Handle(DeleteIdentityProviderCommand request, CancellationToken cancellationToken)
        {
            // SoftDeleteAsync tự động set: DeletedBy, DeletedByDisplay, DeletedAt, IsDeleted
            await _writeRepository.SoftDeleteAsync(request.Id, cancellationToken: cancellationToken);

            // Invalidate cache
            await _providerService.InvalidateCacheAsync();

            return true;
        }
    }
}
