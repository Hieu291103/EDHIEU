using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Enums;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Command để update thông tin user
    /// </summary>
    public class UpdateUserCommand : ICommand<Result>
    {
        public string UserId { get; set; } = string.Empty;

        // Thông tin cơ bản
        public string? Username { get; set; }
        public string? Email { get; set; }
        public string? FullName { get; set; }
        public string? Title { get; set; }
        public string? TenantId { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string? EducationCode { get; set; }
        public string? PhoneNumber { get; set; }
        public string? AvatarUrl { get; set; }
        public string? LoginHint { get; set; }

        // Phân loại
        public UserType? UserType { get; set; }

        // Trạng thái xác thực
        public bool? EmailVerified { get; set; }
        public bool? PhoneNumberVerified { get; set; }

        // Bảo mật & khóa tài khoản
        public bool? TwoFactorEnabled { get; set; }
        public bool? LockoutEnabled { get; set; }

        /// <summary>
        /// Đặt null để mở khóa tài khoản ngay lập tức
        /// </summary>
        public DateTime? LockoutEnd { get; set; }
        public bool ClearLockoutEnd { get; set; } = false;
    }
}
