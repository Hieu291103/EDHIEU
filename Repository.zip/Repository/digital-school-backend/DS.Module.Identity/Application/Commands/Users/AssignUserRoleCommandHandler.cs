using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.Core.Infrastructure.Persistence.Redis;
using Microsoft.Extensions.Caching.Distributed;
using MongoDB.Driver;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Handler cho AssignUserRoleCommand
    /// </summary>
    public class AssignUserRoleCommandHandler : ICommandHandler<AssignUserRoleCommand, Result>
    {
        private readonly IAdminReadRepository<UserEntity> _userReadRepository;
        private readonly IAdminReadRepository<RoleEntity> _roleReadRepository;
        private readonly IAdminWriteRepository<UserRoleAssignmentEntity> _userRoleAssignmentWriteRepository;
        private readonly IAdminReadRepository<UserRoleAssignmentEntity> _userRoleAssignmentReadRepository;
        private readonly IDistributedCache _cache;

        public AssignUserRoleCommandHandler(
            IAdminReadRepository<UserEntity> userReadRepository,
            IAdminReadRepository<RoleEntity> roleReadRepository,
            IAdminWriteRepository<UserRoleAssignmentEntity> userRoleAssignmentWriteRepository,
            IAdminReadRepository<UserRoleAssignmentEntity> userRoleAssignmentReadRepository,
            IDistributedCache cache)
        {
            _userReadRepository = userReadRepository;
            _roleReadRepository = roleReadRepository;
            _userRoleAssignmentWriteRepository = userRoleAssignmentWriteRepository;
            _userRoleAssignmentReadRepository = userRoleAssignmentReadRepository;
            _cache = cache;
        }

        public async Task<Result> Handle(AssignUserRoleCommand request, CancellationToken cancellationToken)
        {
            // Validate user exists
            var user = await _userReadRepository.GetByIdAsync(
                request.UserId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (user == null)
                throw new DSException("UserNotFound");

            // Validate roles exist
            if (request.RoleIds.Any())
            {
                var filterBuilder = Builders<RoleEntity>.Filter;
                var filter = filterBuilder.In(r => r.Id, request.RoleIds);
                var existingRoles = await _roleReadRepository.FilterAsync(
                    filter,
                    tenantId: null,
                    includeSoftDeleted: false,
                    cancellationToken);

                if (existingRoles.Count != request.RoleIds.Count)
                    throw new DSException("SomeRolesNotFound");
            }

            // Check if assignment already exists for this user and client
            var existingAssignment = await _userRoleAssignmentReadRepository.FilterAsync(
                a => a.UserId == request.UserId && a.ClientId == request.ClientId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            UserRoleAssignmentEntity assignment;

            if (existingAssignment.Any())
            {
                // Update existing assignment
                assignment = existingAssignment.First();
                assignment.RoleIds = request.RoleIds;
                assignment.TenantIds = request.TenantIds;
                assignment.IsAllTenants = request.IsAllTenants;
                assignment.IsActive = true;

                if (request.StartDate.HasValue)
                    assignment.StartDate = request.StartDate.Value;

                if (request.EndDate.HasValue)
                    assignment.EndDate = request.EndDate.Value;

                await _userRoleAssignmentWriteRepository.UpdateAsync(assignment, tenantId: null, cancellationToken);
            }
            else
            {
                // Create new assignment
                assignment = new UserRoleAssignmentEntity
                {
                    UserId = request.UserId,
                    ClientId = request.ClientId,
                    RoleIds = request.RoleIds,
                    TenantIds = request.TenantIds,
                    IsAllTenants = request.IsAllTenants,
                    IsActive = true,
                    StartDate = request.StartDate ?? DateTime.UtcNow,
                    EndDate = request.EndDate
                };

                await _userRoleAssignmentWriteRepository.InsertAsync(assignment, cancellationToken);
            }

            // Xóa toàn bộ cache permissions của user trên các client liên quan
            var userAssignments = await _userRoleAssignmentReadRepository.FilterAsync(
                a => a.UserId == request.UserId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            var clientIds = userAssignments
                .Select(a => a.ClientId)
                .Where(clientId => !string.IsNullOrWhiteSpace(clientId))
                .Append(request.ClientId)
                .Where(clientId => !string.IsNullOrWhiteSpace(clientId))
                .Distinct();

            foreach (var clientId in clientIds)
            {
                var cacheKey = RedisKeys.Cache.UserPermissions(request.UserId, clientId);
                await _cache.RemoveAsync(cacheKey, cancellationToken);
            }

            return Result.Success();
        }
    }
}
