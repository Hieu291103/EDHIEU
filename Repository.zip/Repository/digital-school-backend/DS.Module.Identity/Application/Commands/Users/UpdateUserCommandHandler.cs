using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Handler cho UpdateUserCommand
    /// </summary>
    public class UpdateUserCommandHandler : ICommandHandler<UpdateUserCommand, Result>
    {
        private readonly IAdminWriteRepository<UserEntity> _userWriteRepository;
        private readonly IAdminReadRepository<UserEntity> _userReadRepository;

        public UpdateUserCommandHandler(
            IAdminWriteRepository<UserEntity> userWriteRepository,
            IAdminReadRepository<UserEntity> userReadRepository)
        {
            _userWriteRepository = userWriteRepository;
            _userReadRepository = userReadRepository;
        }

        public async Task<Result> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
        {
            var user = await _userReadRepository.GetByIdAsync(
                request.UserId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (user == null)
                throw new DSException("UserNotFound");

            // Thông tin cơ bản
            if (request.Username.IsNotNull())
            {
                var normalizedUsername = StringHelper.NormalizeUsername(request.Username);
                var existing = await _userReadRepository.FilterAsync(
                    u => u.Username == normalizedUsername && u.Id != request.UserId,
                    tenantId: null,
                    includeSoftDeleted: false,
                    cancellationToken);

                if (existing.Any())
                    throw DSException.WithParam("UsernameAlreadyExists", request.Username);

                user.Username = normalizedUsername;
            }

            if (request.Email.IsNotNull())
            {
                var existing = await _userReadRepository.FilterAsync(
                    u => u.Email == request.Email && u.Id != request.UserId,
                    tenantId: null,
                    includeSoftDeleted: false,
                    cancellationToken);

                if (existing.Any())
                    throw DSException.WithParam("EmailAlreadyExists", request.Email);
                user.Email = request.Email.Trim().ToLower();
            }

            if (request.FullName != null)
            {
                user.FullName = request.FullName;
                var (firstName, lastName) = StringHelper.SplitFullName(request.FullName);
                user.FirstName = firstName;
                user.LastName = lastName;
            }

            if (request.Title != null)
                user.Title = request.Title;

            if (request.TenantId != null)
                user.TenantId = request.TenantId;

            if (request.DateOfBirth.HasValue)
                user.DateOfBirth = request.DateOfBirth.Value;

            if (request.EducationCode != null)
                user.EducationCode = request.EducationCode;

            if (request.PhoneNumber != null)
                user.PhoneNumber = request.PhoneNumber;

            if (request.AvatarUrl != null)
                user.AvatarUrl = request.AvatarUrl;

            if (request.LoginHint != null)
                user.LoginHint = request.LoginHint;

            // Phân loại
            if (request.UserType.HasValue)
                user.UserType = request.UserType.Value;

            // Trạng thái xác thực
            if (request.EmailVerified.HasValue)
                user.EmailVerified = request.EmailVerified.Value;

            if (request.PhoneNumberVerified.HasValue)
                user.PhoneNumberVerified = request.PhoneNumberVerified.Value;

            // Bảo mật & khóa tài khoản
            if (request.TwoFactorEnabled.HasValue)
                user.TwoFactorEnabled = request.TwoFactorEnabled.Value;

            if (request.LockoutEnabled.HasValue)
                user.LockoutEnabled = request.LockoutEnabled.Value;

            if (request.ClearLockoutEnd)
                user.LockoutEnd = null;
            else if (request.LockoutEnd.HasValue)
                user.LockoutEnd = request.LockoutEnd.Value;

            await _userWriteRepository.UpdateAsync(user, tenantId: null, cancellationToken);

            return Result.Success();
        }
    }
}
