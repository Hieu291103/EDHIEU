using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Command để xóa user (soft delete)
    /// </summary>
    public class DeleteUserCommand : ICommand<Result>
    {
        public string UserId { get; set; } = string.Empty;
    }
}
