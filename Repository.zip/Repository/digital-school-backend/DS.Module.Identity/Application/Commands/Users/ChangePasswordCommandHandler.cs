using DS.Module.Identity.Domain.Entities;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Handler cho ChangePasswordCommand
    /// </summary>
    public class ChangePasswordCommandHandler : ICommandHandler<ChangePasswordCommand, Result>
    {
        private readonly IAdminWriteRepository<UserEntity> _userWriteRepository;
        private readonly IAdminReadRepository<UserEntity> _userReadRepository;
        private readonly IUserSessionService _userSessionService;

        public ChangePasswordCommandHandler(
            IAdminWriteRepository<UserEntity> userWriteRepository,
            IAdminReadRepository<UserEntity> userReadRepository,
            IUserSessionService userSessionService)
        {
            _userWriteRepository = userWriteRepository;
            _userReadRepository = userReadRepository;
            _userSessionService = userSessionService;
        }

        public async Task<Result> Handle(ChangePasswordCommand request, CancellationToken cancellationToken)
        {
            // Get user
            var user = await _userReadRepository.GetByIdAsync(
                request.UserId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (user == null)
            {
                throw new DSException("UserNotFound");
            }

            // Verify current password
            if (!PasswordHelper.VerifyPassword(request.CurrentPassword, user.PasswordHash))
            {
                throw new DSException("InvalidPassword");
            }

            // Hash new password
            user.PasswordHash = PasswordHelper.HashPassword(request.NewPassword);

            // Update security stamp to invalidate existing tokens
            user.SecurityStamp = Guid.NewGuid().ToString();
            user.UpdatedAt = DateTime.UtcNow;

            // Save changes
            await _userWriteRepository.UpdateAsync(user, tenantId: null, cancellationToken);

            // Revoke all active SSO sessions after password is changed
            await _userSessionService.RevokeAllSessionsAsync(user.Id, cancellationToken);

            return Result.Success();
        }
    }
}
