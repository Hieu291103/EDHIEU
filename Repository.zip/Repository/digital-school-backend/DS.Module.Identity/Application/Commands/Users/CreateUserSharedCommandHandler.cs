using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Constants;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Commands.Users;
using DS.Shared.CQRS.DTOs.Users;
using MongoDB.Bson;

namespace DS.Module.Identity.Application.Commands.Users
{
    public class CreateUserSharedCommandHandler : ICommandHandler<SharedCreateUserCommand, CreateUserResult>
    {
        private readonly IAdminWriteRepository<UserEntity> _userWriteRepository;
        private readonly IAdminReadRepository<UserEntity> _userReadRepository;

        public CreateUserSharedCommandHandler(
            IAdminWriteRepository<UserEntity> userWriteRepository,
            IAdminReadRepository<UserEntity> userReadRepository)
        {
            _userWriteRepository = userWriteRepository;
            _userReadRepository = userReadRepository;
        }

        public async Task<CreateUserResult> Handle(SharedCreateUserCommand request, CancellationToken cancellationToken)
        {
            var normalizedUsername = StringHelper.NormalizeUsername(request.Username);
            var normalizedEmail = string.IsNullOrEmpty(request.Email) ? string.Empty : request.Email.Trim().ToLower();
            var existingUsers = await _userReadRepository.FilterAsync(
                u => u.Username == normalizedUsername,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (existingUsers.Any())
            {
                throw DSException.WithParam("UsernameAlreadyExists", request.Username);
            }

            if (normalizedEmail != string.Empty)
            {
                var existingEmails = await _userReadRepository.FilterAsync(
                   u => u.Email == normalizedEmail,
                   tenantId: null,
                   includeSoftDeleted: false,
                   cancellationToken);
                if (existingEmails.Any())
                {
                    throw DSException.WithParam("EmailAlreadyExists", normalizedEmail);
                }
            }

            var passwordHash = PasswordHelper.HashPassword(request.Password);

            // Tách FirstName và LastName từ FullName nếu chưa được cung cấp
            var firstName = request.FirstName ?? StringHelper.SplitFullName(request.FullName).FirstName;
            var lastName = request.LastName ?? StringHelper.SplitFullName(request.FullName).LastName;

            var user = new UserEntity
            {
                Id = request.UserId ?? ObjectId.GenerateNewId().ToString(),
                Username = normalizedUsername,
                EducationCode = request.EducationCode,
                Email = normalizedEmail,
                PasswordHash = request.IdentityProviderCode == IdentityProviderCodes.Local ? PasswordHelper.HashPassword(request.Password) : "",
                FullName = request.FullName,
                FirstName = firstName,
                LastName = lastName,
                Title = request.Title,
                TenantId = request.TenantId,
                DateOfBirth = request.DateOfBirth,
                PhoneNumber = request.PhoneNumber,
                AvatarUrl = request.AvatarUrl,
                LoginHint = request.LoginHint,
                UserType = request.UserType,
                UseProvider = false,
                IdentityProviderCode = request.IdentityProviderCode ?? IdentityProviderCodes.Local,
                EmailVerified = false,
                PhoneNumberVerified = false,
                TwoFactorEnabled = request.TwoFactorEnabled,
                LockoutEnabled = request.LockoutEnabled,
                AccessFailedCount = 0
            };

            await _userWriteRepository.InsertAsync(user, cancellationToken);

            return new CreateUserResult
            {
                UserId = user.Id,
                Username = user.Username,
                EducationCode = user.EducationCode,
            };
        }
    }
}
