using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Commands.Users;

namespace DS.Module.Identity.Application.Commands.Users
{
    public class UpdateUserSharedCommandHandler : ICommandHandler<SharedUpdateUserCommand, Result>
    {
        private readonly IAdminWriteRepository<UserEntity> _userWriteRepository;
        private readonly IAdminReadRepository<UserEntity> _userReadRepository;

        public UpdateUserSharedCommandHandler(
            IAdminWriteRepository<UserEntity> userWriteRepository,
            IAdminReadRepository<UserEntity> userReadRepository)
        {
            _userWriteRepository = userWriteRepository;
            _userReadRepository = userReadRepository;
        }

        public async Task<Result> Handle(SharedUpdateUserCommand request, CancellationToken cancellationToken)
        {
            var user = await _userReadRepository.GetByIdAsync(
                request.UserId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (user == null)
                throw new DSException("UserNotFound");

            if (!string.IsNullOrEmpty(request.Username))
            {
                var normalizedUsername = StringHelper.NormalizeUsername(request.Username);
                var existing = await _userReadRepository.FilterAsync(
                    u => u.Username == normalizedUsername && u.Id != request.UserId,
                    tenantId: null,
                    includeSoftDeleted: false,
                    cancellationToken);

                if (existing.Any())
                    throw DSException.WithParam("UsernameAlreadyExists", request.Username);

                user.Username = normalizedUsername;
            }

            if (!string.IsNullOrEmpty(request.Email))
            {
                var existing = await _userReadRepository.FilterAsync(
                    u => u.Email == request.Email && u.Id != request.UserId,
                    tenantId: null,
                    includeSoftDeleted: false,
                    cancellationToken);

                if (existing.Any())
                    throw DSException.WithParam("EmailAlreadyExists", request.Email);

                user.Email = request.Email.Trim().ToLower();
            }

            if (request.FullName != null)
            {
                user.FullName = request.FullName;
                var (firstName, lastName) = StringHelper.SplitFullName(request.FullName);
                user.FirstName = firstName;
                user.LastName = lastName;
            }
            else
            {
                // Nếu chỉ update FirstName/LastName mà không update FullName
                if (request.FirstName != null)
                    user.FirstName = request.FirstName;
                if (request.LastName != null)
                    user.LastName = request.LastName;
            }

            if (request.EducationCode != null)
                user.EducationCode = request.EducationCode;

            if (request.Title != null)
                user.Title = request.Title;

            if (request.TenantId != null)
                user.TenantId = request.TenantId;

            if (request.DateOfBirth.HasValue)
                user.DateOfBirth = request.DateOfBirth.Value;

            if (request.PhoneNumber != null)
                user.PhoneNumber = request.PhoneNumber;

            if (request.AvatarUrl != null)
                user.AvatarUrl = request.AvatarUrl;

            if (request.LoginHint != null)
                user.LoginHint = request.LoginHint;

            if (request.UserType.HasValue)
                user.UserType = request.UserType.Value;

            if (request.EmailVerified.HasValue)
                user.EmailVerified = request.EmailVerified.Value;

            if (request.PhoneNumberVerified.HasValue)
                user.PhoneNumberVerified = request.PhoneNumberVerified.Value;

            if (request.TwoFactorEnabled.HasValue)
                user.TwoFactorEnabled = request.TwoFactorEnabled.Value;

            if (request.LockoutEnabled.HasValue)
                user.LockoutEnabled = request.LockoutEnabled.Value;

            if (request.ClearLockoutEnd)
                user.LockoutEnd = null;
            else if (request.LockoutEnd.HasValue)
                user.LockoutEnd = request.LockoutEnd.Value;

            await _userWriteRepository.UpdateAsync(user, tenantId: null, cancellationToken);

            return Result.Success();
        }
    }
}
