using DS.Module.Identity.Domain.Entities;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Handler cho AdminResetPasswordCommand
    /// </summary>
    public class AdminResetPasswordCommandHandler : ICommandHandler<AdminResetPasswordCommand, Result>
    {
        private readonly IAdminWriteRepository<UserEntity> _userWriteRepository;
        private readonly IAdminReadRepository<UserEntity> _userReadRepository;
        private readonly IUserSessionService _userSessionService;

        public AdminResetPasswordCommandHandler(
            IAdminWriteRepository<UserEntity> userWriteRepository,
            IAdminReadRepository<UserEntity> userReadRepository,
            IUserSessionService userSessionService)
        {
            _userWriteRepository = userWriteRepository;
            _userReadRepository = userReadRepository;
            _userSessionService = userSessionService;
        }

        public async Task<Result> Handle(AdminResetPasswordCommand request, CancellationToken cancellationToken)
        {
            var user = await _userReadRepository.GetByIdAsync(
                request.UserId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (user == null)
                throw new DSException("UserNotFound");

            user.PasswordHash = PasswordHelper.HashPassword(request.NewPassword);
            user.SecurityStamp = Guid.NewGuid().ToString();
            user.AccessFailedCount = 0;
            user.LockoutEnd = null;

            await _userWriteRepository.UpdateAsync(user, tenantId: null, cancellationToken);

            // Revoke all active SSO sessions after admin reset password
            await _userSessionService.RevokeAllSessionsAsync(user.Id, cancellationToken);

            return Result.Success();
        }
    }
}
