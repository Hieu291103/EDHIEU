using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Handler cho CreateUserCommand
    /// </summary>
    public class CreateUserCommandHandler : ICommandHandler<CreateUserCommand, CreateUserResult>
    {
        private readonly IAdminWriteRepository<UserEntity> _userWriteRepository;
        private readonly IAdminReadRepository<UserEntity> _userReadRepository;

        public CreateUserCommandHandler(
            IAdminWriteRepository<UserEntity> userWriteRepository,
            IAdminReadRepository<UserEntity> userReadRepository)
        {
            _userWriteRepository = userWriteRepository;
            _userReadRepository = userReadRepository;
        }

        public async Task<CreateUserResult> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {
            // Normalize username for case-insensitive comparison
            var normalizedUsername = StringHelper.NormalizeUsername(request.Username);
            var normalizedEmail = string.IsNullOrEmpty(request.Email) ? string.Empty : request.Email.Trim().ToLower();

            // Check if username already exists
            var existingUsers = await _userReadRepository.FilterAsync(
                u => u.Username == normalizedUsername,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (existingUsers.Any())
            {
                // ✅ Cách mới: Static method trên DSException
                throw DSException.WithParam("UsernameAlreadyExists", request.Username);
            }

            if (normalizedEmail != string.Empty)
            {
                var existingEmails = await _userReadRepository.FilterAsync(
                   u => u.Email == normalizedEmail,
                   tenantId: null,
                   includeSoftDeleted: false,
                   cancellationToken);
                if (existingEmails.Any())
                {
                    throw DSException.WithParam("EmailAlreadyExists", normalizedEmail);
                }
            }

            // Hash password
            var passwordHash = PasswordHelper.HashPassword(request.Password);

            // Tách FirstName và LastName từ FullName
            var (firstName, lastName) = StringHelper.SplitFullName(request.FullName);

            // Create user entity
            var user = new UserEntity
            {
                Username = normalizedUsername,
                Email = request.Email,
                PasswordHash = passwordHash,
                FullName = request.FullName,
                FirstName = firstName,
                LastName = lastName,
                Title = request.Title,
                TenantId = request.TenantId,
                DateOfBirth = request.DateOfBirth,
                PhoneNumber = request.PhoneNumber,
                AvatarUrl = request.AvatarUrl,
                LoginHint = request.LoginHint,
                UserType = request.UserType,
                UseProvider = false,
                IdentityProviderCode = "local",
                EmailVerified = false,
                PhoneNumberVerified = false,
                TwoFactorEnabled = request.TwoFactorEnabled,
                LockoutEnabled = request.LockoutEnabled,
                AccessFailedCount = 0
            };

            // Save to database
            await _userWriteRepository.InsertAsync(user, cancellationToken);

            return new CreateUserResult
            {
                UserId = user.Id,
                Username = user.Username,
                Email = user.Email
            };
        }
    }
}
