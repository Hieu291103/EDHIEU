using DS.Module.Identity.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Enums;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Command để tạo user mới
    /// </summary>
    public class CreateUserCommand : ICommand<CreateUserResult>
    {
        public string Username { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string? FullName { get; set; }
        public string? Title { get; set; }
        public string? TenantId { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string? PhoneNumber { get; set; }
        public string? AvatarUrl { get; set; }
        public string? LoginHint { get; set; }
        public UserType UserType { get; set; } = UserType.None;
        public bool TwoFactorEnabled { get; set; } = false;
        public bool LockoutEnabled { get; set; } = true;
    }
}
