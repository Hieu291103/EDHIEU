using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Command để admin đặt lại mật khẩu cho user (không cần mật khẩu cũ)
    /// </summary>
    public class AdminResetPasswordCommand : ICommand<Result>
    {
        public string UserId { get; set; } = string.Empty;
        public string NewPassword { get; set; } = string.Empty;
    }
}
