using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Command để gán role cho user
    /// </summary>
    public class AssignUserRoleCommand : ICommand<Result>
    {
        public string UserId { get; set; } = string.Empty;
        public string ClientId { get; set; } = string.Empty;
        
        /// <summary>
        /// Danh sách ID của các role cần gán
        /// </summary>
        public List<string> RoleIds { get; set; } = new();
        
        /// <summary>
        /// Danh sách tenant ID. Nếu rỗng, mặc định có quyền truy cập tất cả tenant
        /// </summary>
        public List<string> TenantIds { get; set; } = new();
        
        /// <summary>
        /// Có quyền truy cập tất cả tenant hay không
        /// </summary>
        public bool IsAllTenants { get; set; } = true;
        
        /// <summary>
        /// Ngày bắt đầu. Mặc định là thời gian hiện tại
        /// </summary>
        public DateTime? StartDate { get; set; }
        
        /// <summary>
        /// Ngày kết thúc (null = không có ngày kết thúc)
        /// </summary>
        public DateTime? EndDate { get; set; }
    }
}
