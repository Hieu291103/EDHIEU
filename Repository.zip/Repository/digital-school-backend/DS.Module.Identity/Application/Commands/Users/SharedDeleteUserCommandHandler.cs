using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Commands.Users;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Handler cho SharedDeleteUserCommand — soft delete user
    /// Được sử dụng bởi các module khác (Tenant, etc) để xóa user
    /// </summary>
    public class SharedDeleteUserCommandHandler : ICommandHandler<SharedDeleteUserCommand, Result>
    {
        private readonly IAdminWriteRepository<UserEntity> _userWriteRepository;
        private readonly IAdminReadRepository<UserEntity> _userReadRepository;

        public SharedDeleteUserCommandHandler(
            IAdminWriteRepository<UserEntity> userWriteRepository,
            IAdminReadRepository<UserEntity> userReadRepository)
        {
            _userWriteRepository = userWriteRepository;
            _userReadRepository = userReadRepository;
        }

        public async Task<Result> Handle(SharedDeleteUserCommand request, CancellationToken cancellationToken)
        {
            var user = await _userReadRepository.GetByIdAsync(
                request.UserId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (user == null)
                throw new DSException("UserNotFound");

            await _userWriteRepository.DeleteAsync(request.UserId, tenantId: null, cancellationToken);

            return Result.Success();
        }
    }
}
