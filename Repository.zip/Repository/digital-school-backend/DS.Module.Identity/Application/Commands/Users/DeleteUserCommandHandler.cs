using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Handler cho DeleteUserCommand — soft delete
    /// </summary>
    public class DeleteUserCommandHandler : ICommandHandler<DeleteUserCommand, Result>
    {
        private readonly IAdminWriteRepository<UserEntity> _userWriteRepository;
        private readonly IAdminReadRepository<UserEntity> _userReadRepository;

        public DeleteUserCommandHandler(
            IAdminWriteRepository<UserEntity> userWriteRepository,
            IAdminReadRepository<UserEntity> userReadRepository)
        {
            _userWriteRepository = userWriteRepository;
            _userReadRepository = userReadRepository;
        }

        public async Task<Result> Handle(DeleteUserCommand request, CancellationToken cancellationToken)
        {
            var user = await _userReadRepository.GetByIdAsync(
                request.UserId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (user == null)
                throw new DSException("UserNotFound");

            await _userWriteRepository.SoftDeleteAsync(request.UserId, tenantId: null, cancellationToken);

            return Result.Success();
        }
    }
}
