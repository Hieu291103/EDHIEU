using DS.Module.Identity.Domain.Entities;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Commands.Users;

namespace DS.Module.Identity.Application.Commands.Users
{
    /// <summary>
    /// Handler cho SharedChangePasswordCommand — đổi password user
    /// Được sử dụng bởi các module khác để đổi password user
    /// </summary>
    public class SharedChangePasswordCommandHandler : ICommandHandler<SharedChangePasswordCommand, Result>
    {
        private readonly IAdminWriteRepository<UserEntity> _userWriteRepository;
        private readonly IAdminReadRepository<UserEntity> _userReadRepository;
        private readonly IUserSessionService _userSessionService;

        public SharedChangePasswordCommandHandler(
            IAdminWriteRepository<UserEntity> userWriteRepository,
            IAdminReadRepository<UserEntity> userReadRepository,
            IUserSessionService userSessionService)
        {
            _userWriteRepository = userWriteRepository;
            _userReadRepository = userReadRepository;
            _userSessionService = userSessionService;
        }

        public async Task<Result> Handle(SharedChangePasswordCommand request, CancellationToken cancellationToken)
        {
            // Get user
            var user = await _userReadRepository.GetByIdAsync(
                request.UserId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (user == null)
            {
                throw new DSException("UserNotFound");
            }

            // Hash new password
            user.PasswordHash = PasswordHelper.HashPassword(request.NewPassword);

            // Update security stamp to invalidate existing tokens
            user.SecurityStamp = Guid.NewGuid().ToString();
            user.UpdatedAt = DateTime.UtcNow;

            // Save changes
            await _userWriteRepository.UpdateAsync(user, tenantId: null, cancellationToken);

            // Revoke all active SSO sessions after password is changed
            await _userSessionService.RevokeAllSessionsAsync(user.Id, cancellationToken);

            return Result.Success();
        }
    }
}
