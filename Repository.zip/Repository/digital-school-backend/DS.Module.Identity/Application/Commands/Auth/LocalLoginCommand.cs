using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Commands.Auth
{
    /// <summary>
    /// Command: Đăng nhập local với username/password
    /// </summary>
    public class LocalLoginCommand : ICommand<Result<LocalLoginResult>>
    {
        public required string Username { get; set; }
        public required string Password { get; set; }
        public string? RequestId { get; set; }
        public string? IpAddress { get; set; }
        public string? UserAgent { get; set; }
    }

    public class LocalLoginResult
    {
        public bool Success { get; set; }
        public string? Message { get; set; }
        public string? UserId { get; set; }
        public bool IsAccountLocked { get; set; }
        public int RemainingAttempts { get; set; }
    }
}
