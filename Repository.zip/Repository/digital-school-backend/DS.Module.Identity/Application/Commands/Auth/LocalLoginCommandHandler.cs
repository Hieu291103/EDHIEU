using DS.Module.Identity.Domain.Entities;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Commands.Auth
{
    public class LocalLoginCommandHandler : ICommandHandler<LocalLoginCommand, Result<LocalLoginResult>>
    {
        private readonly IAdminReadRepository<UserEntity> _userReadRepository;
        private readonly IAdminWriteRepository<UserEntity> _userWriteRepository;

        private readonly IUserSessionService _sessionService;

        // Account lockout settings
        private const int MaxFailedAttempts = 6;
        private static readonly TimeSpan LockoutDuration = TimeSpan.FromMinutes(15);

        public LocalLoginCommandHandler(
            IAdminReadRepository<UserEntity> userReadRepository,
            IAdminWriteRepository<UserEntity> userWriteRepository,
            IUserSessionService sessionService)
        {
            _userReadRepository = userReadRepository;
            _userWriteRepository = userWriteRepository;
            _sessionService = sessionService;
        }

        public async Task<Result<LocalLoginResult>> Handle(LocalLoginCommand request, CancellationToken cancellationToken)
        {
            // Normalize username for case-insensitive comparison
            var normalizedUsername = StringHelper.NormalizeUsername(request.Username);

            // 1. Tìm user (username hoặc email)
            var users = await _userReadRepository.FilterAsync(
                u => u.Username == normalizedUsername || u.Email == request.Username,
                tenantId: null,
                includeSoftDeleted: true,
                cancellationToken);

            var user = users.FirstOrDefault();

            // 2. User không tồn tại
            if (user == null)
            {
                throw new DSException("InvalidCredentials");
            }

            // 3. Kiểm tra account locked
            if (user.LockoutEnabled && user.LockoutEnd.HasValue && user.LockoutEnd > DateTime.UtcNow)
            {
                var remainingMinutes = (int)Math.Ceiling((user.LockoutEnd.Value - DateTime.UtcNow).TotalMinutes);
                throw DSException.WithParam("AccountLockedDuration", remainingMinutes.ToString());
            }

            // 4. Reset lockout nếu đã hết hạn
            if (user.LockoutEnd.HasValue && user.LockoutEnd <= DateTime.UtcNow)
            {
                user.LockoutEnd = null;
                user.AccessFailedCount = 0;
                await _userWriteRepository.UpdateAsync(user, tenantId: null, cancellationToken);
            }

            // 5. Verify password
            var isPasswordValid = PasswordHelper.VerifyPassword(request.Password, user.PasswordHash);

            if (!isPasswordValid)
            {
                // ❌ Password sai → tăng counter
                user.AccessFailedCount++;

                // Kiểm tra nếu vượt quá 6 lần
                if (user.AccessFailedCount >= MaxFailedAttempts)
                {
                    user.LockoutEnd = DateTime.UtcNow.Add(LockoutDuration);
                    await _userWriteRepository.UpdateAsync(user, tenantId: null, cancellationToken);

                    throw new DSException("AccountLocked");
                }

                // Lưu số lần thất bại
                await _userWriteRepository.UpdateAsync(user, tenantId: null, cancellationToken);

                if (user.AccessFailedCount > 2)
                {
                    var remainingAttempts = MaxFailedAttempts - user.AccessFailedCount;
                    throw DSException.WithParam("TooManyFailedAttempts", remainingAttempts.ToString());
                }
                else
                {
                    throw new DSException("InvalidPassword");
                }

            }

            // ✅ Password đúng
            // Reset failed attempts
            user.AccessFailedCount = 0;
            user.LockoutEnd = null;
            user.LastLoginAt = DateTime.UtcNow;
            user.LastLoginIp = request.IpAddress;
            await _userWriteRepository.UpdateAsync(user, tenantId: null, cancellationToken);

            // Tạo session
            var sessionKey = await _sessionService.CreateOrUpdateSessionAsync(
                userId: user.Id,
                identityProviderCode: "local",
                deviceInfo: request.UserAgent,
                ipAddress: request.IpAddress,
                userAgent: request.UserAgent,
                lifetimeSeconds: 7776000 // 3 months (90 days)
            );

            return Result<LocalLoginResult>.Success(new LocalLoginResult
            {
                Success = true,
                Message = "Đăng nhập thành công",
                UserId = user.Id,
                IsAccountLocked = false,
                RemainingAttempts = MaxFailedAttempts
            });
        }
    }
}
