using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Commands.Roles
{
    /// <summary>
    /// Command để cập nhật role
    /// </summary>
    public class UpdateRoleCommand : ICommand<Result>
    {
        public string RoleId { get; set; } = string.Empty;
        public string? Name { get; set; }
        public string? Description { get; set; }
        public List<string>? PermissionCodes { get; set; }
        
        /// <summary>
        /// Tenant ID (nullable - null cho admin-scoped roles)
        /// </summary>
        public string? TenantId { get; set; }
    }
}
