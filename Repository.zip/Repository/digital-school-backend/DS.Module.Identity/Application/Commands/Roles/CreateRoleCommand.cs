using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Commands.Roles
{
    /// <summary>
    /// Command để tạo role mới
    /// </summary>
    public class CreateRoleCommand : ICommand<Result>
    {
        public string ClientId { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public List<string> PermissionCodes { get; set; } = new();
        
        /// <summary>
        /// Tenant ID (nullable - null cho admin-scoped roles)
        /// </summary>
        public string? TenantId { get; set; }
    }
}
