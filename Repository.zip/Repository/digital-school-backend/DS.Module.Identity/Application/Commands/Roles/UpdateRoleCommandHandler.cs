using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.Core.Infrastructure.Persistence.Redis;
using Microsoft.Extensions.Caching.Distributed;

namespace DS.Module.Identity.Application.Commands.Roles
{
    /// <summary>
    /// Handler cho UpdateRoleCommand
    /// </summary>
    public class UpdateRoleCommandHandler : ICommandHandler<UpdateRoleCommand, Result>
    {
        private readonly IAdminWriteRepository<RoleEntity> _roleWriteRepository;
        private readonly IAdminReadRepository<RoleEntity> _roleReadRepository;
        private readonly IAdminReadRepository<UserRoleAssignmentEntity> _userRoleAssignmentRepository;
        private readonly IDistributedCache _cache;

        public UpdateRoleCommandHandler(
            IAdminWriteRepository<RoleEntity> roleWriteRepository,
            IAdminReadRepository<RoleEntity> roleReadRepository,
            IAdminReadRepository<UserRoleAssignmentEntity> userRoleAssignmentRepository,
            IDistributedCache cache
                )
        {
            _roleWriteRepository = roleWriteRepository;
            _roleReadRepository = roleReadRepository;
            _userRoleAssignmentRepository = userRoleAssignmentRepository;
            _cache = cache;
        }

        public async Task<Result> Handle(UpdateRoleCommand request, CancellationToken cancellationToken)
        {
            // Get role
            var role = await _roleReadRepository.GetByIdAsync(
                request.RoleId,
                tenantId: request.TenantId,
                includeSoftDeleted: false,
                cancellationToken);

            if (role == null)
            {
                throw new DSException("RoleNotFound");
            }

            // Cannot update system roles
            if (role.IsSystem)
            {
                throw new DSException("CannotModifySystemRole");
            }

            // Update fields
            if (request.Name.IsNotNull())
                role.Name = request.Name;

            if (request.Description.IsNotNull())
                role.Description = request.Description;

            if (request.PermissionCodes != null)
                role.PermissionCodes = request.PermissionCodes;

            // Save changes (UpdatedAt, UpdatedBy, UpdatedByDisplay will be set automatically by Repository)
            await _roleWriteRepository.UpdateAsync(role, tenantId: request.TenantId, cancellationToken);

            // Invalidate user permissions cache cho tất cả users có role này
            // Tìm tất cả UserRoleAssignments có role này
            var affectedAssignments = await _userRoleAssignmentRepository.FilterAsync(
                a => a.RoleIds.Contains(request.RoleId) && a.IsActive,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            // Xóa cache permissions cho từng user-client combination
            foreach (var assignment in affectedAssignments)
            {
                var cacheKeys = new List<string>();

                // Nếu user có nhiều clients, cần xóa cache cho mỗi client
                // Ở đây chúng ta chỉ biết UserId và ClientId từ assignment
                var cacheKey = RedisKeys.Cache.UserPermissions(assignment.UserId, assignment.ClientId);
                await _cache.RemoveAsync(cacheKey, cancellationToken);
            }

            return Result.Success();
        }
    }
}
