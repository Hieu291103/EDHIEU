using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Commands.Roles
{
    /// <summary>
    /// Command để xóa role
    /// </summary>
    public class DeleteRoleCommand : ICommand<Result>
    {
        public string RoleId { get; set; } = string.Empty;
        
        /// <summary>
        /// Tenant ID (nullable - null cho admin-scoped roles)
        /// </summary>
        public string? TenantId { get; set; }
    }
}
