using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Commands.Roles
{
    /// <summary>
    /// Handler cho CreateRoleCommand
    /// </summary>
    public class CreateRoleCommandHandler : ICommandHandler<CreateRoleCommand, Result>
    {
        private readonly IAdminWriteRepository<RoleEntity> _roleWriteRepository;
        private readonly IAdminReadRepository<RoleEntity> _roleReadRepository;

        public CreateRoleCommandHandler(
            IAdminWriteRepository<RoleEntity> roleWriteRepository,
            IAdminReadRepository<RoleEntity> roleReadRepository)
        {
            _roleWriteRepository = roleWriteRepository;
            _roleReadRepository = roleReadRepository;
        }

        public async Task<Result> Handle(CreateRoleCommand request, CancellationToken cancellationToken)
        {
            // Check if role name already exists for this client and tenant
            var existingRoles = await _roleReadRepository.FilterAsync(
                r => r.ClientId == request.ClientId && 
                     r.Name == request.Name && 
                     r.TenantId == request.TenantId,
                tenantId: request.TenantId,
                includeSoftDeleted: false,
                cancellationToken);

            if (existingRoles.Any())
            {
                throw DSException.WithParam("RoleNameAlreadyExists", request.Name);
            }

            var role = new RoleEntity
            {
                ClientId = request.ClientId,
                Name = request.Name,
                Description = request.Description,
                PermissionCodes = request.PermissionCodes,
                IsSystem = false,
                TenantId = request.TenantId
            };

            await _roleWriteRepository.InsertAsync(role, cancellationToken);

            return Result.Success();
        }
    }
}
