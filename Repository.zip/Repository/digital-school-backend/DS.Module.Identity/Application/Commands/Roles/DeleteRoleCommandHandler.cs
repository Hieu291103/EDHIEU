using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Commands.Roles
{
    /// <summary>
    /// Handler cho DeleteRoleCommand
    /// </summary>
    public class DeleteRoleCommandHandler : ICommandHandler<DeleteRoleCommand, Result>
    {
        private readonly IAdminWriteRepository<RoleEntity> _roleWriteRepository;
        private readonly IAdminReadRepository<RoleEntity> _roleReadRepository;

        public DeleteRoleCommandHandler(
            IAdminWriteRepository<RoleEntity> roleWriteRepository,
            IAdminReadRepository<RoleEntity> roleReadRepository)
        {
            _roleWriteRepository = roleWriteRepository;
            _roleReadRepository = roleReadRepository;
        }

        public async Task<Result> Handle(DeleteRoleCommand request, CancellationToken cancellationToken)
        {
            // Get role
            var role = await _roleReadRepository.GetByIdAsync(
                request.RoleId,
                tenantId: request.TenantId,
                includeSoftDeleted: false,
                cancellationToken);

            if (role == null)
            {
                throw new DSException("RoleNotFound");
            }

            // Cannot delete system roles
            if (role.IsSystem)
            {
                throw new DSException("CannotDeleteSystemRole");
            }

            // Delete role (soft delete)
            await _roleWriteRepository.SoftDeleteAsync(request.RoleId, tenantId: request.TenantId, cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}
