using DS.Module.Identity.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Commands.OAuth
{
    /// <summary>
    /// Command: Exchange authorization code for access token
    /// </summary>
    public class ExchangeCodeCommand : ICommand<Result<TokenResponseDto>>
    {
        public required string Code { get; set; }
        public required string ClientId { get; set; }
        public string? ClientSecret { get; set; }
        public required string RedirectUri { get; set; }
        public required string GrantType { get; set; } = "authorization_code";
        public string? CodeVerifier { get; set; }
    }
}
