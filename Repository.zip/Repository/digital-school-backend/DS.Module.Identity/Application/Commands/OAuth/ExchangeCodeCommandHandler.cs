using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Constants;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;

namespace DS.Module.Identity.Application.Commands.OAuth
{
    public class ExchangeCodeCommandHandler : ICommandHandler<ExchangeCodeCommand, Result<TokenResponseDto>>
    {
        private readonly IAuthorizationCodeService _authCodeService;
        private readonly ITokenService _tokenService;
        private readonly IAppClientCache _appClientCache;

        public ExchangeCodeCommandHandler(
            IAuthorizationCodeService authCodeService,
            ITokenService tokenService,
            IAppClientCache appClientCache)
        {
            _authCodeService = authCodeService;
            _tokenService = tokenService;
            _appClientCache = appClientCache;
        }

        public async Task<Result<TokenResponseDto>> Handle(ExchangeCodeCommand request, CancellationToken cancellationToken)
        {
            // 1. Validate client (with caching)
            var client = await _appClientCache.GetCachedClientAsync(request.ClientId, cancellationToken);
            if (client == null)
            {
                throw new DSException("ClientNotFound");
            }

            // 2. Validate client secret (for confidential clients)
            if (client.ClientType == "confidential")
            {
                if (string.IsNullOrEmpty(request.ClientSecret))
                {
                    throw new DSException("ClientSecretRequired");
                }

                var isValidSecret = PasswordHelper.VerifyPassword(request.ClientSecret, client.ClientSecret);
                if (!isValidSecret)
                {
                    throw new DSException("InvalidClientSecret");
                }
            }

            // 3. Validate and consume authorization code
            var codeValidation = await _authCodeService.ValidateAndConsumeAsync(
                request.Code,
                request.ClientId,
                request.RedirectUri,
                request.CodeVerifier,
                cancellationToken);

            if (codeValidation == null)
            {
                throw new DSException("InvalidAuthorizationCode");
            }

            // 4. Generate tokens
            var jti = Guid.NewGuid().ToString();

            var additionalClaims = new Dictionary<string, string>();

            var accessToken = await _tokenService.CreateAccessTokenAsync(
                userId: codeValidation.UserId,
                clientId: request.ClientId,
                scopes: codeValidation.Scopes,
                lifetimeSeconds: client.AccessTokenLifetime ?? OAuthQueryParameters.TokenExpirationSeconds,
                identityProviderCode: codeValidation.IdentityProviderCode,
                additionalClaims: additionalClaims.Count > 0 ? additionalClaims : null,
                cancellationToken: cancellationToken);

            string? refreshToken = null;
            if (client.AllowOfflineAccess && codeValidation.Scopes.Contains("offline_access"))
            {
                refreshToken = await _tokenService.CreateRefreshTokenAsync(
                    userId: codeValidation.UserId,
                    clientId: request.ClientId,
                    jti: jti,
                    lifetimeSeconds: client.RefreshTokenLifetime ?? CookieConstants.RefreshTokenExpirationSeconds,
                    identityProviderCode: codeValidation.IdentityProviderCode,
                    cancellationToken: cancellationToken);
            }

            var response = new TokenResponseDto
            {
                AccessToken = accessToken,
                TokenType = "Bearer",
                ExpiresIn = client.AccessTokenLifetime ?? OAuthQueryParameters.TokenExpirationSeconds,
                RefreshToken = refreshToken,
            };

            return Result<TokenResponseDto>.Success(response);
        }
    }
}
