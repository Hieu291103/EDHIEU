using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Commands.OAuth
{
    /// <summary>
    /// Command: Revoke token (refresh token or access token)
    /// </summary>
    public class RevokeTokenCommand : ICommand<Result>
    {
        public required string Token { get; set; }
        public required string ClientId { get; set; }
        public string? ClientSecret { get; set; }
        public string? TokenTypeHint { get; set; } // "refresh_token" or "access_token"
    }
}
