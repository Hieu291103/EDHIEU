using DS.Module.Identity.Domain.Entities;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Commands.OAuth
{
    public class RevokeTokenCommandHandler : ICommandHandler<RevokeTokenCommand, Result>
    {
        private readonly ITokenService _tokenService;
        private readonly IAdminReadRepository<AppClientEntity> _clientRepository;

        public RevokeTokenCommandHandler(
            ITokenService tokenService,
            IAdminReadRepository<AppClientEntity> clientRepository)
        {
            _tokenService = tokenService;
            _clientRepository = clientRepository;
        }

        public async Task<Result> Handle(RevokeTokenCommand request, CancellationToken cancellationToken)
        {
            // 1. Validate client
            var clients = await _clientRepository.FilterAsync(
                c => c.ClientId == request.ClientId && c.IsActive,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            var client = clients.FirstOrDefault();
            if (client == null)
            {
                throw new DSException("ClientNotFound");
            }

            // 2. Validate client secret (for confidential clients)
            if (client.ClientType == "confidential")
            {
                if (string.IsNullOrEmpty(request.ClientSecret))
                {
                    throw new DSException("ClientSecretRequired");
                }

                var isValidSecret = PasswordHelper.VerifyPassword(request.ClientSecret, client.ClientSecret);
                if (!isValidSecret)
                {
                    throw new DSException("InvalidClientSecret");
                }
            }

            // 3. Revoke token
            await _tokenService.RevokeRefreshTokenAsync(
                request.Token,
                cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}
