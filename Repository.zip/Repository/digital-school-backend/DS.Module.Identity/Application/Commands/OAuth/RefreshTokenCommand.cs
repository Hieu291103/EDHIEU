using DS.Module.Identity.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Commands.OAuth
{
    /// <summary>
    /// Command: Refresh access token
    /// </summary>
    public class RefreshTokenCommand : ICommand<Result<TokenResponseDto>>
    {
        public required string RefreshToken { get; set; }
        public required string ClientId { get; set; }
        public string? ClientSecret { get; set; }
        public required string GrantType { get; set; } = "refresh_token";
    }
}
