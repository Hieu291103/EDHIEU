using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Constants;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;

namespace DS.Module.Identity.Application.Commands.OAuth
{
    public class RefreshTokenCommandHandler : ICommandHandler<RefreshTokenCommand, Result<TokenResponseDto>>
    {
        private readonly ITokenService _tokenService;
        private readonly IAppClientCache _appClientCache;

        public RefreshTokenCommandHandler(
            ITokenService tokenService,
            IAppClientCache appClientCache)
        {
            _tokenService = tokenService;
            _appClientCache = appClientCache;
        }

        public async Task<Result<TokenResponseDto>> Handle(RefreshTokenCommand request, CancellationToken cancellationToken)
        {
            // 1. Validate client (with caching)
            var client = await _appClientCache.GetCachedClientAsync(request.ClientId, cancellationToken);
            if (client == null)
            {
                throw new DSException("ClientNotFound");
            }

            // 2. Validate client secret (for confidential clients)
            if (client.ClientType == "confidential")
            {
                if (string.IsNullOrEmpty(request.ClientSecret))
                {
                    throw new DSException("ClientSecretRequired");
                }

                var isValidSecret = PasswordHelper.VerifyPassword(request.ClientSecret, client.ClientSecret);
                if (!isValidSecret)
                {
                    throw new DSException("InvalidClientSecret");
                }
            }

            // 3. Validate and consume refresh token
            var tokenValidation = await _tokenService.ValidateAndConsumeRefreshTokenAsync(
                request.RefreshToken,
                request.ClientId,
                cancellationToken: cancellationToken);

            if (tokenValidation == null)
            {
                throw new DSException("InvalidRefreshToken");
            }

            // 4. Generate new tokens
            var jti = Guid.NewGuid().ToString();

            var additionalClaims = new Dictionary<string, string>();


            var accessToken = await _tokenService.CreateAccessTokenAsync(
                userId: tokenValidation.UserId,
                clientId: request.ClientId,
                scopes: client.AllowedScopes,
                lifetimeSeconds: client.AccessTokenLifetime ?? OAuthQueryParameters.TokenExpirationSeconds,
                identityProviderCode: tokenValidation.IdentityProviderCode,
                additionalClaims: additionalClaims.Count > 0 ? additionalClaims : null,
                cancellationToken: cancellationToken);

            var response = new TokenResponseDto
            {
                AccessToken = accessToken,
                TokenType = "Bearer",
                ExpiresIn = client.AccessTokenLifetime ?? OAuthQueryParameters.TokenExpirationSeconds,
                RefreshToken = tokenValidation.NewRefreshToken,
            };

            return Result<TokenResponseDto>.Success(response);
        }
    }
}
