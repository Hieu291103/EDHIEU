using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Commands.Permissions
{
    /// <summary>
    /// Command để tạo permission mới
    /// </summary>
    public class CreatePermissionCommand : ICommand<Result>
    {
        public string ClientId { get; set; } = string.Empty;
        public string Code { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string? Module { get; set; }
        public string? Feature { get; set; }
        public string? Action { get; set; }
    }
}
