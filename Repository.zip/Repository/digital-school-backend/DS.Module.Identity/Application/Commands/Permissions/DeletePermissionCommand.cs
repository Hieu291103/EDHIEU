using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Commands.Permissions
{
    /// <summary>
    /// Command để xóa permission
    /// </summary>
    public class DeletePermissionCommand : ICommand<Result>
    {
        public string PermissionId { get; set; } = string.Empty;
    }
}
