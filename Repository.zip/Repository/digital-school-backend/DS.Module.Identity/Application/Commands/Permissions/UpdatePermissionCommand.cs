using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Commands.Permissions
{
    /// <summary>
    /// Command để cập nhật permission
    /// </summary>
    public class UpdatePermissionCommand : ICommand<Result>
    {
        public string PermissionId { get; set; } = string.Empty;
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? Module { get; set; }
        public string? Feature { get; set; }
        public string? Action { get; set; }
    }
}
