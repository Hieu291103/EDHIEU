using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Commands.Permissions
{
    /// <summary>
    /// Handler cho CreatePermissionCommand
    /// </summary>
    public class CreatePermissionCommandHandler : ICommandHandler<CreatePermissionCommand, Result>
    {
        private readonly IAdminWriteRepository<PermissionEntity> _permissionWriteRepository;
        private readonly IAdminReadRepository<PermissionEntity> _permissionReadRepository;

        public CreatePermissionCommandHandler(
            IAdminWriteRepository<PermissionEntity> permissionWriteRepository,
            IAdminReadRepository<PermissionEntity> permissionReadRepository)
        {
            _permissionWriteRepository = permissionWriteRepository;
            _permissionReadRepository = permissionReadRepository;
        }

        public async Task<Result> Handle(CreatePermissionCommand request, CancellationToken cancellationToken)
        {
            // Check if permission code already exists for this client
            var existingPermissions = await _permissionReadRepository.FilterAsync(
                p => p.ClientId == request.ClientId && p.Code == request.Code,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (existingPermissions.Any())
            {
                throw DSException.WithParam("PermissionCodeAlreadyExists", request.Code);
            }

            var permission = new PermissionEntity
            {
                ClientId = request.ClientId,
                Code = request.Code,
                Name = request.Name,
                Description = request.Description,
                Module = request.Module,
                Feature = request.Feature,
                Action = request.Action
            };

            await _permissionWriteRepository.InsertAsync(permission, cancellationToken);

            return Result.Success();
        }
    }
}
