using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Commands.Permissions
{
    /// <summary>
    /// Handler cho DeletePermissionCommand
    /// </summary>
    public class DeletePermissionCommandHandler : ICommandHandler<DeletePermissionCommand, Result>
    {
        private readonly IAdminWriteRepository<PermissionEntity> _permissionWriteRepository;
        private readonly IAdminReadRepository<PermissionEntity> _permissionReadRepository;

        public DeletePermissionCommandHandler(
            IAdminWriteRepository<PermissionEntity> permissionWriteRepository,
            IAdminReadRepository<PermissionEntity> permissionReadRepository)
        {
            _permissionWriteRepository = permissionWriteRepository;
            _permissionReadRepository = permissionReadRepository;
        }

        public async Task<Result> Handle(DeletePermissionCommand request, CancellationToken cancellationToken)
        {
            // Get permission
            var permission = await _permissionReadRepository.GetByIdAsync(
                request.PermissionId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (permission == null)
            {
                throw new DSException("PermissionNotFound");
            }

            // Delete permission (soft delete)
            await _permissionWriteRepository.SoftDeleteAsync(request.PermissionId, tenantId: null, cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}
