using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Commands.Permissions
{
    /// <summary>
    /// Handler cho UpdatePermissionCommand
    /// </summary>
    public class UpdatePermissionCommandHandler : ICommandHandler<UpdatePermissionCommand, Result>
    {
        private readonly IAdminWriteRepository<PermissionEntity> _permissionWriteRepository;
        private readonly IAdminReadRepository<PermissionEntity> _permissionReadRepository;

        public UpdatePermissionCommandHandler(
            IAdminWriteRepository<PermissionEntity> permissionWriteRepository,
            IAdminReadRepository<PermissionEntity> permissionReadRepository)
        {
            _permissionWriteRepository = permissionWriteRepository;
            _permissionReadRepository = permissionReadRepository;
        }

        public async Task<Result> Handle(UpdatePermissionCommand request, CancellationToken cancellationToken)
        {
            // Get permission
            var permission = await _permissionReadRepository.GetByIdAsync(
                request.PermissionId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (permission == null)
            {
                throw new DSException("PermissionNotFound");
            }

            // Update fields
            if (request.Name.IsNotNull())
                permission.Name = request.Name;

            if (request.Code.IsNotNull())
                permission.Code = request.Code;

            if (request.Description.IsNotNull())
                permission.Description = request.Description;

            if (request.Module.IsNotNull())
                permission.Module = request.Module;

            if (request.Feature.IsNotNull())
                permission.Feature = request.Feature;

            if (request.Action.IsNotNull())
                permission.Action = request.Action;

            // Save changes (UpdatedAt, UpdatedBy, UpdatedByDisplay will be set automatically by Repository)
            await _permissionWriteRepository.UpdateAsync(permission, tenantId: null, cancellationToken);

            return Result.Success();
        }
    }
}
