using DS.Module.Identity.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Queries.OAuth
{
    /// <summary>
    /// Query: Get user info from access token (OIDC UserInfo endpoint)
    /// </summary>
    public class GetUserInfoQuery : IQuery<Result<UserInfoDto>>
    {
        public required string AccessToken { get; set; }
    }
}
