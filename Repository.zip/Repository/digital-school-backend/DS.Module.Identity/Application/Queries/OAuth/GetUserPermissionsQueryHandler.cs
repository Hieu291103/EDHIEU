using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Entities;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.Core.Infrastructure.Persistence.Redis;
using Microsoft.Extensions.Caching.Distributed;
using System.Text.Json;

namespace DS.Module.Identity.Application.Queries.OAuth
{
    /// <summary>
    /// Query Handler: Lấy danh sách permissions của user với caching
    /// 
    /// Flow:
    /// 1. Kiểm tra cache (Redis key: user-permissions:{userId}:{clientId})
    /// 2. Nếu miss, query UserRoleAssignment -> lấy roleIds
    /// 3. Query Role collection để lấy permissionCodes từ roleIds
    /// 4. Query Permission collection để lấy thông tin chi tiết (name, description, module, feature)
    /// 5. Tổ chức dữ liệu theo Module -> Feature -> Permission
    /// 6. Cache kết quả 1 giờ
    /// </summary>
    public class GetUserPermissionsQueryHandler : IQueryHandler<GetUserPermissionsQuery, Result<UserPermissionsDto>>
    {
        private readonly IAdminReadRepository<UserRoleAssignmentEntity> _userRoleAssignmentRepository;
        private readonly IAdminReadRepository<RoleEntity> _roleRepository;
        private readonly IAdminReadRepository<PermissionEntity> _permissionRepository;
        private readonly IPermissionHelper _permissionHelper;
        private readonly IDistributedCache _cache;
        private static readonly TimeSpan PermissionsCacheDuration = TimeSpan.FromHours(24);

        public GetUserPermissionsQueryHandler(
            IAdminReadRepository<UserRoleAssignmentEntity> userRoleAssignmentRepository,
            IAdminReadRepository<RoleEntity> roleRepository,
            IAdminReadRepository<PermissionEntity> permissionRepository,
            IPermissionHelper permissionHelper,
            IDistributedCache cache)
        {
            _userRoleAssignmentRepository = userRoleAssignmentRepository;
            _roleRepository = roleRepository;
            _permissionRepository = permissionRepository;
            _permissionHelper = permissionHelper;
            _cache = cache;
        }

        public async Task<Result<UserPermissionsDto>> Handle(GetUserPermissionsQuery request, CancellationToken cancellationToken)
        {

            // 1. Validate input
            if (string.IsNullOrWhiteSpace(request.UserId) || string.IsNullOrWhiteSpace(request.ClientId))
            {
                throw new DSException("InvalidInput");
            }

            // 2. Try to get from cache
            var cacheKey = RedisKeys.Cache.UserPermissions(request.UserId, request.ClientId);
            var cachedJson = await _cache.GetStringAsync(cacheKey, cancellationToken);

            if (!string.IsNullOrEmpty(cachedJson))
            {
                try
                {
                    var cached = JsonSerializer.Deserialize<UserPermissionsDto>(cachedJson);
                    if (cached != null)
                    {
                        return Result<UserPermissionsDto>.Success(cached);
                    }
                }
                catch
                {
                    // Invalid cache, continue to fetch fresh data
                    await _cache.RemoveAsync(cacheKey, cancellationToken);
                }
            }

            // 3. Get user role assignment
            var assignments = await _userRoleAssignmentRepository.FilterAsync(
                a => a.UserId == request.UserId && a.ClientId == request.ClientId && a.IsActive,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            var assignment = assignments.FirstOrDefault();
            if (assignment == null)
            {
                // User không có role gì cho client này, trả về empty permissions
                var emptyResult = new UserPermissionsDto
                {
                    UserId = request.UserId,
                    ClientId = request.ClientId,
                    PermissionCodes = new(),
                    Modules = new(),
                    RoleIds = new(),
                    TenantIds = new(),
                    IsAllTenants = false
                };

                // Cache empty result 15 phút
                await CachePermissionsAsync(cacheKey, emptyResult, TimeSpan.FromMinutes(5), cancellationToken);
                return Result<UserPermissionsDto>.Success(emptyResult);
            }

            // 4. Get roles từ roleIds
            var roleIds = assignment.RoleIds?.Where(id => !string.IsNullOrWhiteSpace(id)).Distinct().ToList()
                ?? new List<string>();

            var roles = new List<RoleEntity>();
            if (roleIds.Count > 0)
            {
                var roleList = await _roleRepository.FilterAsync(
                    r => roleIds.Contains(r.Id) && r.ClientId == request.ClientId,
                    tenantId: null,
                    includeSoftDeleted: false,
                    cancellationToken);
                roles = roleList.ToList();
            }

            // 5. Collect all permission codes từ roles
            var permissionCodes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var role in roles)
            {
                if (role.PermissionCodes != null)
                {
                    foreach (var code in role.PermissionCodes.Where(c => !string.IsNullOrWhiteSpace(c)))
                    {
                        permissionCodes.Add(code);
                    }
                }
            }

            // Nếu chỉ cần codes (dùng để check authorization nhanh)
            if (request.CodesOnly)
            {
                var codesResult = new UserPermissionsDto
                {
                    UserId = request.UserId,
                    ClientId = request.ClientId,
                    PermissionCodes = permissionCodes.ToList(),
                    RoleIds = roleIds,
                    TenantIds = assignment.TenantIds ?? new List<string>(),
                    Modules = new() // Empty khi CodesOnly = true
                };

                await CachePermissionsAsync(cacheKey, codesResult, PermissionsCacheDuration, cancellationToken);

                return Result<UserPermissionsDto>.Success(codesResult);
            }

            // 6. Get permission details
            var permissions = new List<PermissionEntity>();
            if (permissionCodes.Count > 0)
            {
                var permissionList = await _permissionRepository.FilterAsync(
                    p => permissionCodes.Contains(p.Code) && p.ClientId == request.ClientId,
                    tenantId: null,
                    includeSoftDeleted: false,
                    cancellationToken);
                permissions = permissionList.ToList();
            }

            // 7. Organize permissions by Module -> Feature -> Permission
            var modules = OrganizePermissionsByModuleFeature(permissions);

            // 8. Build response
            var result = new UserPermissionsDto
            {
                UserId = request.UserId,
                ClientId = request.ClientId,
                PermissionCodes = permissionCodes.ToList(),
                Modules = modules,
                RoleIds = roleIds,
                TenantIds = assignment.TenantIds ?? new List<string>()
            };

            // 9. Cache result
            await CachePermissionsAsync(cacheKey, result, PermissionsCacheDuration, cancellationToken);

            return Result<UserPermissionsDto>.Success(result);
        }

        /// <summary>
        /// Tổ chức permissions theo cấu trúc Module -> Feature -> Permission
        /// </summary>
        private List<ModuleDisplayDto> OrganizePermissionsByModuleFeature(List<PermissionEntity> permissions)
        {
            var moduleDict = new Dictionary<string, ModuleDisplayDto>(StringComparer.OrdinalIgnoreCase);

            foreach (var permission in permissions)
            {
                if (string.IsNullOrWhiteSpace(permission.Module) || string.IsNullOrWhiteSpace(permission.Feature))
                    continue;

                // Get or create module
                if (!moduleDict.TryGetValue(permission.Module, out var module))
                {
                    module = new ModuleDisplayDto
                    {
                        Code = permission.Module,
                        Name = _permissionHelper.GetModuleDisplayName(permission.Module) ?? permission.Module,
                        Features = new()
                    };
                    moduleDict[permission.Module] = module;
                }

                // Get or create feature
                var feature = module.Features.FirstOrDefault(f =>
                    f.Code.Equals(permission.Feature, StringComparison.OrdinalIgnoreCase));

                if (feature == null)
                {
                    feature = new FeatureDisplayDto
                    {
                        Code = permission.Feature,
                        Name = _permissionHelper.GetFeatureDisplayName(permission.Feature) ?? permission.Feature,
                        Permissions = new()
                    };
                    module.Features.Add(feature);
                }

                // Add permission to feature
                feature.Permissions.Add(new PermissionItemDto
                {
                    Code = permission.Code,
                    Name = permission.Name,
                    Description = permission.Description,
                    Action = permission.Action ?? string.Empty
                });
            }

            return moduleDict.Values.OrderBy(m => m.Code).ToList();
        }

        /// <summary>
        /// Cache permissions data
        /// </summary>
        private async Task CachePermissionsAsync(
            string cacheKey,
            UserPermissionsDto permissions,
            TimeSpan duration,
            CancellationToken cancellationToken)
        {
            try
            {
                var json = JsonSerializer.Serialize(permissions);
                await _cache.SetStringAsync(
                    cacheKey,
                    json,
                    new DistributedCacheEntryOptions
                    {
                        AbsoluteExpirationRelativeToNow = duration
                    },
                    cancellationToken);
            }
            catch
            {
                // Cache failure không gây lỗi, chỉ skip cache
            }
        }
    }
}
