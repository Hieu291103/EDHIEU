using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Entities;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using System.Security.Claims;

namespace DS.Module.Identity.Application.Queries.OAuth
{
    public class GetUserInfoQueryHandler : IQueryHandler<GetUserInfoQuery, Result<UserInfoDto>>
    {
        private readonly ITokenService _tokenService;
        private readonly IAdminReadRepository<UserEntity> _userRepository;

        public GetUserInfoQueryHandler(
            ITokenService tokenService,
            IAdminReadRepository<UserEntity> userRepository)
        {
            _tokenService = tokenService;
            _userRepository = userRepository;
        }

        public async Task<Result<UserInfoDto>> Handle(GetUserInfoQuery request, CancellationToken cancellationToken)
        {
            // 1. Validate access token
            var principal = await _tokenService.ValidateAccessTokenAsync(request.AccessToken, cancellationToken);
            if (principal == null)
            {
                throw new DSException("InvalidAccessToken");
            }

            // 2. Extract user ID from token
            var userIdClaim = principal.FindFirst(ClaimTypes.NameIdentifier)
                ?? principal.FindFirst("sub");

            if (userIdClaim == null)
            {
                throw new DSException("InvalidToken");
            }

            // 3. Get user from database
            var users = await _userRepository.FilterAsync(
                u => u.Id == userIdClaim.Value,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            var user = users.FirstOrDefault();
            if (user == null)
            {
                throw new DSException("UserNotFound");
            }

            // 4. Build UserInfo response
            var userInfo = new UserInfoDto
            {
                Sub = user.Id,
                Name = user.FullName,
                Email = user.Email,
                EmailVerified = user.EmailVerified,
                Title = user.Title,
                TenantId = user.TenantId,
                PhoneNumber = user.PhoneNumber,
                PhoneNumberVerified = user.PhoneNumberVerified,
                DateOfBirth = user.DateOfBirth,
                EducationCode = user.EducationCode,
                Picture = user.AvatarUrl,
                PreferredUsername = user.Username,
                AdditionalClaims = user.Claims
            };

            return Result<UserInfoDto>.Success(userInfo);
        }
    }
}
