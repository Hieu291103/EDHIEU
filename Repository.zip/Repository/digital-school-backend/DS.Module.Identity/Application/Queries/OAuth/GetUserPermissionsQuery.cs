using DS.Module.Identity.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Queries.OAuth
{
    /// <summary>
    /// Query: Lấy danh sách permissions của user cho client hiện tại
    /// Dữ liệu được lấy từ UserRoleAssignment -> Role -> Permission
    /// userId và clientId đã được extract từ Token claims
    /// </summary>
    public class GetUserPermissionsQuery : IQuery<Result<UserPermissionsDto>>
    {
        /// <summary>
        /// User ID (từ token claim "userId")
        /// </summary>
        public required string UserId { get; set; }

        /// <summary>
        /// Client ID (từ token claim "clientId")
        /// </summary>
        public required string ClientId { get; set; }

        /// <summary>
        /// Nếu true, chỉ trả về flat list permission codes (nhanh hơn, dùng cho check authorization)
        /// Nếu false, trả về đầy đủ thông tin tổ chức theo Module/Feature (dùng cho UI)
        /// </summary>
        public bool CodesOnly { get; set; } = false;
    }
}
