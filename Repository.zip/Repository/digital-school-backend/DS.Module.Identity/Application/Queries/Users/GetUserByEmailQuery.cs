using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.CQRS.DTOs.Users;

namespace DS.Module.Identity.Application.Queries.Users
{
    /// <summary>
    /// Query để lấy user theo email
    /// </summary>
    public class GetUserByEmailQuery : IQuery<UserDto?>
    {
        public string Email { get; set; } = string.Empty;
    }
}
