using AutoMapper;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.DTOs.Users;
using DS.Shared.CQRS.Queries.Users;
using MongoDB.Bson;
using MongoDB.Driver;

namespace DS.Module.Identity.Application.Queries.Users
{
    /// <summary>
    /// Handler cho GetUserListQuery
    /// </summary>
    public class GetUserListQueryHandler : IQueryHandler<SharedGetUserListQuery, PagedResult<UserListDto>>
    {
        private readonly IAdminReadRepository<UserEntity> _userRepository;
        private readonly IMapper _mapper;

        public GetUserListQueryHandler(
            IAdminReadRepository<UserEntity> userRepository,
            IMapper mapper)
        {
            _userRepository = userRepository;
            _mapper = mapper;
        }

        public async Task<PagedResult<UserListDto>> Handle(SharedGetUserListQuery request, CancellationToken cancellationToken)
        {
            var fb = Builders<UserEntity>.Filter;
            var filter = fb.Empty;

            // Filter theo UserType
            if (request.UserType.HasValue)
                filter = fb.And(filter, fb.Eq(x => x.UserType, request.UserType.Value));

            if (!string.IsNullOrWhiteSpace(request.TenantId))
                filter = fb.And(filter, fb.Eq(x => x.TenantId, request.TenantId.Trim()));

            // Filter theo trạng thái khóa (LockoutEnd > now)
            if (request.IsLocked.HasValue)
            {
                var lockFilter = request.IsLocked.Value
                    ? fb.Gt(x => x.LockoutEnd, DateTime.UtcNow)
                    : fb.Or(fb.Eq(x => x.LockoutEnd, null), fb.Lte(x => x.LockoutEnd, DateTime.UtcNow));
                filter = fb.And(filter, lockFilter);
            }

            // Keyword search trên Username, Email, FullName
            if (!string.IsNullOrWhiteSpace(request.Keyword))
            {
                var regex = new BsonRegularExpression(request.Keyword.Trim(), "i");
                filter = fb.And(filter, fb.Or(
                    fb.Regex(x => x.Username, regex),
                    fb.Regex(x => x.Email, regex),
                    fb.Regex(x => x.FullName!, regex),
                     fb.Regex(x => x.PhoneNumber!, regex)));
            }

            var includeSoftDeleted = request.IsDeleted ?? false;

            var pagedResult = await _userRepository.PagedFilterAsync(
                filter,
                request.PageIndex ?? 1,
                request.PageSize ?? 50,
                tenantId: null,
                includeSoftDeleted: includeSoftDeleted,
                cancellationToken: cancellationToken);

            var items = _mapper.Map<List<UserListDto>>(pagedResult.Items);

            return new PagedResult<UserListDto>
            {
                Items = items,
                PageIndex = pagedResult.PageIndex,
                PageSize = pagedResult.PageSize,
                Total = pagedResult.Total,
                Page = pagedResult.Page
            };
        }
    }
}
