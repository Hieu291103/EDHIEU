using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Application.Queries.Roles;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using MongoDB.Driver;

namespace DS.Module.Identity.Application.Queries.Users
{
    /// <summary>
    /// Handler cho GetUserRolesByUserIdQuery
    /// 
    /// Flow:
    /// 1. Lấy danh sách UserRoleAssignmentEntity theo UserId
    /// 2. Lấy danh sách AppClientEntity để map ClientName
    /// 3. Cho mỗi UserRoleAssignment, gọi GetAllRolesQuery để lấy RoleList
    /// 4. Map và trả về List<UserRoleDto>
    /// </summary>
    public class GetUserRolesByUserIdQueryHandler : IQueryHandler<GetUserRolesByUserIdQuery, List<UserRoleDto>>
    {
        private readonly IAdminReadRepository<UserRoleAssignmentEntity> _userRoleAssignmentRepository;
        private readonly IAdminReadRepository<AppClientEntity> _appClientRepository;
        private readonly IMediator _mediator;

        public GetUserRolesByUserIdQueryHandler(
            IAdminReadRepository<UserRoleAssignmentEntity> userRoleAssignmentRepository,
            IAdminReadRepository<AppClientEntity> appClientRepository,
            IMediator mediator)
        {
            _userRoleAssignmentRepository = userRoleAssignmentRepository;
            _appClientRepository = appClientRepository;
            _mediator = mediator;
        }

        public async Task<List<UserRoleDto>> Handle(GetUserRolesByUserIdQuery request, CancellationToken cancellationToken)
        {
            // Validate input
            if (string.IsNullOrWhiteSpace(request.UserId))
            {
                return new List<UserRoleDto>();
            }

            // 1. Get all AppClients (lấy trước để luôn có cấu trúc)
            var clientFilter = Builders<AppClientEntity>.Filter.Empty;
            var appClients = await _appClientRepository.FilterAsync(
                clientFilter,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (!appClients.Any())
            {
                return new List<UserRoleDto>();
            }

            // 2. Get all UserRoleAssignments for the user
            var filterBuilder = Builders<UserRoleAssignmentEntity>.Filter;
            var filter = filterBuilder.Eq(u => u.UserId, request.UserId);

            var assignments = await _userRoleAssignmentRepository.FilterAsync(
                filter,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            // Create a lookup dictionary for assignments by ClientId
            var assignmentDict = assignments.ToDictionary(a => a.ClientId, a => a);

            // 3. Build UserRoleDto list for all clients
            var result = new List<UserRoleDto>();

            foreach (var client in appClients)
            {
                // Check if user has assignment for this client
                var assignment = assignmentDict.ContainsKey(client.ClientId)
                    ? assignmentDict[client.ClientId]
                    : null;

                List<RoleDataDto> roleDataList = new();

                // Get roles for this client (if user has assignment)
                var getAllRolesQuery = new GetAllRolesQuery
                {
                    ClientId = client.ClientId,
                    IncludeSystemRoles = true,
                    TenantId = null
                };

                var roleList = await _mediator.Send(getAllRolesQuery, cancellationToken);
                roleDataList = roleList.Select(r => new RoleDataDto
                {
                    Id = r.Id,
                    Name = r.Name,
                    Description = r.Description,
                    IsSystem = r.IsSystem
                }).ToList();

                var userRoleDto = new UserRoleDto
                {
                    UserId = request.UserId,
                    ClientId = client.ClientId,
                    ClientName = client.ClientName,
                    RoleIds = assignment?.RoleIds ?? new List<string>(),
                    TenantIds = assignment?.TenantIds ?? new List<string>(),
                    IsAllTenants = assignment?.IsAllTenants ?? false,
                    RoleList = roleDataList
                };

                result.Add(userRoleDto);
            }

            return result;
        }
    }
}
