using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Queries.Users;

namespace DS.Module.Identity.Application.Queries.Users
{
    /// <summary>
    /// Handler cho CheckUserNameExistsQuery
    /// </summary>
    public class CheckUserNameExistsQueryHandler : IQueryHandler<SharedCheckUserNameExistsQuery, bool>
    {
        private readonly IAdminReadRepository<UserEntity> _userRepository;

        public CheckUserNameExistsQueryHandler(IAdminReadRepository<UserEntity> userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<bool> Handle(SharedCheckUserNameExistsQuery request, CancellationToken cancellationToken)
        {
            var users = await _userRepository.FilterAsync(
                u => u.Username == request.UserName,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            return users.Any();
        }
    }
}
