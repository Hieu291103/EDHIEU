using DS.Module.Identity.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Identity.Application.Queries.Users
{
    /// <summary>
    /// Query để lấy tất cả user roles theo UserId, kèm danh sách roles từ mỗi client
    /// </summary>
    public class GetUserRolesByUserIdQuery : IQuery<List<UserRoleDto>>
    {
        public string UserId { get; set; } = string.Empty;
    }
}
