using AutoMapper;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.DTOs.Users;
using DS.Shared.CQRS.Queries.Users;

namespace DS.Module.Identity.Application.Queries.Users
{
    /// <summary>
    /// Handler cho GetUserByIdQuery
    /// </summary>
    public class GetUserByIdQueryHandler : IQueryHandler<SharedGetUserByIdQuery, UserDto?>
    {
        private readonly IAdminReadRepository<UserEntity> _userRepository;
        private readonly IMapper _mapper;

        public GetUserByIdQueryHandler(
            IAdminReadRepository<UserEntity> userRepository,
            IMapper mapper)
        {
            _userRepository = userRepository;
            _mapper = mapper;
        }

        public async Task<UserDto?> Handle(SharedGetUserByIdQuery request, CancellationToken cancellationToken)
        {
            var user = await _userRepository.GetByIdAsync(
                request.UserId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (user == null)
                return null;

            return _mapper.Map<UserDto>(user);
        }
    }
}
