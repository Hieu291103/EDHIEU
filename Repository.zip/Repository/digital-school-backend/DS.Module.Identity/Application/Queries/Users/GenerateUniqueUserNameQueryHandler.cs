using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Queries.Users;

namespace DS.Module.Identity.Application.Queries.Users
{
    /// <summary>
    /// Handler cho GenerateUniqueUserNameQuery
    /// </summary>
    public class GenerateUniqueUserNameQueryHandler : IQueryHandler<SharedGenerateUniqueUserNameQuery, string>
    {
        private readonly IAdminReadRepository<UserEntity> _userRepository;

        public GenerateUniqueUserNameQueryHandler(IAdminReadRepository<UserEntity> userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<string> Handle(SharedGenerateUniqueUserNameQuery request, CancellationToken cancellationToken)
        {
            string username;

            while (true)
            {
                // Sinh username từ FullName và Domain sử dụng StringHelper
                // Mỗi lần gọi sẽ tạo username mới với 4 chữ số ngẫu nhiên khác nhau
                username = StringHelper.GenerateUsername(request.FullName, request.Domain);

                // Kiểm tra username đã tồn tại chưa
                var existingUsers = await _userRepository.FilterAsync(
                    u => u.Username == username,
                    tenantId: null,
                    includeSoftDeleted: false,
                    cancellationToken);

                // Nếu username không tồn tại, trả về nó
                if (!existingUsers.Any())
                {
                    return username;
                }

                // Nếu tồn tại, vòng lặp sẽ tiếp tục và sinh username mới
            }
        }
    }
}
