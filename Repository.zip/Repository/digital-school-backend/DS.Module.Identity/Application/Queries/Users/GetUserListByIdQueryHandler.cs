using AutoMapper;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.DTOs.Users;
using DS.Shared.CQRS.Queries.Users;
using MongoDB.Driver;

namespace DS.Module.Identity.Application.Queries.Users
{
    /// <summary>
    /// Handler cho GetUserListByIdQuery - lấy danh sách user theo ID (batch query)
    /// </summary>
    public class GetUserListByIdQueryHandler : IQueryHandler<SharedGetUserListByIdQuery, List<UserListDto>>
    {
        private readonly IAdminReadRepository<UserEntity> _userRepository;
        private readonly IMapper _mapper;

        public GetUserListByIdQueryHandler(
            IAdminReadRepository<UserEntity> userRepository,
            IMapper mapper)
        {
            _userRepository = userRepository;
            _mapper = mapper;
        }

        public async Task<List<UserListDto>> Handle(SharedGetUserListByIdQuery request, CancellationToken cancellationToken)
        {
            if (request.UserIds == null || request.UserIds.Count == 0)
            {
                return new List<UserListDto>();
            }

            // Tạo filter để lấy tất cả user có ID trong danh sách
            var filterBuilder = Builders<UserEntity>.Filter;
            var filter = filterBuilder.In(x => x.Id, request.UserIds);

            // Lấy danh sách user
            var users = await _userRepository.FilterAsync(
                filter,
                tenantId: null,
                includeSoftDeleted: request.IncludeSoftDeleted,
                cancellationToken: cancellationToken);

            // Map sang UserDto using AutoMapper
            var userDtos = _mapper.Map<List<UserListDto>>(users.ToList());

            return userDtos;
        }
    }
}
