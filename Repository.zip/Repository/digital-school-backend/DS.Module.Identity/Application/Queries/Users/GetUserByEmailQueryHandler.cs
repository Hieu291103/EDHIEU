using AutoMapper;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.DTOs.Users;

namespace DS.Module.Identity.Application.Queries.Users
{
    /// <summary>
    /// Handler cho GetUserByEmailQuery
    /// </summary>
    public class GetUserByEmailQueryHandler : IQueryHandler<GetUserByEmailQuery, UserDto?>
    {
        private readonly IAdminReadRepository<UserEntity> _userRepository;
        private readonly IMapper _mapper;

        public GetUserByEmailQueryHandler(
            IAdminReadRepository<UserEntity> userRepository,
            IMapper mapper)
        {
            _userRepository = userRepository;
            _mapper = mapper;
        }

        public async Task<UserDto?> Handle(GetUserByEmailQuery request, CancellationToken cancellationToken)
        {
            var users = await _userRepository.FilterAsync(
                u => u.Email == request.Email,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            var user = users.FirstOrDefault();
            if (user == null)
                return null;

            return _mapper.Map<UserDto>(user);
        }
    }
}
