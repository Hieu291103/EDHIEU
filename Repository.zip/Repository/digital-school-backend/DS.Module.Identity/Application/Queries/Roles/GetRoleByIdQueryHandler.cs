using AutoMapper;
using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Queries.Roles
{
    /// <summary>
    /// Handler cho GetRoleByIdQuery
    /// </summary>
    public class GetRoleByIdQueryHandler : IQueryHandler<GetRoleByIdQuery, RoleDto?>
    {
        private readonly IAdminReadRepository<RoleEntity> _roleRepository;
        private readonly IMapper _mapper;

        public GetRoleByIdQueryHandler(
            IAdminReadRepository<RoleEntity> roleRepository,
            IMapper mapper)
        {
            _roleRepository = roleRepository;
            _mapper = mapper;
        }

        public async Task<RoleDto?> Handle(GetRoleByIdQuery request, CancellationToken cancellationToken)
        {
            var role = await _roleRepository.GetByIdAsync(
                request.RoleId,
                tenantId: request.TenantId,
                includeSoftDeleted: false,
                cancellationToken);

            if (role == null)
                return null;

            return _mapper.Map<RoleDto>(role);
        }
    }
}
