using DS.Module.Identity.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Requests;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Queries.Roles
{
    /// <summary>
    /// Query để lấy danh sách role của một client với phân trang
    /// </summary>
    public class GetRoleListQuery : FilterRequest, IQuery<PagedResult<RoleDto>>
    {
        public string ClientId { get; set; } = string.Empty;
        public bool? IncludeSystemRoles { get; set; } = false;
        
        /// <summary>
        /// Tenant ID (nullable - null cho admin-scoped roles)
        /// </summary>
        public string? TenantId { get; set; }
    }
}
