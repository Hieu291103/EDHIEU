using AutoMapper;
using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Driver;

namespace DS.Module.Identity.Application.Queries.Roles
{
    /// <summary>
    /// Handler cho GetRoleListQuery
    /// </summary>
    public class GetRoleListQueryHandler : IQueryHandler<GetRoleListQuery, PagedResult<RoleDto>>
    {
        private readonly IAdminReadRepository<RoleEntity> _roleRepository;
        private readonly IMapper _mapper;

        public GetRoleListQueryHandler(
            IAdminReadRepository<RoleEntity> roleRepository,
            IMapper mapper)
        {
            _roleRepository = roleRepository;
            _mapper = mapper;
        }

        public async Task<PagedResult<RoleDto>> Handle(GetRoleListQuery request, CancellationToken cancellationToken)
        {
            // Build filter using MongoDB native builder
            var filterBuilder = Builders<RoleEntity>.Filter;
            var filter = filterBuilder.Eq(r => r.ClientId, request.ClientId);

            // Add TenantId filter if provided
            if (!string.IsNullOrEmpty(request.TenantId))
            {
                filter = filterBuilder.And(filter, filterBuilder.Eq(r => r.TenantId, request.TenantId));
            }

            // Add IsSystem filter
            if (request.IncludeSystemRoles.HasValue && !request.IncludeSystemRoles.Value)
            {
                filter = filterBuilder.And(filter, filterBuilder.Eq(r => r.IsSystem, false));
            }

            // Add Keyword search on Name (case-insensitive, simple regex)
            if (!string.IsNullOrEmpty(request.Keyword))
            {
                var keywordTrimmed = request.Keyword.Trim();
                var regex = new MongoDB.Bson.BsonRegularExpression(keywordTrimmed, "i"); // "i" for case-insensitive
                var keywordFilter = filterBuilder.Regex(r => r.Name, regex);
                filter = filterBuilder.And(filter, keywordFilter);
            }

            // Apply pagination using repository method
            var pagedResult = await _roleRepository.PagedFilterAsync(
                filter,
                request.PageIndex ?? 1,
                request.PageSize ?? 50,
                tenantId: request.TenantId,
                includeSoftDeleted: false,
                cancellationToken);

            // Map items to DTO
            var dtos = _mapper.Map<List<RoleDto>>(pagedResult.Items);

            return new PagedResult<RoleDto>
            {
                Items = dtos,
                Total = pagedResult.Total,
                Page = pagedResult.Page,
                PageSize = pagedResult.PageSize,
                PageIndex = pagedResult.PageIndex
            };
        }
    }
}
