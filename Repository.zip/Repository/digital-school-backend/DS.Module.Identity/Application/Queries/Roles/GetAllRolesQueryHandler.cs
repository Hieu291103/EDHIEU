using AutoMapper;
using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Driver;

namespace DS.Module.Identity.Application.Queries.Roles
{
    /// <summary>
    /// Handler cho GetAllRolesQuery
    /// </summary>
    public class GetAllRolesQueryHandler : IQueryHandler<GetAllRolesQuery, List<RoleDto>>
    {
        private readonly IAdminReadRepository<RoleEntity> _roleRepository;
        private readonly IMapper _mapper;

        public GetAllRolesQueryHandler(
            IAdminReadRepository<RoleEntity> roleRepository,
            IMapper mapper)
        {
            _roleRepository = roleRepository;
            _mapper = mapper;
        }

        public async Task<List<RoleDto>> Handle(GetAllRolesQuery request, CancellationToken cancellationToken)
        {
            // Build filter using MongoDB native builder
            var filterBuilder = Builders<RoleEntity>.Filter;
            var filter = filterBuilder.Eq(r => r.ClientId, request.ClientId);

            // Add TenantId filter if provided
            if (!string.IsNullOrEmpty(request.TenantId))
            {
                filter = filterBuilder.And(filter, filterBuilder.Eq(r => r.TenantId, request.TenantId));
            }

            // Add IsSystem filter
            if (request.IncludeSystemRoles.HasValue && !request.IncludeSystemRoles.Value)
            {
                filter = filterBuilder.And(filter, filterBuilder.Eq(r => r.IsSystem, false));
            }

            // Get all roles matching the filter (no pagination)
            var roles = await _roleRepository.FilterAsync(
                filter,
                tenantId: request.TenantId,
                includeSoftDeleted: false,
                cancellationToken);

            // Map to DTO
            var dtos = _mapper.Map<List<RoleDto>>(roles);

            return dtos;
        }
    }
}
