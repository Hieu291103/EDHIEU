using DS.Module.Identity.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Identity.Application.Queries.Roles
{
    /// <summary>
    /// Query để lấy tất cả roles (không phân trang)
    /// </summary>
    public class GetAllRolesQuery : IQuery<List<RoleDto>>
    {
        public string ClientId { get; set; } = string.Empty;
        public bool? IncludeSystemRoles { get; set; } = true;

        /// <summary>
        /// Tenant ID (nullable - null cho admin-scoped roles)
        /// </summary>
        public string? TenantId { get; set; }
    }
}
