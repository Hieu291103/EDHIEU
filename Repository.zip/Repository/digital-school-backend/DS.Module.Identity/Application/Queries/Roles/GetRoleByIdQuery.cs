using DS.Module.Identity.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Identity.Application.Queries.Roles
{
    /// <summary>
    /// Query để lấy role theo ID
    /// </summary>
    public class GetRoleByIdQuery : IQuery<RoleDto?>
    {
        public string RoleId { get; set; } = string.Empty;
        
        /// <summary>
        /// Tenant ID (nullable - null cho admin-scoped roles)
        /// </summary>
        public string? TenantId { get; set; }
    }
}
