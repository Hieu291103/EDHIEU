using DS.Module.Identity.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Requests;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Identity.Application.Queries.Permissions
{
    /// <summary>
    /// Query để lấy danh sách permission của một client với phân trang
    /// </summary>
    public class GetPermissionListQuery : FilterRequest, IQuery<PagedResult<PermissionDto>>
    {
        public string ClientId { get; set; } = string.Empty;
        public string? Module { get; set; }
        public string? Feature { get; set; }
    }
}
