using AutoMapper;
using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Driver;

namespace DS.Module.Identity.Application.Queries.Permissions
{
    /// <summary>
    /// Handler cho GetPermissionListQuery
    /// </summary>
    public class GetPermissionListQueryHandler : IQueryHandler<GetPermissionListQuery, PagedResult<PermissionDto>>
    {
        private readonly IAdminReadRepository<PermissionEntity> _permissionRepository;
        private readonly IMapper _mapper;

        public GetPermissionListQueryHandler(
            IAdminReadRepository<PermissionEntity> permissionRepository,
            IMapper mapper)
        {
            _permissionRepository = permissionRepository;
            _mapper = mapper;
        }

        public async Task<PagedResult<PermissionDto>> Handle(GetPermissionListQuery request, CancellationToken cancellationToken)
        {
            // Build filter using MongoDB native builder
            var filterBuilder = Builders<PermissionEntity>.Filter;
            var filter = filterBuilder.Eq(p => p.ClientId, request.ClientId);

            // Add Module filter
            if (!string.IsNullOrEmpty(request.Module))
            {
                filter = filterBuilder.And(filter, filterBuilder.Eq(p => p.Module, request.Module));
            }

            // Add Feature filter
            if (!string.IsNullOrEmpty(request.Feature))
            {
                filter = filterBuilder.And(filter, filterBuilder.Eq(p => p.Feature, request.Feature));
            }

            // Add Keyword search on Code or Name (case-insensitive, simple regex)
            if (!string.IsNullOrEmpty(request.Keyword))
            {
                var keywordTrimmed = request.Keyword.Trim();
                var regex = new MongoDB.Bson.BsonRegularExpression(keywordTrimmed, "i"); // "i" for case-insensitive
                var keywordFilter = filterBuilder.Or(
                    filterBuilder.Regex(p => p.Code, regex),
                    filterBuilder.Regex(p => p.Name, regex));
                filter = filterBuilder.And(filter, keywordFilter);
            }

            // Apply pagination using repository method
            var pagedResult = await _permissionRepository.PagedFilterAsync(
                filter,
                request.PageIndex ?? 1,
                request.PageSize ?? 50,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            // Map items to DTO
            var dtos = _mapper.Map<List<PermissionDto>>(pagedResult.Items);

            return new PagedResult<PermissionDto>
            {
                Items = dtos,
                Total = pagedResult.Total,
                Page = pagedResult.Page,
                PageSize = pagedResult.PageSize,
                PageIndex = pagedResult.PageIndex
            };
        }
    }
}
