using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Queries.Permissions
{
    /// <summary>
    /// Handler cho GetPermissionListByClientQuery - trả về permissions dưới dạng cây phân cấp
    /// </summary>
    public class GetPermissionListByClientQueryHandler : IQueryHandler<GetPermissionListByClientQuery, PermissionTreeResponseDto>
    {
        private readonly IAdminReadRepository<PermissionEntity> _permissionRepository;

        public GetPermissionListByClientQueryHandler(
            IAdminReadRepository<PermissionEntity> permissionRepository)
        {
            _permissionRepository = permissionRepository;
        }

        public async Task<PermissionTreeResponseDto> Handle(GetPermissionListByClientQuery request, CancellationToken cancellationToken)
        {
            // Get all permissions for the specific client
            var permissions = await _permissionRepository.FilterAsync(
                p => p.ClientId == request.ClientId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            // Group permissions by Module -> Feature -> Permission
            var moduleGroups = permissions
                .GroupBy(p => p.Module ?? "Uncategorized")
                .OrderBy(m => m.Key)
                .Select(moduleGroup => new ModuleTreeDto
                {
                    Name = moduleGroup.Key,
                    Features = moduleGroup
                        .GroupBy(p => p.Feature ?? "General")
                        .OrderBy(f => f.Key)
                        .Select(featureGroup => new FeatureTreeDto
                        {
                            Name = featureGroup.Key,
                            Permissions = featureGroup
                                .OrderBy(p => p.Code)
                                .Select(p => new PermissionTreeItemDto
                                {
                                    Id = p.Id,
                                    Code = p.Code,
                                    Name = p.Name,
                                    Description = p.Description,
                                    Action = p.Action
                                })
                                .ToList()
                        })
                        .ToList()
                })
                .ToList();

            return new PermissionTreeResponseDto
            {
                Modules = moduleGroups
            };
        }
    }
}
