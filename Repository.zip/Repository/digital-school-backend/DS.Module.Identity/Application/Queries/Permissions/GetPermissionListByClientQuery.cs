using DS.Module.Identity.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Identity.Application.Queries.Permissions
{
    /// <summary>
    /// Query để lấy danh sách permission của một client dưới dạng cây phân cấp (Module -> Feature -> Permission)
    /// </summary>
    public class GetPermissionListByClientQuery : IQuery<PermissionTreeResponseDto>
    {
        public string ClientId { get; set; } = string.Empty;

        public GetPermissionListByClientQuery(string clientId)
        {
            ClientId = clientId;
        }
    }
}
