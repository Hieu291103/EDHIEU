using DS.Module.Identity.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Identity.Application.Queries.Permissions
{
    /// <summary>
    /// Query để lấy permission theo ID
    /// </summary>
    public class GetPermissionByIdQuery : IQuery<PermissionDto?>
    {
        public string PermissionId { get; set; } = string.Empty;
    }
}
