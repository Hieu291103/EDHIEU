using AutoMapper;
using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Identity.Application.Queries.Permissions
{
    /// <summary>
    /// Handler cho GetPermissionByIdQuery
    /// </summary>
    public class GetPermissionByIdQueryHandler : IQueryHandler<GetPermissionByIdQuery, PermissionDto?>
    {
        private readonly IAdminReadRepository<PermissionEntity> _permissionRepository;
        private readonly IMapper _mapper;

        public GetPermissionByIdQueryHandler(
            IAdminReadRepository<PermissionEntity> permissionRepository,
            IMapper mapper)
        {
            _permissionRepository = permissionRepository;
            _mapper = mapper;
        }

        public async Task<PermissionDto?> Handle(GetPermissionByIdQuery request, CancellationToken cancellationToken)
        {
            var permission = await _permissionRepository.GetByIdAsync(
                request.PermissionId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (permission == null)
                return null;

            return _mapper.Map<PermissionDto>(permission);
        }
    }
}
