using DS.Module.Hrm.Infrastructure.Indexing;
using DS.Module.Hrm.Infrastructure.Localization;
using DS.Shared.Core.Infrastructure.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Context;
using Microsoft.Extensions.DependencyInjection;

namespace DS.Module.Hrm.Infrastructure.Extensions
{
    public static class HrmServiceCollectionExtensions
    {
        public static IServiceCollection AddHrmModule(this IServiceCollection services)
        {
            // 1. Localization Provider
            services.AddLocalizationProvider<HrmLocalizationProvider>();

            // 2. MongoDB Index Registry
            services.AddMongoIndexRegistry<HrmIndexRegistry>();

            return services;
        }

        public static async Task InitializeHrmIndexesAsync(this IServiceProvider serviceProvider)
        {
            await serviceProvider.InitializeMongoIndexesAsync<IHrmMongoDbContext>();
        }
    }
}
