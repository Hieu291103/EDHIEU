using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Context;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Indexing;
using MongoDB.Driver;

namespace DS.Module.Hrm.Infrastructure.Indexing
{
    public class HrmIndexRegistry : BaseIndexRegistry<IHrmMongoDbContext>
    {
        protected override void ConfigureIndexes()
        {
            // ── CompanyEntity (hrmCompanies) ───────────────────────────────
            Register(
                new CreateIndexModel<CompanyEntity>(
                    Builders<CompanyEntity>.IndexKeys.Ascending(x => x.Name),
                    new CreateIndexOptions { Name = "Name_1", Unique = true }),
                new CreateIndexModel<CompanyEntity>(
                    Builders<CompanyEntity>.IndexKeys.Ascending(x => x.IsActive),
                    new CreateIndexOptions { Name = "IsActive_1" }));

            // ── DepartmentEntity (hrmDepartments) ─────────────────────────
            Register(
                new CreateIndexModel<DepartmentEntity>(
                    Builders<DepartmentEntity>.IndexKeys.Ascending(x => x.Name),
                    new CreateIndexOptions { Name = "Name_1" }),
                new CreateIndexModel<DepartmentEntity>(
                    Builders<DepartmentEntity>.IndexKeys.Ascending(x => x.ParentId),
                    new CreateIndexOptions { Name = "ParentId_1" }),
                new CreateIndexModel<DepartmentEntity>(
                    Builders<DepartmentEntity>.IndexKeys.Ascending(x => x.IsActive),
                    new CreateIndexOptions { Name = "IsActive_1" }),
                new CreateIndexModel<DepartmentEntity>(
                    Builders<DepartmentEntity>.IndexKeys.Ascending(x => x.SortOrder),
                    new CreateIndexOptions { Name = "SortOrder_1" }));

            // ── EmployeePositionEntity (hrmEmployeePositions) ──────────────
            Register(
                new CreateIndexModel<EmployeePositionEntity>(
                    Builders<EmployeePositionEntity>.IndexKeys.Ascending(x => x.Name),
                    new CreateIndexOptions { Name = "Name_1", Unique = true }),
                new CreateIndexModel<EmployeePositionEntity>(
                    Builders<EmployeePositionEntity>.IndexKeys.Ascending(x => x.IsActive),
                    new CreateIndexOptions { Name = "IsActive_1" }));

        }
    }
}
