using DS.Shared.Core.Application.Abstractions.Localization;

namespace DS.Module.Hrm.Infrastructure.Localization
{
    /// <summary>
    /// Localization provider cho HRM module
    /// Priority = 100 để override Core messages
    /// </summary>
    public class HrmLocalizationProvider : ILocalizationProvider
    {
        public int Priority => 100;

        private static readonly Dictionary<string, Dictionary<string, string>> Messages = new()
        {
            ["vi"] = new Dictionary<string, string>
            {
                // ── Company ────────────────────────────────────────────────
                ["CompanyNotFound"] = "Không tìm thấy công ty / chi nhánh",
                ["CompanyNameAlreadyExists"] = "Tên công ty '{0}' đã tồn tại",
                ["CompanyHasEmployees"] = "Không thể xóa công ty đang có nhân viên",

                // ── Department ─────────────────────────────────────────────
                ["DepartmentNotFound"] = "Không tìm thấy phòng ban",
                ["DepartmentNameAlreadyExists"] = "Tên phòng ban '{0}' đã tồn tại",
                ["DepartmentHasChildren"] = "Không thể xóa phòng ban đang có tổ nhóm con",
                ["DepartmentHasEmployees"] = "Không thể xóa phòng ban đang có nhân viên",
                ["DepartmentParentNotFound"] = "Không tìm thấy phòng ban cha",
                ["DepartmentCircularReference"] = "Phòng ban không thể là cha của chính nó",

                // ── Position ───────────────────────────────────────────────
                ["PositionNotFound"] = "Không tìm thấy chức vụ",
                ["PositionNameAlreadyExists"] = "Tên chức vụ '{0}' đã tồn tại",
                ["PositionHasEmployees"] = "Không thể xóa chức vụ đang có nhân viên",

                // ── Validator error codes — Company ────────────────────────
                ["CompanyIdRequired"] = "ID công ty không được để trống",
                ["InvalidCompanyIdFormat"] = "ID công ty không hợp lệ",
                ["CompanyNameRequired"] = "Tên công ty không được để trống",
                ["CompanyNameTooLong"] = "Tên công ty không được vượt quá 200 ký tự",
                ["CompanyAddressRequired"] = "Địa chỉ công ty không được để trống",
                ["CompanyAddressTooLong"] = "Địa chỉ công ty không được vượt quá 500 ký tự",
                ["InvalidDirectorIdFormat"] = "ID giám đốc không hợp lệ",

                // ── Validator error codes — Department ─────────────────────
                ["DepartmentIdRequired"] = "ID phòng ban không được để trống",
                ["InvalidDepartmentIdFormat"] = "ID phòng ban không hợp lệ",
                ["DepartmentNameRequired"] = "Tên phòng ban không được để trống",
                ["DepartmentNameTooLong"] = "Tên phòng ban không được vượt quá 200 ký tự",
                ["InvalidManagerIdFormat"] = "ID trưởng phòng không hợp lệ",
                ["InvalidParentDepartmentIdFormat"] = "ID phòng ban cha không hợp lệ",

                // ── Validator error codes — Position ───────────────────────
                ["PositionIdRequired"] = "ID chức vụ không được để trống",
                ["InvalidPositionIdFormat"] = "ID chức vụ không hợp lệ",
                ["PositionNameRequired"] = "Tên chức vụ không được để trống",
                ["PositionNameTooLong"] = "Tên chức vụ không được vượt quá 200 ký tự",
            },
            ["en"] = new Dictionary<string, string>
            {
                // ── Company ────────────────────────────────────────────────
                ["CompanyNotFound"] = "Company / branch not found",
                ["CompanyNameAlreadyExists"] = "Company name '{0}' already exists",
                ["CompanyHasEmployees"] = "Cannot delete company that has employees",

                // ── Department ─────────────────────────────────────────────
                ["DepartmentNotFound"] = "Department not found",
                ["DepartmentNameAlreadyExists"] = "Department name '{0}' already exists",
                ["DepartmentHasChildren"] = "Cannot delete department that has child departments or teams",
                ["DepartmentHasEmployees"] = "Cannot delete department that has employees",
                ["DepartmentParentNotFound"] = "Parent department not found",
                ["DepartmentCircularReference"] = "A department cannot be its own parent",

                // ── Position ───────────────────────────────────────────────
                ["PositionNotFound"] = "Position not found",
                ["PositionNameAlreadyExists"] = "Position name '{0}' already exists",
                ["PositionHasEmployees"] = "Cannot delete position that has employees",

                // ── Employee ───────────────────────────────────────────────
                ["EmployeeNotFound"] = "Employee not found",
                ["EmployeeAlreadyDismissed"] = "Employee has already been dismissed",

                // ── Contract ───────────────────────────────────────────────
                ["ContractNotFound"] = "Employment contract not found",

                // ── Validator error codes — Company ────────────────────────
                ["CompanyIdRequired"] = "Company ID is required",
                ["InvalidCompanyIdFormat"] = "Invalid company ID format",
                ["CompanyNameRequired"] = "Company name is required",
                ["CompanyNameTooLong"] = "Company name must not exceed 200 characters",
                ["CompanyAddressRequired"] = "Company address is required",
                ["CompanyAddressTooLong"] = "Company address must not exceed 500 characters",
                ["InvalidDirectorIdFormat"] = "Invalid director ID format",

                // ── Validator error codes — Department ─────────────────────
                ["DepartmentIdRequired"] = "Department ID is required",
                ["InvalidDepartmentIdFormat"] = "Invalid department ID format",
                ["DepartmentNameRequired"] = "Department name is required",
                ["DepartmentNameTooLong"] = "Department name must not exceed 200 characters",
                ["InvalidManagerIdFormat"] = "Invalid manager ID format",
                ["InvalidParentDepartmentIdFormat"] = "Invalid parent department ID format",

                // ── Validator error codes — Position ───────────────────────
                ["PositionIdRequired"] = "Position ID is required",
                ["InvalidPositionIdFormat"] = "Invalid position ID format",
                ["PositionNameRequired"] = "Position name is required",
                ["PositionNameTooLong"] = "Position name must not exceed 200 characters",
            }
        };

        private static readonly Dictionary<string, Dictionary<string, string>> PropertyNames = new()
        {
            ["vi"] = new Dictionary<string, string>
            {
                ["Name"] = "Tên",
                ["Address"] = "Địa chỉ",
                ["IsActive"] = "Hoạt động",
                ["EmployeeId"] = "Nhân viên",
                ["EmployeeCode"] = "Mã nhân viên",
                ["CompanyId"] = "Công ty",
                ["DepartmentId"] = "Phòng ban",
                ["PositionId"] = "Chức vụ",
                ["ParentId"] = "Phòng ban cha",
                ["ManagerId"] = "Trưởng phòng",
                ["ContractNumber"] = "Số hợp đồng",
                ["StartDate"] = "Ngày bắt đầu",
                ["LeaveDate"] = "Ngày nghỉ việc",
                ["SortOrder"] = "Thứ tự hiển thị",
            },
            ["en"] = new Dictionary<string, string>
            {
                ["Name"] = "Name",
                ["Address"] = "Address",
                ["IsActive"] = "Active",
                ["EmployeeId"] = "Employee",
                ["EmployeeCode"] = "Employee Code",
                ["CompanyId"] = "Company",
                ["DepartmentId"] = "Department",
                ["PositionId"] = "Position",
                ["ParentId"] = "Parent Department",
                ["ManagerId"] = "Manager",
                ["ContractNumber"] = "Contract Number",
                ["StartDate"] = "Start Date",
                ["LeaveDate"] = "Leave Date",
                ["SortOrder"] = "Sort Order",
            }
        };

        public string? GetMessage(string key, string languageCode)
        {
            return Messages.GetValueOrDefault(languageCode)?.GetValueOrDefault(key);
        }

        public string? GetPropertyName(string propertyName, string languageCode)
        {
            return PropertyNames.GetValueOrDefault(languageCode)?.GetValueOrDefault(propertyName);
        }

        public string? GetValidationMessage(string errorCode, string languageCode)
        {
            return null;
        }
    }
}
