using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.Hrm.Domain.Entities
{
    /// <summary>
    /// Phòng ban — lưu trong collection "hrmDepartments"
    /// </summary>  
    [BsonCollection("hrmDepartments")]
    public class DepartmentEntity : BaseAuditableEntity, IHrmEntity
    {

        /// <summary>
        /// Tên phòng ban /nhóm
        /// </summary>
        public string Name { get; set; } = null!;

        /// <summary>
        /// Trưởng phòng/ nhóm
        /// </summary>
        [BsonObjectId]
        public string? ManagerId { get; set; }

        /// <summary>
        /// Thứ tự hiển thị
        /// </summary>
        public int? SortOrder { get; set; }

        /// <summary>
        /// Id của phòng ban cha đối với team/nhóm con, null nếu là phòng ban cấp cao nhất
        /// </summary>
        [BsonObjectId]
        public string? ParentId { get; set; }

        /// <summary>
        /// Là loại Tổ/nhóm
        /// </summary>
        public bool IsTeam { get; set; } = false;

        /// <summary>
        /// Phòng ban còn hoạt động hay đã đóng
        /// </summary>
        public bool IsActive { get; set; } = true;
    }
}
