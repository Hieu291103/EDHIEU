using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.Hrm.Domain.Entities
{
    /// <summary>
    /// Chức vụ nhân viên — lưu trong collection "hrmEmployeePositions"
    /// </summary>
    [BsonCollection("hrmEmployeePositions")]
    public class EmployeePositionEntity : BaseAuditableEntity, IHrmEntity
    {
        /// <summary>
        /// Tên chức vụ (e.g. "Lập trình viên")
        /// </summary>
        public string Name { get; set; } = null!;

        /// <summary>
        /// Chức vụ còn hoạt động
        /// </summary>
        public bool IsActive { get; set; } = true;
    }
}
