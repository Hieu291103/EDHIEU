using DS.Module.Hrm.Domain.Enums;
using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.Hrm.Domain.Entities
{
    /// <summary>
    /// Hợp đồng lao động — lưu trong collection "hrmContract"
    /// </summary>
    [BsonCollection("hrmContracts")]
    public class ContractEntity : BaseAuditableEntity, IHrmEntity
    {
        /// <summary>
        /// ID nhân viên sở hữu hợp đồng này (ref → hrmEmployees)
        /// </summary>
        [BsonObjectId]
        public string EmployeeId { get; set; } = null!;

        /// <summary>
        /// Số hợp đồng (e.g. "HDTV-2023-042")
        /// </summary>
        public string ContractNumber { get; set; } = null!;

        /// <summary>
        /// Loại hợp đồng
        /// </summary>
        public ContractType Type { get; set; }

        /// <summary>
        /// Ngày bắt đầu hợp đồng
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Ngày kết thúc hợp đồng (null nếu không xác định thời hạn)
        /// </summary>
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Ngày ký hợp đồng
        /// </summary>
        public DateTime? SignedDate { get; set; }

        /// <summary>
        /// Trạng thái hợp đồng
        /// </summary>
        public ContractStatus Status { get; set; }

        /// <summary>
        /// Mức lương theo hợp đồng (VNĐ)
        /// </summary>
        public decimal? Salary { get; set; }

        // ── Thông tin thử việc (chỉ áp dụng khi Type == Probation) ──────

        /// <summary>
        /// Ngày dự kiến kết thúc thử việc
        /// </summary>
        public DateTime? ProbationExpectedEndDate { get; set; }

        /// <summary>
        /// Ngày thực tế kết thúc thử việc
        /// </summary>
        public DateTime? ProbationActualEndDate { get; set; }

        /// <summary>
        /// Mức lương chính thức dự kiến sau thử việc
        /// </summary>
        public decimal? ExpectedOfficialSalary { get; set; }

        /// <summary>
        /// File đính kèm lưu trên S3
        /// </summary>
        public List<S3AttachmentInfo>? Attachments { get; set; }

        /// <summary>
        /// Ghi chú hợp đồng
        /// </summary>
        public string? Notes { get; set; }
    }
}
