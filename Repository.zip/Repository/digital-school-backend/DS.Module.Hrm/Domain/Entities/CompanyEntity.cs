using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.Hrm.Domain.Entities
{
    /// <summary>
    /// Công ty / Chi nhánh — lưu trong collection "hrmCompanies"
    /// </summary>
    [BsonCollection("hrmCompanies")]
    public class CompanyEntity : BaseAuditableEntity, IHrmEntity
    {
        /// <summary>
        /// Tên công ty / chi nhánh (e.g. "Edmicro Hà Nội")
        /// </summary>
        public string Name { get; set; } = null!;

        /// <summary>
        /// Địa chỉ công ty / chi nhánh (e.g. "123 Đường ABC, Quận XYZ, Hà Nội")
        /// </summary>
        public string? Address { get; set; }

        /// <summary>
        /// Công ty còn hoạt động
        /// </summary>
        public bool IsActive { get; set; } = true;

        /// <summary>
        /// ID giám đốc (ref → hrmEmployees, optional)
        /// </summary>
        [BsonObjectId]
        public string? DirectorId { get; set; }
    }
}
