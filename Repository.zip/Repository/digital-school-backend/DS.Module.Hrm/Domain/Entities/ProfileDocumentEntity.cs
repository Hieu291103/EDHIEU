using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.Hrm.Domain.Entities
{
    /// <summary>
    /// Giấy tờ / tài liệu HR của nhân viên
    /// </summary>
    [BsonCollection("hrmProfileDocuments")]
    public class ProfileDocumentEntity : BaseAuditableEntity, IHrmEntity
    {
        /// <summary>ID nhân viên sở hữu tài liệu này (ref → hrmEmployees)</summary>
        [BsonObjectId]
        public string EmployeeId { get; set; } = null!;

        /// <summary>
        /// Mã loại tài liệu (e.g. "CCCD", "PASSPORT", "DEGREE", "HEALTH_CHECK")
        /// Dùng để phân loại và tra cứu
        /// </summary>
        public string Code { get; set; } = null!;

        /// <summary>
        /// Tên hiển thị (e.g. "Căn cước công dân", "Bằng tốt nghiệp")
        /// </summary>
        public string Name { get; set; } = null!;

        /// <summary>
        /// Tài liệu này có bắt buộc phải nộp không
        /// true = bắt buộc (CCCD), false = tùy chọn (bằng ngoại ngữ)
        /// </summary>
        public bool IsRequired { get; set; } = false;

        /// <summary>
        /// Trạng thái tài liệu: true = đã nộp, false = chưa nộp
        /// </summary>
        public bool Status { get; set; }

        /// <summary>
        /// File đính kèm lưu trên S3
        /// </summary>
        public List<S3AttachmentInfo>? Attachments { get; set; }
    }
}
