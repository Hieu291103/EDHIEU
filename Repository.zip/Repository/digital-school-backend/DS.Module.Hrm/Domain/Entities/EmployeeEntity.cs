using DS.Module.Hrm.Domain.Enums;
using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.Hrm.Domain.Entities
{
    /// <summary>
    /// Aggregate root: Nhân viên — lưu trong collection "hrmEmployees"
    /// </summary>
    [BsonCollection("hrmEmployees")]
    public class EmployeeEntity : BaseSoftDeleteEntity, IHrmEntity
    {
        // ─── Root identifiers ────────────────────────────────────────────

        /// <summary>
        /// Mã nhân viên dạng người đọc được (e.g. "E000042") E + số nhân viên dạng 6 chữ số
        /// </summary>
        public string EmployeeCode { get; set; } = null!;

        /// <summary>
        /// Số nhân viên
        /// </summary>
        public int EmployeeNumber { get; set; }

        /// <summary>
        /// Mã chấm công (dùng cho hệ thống chấm công, e.g. "00042")
        /// </summary>
        public string? TimekeepingCode { get; set; } = string.Empty;

        /// <summary>
        /// URL ảnh đại diện
        /// </summary>
        public string? Avatar { get; set; }

        // ─── Identity core ───────────────────────────────────────────────

        /// <summary>
        /// Họ và tên đầy đủ
        /// </summary>
        public string FullName { get; set; } = string.Empty;

        /// <summary>
        /// Họ và tên đệm
        /// </summary>
        public string Forename { get; set; } = string.Empty;

        /// <summary>
        /// Tên
        /// </summary>
        public string Surname { get; set; } = string.Empty;

        /// <summary>
        /// Tên gọi khác / Bí danh
        /// </summary>
        public string? OtherName { get; set; }

        /// <summary>
        /// Giới tính
        /// </summary>
        public Gender? Gender { get; set; }

        /// <summary>
        /// Ngày sinh
        /// </summary>
        public DateTime? DateOfBirth { get; set; }

        // ─── Demographics ────────────────────────────────────────────────

        /// <summary>
        /// Nguyên quán
        /// </summary>
        public string? NativePlace { get; set; }

        /// <summary>
        /// Dân tộc
        /// </summary>
        public string? Ethnicity { get; set; }

        /// <summary>
        /// Tôn giáo
        /// </summary>
        public string? Religion { get; set; }

        /// <summary>
        /// Tình trạng hôn nhân (true = đã kết hôn, false = độc thân, null = không xác định)
        /// </summary>
        public bool? MarriageStatus { get; set; }

        /// <summary>
        /// Địa chỉ thường trú (Hộ khẩu)
        /// </summary>
        public string? PermanentAddress { get; set; }

        /// <summary>
        /// Địa chỉ hiện tại
        /// </summary>
        public string? CurrentAddress { get; set; }

        // ─── Contact ─────────────────────────────────────────────────────

        /// <summary>
        /// Số điện thoại
        /// </summary>
        public string? Phone { get; set; }

        /// <summary>
        /// Email cá nhân
        /// </summary>
        public string? Email { get; set; }

        /// <summary>
        /// Email công ty
        /// </summary>
        public string? CompanyEmail { get; set; }

        // ─── Government IDs (PII — role-gated) ───────────────────────────

        /// <summary>
        /// Mã số thuế cá nhân
        /// </summary>
        public string? TaxCode { get; set; }

        /// <summary>
        /// Số sổ bảo hiểm xã hội
        /// </summary>
        public string? SocialInsuranceNumber { get; set; }

        // ─── Org placement (loose refs — all optional) ───────────────────

        /// <summary>
        /// ID công ty / chi nhánh (ref → hrmCompanies, optional)
        /// </summary>
        [BsonObjectId]
        public required string CompanyId { get; set; }

        /// <summary>
        /// ID phòng ban (ref → hrmDepartments, optional)
        /// </summary>
        [BsonObjectId]
        public string? DepartmentId { get; set; }

        /// <summary>
        /// ID nhóm / tổ (ref → hrmTeams, optional)
        /// </summary>
        [BsonObjectId]
        public string? TeamId { get; set; }

        /// <summary>
        /// ID chức vụ (ref → hrmPositions, optional)
        /// </summary>
        [BsonObjectId]
        public string? PositionId { get; set; }

        // ─── Employment status ───────────────────────────────────────────

        /// <summary>
        /// Trạng thái làm việc: true = đang làm việc, false = đã nghỉ việc
        /// </summary>
        public bool IsWorking { get; set; } = true;

        /// <summary>
        /// Nhân viên đã nghỉ việc
        /// </summary>
        public bool HasLeave { get; set; } = false;

        /// <summary>
        /// Ngày nghỉ việc (nếu đã nghỉ)
        /// </summary>
        public DateTime? LeaveDate { get; set; }

        /// <summary>
        /// Lý do / ghi chú khi nghỉ việc
        /// </summary>
        public string? LeaveNote { get; set; }

        // ─── Job details ─────────────────────────────────────────────────

        /// <summary>
        /// Hình thức làm việc
        /// </summary>
        public WorkType WorkType { get; set; } = WorkType.Probationary;

        /// <summary>
        /// Ngày bắt đầu làm việc
        /// </summary>
        public DateTime WorkDate { get; set; } = DateTime.UtcNow;

        // ─── Education ───────────────────────────────────────────────────

        /// <summary>
        /// Bằng cấp cao nhất (e.g. "Cử nhân", "Thạc sĩ")
        /// </summary>
        public string? Degree { get; set; }

        /// <summary>
        /// Năm tốt nghiệp
        /// </summary>
        public int? GraduationYear { get; set; }

        /// <summary>
        /// Trường học
        /// </summary>
        public string? Institution { get; set; }

        /// <summary>
        /// Chuyên ngành
        /// </summary>
        public string? Major { get; set; }

        // ─── Bank account (PII — role-gated) ─────────────────────────────

        /// <summary>
        /// Số tài khoản ngân hàng
        /// </summary>
        public string? BankAccountNumber { get; set; }

        /// <summary>
        /// Tên ngân hàng (e.g. "Vietcombank")
        /// </summary>
        public string? BankName { get; set; }

        /// <summary>
        /// Chi nhánh ngân hàng
        /// </summary>
        public string? BankBranchName { get; set; }

        // ─── Emergency contact ───────────────────────────────────────────

        /// <summary>
        /// Họ tên người liên hệ khẩn cấp
        /// </summary>
        public string? EmergencyContactName { get; set; }

        /// <summary>
        /// Số điện thoại người liên hệ khẩn cấp
        /// </summary>
        public string? EmergencyContactPhone { get; set; }

        /// <summary>
        /// Quan hệ với nhân viên (e.g. "Vợ", "Bố")
        /// </summary>
        public string? EmergencyContactRelationship { get; set; }

        // ─── Profile completion ───────────────────────────────────────────

        /// <summary>
        /// Trạng thái hoàn thiện hồ sơ
        /// </summary>
        public ProfileCompletionStatus ProfileStatus { get; set; } = ProfileCompletionStatus.Incomplete;


        // ─── Misc ────────────────────────────────────────────────────────

        /// <summary>
        /// Ghi chú về nhân viên
        /// </summary>
        public string? Notes { get; set; }
    }
}
