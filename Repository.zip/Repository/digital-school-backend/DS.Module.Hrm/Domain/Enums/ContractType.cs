namespace DS.Module.Hrm.Domain.Enums
{
    /// <summary>
    /// Loại hợp đồng lao động
    /// </summary>
    public enum ContractType
    {
        /// <summary>
        /// Hợp đồng thử việc
        /// </summary>
        Probation = 0,
        
        /// <summary>
        /// HĐLĐ xác định thời hạn
        /// </summary>
        FixedTerm = 1,
        
        /// <summary>
        /// HĐLĐ không xác định thời hạn
        /// </summary>
        IndefiniteTerm = 2,
        
        /// <summary>
        /// Hợp đồng thời vụ
        /// </summary>
        Seasonal = 3,
        
        /// <summary>
        /// Hợp đồng cộng tác viên
        /// </summary>
        Collaborator = 4
    }
}
