namespace DS.Module.Hrm.Domain.Enums
{
    /// <summary>
    /// Giới tính nhân viên
    /// </summary>
    public enum Gender
    {
        /// <summary>
        /// Nam
        /// </summary>
        Male = 0,
        
        /// <summary>
        /// Nữ
        /// </summary>
        Female = 1
    }
}
