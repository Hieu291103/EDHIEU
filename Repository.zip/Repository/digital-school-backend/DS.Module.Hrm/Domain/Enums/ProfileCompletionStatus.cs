namespace DS.Module.Hrm.Domain.Enums
{
    /// <summary>
    /// Trạng thái hoàn thiện hồ sơ nhân viên
    /// </summary>
    public enum ProfileCompletionStatus
    {
        /// <summary>
        /// Chưa đầy đủ
        /// </summary>
        Incomplete = 0,
        
        /// <summary>
        /// Đã đầy đủ
        /// </summary>
        Complete = 1,

        /// <summary>
        /// Đã xác minh
        /// </summary>
        Verified = 2
    }
}
