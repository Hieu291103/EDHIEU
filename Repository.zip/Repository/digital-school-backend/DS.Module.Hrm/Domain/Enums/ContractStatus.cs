namespace DS.Module.Hrm.Domain.Enums
{
    /// <summary>
    /// Trạng thái hợp đồng lao động
    /// </summary>
    public enum ContractStatus
    {

        /// <summary>
        /// Nháp
        /// </summary>
        Draft = 0,
        /// <summary>
        /// Chờ ký
        /// </summary>
        PendingSignature = 1,
        /// <summary>
        /// Đang hiệu lực 
        /// </summary>
        Active = 2,
        /// <summary>
        /// Hết hạn
        /// </summary>
        Expired = 3,
        /// <summary>
        /// Đã chấm dứt
        /// </summary>
        Terminated = 4

    }
}
