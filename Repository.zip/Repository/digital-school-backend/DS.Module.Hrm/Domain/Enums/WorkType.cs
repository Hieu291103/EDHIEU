namespace DS.Module.Hrm.Domain.Enums
{
    /// <summary>
    /// Hình thức làm việc của nhân viên
    /// </summary>
    public enum WorkType
    {
        /// <summary>
        /// Thử việc
        /// </summary>
        Probationary = 0,
        /// <summary>
        /// Chính thức
        /// </summary>
        Fulltime = 1,
        /// <summary>
        /// Thời vụ
        /// </summary>        
        Seasonal = 2,
        /// <summary>
        /// Cộng tác viên
        /// </summary>
        Collaborator = 3,
        /// <summary>
        /// Thực tập sinh
        /// </summary>
        Intern = 4,
        /// <summary>
        /// Nghỉ thai sản
        /// </summary>
        MaternityLeave = 5,
        /// <summary>
        /// Nghỉ dài ngày
        /// </summary>
        LongTermLeave = 6

    }
}
