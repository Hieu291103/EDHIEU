using FluentValidation;

namespace DS.Module.Hrm.Application.Commands.Companies
{
    /// <summary>
    /// Validator cho UpdateCompanyCommand
    /// </summary>
    public class UpdateCompanyCommandValidator : AbstractValidator<UpdateCompanyCommand>
    {
        public UpdateCompanyCommandValidator()
        {
            RuleFor(x => x.Id)
                .NotEmpty()
                .WithErrorCode("CompanyIdRequired")
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithErrorCode("InvalidCompanyIdFormat");

            RuleFor(x => x.Name)
                .MaximumLength(200)
                .WithErrorCode("CompanyNameTooLong")
                .When(x => !string.IsNullOrEmpty(x.Name));

            RuleFor(x => x.Address)
                .MaximumLength(500)
                .WithErrorCode("CompanyAddressTooLong")
                .When(x => !string.IsNullOrEmpty(x.Address));

            RuleFor(x => x.DirectorId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithErrorCode("InvalidDirectorIdFormat")
                .When(x => !string.IsNullOrEmpty(x.DirectorId));
        }
    }
}
