using FluentValidation;

namespace DS.Module.Hrm.Application.Commands.Companies
{
    /// <summary>
    /// Validator cho CreateCompanyCommand
    /// </summary>
    public class CreateCompanyCommandValidator : AbstractValidator<CreateCompanyCommand>
    {
        public CreateCompanyCommandValidator()
        {
            RuleFor(x => x.Name)
                .NotEmpty()
                .WithErrorCode("CompanyNameRequired")
                .MaximumLength(200)
                .WithErrorCode("CompanyNameTooLong");

            RuleFor(x => x.Address)
                .MaximumLength(500)
                .WithErrorCode("CompanyAddressTooLong")
                .When(x => !string.IsNullOrEmpty(x.Address));

            RuleFor(x => x.DirectorId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithErrorCode("InvalidDirectorIdFormat")
                .When(x => !string.IsNullOrEmpty(x.DirectorId));
        }
    }
}
