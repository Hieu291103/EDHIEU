using FluentValidation;

namespace DS.Module.Hrm.Application.Commands.Positions
{
    /// <summary>
    /// Validator cho UpdatePositionCommand
    /// </summary>
    public class UpdateEmployeePositionCommandValidator : AbstractValidator<UpdateEmployeePositionCommand>
    {
        public UpdateEmployeePositionCommandValidator()
        {
            RuleFor(x => x.Id)
                .NotEmpty()
                .WithErrorCode("PositionIdRequired")
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithErrorCode("InvalidPositionIdFormat");

            RuleFor(x => x.Name)
                .NotEmpty()
                .WithErrorCode("PositionNameRequired")
                .MaximumLength(200)
                .WithErrorCode("PositionNameTooLong");
        }
    }
}
