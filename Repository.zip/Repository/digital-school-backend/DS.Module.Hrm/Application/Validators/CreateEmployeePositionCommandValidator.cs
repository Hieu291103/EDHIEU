using FluentValidation;

namespace DS.Module.Hrm.Application.Commands.Positions
{
    /// <summary>
    /// Validator cho CreatePositionCommand
    /// </summary>
    public class CreateEmployeePositionCommandValidator : AbstractValidator<CreateEmployeePositionCommand>
    {
        public CreateEmployeePositionCommandValidator()
        {
            RuleFor(x => x.Name)
                .NotEmpty()
                .WithErrorCode("PositionNameRequired")
                .MaximumLength(200)
                .WithErrorCode("PositionNameTooLong");
        }
    }
}
