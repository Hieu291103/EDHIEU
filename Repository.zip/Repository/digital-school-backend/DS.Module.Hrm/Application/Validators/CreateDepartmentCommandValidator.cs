using FluentValidation;

namespace DS.Module.Hrm.Application.Commands.Departments
{
    /// <summary>
    /// Validator cho CreateDepartmentCommand
    /// </summary>
    public class CreateDepartmentCommandValidator : AbstractValidator<CreateDepartmentCommand>
    {
        public CreateDepartmentCommandValidator()
        {
            RuleFor(x => x.Name)
                .NotEmpty()
                .WithErrorCode("DepartmentNameRequired")
                .MaximumLength(200)
                .WithErrorCode("DepartmentNameTooLong");

            RuleFor(x => x.ManagerId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithErrorCode("InvalidManagerIdFormat")
                .When(x => !string.IsNullOrEmpty(x.ManagerId));

            RuleFor(x => x.ParentId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithErrorCode("InvalidParentDepartmentIdFormat")
                .When(x => !string.IsNullOrEmpty(x.ParentId));
        }
    }
}
