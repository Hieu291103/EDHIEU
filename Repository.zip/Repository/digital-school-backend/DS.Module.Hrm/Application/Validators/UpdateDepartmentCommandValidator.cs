using FluentValidation;

namespace DS.Module.Hrm.Application.Commands.Departments
{
    /// <summary>
    /// Validator cho UpdateDepartmentCommand
    /// </summary>
    public class UpdateDepartmentCommandValidator : AbstractValidator<UpdateDepartmentCommand>
    {
        public UpdateDepartmentCommandValidator()
        {
            RuleFor(x => x.Id)
                .NotEmpty()
                .WithErrorCode("DepartmentIdRequired")
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithErrorCode("InvalidDepartmentIdFormat");

            RuleFor(x => x.Name)
                .MaximumLength(200)
                .WithErrorCode("DepartmentNameTooLong")
                .When(x => !string.IsNullOrEmpty(x.Name));

            RuleFor(x => x.ManagerId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithErrorCode("InvalidManagerIdFormat")
                .When(x => !string.IsNullOrEmpty(x.ManagerId));

            RuleFor(x => x.ParentId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithErrorCode("InvalidParentDepartmentIdFormat")
                .When(x => !string.IsNullOrEmpty(x.ParentId));
        }
    }
}
