namespace DS.Module.Hrm.Application.DTOs
{
    /// <summary>
    /// DTO cho Department entity
    /// </summary>
    public class DepartmentDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;

        public string? ManagerId { get; set; }

        public int? SortOrder { get; set; }

        public string? ParentId { get; set; }

        public bool IsTeam { get; set; } = false;

        public bool IsActive { get; set; } = true;
    }

    /// <summary>
    /// DTO cho danh sách Department
    /// </summary>
    public class DepartmentListDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? ManagerId { get; set; }
        public bool IsActive { get; set; } = true;
        public int? SortOrder { get; set; }
    }
}
