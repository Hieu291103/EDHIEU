using DS.Module.Hrm.Domain.Enums;

namespace DS.Module.Hrm.Application.DTOs
{
    /// <summary>
    /// DTO cho Employee entity
    /// </summary>
    public class EmployeeDto
    {
        // ─── Root identifiers ────────────────────────────────────────────
        public string Id { get; set; } = string.Empty;
        public string EmployeeCode { get; set; } = string.Empty;
        public int EmployeeNumber { get; set; }
        public string? TimekeepingCode { get; set; }
        public string? Avatar { get; set; }

        // ─── Identity core ───────────────────────────────────────────────
        public string FullName { get; set; } = string.Empty;
        public string Forename { get; set; } = string.Empty;
        public string Surname { get; set; } = string.Empty;
        public string? OtherName { get; set; }
        public Gender? Gender { get; set; }
        public DateTime? DateOfBirth { get; set; }

        // ─── Demographics ────────────────────────────────────────────────
        public string? NativePlace { get; set; }
        public string? Ethnicity { get; set; }
        public string? Religion { get; set; }
        public bool? MarriageStatus { get; set; }
        public string? PermanentAddress { get; set; }
        public string? CurrentAddress { get; set; }

        // ─── Contact ─────────────────────────────────────────────────────
        public string? Phone { get; set; }
        public string? Email { get; set; }
        public string? CompanyEmail { get; set; }

        // ─── Government IDs ───────────────────────────────────────────────
        public string? TaxCode { get; set; }
        public string? SocialInsuranceNumber { get; set; }

        // ─── Org placement ───────────────────────────────────────────────
        public string CompanyId { get; set; } = string.Empty;
        public string? DepartmentId { get; set; }
        public string? TeamId { get; set; }
        public string? PositionId { get; set; }

        // ─── Employment status ───────────────────────────────────────────
        public bool IsWorking { get; set; } = true;
        public bool HasLeave { get; set; } = false;
        public DateTime? LeaveDate { get; set; }
        public string? LeaveNote { get; set; }

        // ─── Job details ─────────────────────────────────────────────────
        public WorkType WorkType { get; set; } = WorkType.Probationary;
        public DateTime WorkDate { get; set; }

        // ─── Education ───────────────────────────────────────────────────
        public string? Degree { get; set; }
        public int? GraduationYear { get; set; }
        public string? Institution { get; set; }
        public string? Major { get; set; }

        // ─── Bank account ─────────────────────────────────────────────────
        public string? BankAccountNumber { get; set; }
        public string? BankName { get; set; }
        public string? BankBranchName { get; set; }

        // ─── Emergency contact ───────────────────────────────────────────
        public string? EmergencyContactName { get; set; }
        public string? EmergencyContactPhone { get; set; }
        public string? EmergencyContactRelationship { get; set; }

        // ─── Profile completion ───────────────────────────────────────────
        public ProfileCompletionStatus ProfileStatus { get; set; } = ProfileCompletionStatus.Incomplete;

        // ─── Misc ────────────────────────────────────────────────────────
        public string? Notes { get; set; }
    }

    /// <summary>
    /// DTO cho danh sách Employee
    /// </summary>
    public class EmployeeListDto
    {
        public string Id { get; set; } = string.Empty;
        public string EmployeeCode { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string? Avatar { get; set; }
        public string CompanyId { get; set; } = string.Empty;
        public string? DepartmentId { get; set; }
        public string? PositionId { get; set; }
        public WorkType WorkType { get; set; }
        public bool IsWorking { get; set; }
        public string? Phone { get; set; }
        public string? CompanyEmail { get; set; }
        public DateTime WorkDate { get; set; }
        public ProfileCompletionStatus ProfileStatus { get; set; }
    }
}
