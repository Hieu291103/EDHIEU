namespace DS.Module.Hrm.Application.DTOs
{
    /// <summary>
    /// DTO cho Position entity
    /// </summary>
    public class PositionDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
    }

    /// <summary>
    /// DTO cho danh sách Position
    /// </summary>
    public class PositionListDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
    }
}
