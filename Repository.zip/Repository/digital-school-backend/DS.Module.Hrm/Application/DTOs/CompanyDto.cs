namespace DS.Module.Hrm.Application.DTOs
{
    /// <summary>
    /// DTO cho Company entity
    /// </summary>
    public class CompanyDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? Address { get; set; }
        public bool IsActive { get; set; } = true;
        public string? DirectorId { get; set; }
    }

    /// <summary>
    /// DTO cho danh sách Company
    /// </summary>
    public class CompanyListDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? Address { get; set; }
        public bool IsActive { get; set; } = true;
    }
}
