using DS.Module.Hrm.Domain.Enums;
using DS.Shared.Core.Contracts.Dtos;

namespace DS.Module.Hrm.Application.DTOs
{
    /// <summary>
    /// DTO cho Contract entity
    /// </summary>
    public class ContractDto
    {
        public string Id { get; set; } = string.Empty;

        public string EmployeeId { get; set; } = string.Empty;

        public string ContractNumber { get; set; } = string.Empty;
        public ContractType Type { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? SignedDate { get; set; }
        public ContractStatus Status { get; set; }
        public decimal? Salary { get; set; }

        // ─── Probation fields ─────────────────────────────────────────────
        public DateTime? ProbationExpectedEndDate { get; set; }
        public DateTime? ProbationActualEndDate { get; set; }
        public decimal? ExpectedOfficialSalary { get; set; }

        public List<S3AttachmentDto> Attachments { get; set; } = new();
        public string? Notes { get; set; }
    }

    /// <summary>
    /// DTO cho danh sách Contract
    /// </summary>
    public class ContractListDto
    {
        public string Id { get; set; } = string.Empty;
        public string EmployeeId { get; set; } = string.Empty;
        public string ContractNumber { get; set; } = string.Empty;
        public ContractType Type { get; set; }
        public ContractStatus Status { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public decimal? Salary { get; set; }
    }
}
