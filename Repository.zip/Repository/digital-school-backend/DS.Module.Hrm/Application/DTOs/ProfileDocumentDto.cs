using DS.Shared.Core.Contracts.Dtos;

namespace DS.Module.Hrm.Application.DTOs
{
    /// <summary>
    /// DTO cho ProfileDocument entity
    /// </summary>
    public class ProfileDocumentDto
    {
        public string Id { get; set; } = string.Empty;

        public string EmployeeId { get; set; } = string.Empty;

        public string Code { get; set; } = string.Empty;

        public string Name { get; set; } = string.Empty;

        public bool IsRequired { get; set; } = false;

        public bool Status { get; set; }

        public List<S3AttachmentDto>? Attachments { get; set; } = new();
    }

    /// <summary>
    /// DTO cho danh sách ProfileDocument
    /// </summary>
    public class ProfileDocumentListDto
    {
        public string Id { get; set; } = string.Empty;
        public string EmployeeId { get; set; } = string.Empty;
        public string Code { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public bool IsRequired { get; set; }
        public bool Status { get; set; }
    }
}
