using DS.Module.Hrm.Application.DTOs;
using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Bson;
using MongoDB.Driver;
using System.Text.RegularExpressions;

namespace DS.Module.Hrm.Application.Queries.Positions
{
    /// <summary>
    /// Handler cho GetPositionListQuery
    /// </summary>
    public class GetEmployeePositionListQueryHandler : IQueryHandler<GetEmployeePositionListQuery, PagedResult<PositionListDto>>
    {
        private readonly IHrmReadRepository<EmployeePositionEntity> _readRepository;

        public GetEmployeePositionListQueryHandler(IHrmReadRepository<EmployeePositionEntity> readRepository)
        {
            _readRepository = readRepository;
        }

        public async Task<PagedResult<PositionListDto>> Handle(GetEmployeePositionListQuery request, CancellationToken cancellationToken)
        {
            var filterBuilder = Builders<EmployeePositionEntity>.Filter;
            var filter = filterBuilder.Empty;

            if (!string.IsNullOrWhiteSpace(request.Keyword))
            {
                var regex = new BsonRegularExpression(Regex.Escape(request.Keyword.Trim()), "i");
                filter = filterBuilder.And(filter, filterBuilder.Regex(p => p.Name, regex));
            }

            if (request.IsActive.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Eq(p => p.IsActive, request.IsActive.Value));

            var pagedResult = await _readRepository.PagedFilterAsync(
                filter,
                p => new PositionListDto
                {
                    Id = p.Id,
                    Name = p.Name,
                    IsActive = p.IsActive,
                },
                request.PageIndex ?? 1,
                request.PageSize ?? 50,
                orderByDescending: true,
                cancellationToken: cancellationToken);

            return new PagedResult<PositionListDto>
            {
                Items = pagedResult.Items.ToList(),
                Total = pagedResult.Total,
                Page = pagedResult.Page,
                PageSize = pagedResult.PageSize,
                PageIndex = pagedResult.PageIndex,
            };
        }
    }
}
