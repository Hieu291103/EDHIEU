using AutoMapper;
using DS.Module.Hrm.Application.DTOs;
using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Hrm.Application.Queries.Positions
{
    /// <summary>
    /// Handler cho GetPositionByIdQuery.
    /// Trả về null nếu chức vụ không tồn tại.
    /// </summary>
    public class GetEmployeePositionByIdQueryHandler : IQueryHandler<GetEmployeePositionByIdQuery, PositionDto?>
    {
        private readonly IHrmReadRepository<EmployeePositionEntity> _readRepository;
        private readonly IMapper _mapper;

        public GetEmployeePositionByIdQueryHandler(
            IHrmReadRepository<EmployeePositionEntity> readRepository,
            IMapper mapper)
        {
            _readRepository = readRepository;
            _mapper = mapper;
        }

        public async Task<PositionDto?> Handle(GetEmployeePositionByIdQuery request, CancellationToken cancellationToken)
        {
            var position = await _readRepository.GetByIdAsync(request.Id, cancellationToken: cancellationToken);
            if (position is null)
                return null;

            return _mapper.Map<PositionDto>(position);
        }
    }
}

