using DS.Module.Hrm.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Hrm.Application.Queries.Positions
{
    /// <summary>
    /// Query để lấy chi tiết chức vụ theo ID
    /// </summary>
    public class GetEmployeePositionByIdQuery : IQuery<PositionDto?>
    {
        public string Id { get; set; } = string.Empty;
    }
}
