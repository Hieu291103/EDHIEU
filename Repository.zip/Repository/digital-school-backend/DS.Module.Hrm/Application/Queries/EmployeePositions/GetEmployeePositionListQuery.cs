using DS.Module.Hrm.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Requests;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Hrm.Application.Queries.Positions
{
    /// <summary>
    /// Query để lấy danh sách chức vụ với bộ lọc và phân trang
    /// </summary>
    public class GetEmployeePositionListQuery : FilterRequest, IQuery<PagedResult<PositionListDto>>
    {
        public bool? IsActive { get; set; }
    }
}
