using AutoMapper;
using DS.Module.Hrm.Application.DTOs;
using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Bson;
using MongoDB.Driver;
using System.Text.RegularExpressions;

namespace DS.Module.Hrm.Application.Queries.Companies
{
    /// <summary>
    /// Handler cho GetCompanyListQuery
    /// </summary>
    public class GetCompanyListQueryHandler : IQueryHandler<GetCompanyListQuery, PagedResult<CompanyListDto>>
    {
        private readonly IHrmReadRepository<CompanyEntity> _readRepository;
        private readonly IMapper _mapper;

        public GetCompanyListQueryHandler(
            IHrmReadRepository<CompanyEntity> readRepository,
            IMapper mapper)
        {
            _readRepository = readRepository;
            _mapper = mapper;
        }

        public async Task<PagedResult<CompanyListDto>> Handle(GetCompanyListQuery request, CancellationToken cancellationToken)
        {
            var filterBuilder = Builders<CompanyEntity>.Filter;
            var filter = filterBuilder.Empty;

            if (!string.IsNullOrWhiteSpace(request.Keyword))
            {
                var regex = new BsonRegularExpression(Regex.Escape(request.Keyword.Trim()), "i");
                var keywordFilter = filterBuilder.Or(
                    filterBuilder.Regex(c => c.Name, regex),
                    filterBuilder.Regex(c => c.Address, regex));
                filter = filterBuilder.And(filter, keywordFilter);
            }

            if (request.IsActive.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Eq(c => c.IsActive, request.IsActive.Value));

            var pagedResult = await _readRepository.PagedFilterAsync(
                filter,
                c => new CompanyListDto
                {
                    Id = c.Id,
                    Name = c.Name,
                    Address = c.Address,
                    IsActive = c.IsActive,
                },
                request.PageIndex ?? 1,
                request.PageSize ?? 50,
                orderByDescending: true,
                cancellationToken: cancellationToken);

            return new PagedResult<CompanyListDto>
            {
                Items = pagedResult.Items.ToList(),
                Total = pagedResult.Total,
                Page = pagedResult.Page,
                PageSize = pagedResult.PageSize,
                PageIndex = pagedResult.PageIndex,
            };
        }
    }
}
