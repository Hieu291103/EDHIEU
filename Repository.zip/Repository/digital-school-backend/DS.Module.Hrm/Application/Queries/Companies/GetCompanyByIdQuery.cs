using DS.Module.Hrm.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Hrm.Application.Queries.Companies
{
    /// <summary>
    /// Query để lấy chi tiết công ty theo ID
    /// </summary>
    public class GetCompanyByIdQuery : IQuery<CompanyDto?>
    {
        public string Id { get; set; } = string.Empty;
    }
}
