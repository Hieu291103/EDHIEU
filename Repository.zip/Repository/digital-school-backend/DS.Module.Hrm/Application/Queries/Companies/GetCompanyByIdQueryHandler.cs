using AutoMapper;
using DS.Module.Hrm.Application.DTOs;
using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Hrm.Application.Queries.Companies
{
    /// <summary>
    /// Handler cho GetCompanyByIdQuery.
    /// Trả về null nếu công ty không tồn tại.
    /// </summary>
    public class GetCompanyByIdQueryHandler : IQueryHandler<GetCompanyByIdQuery, CompanyDto?>
    {
        private readonly IHrmReadRepository<CompanyEntity> _readRepository;
        private readonly IMapper _mapper;

        public GetCompanyByIdQueryHandler(
            IHrmReadRepository<CompanyEntity> readRepository,
            IMapper mapper)
        {
            _readRepository = readRepository;
            _mapper = mapper;
        }

        public async Task<CompanyDto?> Handle(GetCompanyByIdQuery request, CancellationToken cancellationToken)
        {
            var company = await _readRepository.GetByIdAsync(request.Id, cancellationToken: cancellationToken);
            if (company is null)
                return null;

            return _mapper.Map<CompanyDto>(company);
        }
    }
}
