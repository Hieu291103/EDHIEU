using DS.Module.Hrm.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Requests;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Hrm.Application.Queries.Companies
{
    /// <summary>
    /// Query để lấy danh sách công ty với bộ lọc và phân trang
    /// </summary>
    public class GetCompanyListQuery : FilterRequest, IQuery<PagedResult<CompanyListDto>>
    {
        public bool? IsActive { get; set; }
    }
}
