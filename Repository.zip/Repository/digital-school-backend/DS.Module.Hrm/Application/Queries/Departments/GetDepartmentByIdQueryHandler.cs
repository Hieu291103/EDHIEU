using AutoMapper;
using DS.Module.Hrm.Application.DTOs;
using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Hrm.Application.Queries.Departments
{
    /// <summary>
    /// Handler cho GetDepartmentByIdQuery.
    /// Trả về null nếu phòng ban không tồn tại.
    /// </summary>
    public class GetDepartmentByIdQueryHandler : IQueryHandler<GetDepartmentByIdQuery, DepartmentDto?>
    {
        private readonly IHrmReadRepository<DepartmentEntity> _readRepository;
        private readonly IMapper _mapper;

        public GetDepartmentByIdQueryHandler(
            IHrmReadRepository<DepartmentEntity> readRepository,
            IMapper mapper)
        {
            _readRepository = readRepository;
            _mapper = mapper;
        }

        public async Task<DepartmentDto?> Handle(GetDepartmentByIdQuery request, CancellationToken cancellationToken)
        {
            var department = await _readRepository.GetByIdAsync(request.Id, cancellationToken: cancellationToken);
            if (department is null)
                return null;

            return _mapper.Map<DepartmentDto>(department);
        }
    }
}
