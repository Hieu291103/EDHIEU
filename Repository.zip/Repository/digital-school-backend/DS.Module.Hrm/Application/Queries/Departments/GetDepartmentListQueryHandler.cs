using DS.Module.Hrm.Application.DTOs;
using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Bson;
using MongoDB.Driver;
using System.Text.RegularExpressions;

namespace DS.Module.Hrm.Application.Queries.Departments
{
    /// <summary>
    /// Handler cho GetDepartmentListQuery
    /// </summary>
    public class GetDepartmentListQueryHandler : IQueryHandler<GetDepartmentListQuery, PagedResult<DepartmentListDto>>
    {
        private readonly IHrmReadRepository<DepartmentEntity> _readRepository;

        public GetDepartmentListQueryHandler(IHrmReadRepository<DepartmentEntity> readRepository)
        {
            _readRepository = readRepository;
        }

        public async Task<PagedResult<DepartmentListDto>> Handle(GetDepartmentListQuery request, CancellationToken cancellationToken)
        {
            var filterBuilder = Builders<DepartmentEntity>.Filter;
            var filter = filterBuilder.Empty;

            if (!string.IsNullOrWhiteSpace(request.Keyword))
            {
                var regex = new BsonRegularExpression(Regex.Escape(request.Keyword.Trim()), "i");
                filter = filterBuilder.And(filter, filterBuilder.Regex(d => d.Name, regex));
            }

            if (request.IsActive.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Eq(d => d.IsActive, request.IsActive.Value));

            if (request.IsTeam.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Eq(d => d.IsTeam, request.IsTeam.Value));

            if (!string.IsNullOrWhiteSpace(request.ParentId))
                filter = filterBuilder.And(filter, filterBuilder.Eq(d => d.ParentId, request.ParentId));

            var pagedResult = await _readRepository.PagedFilterAsync(
                filter,
                d => new DepartmentListDto
                {
                    Id = d.Id,
                    Name = d.Name,
                    ManagerId = d.ManagerId,
                    IsActive = d.IsActive,
                    SortOrder = d.SortOrder,
                },
                request.PageIndex ?? 1,
                request.PageSize ?? 50,
                orderByDescending: false,
                cancellationToken: cancellationToken);

            return new PagedResult<DepartmentListDto>
            {
                Items = pagedResult.Items.ToList(),
                Total = pagedResult.Total,
                Page = pagedResult.Page,
                PageSize = pagedResult.PageSize,
                PageIndex = pagedResult.PageIndex,
            };
        }
    }
}
