using DS.Module.Hrm.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Hrm.Application.Queries.Departments
{
    /// <summary>
    /// Query để lấy chi tiết phòng ban theo ID
    /// </summary>
    public class GetDepartmentByIdQuery : IQuery<DepartmentDto?>
    {
        public string Id { get; set; } = string.Empty;
    }
}
