using DS.Module.Hrm.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Requests;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Hrm.Application.Queries.Departments
{
    /// <summary>
    /// Query để lấy danh sách phòng ban với bộ lọc và phân trang
    /// </summary>
    public class GetDepartmentListQuery : FilterRequest, IQuery<PagedResult<DepartmentListDto>>
    {
        public bool? IsActive { get; set; }
        public bool? IsTeam { get; set; }
        public string? ParentId { get; set; }
    }
}
