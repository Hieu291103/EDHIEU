using AutoMapper;
using DS.Module.Hrm.Application.DTOs;
using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Contracts.Dtos;
using DS.Shared.Core.Domain.Entities;

namespace DS.Module.Hrm.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho ProfileDocument entity
    /// </summary>
    public class ProfileDocumentMappingProfile : Profile
    {
        public ProfileDocumentMappingProfile()
        {
            CreateMap<ProfileDocumentEntity, ProfileDocumentDto>().ReverseMap();
            CreateMap<ProfileDocumentEntity, ProfileDocumentListDto>();
            CreateMap<S3AttachmentInfo, S3AttachmentDto>();
            CreateMap<S3AttachmentDto, S3AttachmentInfo>();
        }
    }
}
