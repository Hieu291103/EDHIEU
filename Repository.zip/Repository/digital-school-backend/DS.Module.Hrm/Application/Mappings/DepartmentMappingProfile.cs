using AutoMapper;
using DS.Module.Hrm.Application.DTOs;
using DS.Module.Hrm.Domain.Entities;

namespace DS.Module.Hrm.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho Department entity
    /// </summary>
    public class DepartmentMappingProfile : Profile
    {
        public DepartmentMappingProfile()
        {
            CreateMap<DepartmentEntity, DepartmentDto>().ReverseMap();
            CreateMap<DepartmentEntity, DepartmentListDto>();
        }
    }
}
