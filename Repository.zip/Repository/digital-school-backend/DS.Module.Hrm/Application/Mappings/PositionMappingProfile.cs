using AutoMapper;
using DS.Module.Hrm.Application.DTOs;
using DS.Module.Hrm.Domain.Entities;

namespace DS.Module.Hrm.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho Position entity
    /// </summary>
    public class PositionMappingProfile : Profile
    {
        public PositionMappingProfile()
        {
            CreateMap<EmployeePositionEntity, PositionDto>().ReverseMap();
            CreateMap<EmployeePositionEntity, PositionListDto>();
        }
    }
}

