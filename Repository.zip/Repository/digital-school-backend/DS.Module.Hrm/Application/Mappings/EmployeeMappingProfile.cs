using AutoMapper;
using DS.Module.Hrm.Application.DTOs;
using DS.Module.Hrm.Domain.Entities;

namespace DS.Module.Hrm.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho Employee entity
    /// </summary>
    public class EmployeeMappingProfile : Profile
    {
        public EmployeeMappingProfile()
        {
            CreateMap<EmployeeEntity, EmployeeDto>().ReverseMap();
            CreateMap<EmployeeEntity, EmployeeListDto>();
        }
    }
}
