using AutoMapper;
using DS.Module.Hrm.Application.DTOs;
using DS.Module.Hrm.Domain.Entities;

namespace DS.Module.Hrm.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho Company entity
    /// </summary>
    public class CompanyMappingProfile : Profile
    {
        public CompanyMappingProfile()
        {
            CreateMap<CompanyEntity, CompanyDto>().ReverseMap();
            CreateMap<CompanyEntity, CompanyListDto>();
        }
    }
}
