using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Hrm.Application.Commands.Positions
{
    /// <summary>
    /// Handler cho CreatePositionCommand
    /// </summary>
    public class CreateEmployeePositionCommandHandler : ICommandHandler<CreateEmployeePositionCommand, Result>
    {
        private readonly IHrmWriteRepository<EmployeePositionEntity> _writeRepository;
        private readonly IHrmReadRepository<EmployeePositionEntity> _readRepository;

        public CreateEmployeePositionCommandHandler(
            IHrmWriteRepository<EmployeePositionEntity> writeRepository,
            IHrmReadRepository<EmployeePositionEntity> readRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
        }

        public async Task<Result> Handle(CreateEmployeePositionCommand request, CancellationToken cancellationToken)
        {
            // Kiểm tra trùng tên chức vụ
            var existing = await _readRepository.FilterAsync(
                p => p.Name == request.Name,
                cancellationToken: cancellationToken);

            if (existing.Any())
                throw DSException.WithParam("PositionNameAlreadyExists", request.Name);

            var position = new EmployeePositionEntity
            {
                Name = request.Name,
                IsActive = request.IsActive,
            };

            await _writeRepository.InsertAsync(position, cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}

