using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Hrm.Application.Commands.Positions
{
    /// <summary>
    /// Command để tạo chức vụ mới
    /// </summary>
    public class CreateEmployeePositionCommand : ICommand<Result>
    {
        public required string Name { get; set; }
        public bool IsActive { get; set; } = true;
    }
}
