using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Hrm.Application.Commands.Positions
{
    /// <summary>
    /// Handler cho DeletePositionCommand.
    /// Kiểm tra không còn nhân viên nào đang giữ chức vụ này trước khi xóa.
    /// </summary>
    public class DeleteEmployeePositionCommandHandler : ICommandHandler<DeleteEmployeePositionCommand, Result>
    {
        private readonly IHrmWriteRepository<EmployeePositionEntity> _writeRepository;
        private readonly IHrmReadRepository<EmployeePositionEntity> _readRepository;
        private readonly IHrmReadRepository<EmployeeEntity> _employeeReadRepository;

        public DeleteEmployeePositionCommandHandler(
            IHrmWriteRepository<EmployeePositionEntity> writeRepository,
            IHrmReadRepository<EmployeePositionEntity> readRepository,
            IHrmReadRepository<EmployeeEntity> employeeReadRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _employeeReadRepository = employeeReadRepository;
        }

        public async Task<Result> Handle(DeleteEmployeePositionCommand request, CancellationToken cancellationToken)
        {
            var position = await _readRepository.GetByIdAsync(request.Id, cancellationToken: cancellationToken);
            if (position is null)
                throw new DSException("PositionNotFound");

            // Ngăn xóa nếu còn nhân viên đang giữ chức vụ này
            var employees = await _employeeReadRepository.FilterAsync(
                e => e.PositionId == request.Id,
                cancellationToken: cancellationToken);

            if (employees.Any())
                throw new DSException("PositionHasEmployees");

            await _writeRepository.DeleteAsync(request.Id, cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}

