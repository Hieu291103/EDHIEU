using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Hrm.Application.Commands.Positions
{
    /// <summary>
    /// Command để cập nhật chức vụ
    /// </summary>
    public class UpdateEmployeePositionCommand : ICommand<Result>
    {
        public required string Id { get; set; }
        public required string Name { get; set; }
        public bool IsActive { get; set; }
    }
}
