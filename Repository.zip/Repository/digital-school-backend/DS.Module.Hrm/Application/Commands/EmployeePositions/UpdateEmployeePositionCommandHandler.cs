using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Hrm.Application.Commands.Positions
{
    /// <summary>
    /// Handler cho UpdatePositionCommand
    /// </summary>
    public class UpdateEmployeePositionCommandHandler : ICommandHandler<UpdateEmployeePositionCommand, Result>
    {
        private readonly IHrmWriteRepository<EmployeePositionEntity> _writeRepository;
        private readonly IHrmReadRepository<EmployeePositionEntity> _readRepository;

        public UpdateEmployeePositionCommandHandler(
            IHrmWriteRepository<EmployeePositionEntity> writeRepository,
            IHrmReadRepository<EmployeePositionEntity> readRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
        }

        public async Task<Result> Handle(UpdateEmployeePositionCommand request, CancellationToken cancellationToken)
        {
            var position = await _readRepository.GetByIdAsync(request.Id, cancellationToken: cancellationToken);
            if (position is null)
                throw new DSException("PositionNotFound");

            // Kiểm tra trùng tên với chức vụ khác
            var duplicates = await _readRepository.FilterAsync(
                p => p.Name == request.Name && p.Id != request.Id,
                cancellationToken: cancellationToken);

            if (duplicates.Any())
                throw DSException.WithParam("PositionNameAlreadyExists", request.Name);

            if (request.Name.IsNotNull())
                position.Name = request.Name;

            position.IsActive = request.IsActive;

            await _writeRepository.UpdateAsync(position, cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}

