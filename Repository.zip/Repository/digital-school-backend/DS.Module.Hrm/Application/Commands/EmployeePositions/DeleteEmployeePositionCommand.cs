using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Hrm.Application.Commands.Positions
{
    /// <summary>
    /// Command để xóa chức vụ
    /// </summary>
    public class DeleteEmployeePositionCommand : ICommand<Result>
    {
        public required string Id { get; set; }
    }
}
