using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Hrm.Application.Commands.Departments
{
    /// <summary>
    /// Command để xóa phòng ban / tổ nhóm
    /// </summary>
    public class DeleteDepartmentCommand : ICommand<Result>
    {
        public required string Id { get; set; }
    }
}
