using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Hrm.Application.Commands.Departments
{
    /// <summary>
    /// Handler cho UpdateDepartmentCommand
    /// </summary>
    public class UpdateDepartmentCommandHandler : ICommandHandler<UpdateDepartmentCommand, Result>
    {
        private readonly IHrmWriteRepository<DepartmentEntity> _writeRepository;
        private readonly IHrmReadRepository<DepartmentEntity> _readRepository;

        public UpdateDepartmentCommandHandler(
            IHrmWriteRepository<DepartmentEntity> writeRepository,
            IHrmReadRepository<DepartmentEntity> readRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
        }

        public async Task<Result> Handle(UpdateDepartmentCommand request, CancellationToken cancellationToken)
        {
            var department = await _readRepository.GetByIdAsync(request.Id, cancellationToken: cancellationToken);
            if (department is null)
                throw new DSException("DepartmentNotFound");

            // Kiểm tra ParentId tồn tại nếu được cung cấp và không tự tham chiếu
            if (request.ParentId is not null)
            {
                if (request.ParentId == request.Id)
                    throw new DSException("DepartmentCircularReference");

                var parent = await _readRepository.GetByIdAsync(request.ParentId, cancellationToken: cancellationToken);
                if (parent is null)
                    throw new DSException("DepartmentParentNotFound");
            }

            if (request.Name.IsNotNull())
                department.Name = request.Name;
            if (request.ManagerId.IsNotNull())
                department.ManagerId = request.ManagerId;
            if (request.ParentId.IsNotNull())
                department.ParentId = request.ParentId;

            department.IsTeam = request.IsTeam;
            department.IsActive = request.IsActive;
            department.SortOrder = request.SortOrder;

            await _writeRepository.UpdateAsync(department, cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}
