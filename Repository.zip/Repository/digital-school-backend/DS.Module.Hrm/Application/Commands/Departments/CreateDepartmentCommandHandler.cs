using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Hrm.Application.Commands.Departments
{
    /// <summary>
    /// Handler cho CreateDepartmentCommand
    /// </summary>
    public class CreateDepartmentCommandHandler : ICommandHandler<CreateDepartmentCommand, Result>
    {
        private readonly IHrmWriteRepository<DepartmentEntity> _writeRepository;
        private readonly IHrmReadRepository<DepartmentEntity> _readRepository;

        public CreateDepartmentCommandHandler(
            IHrmWriteRepository<DepartmentEntity> writeRepository,
            IHrmReadRepository<DepartmentEntity> readRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
        }

        public async Task<Result> Handle(CreateDepartmentCommand request, CancellationToken cancellationToken)
        {
            // Kiểm tra ParentId tồn tại nếu được cung cấp
            if (request.ParentId is not null)
            {
                var parent = await _readRepository.GetByIdAsync(request.ParentId, cancellationToken: cancellationToken);
                if (parent is null)
                    throw new DSException("DepartmentParentNotFound");
            }

            var department = new DepartmentEntity
            {
                Name = request.Name,
                ManagerId = request.ManagerId,
                ParentId = request.ParentId,
                IsTeam = request.IsTeam,
                SortOrder = request.SortOrder,
                IsActive = request.IsActive,
            };

            await _writeRepository.InsertAsync(department, cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}
