using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Hrm.Application.Commands.Departments
{
    /// <summary>
    /// Handler cho DeleteDepartmentCommand.
    /// Kiểm tra không còn nhân viên hoặc phòng ban con trước khi xóa.
    /// </summary>
    public class DeleteDepartmentCommandHandler : ICommandHandler<DeleteDepartmentCommand, Result>
    {
        private readonly IHrmWriteRepository<DepartmentEntity> _writeRepository;
        private readonly IHrmReadRepository<DepartmentEntity> _readRepository;
        private readonly IHrmReadRepository<EmployeeEntity> _employeeReadRepository;

        public DeleteDepartmentCommandHandler(
            IHrmWriteRepository<DepartmentEntity> writeRepository,
            IHrmReadRepository<DepartmentEntity> readRepository,
            IHrmReadRepository<EmployeeEntity> employeeReadRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _employeeReadRepository = employeeReadRepository;
        }

        public async Task<Result> Handle(DeleteDepartmentCommand request, CancellationToken cancellationToken)
        {
            var department = await _readRepository.GetByIdAsync(request.Id, cancellationToken: cancellationToken);
            if (department is null)
                throw new DSException("DepartmentNotFound");

            // Ngăn xóa nếu còn phòng ban / tổ con tham chiếu
            var children = await _readRepository.FilterAsync(
                d => d.ParentId == request.Id,
                cancellationToken: cancellationToken);

            if (children.Any())
                throw new DSException("DepartmentHasChildren");

            // Ngăn xóa nếu còn nhân viên đang thuộc phòng ban này
            var employees = await _employeeReadRepository.FilterAsync(
                e => e.DepartmentId == request.Id || e.TeamId == request.Id,
                cancellationToken: cancellationToken);

            if (employees.Any())
                throw new DSException("DepartmentHasEmployees");

            await _writeRepository.DeleteAsync(request.Id, cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}
