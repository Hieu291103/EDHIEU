using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Hrm.Application.Commands.Departments
{
    /// <summary>
    /// Command để tạo phòng ban / tổ nhóm mới
    /// </summary>
    public class CreateDepartmentCommand : ICommand<Result>
    {
        public required string Name { get; set; } = string.Empty;
        public string? ManagerId { get; set; }
        public string? ParentId { get; set; }
        public bool IsTeam { get; set; } = false;
        public int? SortOrder { get; set; }
        public bool IsActive { get; set; } = true;
    }
}
