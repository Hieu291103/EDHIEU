using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Hrm.Application.Commands.Departments
{
    /// <summary>
    /// Command để cập nhật thông tin phòng ban / tổ nhóm
    /// </summary>
    public class UpdateDepartmentCommand : ICommand<Result>
    {
        public required string Id { get; set; } = string.Empty;
        public required string? Name { get; set; }
        public string? ManagerId { get; set; }
        public string? ParentId { get; set; }
        public bool IsTeam { get; set; }
        public bool IsActive { get; set; }
        public int? SortOrder { get; set; }
    }
}
