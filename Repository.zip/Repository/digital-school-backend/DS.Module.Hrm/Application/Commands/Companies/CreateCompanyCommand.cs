using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Hrm.Application.Commands.Companies
{
    /// <summary>
    /// Command để tạo công ty / chi nhánh mới
    /// </summary>
    public class CreateCompanyCommand : ICommand<Result>
    {
        public required string Name { get; set; } = string.Empty;
        public string? Address { get; set; }
        public string? DirectorId { get; set; }
        public bool IsActive { get; set; } = true;
    }
}
