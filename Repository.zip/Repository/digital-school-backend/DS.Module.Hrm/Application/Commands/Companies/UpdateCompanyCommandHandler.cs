using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Hrm.Application.Commands.Companies
{
    /// <summary>
    /// Handler cho UpdateCompanyCommand
    /// </summary>
    public class UpdateCompanyCommandHandler : ICommandHandler<UpdateCompanyCommand, Result>
    {
        private readonly IHrmWriteRepository<CompanyEntity> _writeRepository;
        private readonly IHrmReadRepository<CompanyEntity> _readRepository;

        public UpdateCompanyCommandHandler(
            IHrmWriteRepository<CompanyEntity> writeRepository,
            IHrmReadRepository<CompanyEntity> readRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
        }

        public async Task<Result> Handle(UpdateCompanyCommand request, CancellationToken cancellationToken)
        {
            var company = await _readRepository.GetByIdAsync(request.Id, cancellationToken: cancellationToken);
            if (company is null)
                throw new DSException("CompanyNotFound");

            // Kiểm tra trùng tên với công ty khác
            var duplicates = await _readRepository.FilterAsync(
                c => c.Name == request.Name && c.Id != request.Id,
                cancellationToken: cancellationToken);

            if (duplicates.Any())
                throw DSException.WithParam("CompanyNameAlreadyExists", request.Name);

            if (request.Name.IsNotNull())
                company.Name = request.Name;
            if (request.Address.IsNotNull())
                company.Address = request.Address;
            if (request.DirectorId.IsNotNull())
                company.DirectorId = request.DirectorId;
            company.IsActive = request.IsActive;

            await _writeRepository.UpdateAsync(company, cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}
