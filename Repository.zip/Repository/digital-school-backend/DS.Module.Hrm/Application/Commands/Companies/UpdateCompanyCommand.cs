using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Hrm.Application.Commands.Companies
{
    /// <summary>
    /// Command để cập nhật thông tin công ty / chi nhánh
    /// </summary>
    public class UpdateCompanyCommand : ICommand<Result>
    {
        public required string Id { get; set; } = string.Empty;
        public required string? Name { get; set; }
        public required string? Address { get; set; }
        public bool IsActive { get; set; }
        public string? DirectorId { get; set; }
    }
}
