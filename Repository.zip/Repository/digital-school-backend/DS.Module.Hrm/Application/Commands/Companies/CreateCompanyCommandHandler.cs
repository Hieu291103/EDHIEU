using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Hrm.Application.Commands.Companies
{
    /// <summary>
    /// Handler cho CreateCompanyCommand
    /// </summary>
    public class CreateCompanyCommandHandler : ICommandHandler<CreateCompanyCommand, Result>
    {
        private readonly IHrmWriteRepository<CompanyEntity> _writeRepository;
        private readonly IHrmReadRepository<CompanyEntity> _readRepository;

        public CreateCompanyCommandHandler(
            IHrmWriteRepository<CompanyEntity> writeRepository,
            IHrmReadRepository<CompanyEntity> readRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
        }

        public async Task<Result> Handle(CreateCompanyCommand request, CancellationToken cancellationToken)
        {
            // Kiểm tra trùng tên công ty
            var existing = await _readRepository.FilterAsync(
                c => c.Name == request.Name,
                cancellationToken: cancellationToken);

            if (existing.Any())
                throw new DSException("CompanyNameAlreadyExists");

            var company = new CompanyEntity
            {
                Name = request.Name,
                Address = request.Address,
                DirectorId = request.DirectorId,
                IsActive = request.IsActive,
            };

            await _writeRepository.InsertAsync(company, cancellationToken);

            return Result.Success();
        }
    }
}
