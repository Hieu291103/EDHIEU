using DS.Module.Hrm.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Hrm.Application.Commands.Companies
{
    /// <summary>
    /// Handler cho DeleteCompanyCommand.
    /// Kiểm tra không còn nhân viên nào thuộc công ty trước khi xóa.
    /// </summary>
    public class DeleteCompanyCommandHandler : ICommandHandler<DeleteCompanyCommand, Result>
    {
        private readonly IHrmWriteRepository<CompanyEntity> _writeRepository;
        private readonly IHrmReadRepository<CompanyEntity> _readRepository;
        private readonly IHrmReadRepository<EmployeeEntity> _employeeReadRepository;

        public DeleteCompanyCommandHandler(
            IHrmWriteRepository<CompanyEntity> writeRepository,
            IHrmReadRepository<CompanyEntity> readRepository,
            IHrmReadRepository<EmployeeEntity> employeeReadRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _employeeReadRepository = employeeReadRepository;
        }

        public async Task<Result> Handle(DeleteCompanyCommand request, CancellationToken cancellationToken)
        {
            var company = await _readRepository.GetByIdAsync(request.Id, cancellationToken: cancellationToken);
            if (company is null)
                throw new DSException("CompanyNotFound");

            // Ngăn xóa nếu còn nhân viên đang thuộc công ty này
            var employees = await _employeeReadRepository.FilterAsync(
                e => e.CompanyId == request.Id,
                cancellationToken: cancellationToken);

            if (employees.Any())
                throw new DSException("CompanyHasEmployees");

            await _writeRepository.DeleteAsync(request.Id, cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}
