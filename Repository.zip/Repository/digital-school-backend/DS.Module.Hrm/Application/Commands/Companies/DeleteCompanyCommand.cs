using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Hrm.Application.Commands.Companies
{
    /// <summary>
    /// Command để xóa công ty / chi nhánh
    /// </summary>
    public class DeleteCompanyCommand : ICommand<Result>
    {
        public required string Id { get; set; }
    }
}
