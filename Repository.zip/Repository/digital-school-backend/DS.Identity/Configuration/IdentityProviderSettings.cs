namespace DS.Identity.Configuration
{
    /// <summary>
    /// Identity Provider Configuration
    /// Kết hợp cấu hình từ appsettings với database
    /// </summary>
    public class IdentityProviderSettings
    {
        /// <summary>
        /// Danh sách provider được bật
        /// Mỗi provider sẽ được cache từ database, nếu không có thì fallback appsettings
        /// </summary>
        public List<ProviderConfig> Providers { get; set; } = new();

        /// <summary>
        /// Thời gian cache provider config (seconds)
        /// </summary>
        public int CacheDurationSeconds { get; set; } = 3600; // 1 hour
    }

    /// <summary>
    /// Cấu hình provider từ appsettings.json
    /// </summary>
    public class ProviderConfig
    {
        /// <summary>
        /// Mã provider (local, google, azuread,...)
        /// </summary>
        public string Code { get; set; } = string.Empty;

        /// <summary>
        /// Tên hiển thị
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Loại: local, oauth2, saml, openid
        /// </summary>
        public string ProviderType { get; set; } = "local";

        /// <summary>
        /// Bật/tắt
        /// </summary>
        public bool IsEnabled { get; set; } = true;

        /// <summary>
        /// OAuth2 Configuration
        /// </summary>
        public OAuthSettings? OAuth { get; set; }

        /// <summary>
        /// SAML Configuration
        /// </summary>
        public SamlSettings? Saml { get; set; }

        /// <summary>
        /// Thứ tự hiển thị
        /// </summary>
        public int DisplayOrder { get; set; } = 0;

        /// <summary>
        /// Cho phép đăng ký
        /// </summary>
        public bool AllowUserRegistration { get; set; } = false;

        /// <summary>
        /// Yêu cầu email verified
        /// </summary>
        public bool RequireEmailVerification { get; set; } = false;
    }

    /// <summary>
    /// OAuth2/OIDC Settings từ appsettings
    /// </summary>
    public class OAuthSettings
    {
        public string? AuthorizationEndpoint { get; set; }
        public string? TokenEndpoint { get; set; }
        public string? UserInfoEndpoint { get; set; }
        public string? JwksUri { get; set; }
        public string? ClientId { get; set; }
        public string? ClientSecret { get; set; }
        public string? RedirectUri { get; set; }
        public string? Scopes { get; set; }
        public string ResponseType { get; set; } = "code";
        public string GrantType { get; set; } = "authorization_code";
    }

    /// <summary>
    /// SAML Settings từ appsettings
    /// </summary>
    public class SamlSettings
    {
        public string? MetadataUrl { get; set; }
        public string? SingleSignOnServiceUrl { get; set; }
        public string? Certificate { get; set; }
        public string? EntityId { get; set; }
        public string? NameIdFormat { get; set; }
    }
}
