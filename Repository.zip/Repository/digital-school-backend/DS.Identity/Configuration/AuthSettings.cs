namespace DS.Identity.Configuration
{
    /// <summary>
    /// OAuth2/Auth Configuration from appsettings.json
    /// Section: "Auth"
    /// </summary>
    public class AuthSettings
    {
        /// <summary>
        /// Default OAuth2 Client ID
        /// Used when client_id is not provided in request
        /// </summary>
        public string DefaultClientId { get; set; } = string.Empty;

        /// <summary>
        /// Default OAuth2 Redirect URI
        /// Used when redirect_uri is not provided in request
        /// </summary>
        public string DefaultRedirectUri { get; set; } = string.Empty;

        /// <summary>
        /// Default return URL after authentication
        /// Where to redirect user after successful login
        /// </summary>
        public string DefaultRedirectReturn { get; set; } = string.Empty;
    }
}
