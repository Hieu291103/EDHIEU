using DS.Module.Identity.Domain.Entities;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Common.Constants;

namespace DS.Identity.Pages.Examples
{
    /// <summary>
    /// Example: Sử dụng IdentityProviderService trong Login flow
    /// </summary>
    public class LoginWithProviderExample
    {
        private readonly IIdentityProviderService _identityProviderService;
        private readonly ILoginRequestService _loginRequestService;

        public LoginWithProviderExample(
            IIdentityProviderService identityProviderService,
            ILoginRequestService loginRequestService)
        {
            _identityProviderService = identityProviderService;
            _loginRequestService = loginRequestService;
        }

        /// <summary>
        /// Ví dụ 1: Khi user nhập email, kiểm tra domain để route tới provider đúng
        /// </summary>
        public async Task<string?> HandleLoginHintAsync(string emailOrUsername)
        {
            // Tìm provider phù hợp dựa trên login hint (email domain)
            var provider = await _identityProviderService.FindProviderByLoginHintAsync(emailOrUsername);

            if (provider == null)
            {
                // Fallback: dùng provider mặc định (local)
                provider = await _identityProviderService.GetDefaultProviderAsync();
            }

            // Nếu provider là external (không phải local), redirect tới OAuth provider
            if (provider != null && provider.Code != IdentityProviderCodes.Local)
            {
                // Redirect tới OAuth endpoint của provider
                return provider.Code;
            }

            // Nếu là local, tiếp tục normal login flow
            return IdentityProviderCodes.Local;
        }

        /// <summary>
        /// Ví dụ 2: Sau khi user đăng nhập thành công, cập nhật User entity với provider
        /// </summary>
        public async Task UpdateUserProviderAsync(UserEntity user, string providerCode)
        {
            // Lấy thông tin provider từ database (có cache)
            var provider = await _identityProviderService.GetProviderByCodeAsync(providerCode);

            if (provider != null)
            {
                // Cập nhật user entity
                user.SetIdentityProvider(provider.Code);
                user.UseProvider = provider.Code != IdentityProviderCodes.Local;
                user.IdentityProviderCode = provider.Code;

                // Nếu provider là external, có thể cập nhật thêm info
                if (user.IsExternalProvider())
                {
                    // Update email verified status từ provider
                    if (!string.IsNullOrEmpty(user.Email))
                    {
                        user.EmailVerified = true;
                    }
                }
            }
        }

        /// <summary>
        /// Ví dụ 3: Lấy danh sách provider được bật để hiển thị trên login page
        /// </summary>
        public async Task<List<ProviderViewModel>> GetLoginProvidersAsync()
        {
            var providers = await _identityProviderService.GetEnabledProvidersAsync();

            return providers
                .Where(p => p.Code != IdentityProviderCodes.Local || p.IsDefault)
                .Select(p => new ProviderViewModel
                {
                    Code = p.Code,
                    Name = p.Name,
                    DisplayName = p.DisplayName ?? p.Name
                })
                .ToList();
        }
    }

    /// <summary>
    /// View model cho provider display
    /// </summary>
    public class ProviderViewModel
    {
        public string Code { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
    }
}
