using DS.Identity.Configuration;
using DS.Module.Identity.Application.Commands.Auth;
using DS.Module.Identity.Application.DTOs;
using DS.Module.Identity.Domain.Constants;
using DS.Module.Identity.Domain.Entities;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.Localization;
using DS.Shared.Core.Common.Constants;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Options;

namespace DS.Identity.Pages
{
    public class LoginModel : PageModel
    {
        private readonly ILoginRequestService _loginRequestService;
        private readonly IMediator _mediator;
        private readonly ILocalizationService _localizationService;
        private readonly IUserSessionService _sessionService;
        private readonly IAdminReadRepository<UserEntity> _userRepository;
        private readonly AuthSettings _authSettings;
        private readonly IDataProtectionProvider _dataProtectionProvider;

        public LoginModel(
            ILoginRequestService loginRequestService,
            IMediator mediator,
            ILocalizationService localizationService,
            IUserSessionService sessionService,
            IAdminReadRepository<UserEntity> userRepository,
            IOptions<AuthSettings> authSettingsOptions,
            IDataProtectionProvider dataProtectionProvider)
        {
            _loginRequestService = loginRequestService;
            _localizationService = localizationService;
            _mediator = mediator;
            _sessionService = sessionService;
            _userRepository = userRepository;
            _authSettings = authSettingsOptions.Value;
            _dataProtectionProvider = dataProtectionProvider;
        }

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public bool LoginWithPassword { get; set; } = false;

        /// <summary>
        /// Request ID - single parameter to lookup OAuth context from server
        /// Replaces all individual OAuth parameters
        /// </summary>
        [BindProperty(SupportsGet = true)]
        public string? RequestId { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? RedirectUri { get; set; }

        /// <summary>
        /// SSO: List of all saved accounts with session keys
        /// Used for account selection during login
        /// </summary>
        public List<(string? Username, string? Email, string? FullName, string? SessionKey)> SavedAccounts { get; set; } = new();

        // Internal - loaded from LoginRequest
        private LoginRequestDto? _loginRequest;

        /// <summary>
        /// Helper: Extract error code and parameters from exception
        /// For DSException, use the error code; for others, use generic error code
        /// </summary>
        private string GetLocalizedErrorMessage(Exception ex)
        {
            var languageCode = RequestHelper.GetHeaderValueLanguage(Request.Headers);
            if (ex is DSException dsEx)
            {
                if (dsEx.errorParam != null)
                {
                    return _localizationService.GetFormattedMessage(dsEx.errorCode, languageCode, dsEx.errorParam);
                }
                return _localizationService.GetMessage(dsEx.errorCode, languageCode) ?? dsEx.errorCode;
            }

            return _localizationService.GetMessage("InvalidRequest", languageCode) ?? "Yêu cầu không hợp lệ";
        }

        /// <summary>
        /// Validate and load login request from cache
        /// Return null if expired/invalid, show error and redirect to start
        /// </summary>
        private async Task<LoginRequestDto?> ValidateLoginRequestAsync()
        {
            if (string.IsNullOrEmpty(RequestId))
            {
                return null;
            }

            var loginRequest = await _loginRequestService.GetByRequestIdAsync(RequestId);
            if (loginRequest == null)
            {
                // Session expired - redirect to OAuth start (client will retry)
                // ✅ Add error with key "RequestIdExpired" so client knows to show session expired modal
                ModelState.AddModelError("RequestIdExpired", "Phiên đăng nhập đã hết hạn. Vui lòng thử lại.");
                return null;
            }

            return loginRequest;
        }

        /// <summary>
        /// Helper: Redirect về Login page với RequestId
        /// Dùng khi action thành công và cần giữ RequestId trong URL
        /// </summary>
        private IActionResult RedirectWithRequestId()
        {
            return RedirectToPage("/Login", new { requestId = RequestId, redirectUri = RedirectUri });
        }

        /// <summary>
        /// Get all stored session keys from cookie
        /// Returns list of session keys (JSON format)
        /// </summary>
        private List<string> GetStoredSessionKeys()
        {
            var sessionKeysJson = Request.Cookies[CookieConstants.SessionKeysCookieName];
            if (string.IsNullOrEmpty(sessionKeysJson))
                return new List<string>();

            try
            {
                return System.Text.Json.JsonSerializer.Deserialize<List<string>>(sessionKeysJson) ?? new List<string>();
            }
            catch
            {
                return new List<string>();
            }
        }

        /// <summary>
        /// Save session keys to cookie (JSON format)
        /// </summary>
        private void SaveSessionKeysToCookie(List<string> sessionKeys)
        {
            var sessionKeysJson = System.Text.Json.JsonSerializer.Serialize(sessionKeys);
            Response.Cookies.Append(
                CookieConstants.SessionKeysCookieName,
                sessionKeysJson,
                new Microsoft.AspNetCore.Http.CookieOptions
                {
                    HttpOnly = CookieConstants.CookieHttpOnly,
                    Secure = CookieConstants.CookieSecure,
                    SameSite = SameSiteMode.Lax,
                    Expires = DateTimeOffset.UtcNow.AddSeconds(CookieConstants.SessionLifetimeSeconds)
                });
        }

        public async Task<IActionResult> OnGetAsync()
        {
            // If no RequestId, this is initial OAuth request with all parameters in query string
            if (string.IsNullOrEmpty(RequestId))
            {
                var clientId = Request.Query[OAuthQueryParameters.ClientId].ToString();
                var redirectUri = Request.Query[OAuthQueryParameters.RedirectUri].ToString();
                var responseType = Request.Query[OAuthQueryParameters.ResponseType].ToString();
                var scope = Request.Query[OAuthQueryParameters.Scope].ToString();
                var state = Request.Query[OAuthQueryParameters.State].ToString();
                var codeChallenge = Request.Query[OAuthQueryParameters.CodeChallenge].ToString();
                var codeChallengeMethod = Request.Query[OAuthQueryParameters.CodeChallengeMethod].ToString();
                var nonce = Request.Query[OAuthQueryParameters.Nonce].ToString();
                var loginHint = Request.Query[OAuthQueryParameters.LoginHint].ToString();
                var idpHint = Request.Query[OAuthQueryParameters.IdpHint].ToString();
                var prompt = Request.Query[OAuthQueryParameters.Prompt].ToString();

                if (string.IsNullOrEmpty(clientId) || string.IsNullOrEmpty(redirectUri))
                {
                    //Use default settings from appsettings.json
                    clientId = _authSettings.DefaultClientId ?? "426a0846-0222-4965-afd5-d475ef4fc60f";
                    redirectUri = _authSettings.DefaultRedirectUri ?? "https://truonghocso.edu.vn/auth/callback";
                    responseType = OAuthQueryParameters.DefaultResponseType;
                    scope = string.Join(OAuthQueryParameters.ScopeSeparator, StandardScopes.StandardOpenIdScopes);
                }

                try
                {
                    // Create and validate login request on server
                    var (requestId, expiresAt) = await _loginRequestService.CreateAsync(
                        clientId: clientId,
                        redirectUri: redirectUri,
                        responseType: string.IsNullOrEmpty(responseType) ? OAuthQueryParameters.DefaultResponseType : responseType,
                        scope: scope,
                        state: state,
                        codeChallenge: codeChallenge,
                        codeChallengeMethod: codeChallengeMethod,
                        nonce: nonce,
                        loginHint: loginHint,
                        identityProvider: idpHint,
                        prompt: prompt
                    );

                    // Redirect to clean URL with only RequestId
                    return RedirectToPage("/Login", new { requestId, redirectUri });
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", GetLocalizedErrorMessage(ex));
                    return Page();
                }
            }

            // Load and validate existing login request
            try
            {
                _loginRequest = await ValidateLoginRequestAsync();
                if (_loginRequest == null)
                {
                    return Page();
                }

                // Pre-fill username if login_hint was provided
                if (!string.IsNullOrEmpty(_loginRequest.LoginHint))
                {
                    Input.Username = _loginRequest.LoginHint;
                }

                // ✨ Load saved accounts only once when displaying form
                await LoadSavedAccountsAsync();
                // ✨ SSO: Check if loginHint matches any saved account - auto-login if found
                if (!string.IsNullOrEmpty(_loginRequest.LoginHint) && SavedAccounts.Count > 0)
                {
                    var matchedAccount = SavedAccounts.FirstOrDefault(acc =>
                        acc.Username!.Equals(_loginRequest.LoginHint, StringComparison.OrdinalIgnoreCase) ||
                        acc.Email!.Equals(_loginRequest.LoginHint, StringComparison.OrdinalIgnoreCase));

                    if (matchedAccount != default)
                    {
                        // ✅ Found matching account in SavedAccounts - auto-login via session
                        await _loginRequestService.MarkAsAuthenticatedAsync(RequestId!,
                            (await _sessionService.GetUserIdFromSessionAsync(matchedAccount.SessionKey!))!);
                        return Redirect($"/oauth2/callback?requestId={RequestId}");
                    }
                }

                // If username already validated, show password form
                if (!string.IsNullOrEmpty(_loginRequest.ValidatedUsername))
                {
                    Input.Username = _loginRequest.ValidatedUsername;
                    LoginWithPassword = true;
                }

                return Page();
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", GetLocalizedErrorMessage(ex));
                return Page();
            }
        }

        public async Task<IActionResult> OnPostCheckUserAsync()
        {
            try
            {
                // ✅ Load saved accounts for display on page
                await LoadSavedAccountsAsync();

                if (string.IsNullOrWhiteSpace(Input.Username))
                {
                    ModelState.AddModelError(nameof(Input.Username), "Vui lòng nhập tên đăng nhập hoặc email");
                    return Page();
                }

                // ✅ Validate RequestId first
                _loginRequest = await ValidateLoginRequestAsync();
                if (_loginRequest == null)
                {
                    return Page();
                }

                // Check if user exists
                var user = await _loginRequestService.FindByUsernameOrEmailAsync(Input.Username);
                if (user == null)
                {
                    ModelState.AddModelError(nameof(Input.Username), "Tên đăng nhập không tồn tại");
                    return Page();
                }

                // ✨ Check if username is in saved accounts (SSO) - use cached data from hidden input
                if (SavedAccounts.Count > 0)
                {
                    var matchedAccount = SavedAccounts.FirstOrDefault(acc =>
                        acc.Username!.Equals(Input.Username, StringComparison.OrdinalIgnoreCase) ||
                        acc.Email!.Equals(Input.Username, StringComparison.OrdinalIgnoreCase));

                    if (matchedAccount != default)
                    {
                        var userId = await _sessionService.GetUserIdFromSessionAsync(matchedAccount.SessionKey!);
                        if (!string.IsNullOrEmpty(userId))
                        {
                            // ✅ Found matching account in saved sessions - auto-login
                            await _loginRequestService.MarkAsAuthenticatedAsync(RequestId!, userId);
                            return Redirect($"/oauth2/callback?requestId={RequestId}");
                        }
                    }
                }

                // Save validated username to server
                await _loginRequestService.UpdateValidatedUsernameAsync(RequestId!, Input.Username);

                LoginWithPassword = true;
                // ✅ Keep RequestId in URL after POST - redirect to show password form
                return RedirectWithRequestId();
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", GetLocalizedErrorMessage(ex));
                return Page();
            }
        }

        public async Task<IActionResult> OnPostLocalLoginAsync()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(Input.Username))
                    ModelState.AddModelError(nameof(Input.Username), "Vui lòng nhập tên đăng nhập");
                if (string.IsNullOrWhiteSpace(Input.Password))
                    ModelState.AddModelError(nameof(Input.Password), "Vui lòng nhập mật khẩu");

                if (!ModelState.IsValid)
                {
                    LoginWithPassword = true;
                    return Page();
                }

                // ✅ Validate RequestId first
                _loginRequest = await ValidateLoginRequestAsync();
                if (_loginRequest == null)
                {
                    LoginWithPassword = true;
                    return Page();
                }

                // ✅ NEW: Use LocalLoginCommand to validate credentials with account lockout
                var loginCommand = new LocalLoginCommand
                {
                    Username = Input.Username!,
                    Password = Input.Password!,
                    RequestId = RequestId,
                    IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                    UserAgent = Request.Headers.UserAgent.ToString()
                };

                var loginResult = await _mediator.Send(loginCommand);

                // Check if login failed
                if (!loginResult.Data!.Success)
                {
                    // Account is locked
                    if (loginResult.Data.IsAccountLocked)
                    {
                        ModelState.AddModelError("", loginResult.Data!.Message!);
                        LoginWithPassword = true;
                        return Page();
                    }

                    // Wrong password but account is not locked yet
                    ModelState.AddModelError("", loginResult.Data!.Message!);
                    LoginWithPassword = true;
                    return Page();
                }

                // ✅ Login successful
                var userId = loginResult.Data.UserId!;

                // ✨ SSO: Set session cookie for SSO on next visit (only if RememberMe is checked)
                var sessionKey = await _sessionService.CreateOrUpdateSessionAsync(
                    userId: userId,
                    identityProviderCode: "local",
                    deviceInfo: Request.Headers.UserAgent.ToString(),
                    ipAddress: HttpContext.Connection.RemoteIpAddress?.ToString(),
                    userAgent: Request.Headers.UserAgent.ToString(),
                    lifetimeSeconds: CookieConstants.SessionLifetimeSeconds
                );

                // ✨ Only save session key to cookie if RememberMe is checked
                if (Input.RememberMe)
                {
                    // Store this session key in our multi-session list
                    var storedSessionKeys = GetStoredSessionKeys();
                    if (!storedSessionKeys.Contains(sessionKey))
                    {
                        // Add new session (keep max sessions per browser)
                        storedSessionKeys.Insert(0, sessionKey);  // Add to front (most recent)
                        if (storedSessionKeys.Count > CookieConstants.MaxSessionsPerBrowser)
                        {
                            // Remove oldest session from browser storage
                            // (but keep in database for other devices)
                            storedSessionKeys = storedSessionKeys.Take(CookieConstants.MaxSessionsPerBrowser).ToList();
                        }
                    }

                    // Save all session keys to cookie
                    SaveSessionKeysToCookie(storedSessionKeys);
                }

                // Mark as authenticated in login request
                await _loginRequestService.MarkAsAuthenticatedAsync(RequestId!, userId);

                // Redirect to OAuth callback to generate authorization code
                return Redirect($"/oauth2/callback?requestId={RequestId}");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", GetLocalizedErrorMessage(ex));
                LoginWithPassword = true;
                return Page();
            }
        }

        public async Task<IActionResult> OnPostBackAsync()
        {
            try
            {
                // Clear validated username on server
                if (!string.IsNullOrEmpty(RequestId))
                {
                    _loginRequest = await _loginRequestService.GetByRequestIdAsync(RequestId);
                    if (_loginRequest != null)
                    {
                        await _loginRequestService.UpdateValidatedUsernameAsync(RequestId, string.Empty);
                    }
                }

                LoginWithPassword = false;
                Input.Password = string.Empty;
                ModelState.Clear();

                // ✅ Keep RequestId in URL after POST - redirect back to username form
                return RedirectWithRequestId();
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", GetLocalizedErrorMessage(ex));
                return Page();
            }
        }

        /// <summary>
        /// Use a different saved account (multi-account SSO)
        /// SessionKey is retrieved from encrypted SavedAccountsData (hidden input)
        /// </summary>
        public async Task<IActionResult> OnPostUseAccountAsync(string useUsername)
        {
            try
            {
                // ✅ Load saved accounts for display on page
                await LoadSavedAccountsAsync();

                if (string.IsNullOrEmpty(useUsername))
                {
                    ModelState.AddModelError("", "Vui lòng chọn tài khoản");
                    return Page();
                }

                // Validate login request
                _loginRequest = await ValidateLoginRequestAsync();
                if (_loginRequest == null)
                {
                    return Page();
                }

                // Find the selected account
                var selectedAccount = SavedAccounts.FirstOrDefault(acc =>
                    acc.Username!.Equals(useUsername, StringComparison.OrdinalIgnoreCase));

                if (selectedAccount == default)
                {
                    ModelState.AddModelError("", "Tài khoản không hợp lệ");
                    return Page();
                }

                // ✅ Validate sessionKey exists in cookie (double-check security)
                var storedSessionKeys = GetStoredSessionKeys();
                var sessionKey = selectedAccount.SessionKey;

                if (!storedSessionKeys.Contains(sessionKey ?? ""))
                {
                    ModelState.AddModelError("", "Phiên đăng nhập không tồn tại hoặc đã hết hạn");
                    storedSessionKeys.Remove(sessionKey ?? "");
                    SaveSessionKeysToCookie(storedSessionKeys);
                    return Page();
                }

                // Get userId from session
                var userId = await _sessionService.GetUserIdFromSessionAsync(sessionKey ?? "");
                if (string.IsNullOrEmpty(userId))
                {
                    ModelState.AddModelError("", "Phiên đăng nhập đã hết hạn hoặc không hợp lệ");
                    //xoa session key khoi cookie
                    storedSessionKeys.Remove(sessionKey ?? "");
                    SaveSessionKeysToCookie(storedSessionKeys);
                    return Page();
                }

                // Mark as authenticated in login request
                await _loginRequestService.MarkAsAuthenticatedAsync(RequestId!, userId);

                // Redirect to OAuth callback
                return Redirect($"/oauth2/callback?requestId={RequestId}");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", GetLocalizedErrorMessage(ex));
                return Page();
            }
        }

        /// <summary>
        /// Close/Remove a saved account from the browser
        /// SessionKey is retrieved from encrypted SavedAccountsData (hidden input)
        /// </summary>
        public async Task<IActionResult> OnPostCloseAccountAsync(string closeUsername)
        {
            try
            {
                // ✅ Load saved accounts first for validation
                await LoadSavedAccountsAsync();

                if (string.IsNullOrEmpty(closeUsername))
                {
                    ModelState.AddModelError("", "Vui lòng chọn tài khoản");
                    return Page();
                }

                // Validate login request
                _loginRequest = await ValidateLoginRequestAsync();
                if (_loginRequest == null)
                {
                    return Page();
                }

                // Find the selected account
                var selectedAccount = SavedAccounts.FirstOrDefault(acc =>
                    acc.Username!.Equals(closeUsername, StringComparison.OrdinalIgnoreCase));

                if (selectedAccount == default)
                {
                    ModelState.AddModelError("", "Tài khoản không hợp lệ");
                    return Page();
                }

                // ✅ Validate sessionKey exists in cookie (double-check security)
                var storedSessionKeys = GetStoredSessionKeys();
                var sessionKey = selectedAccount.SessionKey;

                if (!storedSessionKeys.Contains(sessionKey ?? ""))
                {
                    ModelState.AddModelError("", "Phiên đăng nhập không tồn tại hoặc đã hết hạn");
                    return Page();
                }

                // Remove the selected session key from cookie
                storedSessionKeys.Remove(sessionKey ?? "");

                // Save updated list back to cookie
                if (storedSessionKeys.Count > 0)
                {
                    SaveSessionKeysToCookie(storedSessionKeys);
                }
                else
                {
                    // Remove cookie if no more sessions
                    Response.Cookies.Delete(CookieConstants.SessionKeysCookieName);
                }
                // Return to login page with updated accounts
                return RedirectWithRequestId();
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", GetLocalizedErrorMessage(ex));
                return Page();
            }
        }

        private async Task LoadSavedAccountsAsync()
        {
            SavedAccounts.Clear();
            var storedSessionKeys = GetStoredSessionKeys();
            var validSessionKeys = new List<string>();

            if (storedSessionKeys.Count == 0)
                return;

            // Step 1: Get all userIds from sessions (Redis lookups)
            var userIds = new List<string>();
            var sessionKeyToUserIdMap = new Dictionary<string, string>();

            foreach (var sessionKey in storedSessionKeys)
            {
                var userId = await _sessionService.GetUserIdFromSessionAsync(sessionKey);
                if (!string.IsNullOrEmpty(userId))
                {
                    userIds.Add(userId);
                    sessionKeyToUserIdMap[sessionKey] = userId;
                    validSessionKeys.Add(sessionKey);
                }
            }

            if (validSessionKeys.Count != storedSessionKeys.Count)
            {
                if (validSessionKeys.Count > 0)
                {
                    SaveSessionKeysToCookie(validSessionKeys);
                }
                else
                {
                    Response.Cookies.Delete(CookieConstants.SessionKeysCookieName);
                }
            }

            if (userIds.Count == 0)
                return;

            // Step 2: Batch load all users with single query instead of N queries
            var users = await _userRepository.FilterAsync(u => userIds.Contains(u.Id));
            var userDict = users.ToDictionary(u => u.Id);

            // Step 3: Build SavedAccounts from cached data
            foreach (var sessionKey in storedSessionKeys)
            {
                if (sessionKeyToUserIdMap.TryGetValue(sessionKey, out var userId) &&
                    userDict.TryGetValue(userId, out var user))
                {
                    if (!string.IsNullOrEmpty(user.Username))
                    {
                        SavedAccounts.Add((
                            user.Username,
                            user.Email,
                            user.FullName,
                            sessionKey
                        ));
                    }
                }
            }
        }

        public class InputModel
        {
            public string? Username { get; set; } = string.Empty;
            public string? Password { get; set; } = string.Empty;

            public bool RememberMe { get; set; } = true;
        }
    }
}
