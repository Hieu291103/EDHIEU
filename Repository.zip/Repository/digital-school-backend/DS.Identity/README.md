# DS.Identity - OAuth2 & OIDC Identity Service

Dịch vụ xác thực tập trung cho Digital School, cung cấp OAuth2/OIDC flows, SSO (Single Sign-On) và quản lý phiên đăng nhập.

## 📋 Mục Lục

- [Tổng Quan Kiến Trúc](#tổng-quan-kiến-trúc)
- [Stack Công Nghệ](#stack-công-nghệ)
- [Tính Năng Chính](#tính-năng-chính)
- [Cấu Trúc Dự Án](#cấu-trúc-dự-án)
- [Cài Đặt & Khởi Động](#cài-đặt--khởi-động)
- [API Endpoints](#api-endpoints)
- [SSO Flow (Single Sign-On)](#sso-flow-single-sign-on)
- [OAuth2 Authorization Code Flow](#oauth2-authorization-code-flow)
- [Xác Thực & Cấp Phép](#xác-thực--cấp-phép)
- [Cấu Hình](#cấu-hình)
- [Quản Lý Lỗi](#quản-lý-lỗi)

---

## 🏗️ Tổng Quan Kiến Trúc

### Kiến Trúc Tổng Quát

```
┌─────────────────────────────────────────────────────────┐
│                   OAuth2/OIDC Provider                   │
│                    (DS.Identity)                         │
└─────────────────────────────────────────────────────────┘
            │
            ├──────────────────────────────────────────────┐
            │                                               │
    ┌──────▼──────┐    ┌─────────────┐    ┌─────────────┐
    │ Razor Pages │    │  API/OAuth  │    │  Domain     │
    │ (Login UI)  │    │ Controllers │    │  Services   │
    └──────┬──────┘    └──────┬──────┘    └─────────────┘
           │                   │
    ┌──────▼───────────────────▼──────┐
    │   CQRS with MediatR             │
    │  (Commands & Query Handlers)    │
    └──────┬───────────────────┬──────┘
           │                   │
    ┌──────▼──────┐    ┌──────▼──────────┐
    │  MongoDB    │    │  Redis Cache    │
    │  (Entities) │    │  (Login Session)│
    └─────────────┘    └─────────────────┘
```

### Lớp Architecture (Layered)

1. **Presentation Layer**: Razor Pages (Login) + API Controllers (OAuth)
2. **Application Layer**: CQRS Commands/Queries, DTOs, Services
3. **Domain Layer**: Entities, Constants, Enums
4. **Infrastructure Layer**: MongoDB Repositories, Redis Cache, Token Service

---

## 🛠️ Stack Công Nghệ

- **.NET 10** - Framework
- **ASP.NET Core Razor Pages** - Login UI (Server-side rendering)
- **ASP.NET Core MVC** - REST API Controllers
- **MediatR** - CQRS pattern implementation
- **MongoDB** - Persistent database (Users, Clients, Auth Codes)
- **Redis** - Session cache & temporary login context
- **JWT** - Token generation & validation

---

## ✨ Tính Năng Chính

### 1. **OAuth2 Authorization Code Flow**
   - PKCE support (Code Challenge)
   - Authorization code generation & exchange
   - Access token + Refresh token

### 2. **OIDC (OpenID Connect) Support**
   - UserInfo endpoint
   - ID token generation
   - Discovery endpoint (`.well-known/openid-configuration`)
   - Nonce support

### 3. **Single Sign-On (SSO) - Multi-Account**
   - Lưu trữ nhiều tài khoản trên một trình duyệt
   - Chuyển đổi tài khoản nhanh chóng
   - Session recovery (nếu cookies chưa hết hạn)
   - Quản lý phiên đăng nhập (remember me)

### 4. **Xác Thực Cục Bộ (Local Login)**
   - Username/Password authentication
   - Account lockout sau 6 lần thất bại
   - Password hashing with salt
   - Audit logging (IP, User Agent)

### 5. **Quản Lý Phiên Đăng Nhập**
   - Device tracking
   - Session revocation
   - Logout (single session)
   - Logout All (tất cả phiên)

### 6. **Bảo Mật**
   - HTTPS enforcement
   - XSS protection (HttpOnly cookies)
   - CSRF protection (SameSite cookies)
   - Account lockout mechanism
   - Token revocation

---

## 📂 Cấu Trúc Dự Án

### DS.Identity (Razor Pages + OAuth API)

```
DS.Identity/
├── Pages/
│   ├── Login.cshtml              # UI đăng nhập
│   ├── Login.cshtml.cs           # Logic xử lý login & SSO
│   └── Shared/
│       └── _Layout.cshtml        # Master layout
├── Controllers/
│   └── OAuthController.cs        # OAuth2/OIDC endpoints
├── Configuration/
│   ├── AuthSettings.cs           # Auth config từ appsettings
│   └── IdentityProviderSettings.cs # Identity Provider settings
├── Program.cs                    # Startup configuration
└── README.md                     # Tài liệu này
```

### DS.Module.Identity (Business Logic)

```
DS.Module.Identity/
├── Domain/
│   ├── Entities/
│   │   ├── User.cs              # Entity người dùng
│   │   ├── UserSession.cs       # Entity phiên đăng nhập
│   │   ├── AuthorizationCode.cs # Entity auth code
│   │   ├── RefreshToken.cs      # Entity refresh token
│   │   └── AppClient.cs         # Entity OAuth client
│   ├── Constants/
│   │   ├── SsoConstants.cs      # SSO configuration
│   │   ├── OAuthQueryParameters.cs # OAuth parameter names
│   │   ├── StandardScopes.cs    # OAuth scopes
│   │   └── IdentityProviderCodes.cs # Provider codes
│   └── Enums/
│       └── UserType.cs          # User type enum
├── Application/
│   ├── Commands/
│   │   ├── Auth/
│   │   │   ├── LocalLoginCommand.cs
│   │   │   └── LocalLoginCommandHandler.cs
│   │   ├── Users/
│   │   │   ├── CreateUserCommand.cs
│   │   │   ├── UpdateUserCommand.cs
│   │   │   ├── ChangePasswordCommand.cs
│   │   │   └── *CommandHandler.cs
│   │   └── OAuth/
│   │       ├── ExchangeCodeCommand.cs
│   │       ├── RefreshTokenCommand.cs
│   │       ├── RevokeTokenCommand.cs
│   │       └── *CommandHandler.cs
│   ├── Queries/
│   │   ├── Users/
│   │   │   ├── GetUserByIdQuery.cs
│   │   │   ├── GetUserByEmailQuery.cs
│   │   │   └── *QueryHandler.cs
│   │   └── OAuth/
│   │       ├── GetUserInfoQuery.cs
│   │       └── GetUserInfoQueryHandler.cs
│   ├── Services/
│   │   ├── ITokenService.cs & TokenService.cs           # JWT generation
│   │   ├── IPasswordService.cs & PasswordService.cs     # Password hashing
│   │   ├── ILoginRequestService.cs & LoginRequestService.cs    # Login context
│   │   ├── IAuthorizationCodeService.cs & AuthorizationCodeService.cs
│   │   ├── IUserSessionService.cs & UserSessionService.cs      # SSO sessions
│   │   └── IdentityProviderService.cs   # Provider integration
│   ├── DTOs/
│   │   ├── UserDto.cs
│   │   ├── UserInfoDto.cs
│   │   ├── LoginRequestDto.cs
│   │   ├── TokenResponseDto.cs
│   │   └── AuthorizeCallbackDto.cs
│   └── Validators/
│       ├── CreateUserCommandValidator.cs
│       ├── UpdateUserCommandValidator.cs
│       └── ChangePasswordCommandValidator.cs
└── Infrastructure/
    └── Extensions/
        └── IdentityServiceCollectionExtensions.cs # DI registration
```

---

## 🚀 Cài Đặt & Khởi Động

### Yêu Cầu Tiên Quyết
- .NET 10 SDK
- MongoDB 5.0+
- Redis 6.0+

### Bước 1: Cài Đặt Dependencies
```bash
cd DS.Identity
dotnet restore
```

### Bước 2: Cấu Hình appsettings.json
```json
{
  "Auth": {
    "DefaultClientId": "426a0846-0222-4965-afd5-d475ef4fc60f",
    "DefaultRedirectUri": "https://truonghocso.edu.vn/auth/callback",
    "DefaultRedirectReturn": "https://truonghocso.edu.vn"
  },
  "MongoDb": {
    "ConnectionString": "mongodb://localhost:27017",
    "DatabaseName": "DigitalSchool"
  },
  "Redis": {
    "ConnectionString": "localhost:6379"
  },
  "Jwt": {
    "SecretKey": "your-secret-key-min-32-chars",
    "ExpirationMinutes": 60,
    "RefreshTokenExpirationDays": 7
  }
}
```

### Bước 3: Khởi Động Ứng Dụng
```bash
dotnet run
```

Truy cập: `https://localhost:7001`

---

## 🔌 API Endpoints

### 1. OAuth2 Authorization Endpoint

**Request:**
```http
GET /oauth2/authorize?
  client_id=426a0846-0222-4965-afd5-d475ef4fc60f&
  redirect_uri=https://truonghocso.edu.vn/auth/callback&
  response_type=code&
  scope=openid%20profile%20email&
  state=random_state&
  code_challenge=E9Mrozoa2owLb5SbiUlrzaSC65KLH8GF...&
  code_challenge_method=S256
```

**Quy Trình:**
1. Server validate tất cả parameters
2. Tạo `LoginRequest` object lưu vào Redis (TTL 10 phút)
3. Redirect đến `/Login?requestId=xxx`
4. User nhấn login → Mark as authenticated
5. Redirect đến `/oauth2/callback?requestId=xxx`

**Response:** Redirect to Login page

---

### 2. OAuth2 Callback Endpoint

**Request:**
```http
GET /oauth2/callback?requestId=abc123def456
```

**Quy Trình:**
1. Lấy `LoginRequest` từ Redis (phải đã authenticated)
2. Tạo `AuthorizationCode` (TTL 5 phút)
3. Redirect back to client with code

**Response:**
```
Location: https://truonghocso.edu.vn/auth/callback?
  code=xxxx&
  state=random_state
```

---

### 3. OAuth2 Token Endpoint

**Request (Authorization Code):**
```http
POST /oauth2/token

grant_type=authorization_code&
code=xxxx&
client_id=426a0846-0222-4965-afd5-d475ef4fc60f&
client_secret=secret&
redirect_uri=https://truonghocso.edu.vn/auth/callback&
code_verifier=E9Mrozoa2owLb5SbiUlrzaSC65KLH8GF...
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIs...",
  "token_type": "Bearer",
  "expires_in": 3600,
  "refresh_token": "refresh_token_xxx",
  "scope": "openid profile email",
  "id_token": "eyJhbGciOiJIUzI1NiIs..."
}
```

---

### 4. OAuth2 Token Refresh Endpoint

**Request:**
```http
POST /oauth2/token

grant_type=refresh_token&
refresh_token=refresh_token_xxx&
client_id=426a0846-0222-4965-afd5-d475ef4fc60f&
client_secret=secret
```

**Response:**
```json
{
  "access_token": "new_access_token",
  "token_type": "Bearer",
  "expires_in": 3600,
  "refresh_token": "new_refresh_token"
}
```

---

### 5. OIDC UserInfo Endpoint

**Request:**
```http
GET /oauth2/userinfo
Authorization: Bearer access_token_xxx
```

**Response:**
```json
{
  "sub": "user_id_123",
  "name": "Nguyễn Văn A",
  "email": "a@example.com",
  "email_verified": true,
  "phone_number": "+84901234567",
  "phone_number_verified": false,
  "picture": "https://example.com/avatar.jpg",
  "preferred_username": "nguyenvana",
  "additional_claims": {
    "school_id": "school_123"
  }
}
```

---

### 6. OAuth2 Token Revocation Endpoint

**Request:**
```http
POST /oauth2/revoke

token=access_token_or_refresh_token&
client_id=426a0846-0222-4965-afd5-d475ef4fc60f&
client_secret=secret&
token_type_hint=access_token
```

**Response:**
```
200 OK
```

---

### 7. OIDC Discovery Endpoint

**Request:**
```http
GET /.well-known/openid-configuration
```

**Response:**
```json
{
  "issuer": "https://identity.truonghocso.edu.vn",
  "authorization_endpoint": "https://identity.truonghocso.edu.vn/oauth2/authorize",
  "token_endpoint": "https://identity.truonghocso.edu.vn/oauth2/token",
  "userinfo_endpoint": "https://identity.truonghocso.edu.vn/oauth2/userinfo",
  "revocation_endpoint": "https://identity.truonghocso.edu.vn/oauth2/revoke",
  "jwks_uri": "https://identity.truonghocso.edu.vn/oauth2/.well-known/jwks.json",
  "response_types_supported": ["code"],
  "grant_types_supported": ["authorization_code", "refresh_token"],
  "subject_types_supported": ["public"],
  "id_token_signing_alg_values_supported": ["HS256"],
  "scopes_supported": ["openid", "profile", "email", "offline_access"],
  "token_endpoint_auth_methods_supported": ["client_secret_post", "client_secret_basic"],
  "code_challenge_methods_supported": ["S256", "plain"]
}
```

---

### 8. Logout Endpoint

**Request:**
```http
GET /oauth2/logout?returnUrl=https://truonghocso.edu.vn
```

**Quy Trình:**
1. Lấy `CurrentSessionKey` từ cookie
2. Revoke session từ database
3. Xoá cookies
4. Redirect to returnUrl

**Response:**
```
Location: https://truonghocso.edu.vn
```

---

### 9. Logout All Endpoint

**Request:**
```http
GET /oauth2/logout-all?returnUrl=https://truonghocso.edu.vn
```

**Quy Trình:**
1. Lấy tất cả `SessionKeys` từ cookie
2. Revoke tất cả sessions
3. Xoá tất cả cookies
4. Redirect to returnUrl

**Response:**
```
Location: https://truonghocso.edu.vn
```

---

## 🔐 SSO Flow (Single Sign-On)

### Tổng Quan SSO Multi-Account

SSO cho phép user lưu trữ nhiều tài khoản trên cùng một trình duyệt và chuyển đổi giữa chúng mà không cần nhập lại password.

### Session Storage

```
┌─────────────────────────────────────────┐
│          Browser Cookie                  │
├─────────────────────────────────────────┤
│ session_keys (JSON Array - HttpOnly)    │
│  ["sessionKey1", "sessionKey2", ...]    │
│                                          │
│ current_session (Current Active Key)    │
│  "sessionKeyX"                          │
└─────────────────────────────────────────┘
         │ Secure + HttpOnly
         ▼
┌─────────────────────────────────────────┐
│      Redis Cache (Session Store)         │
├─────────────────────────────────────────┤
│ sessionKey1: {userId, ipAddress, ...}   │
│ sessionKey2: {userId, ipAddress, ...}   │
│ sessionKey3: {userId, ipAddress, ...}   │
│ TTL: 240 days                           │
└─────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│       MongoDB (Persistent)               │
├─────────────────────────────────────────┤
│ UserSession Collection                  │
│  - sessionKey, userId, deviceInfo       │
│  - createdAt, lastActivityAt            │
│  - ipAddress, userAgent                 │
└─────────────────────────────────────────┘
```

### SSO Login Flow (Lần Đầu Tiên)

```
┌─────────────────────────────────────────────────────────┐
│  1. User nhấn Login → Authorization Request             │
│     GET /oauth2/authorize?client_id=xxx&redirect_uri=yyy │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│  2. Server tạo LoginRequest & redirect đến Login page    │
│     POST /Login?requestId=abc123&username=&password=     │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│  3. Hiển thị Login Form                                  │
│     - Username field                                    │
│     - "Saved Accounts" list (nếu có từ cookie)         │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│  4. Nhập Username → OnPostCheckUserAsync                │
│     - Validate username tồn tại                        │
│     - Lưu validated username vào LoginRequest          │
│     - Hiển thị Password field                          │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│  5. Nhập Password → OnPostLocalLoginAsync               │
│     - Validate credentials (Account Lockout)            │
│     - Tạo UserSession mới → sessionKey                  │
│     - Nếu "Remember Me": Lưu sessionKey vào cookie     │
│     - Mark LoginRequest as Authenticated                │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│  6. Redirect to /oauth2/callback?requestId=abc123       │
│     - Tạo AuthorizationCode                             │
│     - Mark LoginRequest as Consumed                     │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│  7. Redirect to Client                                  │
│     https://client/callback?code=xxxx&state=yyyy        │
└─────────────────────────────────────────────────────────┘
```

### SSO Auto-Login Flow (Lần Thứ 2+)

```
┌─────────────────────────────────────────────────────────┐
│  1. User nhấn Login → Authorization Request             │
│     GET /oauth2/authorize?client_id=xxx&redirect_uri=yyy │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│  2. Server tạo LoginRequest & redirect đến Login page    │
│     GET /Login?requestId=abc123                         │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│  3. OnGetAsync: Load Saved Accounts từ Cookie           │
│     - Lấy session_keys từ cookie                        │
│     - Query Redis để lấy userId từ mỗi sessionKey      │
│     - Query MongoDB để lấy username, email, fullname    │
│     - Hiển thị danh sách saved accounts                │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│ Người dùng   │ │ Người dùng   │ │ Nhấn vào     │
│ Khác Nhất Gần│ │ Khác Nhất Gần│ │ "Đăng nhập   │
│ Đây (Auto)   │ │ Đây #2      │ │ Khác" / "Khác│
└──────────────┘ └──────────────┘ └──────────────┘
        │                │                │
        │                ▼                ▼
        │         ┌──────────────────────────────┐
        │         │ OnPostUseAccountAsync         │
        │         │ - Validate selected account  │
        │         │ - Mark LoginRequest as Auth  │
        │         │ - Redirect to callback       │
        │         └──────────────────────────────┘
        │                │
        ▼                ▼
┌──────────────────────────────────────────────────┐
│ (Auto) OnGetAsync / OnPostUseAccountAsync        │
│ - sessionKey từ cookie valid?                   │
│ - GetUserIdFromSessionAsync(sessionKey)          │
│ - Mark LoginRequest as Authenticated             │
└──────────────────────────────────────────────────┘
                         │
                         ▼
┌──────────────────────────────────────────────────┐
│ Redirect to /oauth2/callback?requestId=abc123    │
│ → Tạo code → Redirect to client                 │
└──────────────────────────────────────────────────┘
```

### SSO Account Management

#### Lưu Tài Khoản (Remember Me)
```csharp
// OnPostLocalLoginAsync - khi login thành công
if (Input.RememberMe)
{
    var storedSessionKeys = GetStoredSessionKeys(); // Từ cookie
    storedSessionKeys.Insert(0, sessionKey); // Add to front
    
    // Giữ max 5 sessions per browser
    if (storedSessionKeys.Count > MaxSessionsPerBrowser)
        storedSessionKeys = storedSessionKeys.Take(5).ToList();
    
    SaveSessionKeysToCookie(storedSessionKeys); // Set secure cookie
}
```

#### Chuyển Đổi Tài Khoản
```
// OnPostUseAccountAsync
1. Lấy selected account từ SavedAccounts
2. Validate sessionKey có trong cookie
3. Get userId từ sessionKey (Redis)
4. Mark LoginRequest as Authenticated
5. Redirect to /oauth2/callback
```

#### Xoá Tài Khoản từ Trình Duyệt
```
// OnPostCloseAccountAsync
1. Remove sessionKey từ cookie
2. Không xoá từ database (có thể dùng từ device khác)
3. Return to login page (refresh saved accounts list)
```

### Bảo Mật SSO

| Feature | Cách Thực Hiện |
|---------|----------------|
| Session Storage | Encrypted cookies (HttpOnly + Secure) |
| Session ID Validation | Validate sessionKey trong Redis trước khi dùng |
| Device Tracking | Lưu IP, User Agent, Device Info |
| Session Revocation | Revoke từ database (Logout) |
| Token Lifetime | 240 days (configurable via SsoConstants) |
| Max Sessions/Browser | 5 (configurable via MaxSessionsPerBrowser) |

---

## 🔑 OAuth2 Authorization Code Flow

### Quy Trình Chi Tiết

```
┌─────────────┐                                  ┌──────────────┐
│             │                                  │              │
│   Browser   │                                  │  API Server  │
│ (Resource   │                                  │  (Identity   │
│  Owner)     │                                  │   Provider)  │
└─────────────┘                                  └──────────────┘
        │                                                │
        │ 1. Click "Login"                              │
        ├─────────────────────────────────────────────>│
        │    /oauth2/authorize?                        │
        │    client_id=xxx&redirect_uri=yyy            │
        │                                               │
        │ 2. Validate params & create LoginRequest     │
        │ Store in Redis (10 min TTL)                  │
        │                                               │
        │ 3. Redirect to Login page                    │
        │<─────────────────────────────────────────────┤
        │    /Login?requestId=abc123                   │
        │                                               │
        │ 4. User enters credentials                   │
        │    POST /Login                               │
        ├─────────────────────────────────────────────>│
        │                                               │
        │ 5. Validate credentials & create Session    │
        │ Mark LoginRequest as Authenticated           │
        │                                               │
        │ 6. Redirect to callback                      │
        │<─────────────────────────────────────────────┤
        │    /oauth2/callback?requestId=abc123         │
        │                                               │
        │ 7. Create AuthorizationCode (5 min TTL)     │
        │                                               │
        │ 8. Redirect to client with code             │
        │<─────────────────────────────────────────────┤
        │    https://client/callback?                  │
        │    code=xxxx&state=yyyy                      │
        │                                               │
        │ 9. Exchange code for tokens                  │
        │    (Backend-to-Backend)                      │
        │    POST /oauth2/token                        │
        ├─────────────────────────────────────────────>│
        │    grant_type=authorization_code             │
        │    code=xxxx&client_id=...                   │
        │                                               │
        │ 10. Validate code & create tokens            │
        │     (Access Token, Refresh Token, ID Token)  │
        │                                               │
        │ 11. Return tokens                            │
        │<─────────────────────────────────────────────┤
        │     {                                         │
        │       "access_token": "...",                 │
        │       "refresh_token": "...",                │
        │       "id_token": "...",                     │
        │       "expires_in": 3600                     │
        │     }                                         │
        │                                               │
```

### State Parameter (CSRF Protection)

```
┌──────────────────────────────────────┐
│ Client generates random state value  │
│ state = "abc123def456"               │
└──────────────────────────────────────┘
            │
            ├─ Store state in session
            │
            ├─ Include in authorization request
            │  /oauth2/authorize?...&state=abc123
            │
            ├─ Server echoes state in callback
            │  /callback?code=xxx&state=abc123
            │
            └─ Client validates state matches
               ✅ If match → Process code
               ❌ If no match → Reject (CSRF attack)
```

### PKCE Flow (Code Challenge)

```
┌────────────────────────────────────┐
│ Client generates:                  │
│ - code_verifier = random 128 chars │
│ - code_challenge = SHA256(verifier)│
│   (Base64URL encoded)              │
└────────────────────────────────────┘
            │
            ├─ Include code_challenge in auth request
            │  /oauth2/authorize?
            │  code_challenge=E9Mrozoa...&
            │  code_challenge_method=S256
            │
            ├─ Server stores code_challenge
            │
            ├─ Client calls token endpoint with verifier
            │  POST /oauth2/token
            │  code_verifier=original_verifier
            │
            └─ Server validates: SHA256(verifier) == challenge
               ✅ Match → Issue tokens
               ❌ No match → Reject
```

### Token Response Format

```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "Bearer",
  "expires_in": 3600,                // 1 hour
  "refresh_token": "refresh_token_xxx",
  "scope": "openid profile email",
  "id_token": "eyJhbGciOiJIUzI1NiIs..."
}
```

### Access Token Claims

```json
{
  "sub": "user_id_123",               // User ID
  "iss": "https://identity.school.vn",  // Issuer
  "aud": "client_id_xxx",             // Audience
  "exp": 1704067200,                  // Expiration time
  "iat": 1704063600,                  // Issued at
  "auth_time": 1704063600,           // Authentication time
  "scope": "openid profile email"
}
```

---

## 🔐 Xác Thực & Cấp Phép

### User Entity Fields

```csharp
public class User : BaseEntity
{
    public string Username { get; set; }           // Unique login name
    public string Email { get; set; }              // Email address
    public string FullName { get; set; }           // Full name
    public string PasswordHash { get; set; }       // Hashed password
    public string? PhoneNumber { get; set; }
    public string? AvatarUrl { get; set; }
    
    // Email verification
    public bool EmailVerified { get; set; }
    
    // Phone verification
    public bool PhoneNumberVerified { get; set; }
    
    // Account lockout
    public int AccessFailedCount { get; set; }
    public DateTime? LockoutEnd { get; set; }
    public bool LockoutEnabled { get; set; } = true;
    
    // Login tracking
    public DateTime? LastLoginAt { get; set; }
    public string? LastLoginIp { get; set; }
    
    // User status
    public bool IsActive { get; set; } = true;
    
    // Claims for JWT/OIDC
    public Dictionary<string, string> Claims { get; set; } = new();
}
```

### Account Lockout Mechanism

| Event | Action |
|-------|--------|
| Login attempt fails | AccessFailedCount++ |
| > 2 failures | Show warning: "3 attempts remaining" |
| >= 6 failures | Lock account for 15 minutes |
| Successful login | Reset AccessFailedCount to 0 |
| Lockout expired | Auto unlock |

### Password Hashing

```csharp
// PasswordService uses bcrypt with salt
public string HashPassword(string password)
{
    // Generates: $2a$11$salt$hash
    return BCrypt.Net.BCrypt.HashPassword(password);
}

public bool VerifyPassword(string password, string hash)
{
    return BCrypt.Net.BCrypt.Verify(password, hash);
}
```

### Token Service

```csharp
public interface ITokenService
{
    // Generate JWT with claims
    string GenerateAccessToken(User user, string[] scopes);
    
    // Generate refresh token (long-lived)
    string GenerateRefreshToken(User user);
    
    // Generate ID token (OIDC)
    string GenerateIdToken(User user, string nonce);
    
    // Validate and extract claims
    ClaimsPrincipal? ValidateAccessTokenAsync(string token);
}
```

---

## ⚙️ Cấu Hình

### appsettings.json

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "DS": "Debug"
    }
  },
  
  "Auth": {
    "DefaultClientId": "426a0846-0222-4965-afd5-d475ef4fc60f",
    "DefaultRedirectUri": "https://truonghocso.edu.vn/auth/callback",
    "DefaultRedirectReturn": "https://truonghocso.edu.vn"
  },
  
  "MongoDb": {
    "ConnectionString": "mongodb://localhost:27017",
    "DatabaseName": "DigitalSchool",
    "Options": {
      "maxPoolSize": 10,
      "minPoolSize": 5
    }
  },
  
  "Redis": {
    "ConnectionString": "localhost:6379",
    "Options": {
      "SyncTimeout": 5000,
      "AllowAdmin": false
    }
  },
  
  "Jwt": {
    "SecretKey": "your-secret-key-min-32-chars-long",
    "ExpirationMinutes": 60,
    "RefreshTokenExpirationDays": 7,
    "Issuer": "https://identity.truonghocso.edu.vn",
    "Audience": "digital-school-api"
  },
  
  "OAuthSettings": {
    "AuthorizationCodeExpirationMinutes": 5,
    "RefreshTokenExpirationDays": 30,
    "AccessTokenExpirationMinutes": 60
  }
}
```

### Environment-Specific Configuration

**appsettings.Development.json:**
```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Debug"
    }
  },
  "Jwt": {
    "SecretKey": "development-secret-key-32-chars"
  }
}
```

**appsettings.Production.json:**
```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Warning"
    }
  },
  "Jwt": {
    "SecretKey": "LOAD_FROM_VAULT"
  },
  "MongoDb": {
    "ConnectionString": "mongodb+srv://user:pass@cluster.mongodb.net"
  },
  "Redis": {
    "ConnectionString": "redis-prod.azure.redis.cache.windows.net:6379"
  }
}
```

### Constants Configuration

```csharp
// SsoConstants.cs - Quản lý SSO configuration
public static class SsoConstants
{
    public const int SessionLifetimeSeconds = 60 * 60 * 24 * 240;  // 240 days
    public const string SessionKeysCookieName = "session_keys";
    public const string CurrentSessionCookieName = "current_session";
    public const int MaxSessionsPerBrowser = 5;
}

// OAuthQueryParameters.cs - OAuth parameter names
public static class OAuthQueryParameters
{
    public const string ClientId = "client_id";
    public const string RedirectUri = "redirect_uri";
    public const string ResponseType = "response_type";
    public const string Code = "code";
    public const string State = "state";
    public const string Scope = "scope";
    // ... more parameters
}

// StandardScopes.cs - OIDC scopes
public static class StandardScopes
{
    public static string[] StandardOpenIdScopes = 
    {
        "openid",           // Required for OIDC
        "profile",          // name, family_name, given_name, etc
        "email",            // email, email_verified
        "phone",            // phone_number, phone_number_verified
        "offline_access"    // Enables refresh token
    };
}
```

---

## ❌ Quản Lý Lỗi

### Custom Exception: DSException

```csharp
// Throw error with localization support
throw new DSException("InvalidCredentials");

// Throw error with parameter
throw DSException.WithParam("AccountLockedDuration", "10");
```

### Error Codes & Localization

| Error Code | Message (EN) | Message (VI) | HTTP Status |
|-----------|--------------|--------------|------------|
| InvalidCredentials | Invalid username or password | Tên đăng nhập hoặc mật khẩu không hợp lệ | 401 |
| AccountLocked | Account is locked | Tài khoản bị khóa | 403 |
| AccountLockedDuration | Account locked for {0} minutes | Tài khoản bị khóa trong {0} phút | 403 |
| InvalidRequest | Invalid request | Yêu cầu không hợp lệ | 400 |
| InvalidAccessToken | Access token is invalid | Access token không hợp lệ | 401 |
| UserNotFound | User not found | Không tìm thấy người dùng | 404 |
| UnsupportedGrantType | Grant type not supported | Kiểu cấp phép không được hỗ trợ | 400 |
| RequestIdExpired | Request ID has expired | RequestId đã hết hạn | 400 |

### Global Exception Handler Middleware

```csharp
// ExceptionHandlingMiddleware (from DS.Shared.Core)
app.UseExceptionHandling();

// Catches all exceptions and returns structured error response:
{
  "statusCode": 400,
  "errorCode": "InvalidRequest",
  "message": "Localized error message",
  "timestamp": "2024-01-01T12:00:00Z"
}
```

### Error Response Examples

**Authorization Error:**
```
Location: https://client/callback?
  error=invalid_request&
  error_description=redirect_uri+is+required&
  state=random_state
```

**Token Error:**
```json
{
  "error": "invalid_grant",
  "error_description": "Authorization code has expired"
}
```

**API Error (REST):**
```json
{
  "statusCode": 401,
  "errorCode": "InvalidAccessToken",
  "message": "Access token is invalid or has expired"
}
```

---

## 🔄 CQRS Pattern Usage

### Example: Local Login Command

```csharp
// 1. Command Definition
public class LocalLoginCommand : IRequest<Result<LocalLoginResult>>
{
    public string Username { get; set; }
    public string Password { get; set; }
    public string RequestId { get; set; }
    public string IpAddress { get; set; }
    public string UserAgent { get; set; }
}

// 2. Command Handler
public class LocalLoginCommandHandler : IRequestHandler<LocalLoginCommand, Result<LocalLoginResult>>
{
    public async Task<Result<LocalLoginResult>> Handle(LocalLoginCommand request, CancellationToken cancellationToken)
    {
        // Validate user exists
        // Check account lockout
        // Verify password
        // Create session
        // Return result
    }
}

// 3. Usage in Razor Page
var loginCommand = new LocalLoginCommand
{
    Username = Input.Username,
    Password = Input.Password,
    RequestId = RequestId,
    IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
    UserAgent = Request.Headers.UserAgent.ToString()
};

var loginResult = await _mediator.Send(loginCommand);
```

---

## 📦 Dependencies

```xml
<ItemGroup>
    <PackageReference Include="Microsoft.Extensions.Caching.StackExchangeRedis" Version="9.0.0" />
</ItemGroup>

<ItemGroup>
    <ProjectReference Include="..\DS.Module.Identity\DS.Module.Identity.csproj" />
    <ProjectReference Include="..\DS.Shared.Core\DS.Shared.Core.csproj" />
</ItemGroup>
```

---

## 🚀 Deployment

### Docker

```dockerfile
FROM mcr.microsoft.com/dotnet/sdk:10.0 AS build
WORKDIR /app
COPY . .
RUN dotnet publish -c Release -o out

FROM mcr.microsoft.com/dotnet/aspnet:10.0
WORKDIR /app
COPY --from=build /app/out .
EXPOSE 5000
ENTRYPOINT ["dotnet", "DS.Identity.dll"]
```

### Azure App Service

```bash
# Publish to Azure
dotnet publish -c Release -o ./publish
az webapp up --name identity-service --resource-group digital-school
```

---

## 📝 License

Digital School © 2024

