using DS.Module.Identity.Infrastructure.Extensions;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Infrastructure.Configuration;
using DS.Shared.Core.Infrastructure.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Configuration;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.Redis.Extensions;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.IdentityModel.Tokens;

MongoDbConventions.RegisterConventions();
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDataProtection()
    .PersistKeysToFileSystem(new DirectoryInfo(Path.Combine(builder.Environment.ContentRootPath, "keys")))
    .SetApplicationName("IDTruongHocSo")
    .SetDefaultKeyLifetime(TimeSpan.FromDays(365)); // 1 năm;

// Tự động load appsettings.{ENVIRONMENT}.json
builder.Configuration
    .AddJsonFile("appsettings.json", optional: false)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true)
    .AddEnvironmentVariables();

// Serilog
builder.Host.AddSerilogLogging(builder.Configuration);

// Add services to the container.
builder.Services.AddRazorPages(options =>
{
    // Đặt trang mặc định là /Login
    options.Conventions.AddPageRoute("/Login", "");
});

// Add Controllers for API endpoints
builder.Services.AddControllers();

builder.Services.AddDefaultCors(builder.Configuration);

builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    // Chỉ định các header cần đọc
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    // xóa danh sách mặc định (thường chỉ tin loopback 127.0.0.1)
    options.KnownIPNetworks.Clear();
    options.KnownProxies.Clear();
});

// Register Identity module (includes localization provider and services)
builder.Services.AddIdentityModule();

// Đăng ký dịch vụ RequestContext + UserContext
builder.Services.AddRequestContext();

// Register Auth Configuration from appsettings.json
builder.Services.Configure<DS.Identity.Configuration.AuthSettings>(
    builder.Configuration.GetSection("Auth"));

builder.Services.Configure<JwtSettings>(builder.Configuration.GetSection(JwtSettings.SectionName));

// MongoDB for persistent data (users, clients, tokens)
builder.Services.AddAdminMongoDatabase(builder.Configuration);

// Redis for temporary login context (auto-expire after 10 minutes)
builder.Services.AddRedisCache(builder.Configuration);

// AutoMapper with auto-discovery
builder.Services.AddAutoMapperWithAutoDiscovery();

// MediatR with auto-discovery
builder.Services.AddMediatRWithAutoDiscovery();

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer();

builder.Services.AddOptions<JwtBearerOptions>(JwtBearerDefaults.AuthenticationScheme)
    .Configure<IJwtKeyService, Microsoft.Extensions.Options.IOptions<JwtSettings>>((options, jwtKeyService, jwtOptions) =>
    {
        var jwtSettings = jwtOptions.Value;
        options.RequireHttpsMetadata = false;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = jwtKeyService.GetSigningKey(),
            ValidateIssuer = !string.IsNullOrWhiteSpace(jwtSettings.Issuer),
            ValidIssuer = jwtSettings.Issuer,
            ValidateAudience = !string.IsNullOrWhiteSpace(jwtSettings.Audience),
            ValidAudience = jwtSettings.Audience,
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromSeconds(30)
        };
    });

builder.Services.AddAuthorization();

// Health checks
builder.Services.AddDefaultHealthChecks();

var app = builder.Build();

// Middleware to allow embedding in iframe from any origin
// Uses custom middleware to properly intercept and remove security headers
//app.UseRemoveSecurityHeaders();

// Create MongoDB indexes on startup
await app.Services.InitializeIdentityIndexesAsync();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Logs");
    // Note: HSTS is disabled for iframe embedding compatibility
    // If needed in production, configure it with proper security policy
    app.UseHsts();
}

// Use ForwardedHeaders middleware BEFORE other middleware (recommended order)
app.UseForwardedHeaders();

app.UseCors(CorsSettings.DefaultPolicyName);

app.UseExceptionHandling();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapStaticAssets();
app.MapRazorPages()
   .WithStaticAssets();

// Map Controllers for OAuth API endpoints
app.MapControllers();
app.UseDefaultHealthChecks();
app.Run();

