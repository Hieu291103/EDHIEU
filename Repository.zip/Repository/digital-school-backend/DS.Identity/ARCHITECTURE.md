# DS.Identity — Architecture Overview

## Mục đích
`DS.Identity` là **OAuth2 Authorization Server** của hệ thống Digital School. Đây là Razor Pages + Web API project đảm nhận việc xác thực người dùng (login), phát hành JWT token, quản lý OAuth2 flow (Authorization Code + PKCE), và refresh token.

---

## Cấu trúc thư mục

```
DS.Identity/
├── Program.cs                                  # Entry point, DI setup, middleware pipeline
├── ARCHITECTURE.md                             # Tài liệu kiến trúc (file này)
├── Configuration/
│   ├── AuthSettings.cs                         # OAuth2 default client/redirect config (section: "Auth")
│   └── IdentityProviderSettings.cs             # Cấu hình các identity provider (local, google, saml,...)
├── Controllers/
│   └── OAuthController.cs                      # OAuth2 API endpoints (route: /oauth2/*)
├── Middleware/
│   └── RemoveSecurityHeadersMiddleware.cs      # Xóa security headers (dùng khi nhúng iframe)
└── Pages/
    ├── Login.cshtml / Login.cshtml.cs           # Trang đăng nhập (Razor Pages)
    └── Examples/
        └── LoginWithProviderExample.cs          # Ví dụ tích hợp provider ngoài
```

---

## Kiến trúc tổng thể

`DS.Identity` vừa là **Razor Pages app** (trang login UI) vừa là **API server** (OAuth2 endpoints):

```
Browser / Client App
        │
        ▼
  [GET /]  →  Login.cshtml (Razor Page)
        │         ├── Validate RequestId (lookup OAuth context from Redis)
        │         ├── POST → LoginModel.OnPostAsync() → gửi LoginCommand qua MediatR
        │         └── Redirect → redirect_uri?code=xxx (Authorization Code)
        │
  [POST /oauth2/token]  →  OAuthController
        │         ├── Exchange authorization_code → JWT access_token + refresh_token
        │         └── Refresh token → new access_token
```

---

## OAuth2 Flow (Authorization Code + PKCE)

### Bước 1 — Client khởi tạo login
Client gửi request đến `/oauth2/authorize` (hoặc tương đương), server tạo `RequestId` và lưu OAuth context vào Redis (TTL ngắn, ~10 phút).

### Bước 2 — User đăng nhập
`Login.cshtml` nhận `?requestId=xxx`, lookup context từ Redis, hiển thị form đăng nhập.

### Bước 3 — Submit login
`LoginModel.OnPostAsync()` → gửi `LoginCommand` qua MediatR → xác thực user → tạo Authorization Code → redirect về `redirect_uri?code=xxx`.

### Bước 4 — Exchange code lấy token
Client gọi `POST /oauth2/token` → `OAuthController` exchange code → phát hành JWT.

---

## Các Services quan trọng (từ DS.Module.Identity)

| Service | Mục đích |
|---|---|
| `ILoginRequestService` | Tạo/lookup OAuth login request context (Redis) |
| `IAuthorizationCodeService` | Tạo/validate authorization code |
| `IUserSessionService` | Quản lý user session sau login |
| `IJwtKeyService` | Lấy signing key để phát hành/validate JWT |

---

## Module Dependencies

| Module / Service | Mục đích |
|---|---|
| `DS.Module.Identity` | Core identity logic (user, role, permission, OAuth) |
| `DS.Shared.Core` (MongoDB) | Lưu user, client, token entities |
| `DS.Shared.Core` (Redis) | Lưu tạm OAuth context, login request (TTL ~10 phút) |
| `IMediator` (MediatR) | Dispatch login command, OAuth queries |
| `ILocalizationService` | Dịch error message theo ngôn ngữ |
| `DataProtection` | Bảo vệ sensitive data, persist keys vào filesystem |

---

## Authentication trong DS.Identity
DS.Identity **phát hành** JWT cho các service khác, nhưng bản thân nó cũng validate JWT Bearer cho các API endpoint nội bộ:
- Signing key từ `IJwtKeyService` (RSA hoặc symmetric)
- Validate: Issuer, Audience, Lifetime, ClockSkew = 30s
- Keys persist vào `./keys/` directory, ApplicationName = `"IDTruongHocSo"`, lifetime 1 năm

---

## Data Protection
```csharp
.PersistKeysToFileSystem(new DirectoryInfo("./keys"))
.SetApplicationName("IDTruongHocSo")
.SetDefaultKeyLifetime(TimeSpan.FromDays(365))
```
> ⚠️ Thư mục `keys/` phải được mount persistent khi deploy container.

---

## Cấu hình `appsettings.json` cần có
```json
{
  "Auth": {
    "DefaultClientId": "ds-web-client",
    "DefaultRedirectUri": "https://app.domain.com/callback",
    "DefaultRedirectReturn": "https://app.domain.com"
  },
  "Jwt": {
    "Issuer": "https://identity.domain.com",
    "Audience": "ds-api",
    "SecretKey": "..."
  },
  "Mongo": {
    "Admin": {
      "ConnectionString": "mongodb://...",
      "DatabaseName": "ds-admin"
    }
  },
  "Redis": {
    "ConnectionString": "localhost:6379"
  },
  "Cors": {
    "AllowedOrigins": ["https://app.domain.com"]
  }
}
```

---

## Luồng khởi động (Program.cs)

```
1.  DataProtection (persist keys, AppName, 1 năm)
2.  Load config (appsettings.json + appsettings.{ENV}.json + env vars)
3.  Serilog logging
4.  Razor Pages (default route: /Login → trang chủ)
5.  Controllers (cho OAuth API endpoints)
6.  CORS
7.  ForwardedHeaders config
8.  Identity module (AddIdentityModule)
9.  RequestContext + UserContext
10. AuthSettings (section: "Auth")
11. JwtSettings
12. MongoDB (Admin database)
13. Redis cache
14. AutoMapper + MediatR
15. JWT Bearer authentication
--- app.Build() ---
16. InitializeIdentityIndexesAsync() ← tạo MongoDB indexes khi startup
17. ExceptionHandler (prod) / HSTS
18. UseForwardedHeaders
19. UseCors
20. UseExceptionHandling
21. UseRouting
22. UseAuthentication → UseAuthorization
23. MapStaticAssets
24. MapRazorPages (với static assets)
25. MapControllers
26. app.Run()
```

---

## Login Page (Razor Pages)

| Property | Mô tả |
|---|---|
| `RequestId` | Query param duy nhất để lookup OAuth context từ Redis |
| `LoginWithPassword` | Flag hiển thị form username/password hay chọn provider |
| `Input` | Bind model: Username, Password, RememberMe |

---

## OAuthController (`/oauth2`)

| Endpoint | Mô tả |
|---|---|
| `GET /oauth2/test` | Health check |
| `POST /oauth2/token` | Exchange code hoặc refresh token → JWT |

---

## Lưu ý quan trọng
- Project này là **Razor Pages** (không phải MVC hay Blazor) — ưu tiên Razor Pages conventions
- Trang Login không cần `[Authorize]` — là entry point public
- OAuth context (login request) lưu Redis với TTL ngắn (~10 phút), không lưu database
- `RemoveSecurityHeadersMiddleware` có thể bật khi cần nhúng login page vào iframe
- MongoDB indexes được khởi tạo tự động khi startup qua `InitializeIdentityIndexesAsync()`
