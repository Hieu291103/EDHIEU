using DS.Module.Identity.Application.Commands.OAuth;
using DS.Module.Identity.Application.Queries.OAuth;
using DS.Module.Identity.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.Localization;
using DS.Shared.Core.Common.Constants;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Infrastructure.Configuration;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace DS.Identity.Controllers
{
    [Route("oauth2")]
    [ApiController]
    public class OAuthController : BaseAPIController
    {
        private readonly ILoginRequestService _loginRequestService;
        private readonly IAuthorizationCodeService _authCodeService;
        private readonly IUserSessionService _sessionService;
        private readonly ILocalizationService _localizationService;
        private readonly IJwtKeyService _jwtKeyService;
        private readonly JwtSettings _jwtSettings;

        public OAuthController(
            IMediator mediator,
            ILoginRequestService loginRequestService,
            IAuthorizationCodeService authCodeService,
            IUserSessionService sessionService,
            ILocalizationService localizationService,
            IJwtKeyService jwtKeyService,
            IOptions<JwtSettings> jwtOptions)
            : base(mediator)
        {
            _loginRequestService = loginRequestService;
            _authCodeService = authCodeService;
            _sessionService = sessionService;
            _localizationService = localizationService;
            _jwtKeyService = jwtKeyService;
            _jwtSettings = jwtOptions.Value;
        }

        [HttpGet("test")]
        public async Task<IActionResult> GetTest()
        {
            return SuccessResponse(new { Message = "OAuthController is working!" });
        }

        /// <summary>
        /// Get localized error message from DSException
        /// </summary>
        private string GetLocalizedErrorMessage(DSException ex)
        {
            var languageCode = RequestHelper.GetHeaderValueLanguage(Request.Headers);
            if (ex.errorParam != null)
            {
                return _localizationService.GetFormattedMessage(ex.errorCode, languageCode, ex.errorParam);
            }
            return _localizationService.GetMessage(ex.errorCode, languageCode) ?? ex.errorCode;
        }


        /// <summary>
        /// OAuth2 Authorization Endpoint
        /// Khởi tạo OAuth flow, validate params và redirect đến login page
        /// </summary>
        [HttpGet("authorize")]
        [AllowAnonymous]
        public async Task<IActionResult> Authorize(
            [FromQuery(Name = OAuthQueryParameters.ClientId)] string clientId,
            [FromQuery(Name = OAuthQueryParameters.RedirectUri)] string redirectUri,
            [FromQuery(Name = OAuthQueryParameters.ResponseType)] string? responseType = OAuthQueryParameters.DefaultResponseType,
            [FromQuery(Name = OAuthQueryParameters.Scope)] string? scope = null,
            [FromQuery(Name = OAuthQueryParameters.State)] string? state = null,
            [FromQuery(Name = OAuthQueryParameters.CodeChallenge)] string? codeChallenge = null,
            [FromQuery(Name = OAuthQueryParameters.CodeChallengeMethod)] string? codeChallengeMethod = null,
            [FromQuery(Name = OAuthQueryParameters.Nonce)] string? nonce = null,
            [FromQuery(Name = OAuthQueryParameters.LoginHint)] string? loginHint = null,
            [FromQuery(Name = OAuthQueryParameters.IdpHint)] string? idpHint = null,
            [FromQuery(Name = OAuthQueryParameters.Prompt)] string? prompt = null)
        {
            try
            {
                // Create and validate login request
                var (requestId, expiresAt) = await _loginRequestService.CreateAsync(
                    clientId: clientId,
                    redirectUri: redirectUri,
                    responseType: responseType,
                    scope: scope,
                    state: state,
                    codeChallenge: codeChallenge,
                    codeChallengeMethod: codeChallengeMethod,
                    nonce: nonce,
                    loginHint: loginHint,
                    identityProvider: idpHint,
                    prompt: prompt
                );

                // Redirect to login page with requestId
                return Redirect($"/Login?requestId={requestId}&redirectUri={redirectUri}");
            }
            catch (DSException ex)
            {
                // Return error to client redirect_uri
                var errorDescription = GetLocalizedErrorMessage(ex);
                var errorUrl = $"{redirectUri}?{OAuthQueryParameters.Error}={ex.errorCode}&{OAuthQueryParameters.ErrorDescription}={Uri.EscapeDataString(errorDescription)}";
                if (!string.IsNullOrEmpty(state))
                {
                    errorUrl += $"&{OAuthQueryParameters.State}={state}";
                }
                return Redirect(errorUrl);
            }
        }

        /// <summary>
        /// OAuth2 Callback Endpoint
        /// Called after user authentication, generates authorization code
        /// </summary>
        [HttpGet("callback")]
        [AllowAnonymous]
        public async Task<IActionResult> Callback([FromQuery] string requestId)
        {
            try
            {
                // Get login request context
                var loginRequest = await _loginRequestService.GetByRequestIdAsync(requestId);
                if (loginRequest == null || !loginRequest.IsAuthenticated)
                {
                    throw new DSException("InvalidLoginRequest");
                }

                // Generate authorization code
                var code = await _authCodeService.CreateAsync(
                    userId: loginRequest.AuthenticatedUserId!,
                    clientId: loginRequest.ClientId,
                    redirectUri: loginRequest.RedirectUri,
                    scopes: loginRequest.Scopes,
                    codeChallenge: loginRequest.CodeChallenge,
                    codeChallengeMethod: loginRequest.CodeChallengeMethod,
                    identityProviderCode: loginRequest.IdentityProvider,
                    nonce: loginRequest.Nonce
                );

                // Mark request as consumed
                await _loginRequestService.MarkAsConsumedAsync(requestId);

                // Redirect back to client with authorization code
                var redirectUrl = $"{loginRequest.RedirectUri}?{OAuthQueryParameters.Code}={code}";
                if (!string.IsNullOrEmpty(loginRequest.State))
                {
                    redirectUrl += $"&{OAuthQueryParameters.State}={loginRequest.State}";
                }

                return Redirect(redirectUrl);
            }
            catch (DSException ex)
            {
                return BadRequest(ex.errorCode, GetLocalizedErrorMessage(ex));
            }
        }

        /// <summary>
        /// OAuth2 Token Endpoint
        /// Exchange authorization code or refresh token for access token
        /// </summary>
        [HttpPost("token")]
        [AllowAnonymous]
        public async Task<IActionResult> Token(
            [FromForm(Name = OAuthQueryParameters.GrantType)] string grantType,
            [FromForm(Name = OAuthQueryParameters.Code)] string? code = null,
            [FromForm(Name = OAuthQueryParameters.ClientId)] string? clientId = null,
            [FromForm(Name = OAuthQueryParameters.ClientSecret)] string? clientSecret = null,
            [FromForm(Name = OAuthQueryParameters.RedirectUri)] string? redirectUri = null,
            [FromForm(Name = OAuthQueryParameters.CodeVerifier)] string? codeVerifier = null,
            [FromForm(Name = OAuthQueryParameters.RefreshToken)] string? refreshToken = null)
        {
            try
            {
                if (grantType == OAuthQueryParameters.AuthorizationCode)
                {
                    if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(clientId) || string.IsNullOrEmpty(redirectUri))
                    {
                        throw new DSException("InvalidRequest");
                    }

                    var command = new ExchangeCodeCommand
                    {
                        Code = code,
                        ClientId = clientId,
                        ClientSecret = clientSecret,
                        RedirectUri = redirectUri,
                        GrantType = grantType,
                        CodeVerifier = codeVerifier
                    };

                    var result = await _mediator.Send(command);
                    return Ok(result);
                }
                else if (grantType == OAuthQueryParameters.RefreshToken)
                {
                    if (string.IsNullOrEmpty(refreshToken) || string.IsNullOrEmpty(clientId))
                    {
                        throw new DSException("InvalidRequest");
                    }

                    var command = new RefreshTokenCommand
                    {
                        RefreshToken = refreshToken,
                        ClientId = clientId,
                        ClientSecret = clientSecret,
                        GrantType = grantType
                    };

                    var result = await _mediator.Send(command);
                    return Ok(result);
                }
                else
                {
                    throw new DSException("UnsupportedGrantType");
                }
            }
            catch (DSException ex)
            {
                return BadRequest(ex.errorCode, GetLocalizedErrorMessage(ex));
            }
        }

        /// <summary>
        /// OAuth2 Token Revocation Endpoint
        /// </summary>
        [HttpPost("revoke")]
        [AllowAnonymous]
        public async Task<IActionResult> Revoke(
            [FromForm(Name = OAuthQueryParameters.Token)] string token,
            [FromForm(Name = OAuthQueryParameters.ClientId)] string clientId,
            [FromForm(Name = OAuthQueryParameters.ClientSecret)] string? clientSecret = null,
            [FromForm(Name = OAuthQueryParameters.TokenTypeHint)] string? tokenTypeHint = null)
        {
            try
            {
                var command = new RevokeTokenCommand
                {
                    Token = token,
                    ClientId = clientId,
                    ClientSecret = clientSecret,
                    TokenTypeHint = tokenTypeHint
                };

                await _mediator.Send(command);
                return Ok();
            }
            catch (DSException ex)
            {
                return BadRequest(ex.errorCode, GetLocalizedErrorMessage(ex));
            }
        }

        /// <summary>
        /// OIDC UserInfo Endpoint
        /// Returns user information from access token
        /// </summary>
        [HttpGet("userinfo")]
        [Authorize]
        public async Task<IActionResult> UserInfo()
        {
            try
            {
                var accessToken = Request.Headers.Authorization.ToString().Replace("Bearer ", "");

                var query = new GetUserInfoQuery
                {
                    AccessToken = accessToken
                };

                var result = await _mediator.Send(query);
                return Ok(result);
            }
            catch (DSException ex)
            {
                return BadRequest(ex.errorCode, GetLocalizedErrorMessage(ex));
            }
        }

        /// <summary>
        /// Get User Permissions Endpoint
        /// Returns list of permissions for user in current client
        /// 
        /// Lấy thông tin từ Token claims:
        /// - userId: từ claim "userId"
        /// - clientId: từ claim "clientId"
        /// - roleIds: từ claim "roles" (parsed from JSON)
        /// 
        /// Usage:
        /// - For authorization check: GET /oauth2/permissions?codesOnly=true
        /// - For UI permission list: GET /oauth2/permissions?codesOnly=false
        /// 
        /// Supported query parameters:
        /// - codesOnly: optional, default false. If true, returns only permission codes for faster checks
        /// </summary>
        [HttpGet("permissions")]
        [Authorize]
        public async Task<IActionResult> GetPermissions(
            [FromQuery] bool codesOnly = false,
            CancellationToken cancellationToken = default)
        {
            try
            {
                // Extract userId from token claims
                var userId = User.FindFirst(TokenClaimTypes.UserId)?.Value;
                if (string.IsNullOrWhiteSpace(userId))
                {
                    throw new DSException("InvalidToken");
                }

                // Extract clientId from token claims
                var clientId = User.FindFirst(TokenClaimTypes.ClientId)?.Value;
                if (string.IsNullOrWhiteSpace(clientId))
                {
                    throw new DSException("InvalidToken");
                }

                var query = new GetUserPermissionsQuery
                {
                    UserId = userId,
                    ClientId = clientId,
                    CodesOnly = codesOnly
                };

                var result = await _mediator.Send(query, cancellationToken);
                return Ok(result);
            }
            catch (DSException ex)
            {
                return BadRequest(ex.errorCode, GetLocalizedErrorMessage(ex));
            }
        }

        /// <summary>
        /// JWKS Endpoint
        /// </summary>
        [HttpGet(".well-known/jwks.json")]
        [AllowAnonymous]
        public IActionResult Jwks()
        {
            var jwk = _jwtKeyService.GetJsonWebKey();
            return Ok(new { keys = new[] { jwk } });
        }

        /// <summary>
        /// OIDC Discovery Endpoint (.well-known/openid-configuration)
        /// </summary>
        [HttpGet(".well-known/openid-configuration")]
        public IActionResult Discovery()
        {
            var baseUrl = $"{Request.Scheme}://{Request.Host}";
            var issuer = string.IsNullOrWhiteSpace(_jwtSettings.Issuer) ? baseUrl : _jwtSettings.Issuer;
            var jwksPath = string.IsNullOrWhiteSpace(_jwtSettings.JwksPath) ? "/oauth2/.well-known/jwks.json" : _jwtSettings.JwksPath;
            var jwksUri = jwksPath.StartsWith("http", StringComparison.OrdinalIgnoreCase)
                ? jwksPath
                : $"{baseUrl.TrimEnd('/')}/{jwksPath.TrimStart('/')}";

            var discovery = new
            {
                issuer = issuer,
                authorization_endpoint = $"{baseUrl}/oauth2/authorize",
                token_endpoint = $"{baseUrl}/oauth2/token",
                userinfo_endpoint = $"{baseUrl}/oauth2/userinfo",
                permissions_endpoint = $"{baseUrl}/oauth2/permissions",
                revocation_endpoint = $"{baseUrl}/oauth2/revoke",
                jwks_uri = jwksUri,
                response_types_supported = new[] { "code" },
                grant_types_supported = new[] { "authorization_code", "refresh_token" },
                subject_types_supported = new[] { "public" },
                id_token_signing_alg_values_supported = new[] { "RS256" },
                scopes_supported = new[] { "openid", "profile", "email", "offline_access" },
                token_endpoint_auth_methods_supported = new[] { "client_secret_post", "client_secret_basic" },
                code_challenge_methods_supported = new[] { "S256", "plain" }
            };

            return Ok(discovery);
        }

        /// <summary>
        /// Logout Endpoint - Revoke SSO session and clear session cookies
        /// </summary>
        [HttpGet("logout")]
        public async Task<IActionResult> Logout([FromQuery] string? returnUrl = null)
        {
            try
            {
                // Get current session key from cookie
                var currentSessionKey = Request.Cookies[CookieConstants.CurrentSessionCookieName];
                if (!string.IsNullOrEmpty(currentSessionKey))
                {
                    // Revoke the current session
                    await _sessionService.RevokeSessionAsync(currentSessionKey);
                }

                // Clear multi-session cookies
                Response.Cookies.Delete(CookieConstants.CurrentSessionCookieName);
                Response.Cookies.Delete(CookieConstants.SessionKeysCookieName);

                // Redirect to return URL or home
                if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                {
                    return Redirect(returnUrl);
                }

                return Redirect("/");
            }
            catch (DSException ex)
            {
                return BadRequest(ex.errorCode, GetLocalizedErrorMessage(ex));
            }
        }

        /// <summary>
        /// Logout All Sessions Endpoint - Revoke all SSO sessions for current user
        /// </summary>
        [HttpGet("logout-all")]
        public async Task<IActionResult> LogoutAll([FromQuery] string? returnUrl = null)
        {
            try
            {
                // Get all stored session keys
                var sessionKeysJson = Request.Cookies[CookieConstants.SessionKeysCookieName];
                if (!string.IsNullOrEmpty(sessionKeysJson))
                {
                    try
                    {
                        var sessionKeys = System.Text.Json.JsonSerializer.Deserialize<List<string>>(sessionKeysJson) ?? new List<string>();

                        // Revoke all sessions
                        foreach (var sessionKey in sessionKeys)
                        {
                            await _sessionService.RevokeSessionAsync(sessionKey);
                        }
                    }
                    catch { }
                }

                // Clear all session cookies
                Response.Cookies.Delete(CookieConstants.CurrentSessionCookieName);
                Response.Cookies.Delete(CookieConstants.SessionKeysCookieName);

                // Redirect to return URL or home
                if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                {
                    return Redirect(returnUrl);
                }

                return Redirect("/");
            }
            catch (DSException ex)
            {
                return BadRequest(ex.errorCode, GetLocalizedErrorMessage(ex));
            }
        }
    }
}
