namespace DS.Identity.Middleware
{
    /// <summary>
    /// Middleware để xóa security headers hạn chế iframe embedding
    /// Middleware này chạy CUỐI CÙNG trong pipeline để catch bất kỳ header nào được thêm bởi middleware khác
    /// </summary>
    public class RemoveSecurityHeadersMiddleware
    {
        private readonly RequestDelegate _next;

        public RemoveSecurityHeadersMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Register callback sẽ chạy TRƯỚC khi headers được gửi đi
            context.Response.OnStarting(() =>
            {
                // Xóa tất cả security headers hạn chế iframe
                context.Response.Headers.Remove("X-Frame-Options");
                context.Response.Headers.Remove("X-Content-Type-Options");
                //context.Response.Headers.Remove("X-XSS-Protection");
                //context.Response.Headers.Remove("X-Permitted-Cross-Domain-Policies");

                // Nếu muốn allow iframe từ bất kỳ origin nào, xóa CSP frame-ancestors
                // Nếu muốn restrict, sử dụng CSP thay vì X-Frame-Options
                if (context.Response.Headers.ContainsKey("Content-Security-Policy"))
                {
                    var csp = context.Response.Headers["Content-Security-Policy"].ToString();
                    if (csp.Contains("frame-ancestors"))
                    {
                        // Remove restrictive frame-ancestors directive
                        csp = System.Text.RegularExpressions.Regex.Replace(csp, @"frame-ancestors\s+[^;]+;?\s*", "");
                        context.Response.Headers["Content-Security-Policy"] = csp;
                    }
                }

                return Task.CompletedTask;
            });

            await _next(context);
        }
    }

    /// <summary>
    /// Extension method để register middleware
    /// </summary>
    public static class RemoveSecurityHeadersMiddlewareExtensions
    {
        public static IApplicationBuilder UseRemoveSecurityHeaders(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RemoveSecurityHeadersMiddleware>();
        }
    }
}
