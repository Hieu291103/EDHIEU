using DS.Shared.Core.Application.Abstractions.Localization;

namespace DS.Api.Infrastructure.Localization
{
    /// <summary>
    /// Localization provider cho DS.Api
    /// Priority = 100 để override Core messages
    /// </summary>
    public class ApiLocalizationProvider : ILocalizationProvider
    {
        public int Priority => 100;

        private static readonly Dictionary<string, Dictionary<string, string>> Messages = new()
        {
            ["vi"] = new Dictionary<string, string>
            {
                // Auth proxy errors
                ["OAuthExchangeFailed"] = "Không thể đổi authorization code để lấy token",
                ["OAuthRefreshFailed"] = "Không thể làm mới token",
                ["Unauthorized"] = "Không có quyền truy cập",

                // Generic
                ["InvalidRequest"] = "Yêu cầu không hợp lệ",
                ["UnsupportedGrantType"] = "Grant type không được hỗ trợ",
            },
            ["en"] = new Dictionary<string, string>
            {
                // Auth proxy errors
                ["OAuthExchangeFailed"] = "Failed to exchange authorization code for token",
                ["OAuthRefreshFailed"] = "Failed to refresh token",
                ["Unauthorized"] = "Unauthorized",

                // Generic
                ["InvalidRequest"] = "Invalid request",
                ["UnsupportedGrantType"] = "Unsupported grant type",
            }
        };

        private static readonly Dictionary<string, Dictionary<string, string>> PropertyNames = new()
        {
            ["vi"] = new Dictionary<string, string>
            {
                // Auth request properties
                ["GrantType"] = "Grant type",
                ["Code"] = "Code",
                ["RedirectUri"] = "Redirect URI",
                ["RefreshToken"] = "Refresh token",
                ["CodeVerifier"] = "Code verifier",
                ["ReturnUrl"] = "Return URL",
            },
            ["en"] = new Dictionary<string, string>
            {
                // Auth request properties
                ["GrantType"] = "Grant type",
                ["Code"] = "Code",
                ["RedirectUri"] = "Redirect URI",
                ["RefreshToken"] = "Refresh token",
                ["CodeVerifier"] = "Code verifier",
                ["ReturnUrl"] = "Return URL",
            }
        };

        public string? GetMessage(string key, string languageCode)
        {
            return Messages.GetValueOrDefault(languageCode)?.GetValueOrDefault(key);
        }

        public string? GetPropertyName(string propertyName, string languageCode)
        {
            return PropertyNames.GetValueOrDefault(languageCode)?.GetValueOrDefault(propertyName);
        }

        public string? GetValidationMessage(string errorCode, string languageCode)
        {
            // DS.Api không override validation messages
            return null;
        }
    }
}
