using DS.Api.Infrastructure.Localization;
using DS.Module.Identity.Infrastructure.Extensions;
using DS.Module.OnlineClass.Infrastructure.Extensions;
using DS.Module.Tenant.Infrastructure.Extensions;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Infrastructure.Configuration;
using DS.Shared.Core.Infrastructure.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Configuration;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.Redis.Extensions;
using DS.Shared.Core.Infrastructure.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.IdentityModel.Tokens;
using System.Text.Json;
using System.Text.Json.Serialization;

MongoDbConventions.RegisterConventions();

var builder = WebApplication.CreateBuilder(args);
// Tự động load appsettings.{ENVIRONMENT}.json
builder.Configuration
    .AddJsonFile("appsettings.json", optional: false)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true)
    .AddEnvironmentVariables();

// Serilog
builder.Host.AddSerilogLogging(builder.Configuration);

//ForwardedHeader
builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    // Chỉ định các header cần đọc
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    // xóa danh sách mặc định (thường chỉ tin loopback 127.0.0.1)
    options.KnownIPNetworks.Clear();
    options.KnownProxies.Clear();
});

// Add controllers with JSON options
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });

builder.Services.AddDefaultCors(builder.Configuration);

// Đăng ký dịch vụ RequestContext
builder.Services.AddRequestContext();

// Register both Mongo databases (Admin + School)
builder.Services.AddMongoDatabases(builder.Configuration);

// Redis for caching and distributed features
builder.Services.AddRedisCache(builder.Configuration);

// Localization (Core + DS.Api overrides)
builder.Services.AddCoreLocalization();
builder.Services.AddLocalizationProvider<ApiLocalizationProvider>();

// Tenant module services
builder.Services.AddTenantModule();
// Identity module services
builder.Services.AddIdentityModule();
// Excel export services (EPPlus)
builder.Services.AddExcelServices();
// OnlineClass module services
builder.Services.AddOnlineClassModule(builder.Configuration);

// S3 Upload Service
builder.Services.AddS3UploadService(builder.Configuration);
// Onluyen integration
builder.Services.AddOnluyenIntegration(builder.Configuration);
// AutoMapper with auto-discovery
builder.Services.AddAutoMapperWithAutoDiscovery();

// MediatR with auto-discovery
// Default: Chỉ enable Validation, các behaviors khác off
builder.Services.AddMediatRWithAutoDiscovery(options =>
{
    // Override default nếu cần
    options.EnableTenantContext = true; // School API cần tenant context
    options.EnableCaching = true; // Enable caching cho queries
    options.EnableValidation = true; // Enable validation cho commands
});

// OAuth settings (shared in DS.Shared.Core)
builder.Services.Configure<OAuthSettings>(builder.Configuration.GetSection(OAuthSettings.SectionName));
builder.Services.Configure<JwtSettings>(builder.Configuration.GetSection(JwtSettings.SectionName));
builder.Services.AddHttpClient<IOAuthClient, OAuthClientService>();

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        var oauthSettings = builder.Configuration.GetSection(OAuthSettings.SectionName).Get<OAuthSettings>() ?? new OAuthSettings();
        options.RequireHttpsMetadata = false;
        if (!string.IsNullOrWhiteSpace(oauthSettings.Url))
        {
            options.Authority = oauthSettings.Url;
        }
        options.RefreshOnIssuerKeyNotFound = true;
        options.AutomaticRefreshInterval = TimeSpan.FromHours(12);
        options.RefreshInterval = TimeSpan.FromMinutes(30);
        options.Backchannel = new HttpClient(new SocketsHttpHandler
        {
            PooledConnectionLifetime = TimeSpan.FromMinutes(10),
            MaxConnectionsPerServer = 50
        });
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = !string.IsNullOrWhiteSpace(oauthSettings.Issuer),
            ValidIssuer = oauthSettings.Issuer,
            ValidateAudience = !string.IsNullOrWhiteSpace(oauthSettings.Audience),
            ValidAudience = oauthSettings.Audience,
            ValidateIssuerSigningKey = true,
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromSeconds(30)
        };
    });

builder.Services.AddPermissionAuthorization();
builder.Services.AddAuthorization();

// Health checks
builder.Services.AddDefaultHealthChecks();

var app = builder.Build();

// Use ForwardedHeaders middleware BEFORE other middleware (recommended order)
app.UseForwardedHeaders();

// Add Exception Handling Middleware (must be first)
app.UseExceptionHandling();

// Add Request Context Middleware
app.UseRequestContext();

// Add Response Time Header Middleware (thêm X-Time-Server và X-Time-Client headers)
app.UseResponseTimeHeaders();

app.UseCors(CorsSettings.DefaultPolicyName);

app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.UseDefaultHealthChecks();
app.Run();
