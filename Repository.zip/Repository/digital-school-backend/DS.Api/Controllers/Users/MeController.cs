using DS.Module.Identity.Application.Commands.Users;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Presentation.Controllers;
using DS.Shared.CQRS.Queries.Users;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Api.Controllers.Users
{
    [Route("api/me")]
    [Authorize]
    [ApiController]
    public class MeController : BaseAPIController
    {
        private readonly ICurrentUser _currentUser;

        public MeController(IMediator mediator, ICurrentUser currentUser)
            : base(mediator)
        {
            _currentUser = currentUser;
        }

        /// <summary>
        /// Lấy thông tin profile của user hiện tại
        /// </summary>
        [HttpGet("profile")]
        public async Task<IActionResult> GetProfile(CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(_currentUser.UserId))
                return Unauthorized();

            var query = new SharedGetUserByIdQuery { UserId = _currentUser.UserId };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
                return NotFound();

            return SuccessResponse(result);
        }

        /// <summary>
        /// Đổi mật khẩu của user hiện tại
        /// </summary>
        [HttpPost("change-password")]
        public async Task<IActionResult> ChangePassword(
            [FromBody] ChangePasswordRequest request,
            CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(_currentUser.UserId))
                return Unauthorized();

            var command = new ChangePasswordCommand
            {
                UserId = _currentUser.UserId,
                CurrentPassword = request.CurrentPassword,
                NewPassword = request.NewPassword
            };

            return await SendAsync(command);
        }

        /// <summary>
        /// Request model cho change password
        /// </summary>
        public class ChangePasswordRequest
        {
            public string CurrentPassword { get; set; } = string.Empty;
            public string NewPassword { get; set; } = string.Empty;
        }
    }
}
