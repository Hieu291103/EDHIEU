using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Services.S3;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Api.Controllers.Storage
{
    [Route("api/s3")]
    [Authorize]
    [ApiController]
    public class S3Controller : ControllerBase
    {
        private readonly IS3UploadService _s3UploadService;

        public S3Controller(IS3UploadService s3UploadService)
        {
            _s3UploadService = s3UploadService;
        }

        /// <summary>
        /// Tạo presigned URL để client upload file trực tiếp lên S3
        /// </summary>
        [HttpPost("upload-url")]
        public async Task<IActionResult> GetUploadUrl(
            [FromBody] S3PresignedUploadRequest request,
            CancellationToken cancellationToken = default)
        {
            var response = await _s3UploadService.GeneratePresignedUploadUrlAsync(request, cancellationToken);
            return Ok(Result<S3PresignedUploadResponse>.Success(response));
        }

        /// <summary>
        /// Tạo presigned URL để client upload nhiều file trực tiếp lên S3
        /// </summary>
        [HttpPost("upload-urls")]
        public async Task<IActionResult> GetUploadUrls(
            [FromBody] S3PresignedUploadBatchRequest request,
            CancellationToken cancellationToken = default)
        {
            var response = await _s3UploadService.GeneratePresignedUploadUrlsAsync(request, cancellationToken);
            return Ok(Result<S3PresignedUploadBatchResponse>.Success(response));
        }

        /// <summary>
        /// Tạo presigned URL để client preview file trực tiếp từ S3
        /// </summary>
        [HttpPost("preview-url")]
        public async Task<IActionResult> GetPreviewUrl(
            [FromBody] S3PresignedDownloadRequest request,
            CancellationToken cancellationToken = default)
        {
            var response = await _s3UploadService.GeneratePresignedPreviewUrlAsync(request, cancellationToken);
            return Ok(Result<S3PresignedDownloadResponse>.Success(response));
        }

        /// <summary>
        /// Tạo presigned URL để client preview nhiều file trực tiếp từ S3
        /// </summary>
        [HttpPost("preview-urls")]
        public async Task<IActionResult> GetPreviewUrls(
            [FromBody] S3PresignedPreviewBatchRequest request,
            CancellationToken cancellationToken = default)
        {
            var response = await _s3UploadService.GeneratePresignedPreviewUrlsAsync(request, cancellationToken);
            return Ok(Result<S3PresignedPreviewBatchResponse>.Success(response));
        }

        /// <summary>
        /// Tạo presigned URL để client download file trực tiếp từ S3
        /// </summary>
        [HttpPost("download-url")]
        public async Task<IActionResult> GetDownloadUrl(
            [FromBody] S3PresignedDownloadRequest request,
            CancellationToken cancellationToken = default)
        {
            var response = await _s3UploadService.GeneratePresignedDownloadUrlAsync(request, cancellationToken);
            return Ok(Result<S3PresignedDownloadResponse>.Success(response));
        }

        /// <summary>
        /// Tạo presigned URL để client download nhiều file trực tiếp từ S3
        /// </summary>
        [HttpPost("download-urls")]
        public async Task<IActionResult> GetDownloadUrls(
            [FromBody] S3PresignedDownloadBatchRequest request,
            CancellationToken cancellationToken = default)
        {
            var response = await _s3UploadService.GeneratePresignedDownloadUrlsAsync(request, cancellationToken);
            return Ok(Result<S3PresignedDownloadBatchResponse>.Success(response));
        }

        /// <summary>
        /// Xóa một file trực tiếp trên S3
        /// </summary>
        [HttpPost("delete-object")]
        public async Task<IActionResult> DeleteObject(
            [FromBody] S3DeleteObjectRequest request,
            CancellationToken cancellationToken = default)
        {
            var response = await _s3UploadService.DeleteObjectsAsync(
                new S3DeleteObjectsRequest { S3Keys = [request.S3Key] },
                cancellationToken);

            return Ok(Result<S3DeleteObjectsResponse>.Success(response));
        }

        /// <summary>
        /// Xóa nhiều file trực tiếp trên S3
        /// </summary>
        [HttpPost("delete-objects")]
        public async Task<IActionResult> DeleteObjects(
            [FromBody] S3DeleteObjectsRequest request,
            CancellationToken cancellationToken = default)
        {
            var response = await _s3UploadService.DeleteObjectsAsync(request, cancellationToken);
            return Ok(Result<S3DeleteObjectsResponse>.Success(response));
        }
    }
}
