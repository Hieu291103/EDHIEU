# Copilot Instructions

## Project Guidelines
- In DS.Module.Tenant, `UserTenantMappingEntity` is the canonical entity to store tenant users (student, teacher, school staff, etc.) and role is determined by `UserType` (`Type` field). This table serves as a common repository for users across the tenant, distinguishing roles by the `Type` field.
- Do not add `TenantId` directly to `UserEntity` because `TenantId` is already inherited from a base class in this codebase.
- `Subject` should follow a shared template model, incorporating a global template with tenant-level overrides, similar to academic time templates.
- For academic time tree entities, the business key code must be canonical and auto-generated deterministically rather than manually edited.
- Use DSException/DXException-based error handling in controllers and declare corresponding localization keys in module localization providers instead of returning direct BadRequest for business validation errors.

## Query Parameters
- For Onluyen pagination, use `page` (not `pageIndex`).

## DS.Job Architecture
- Full architecture documentation is at `DS.Job/ARCHITECTURE.md`. Read it before working on any job-related task.
- All background jobs must implement `IBackgroundJob` and be registered as **Scoped** in `BackgroundJobRegistry.cs → AddBackgroundJobServices()`.
- Recurring job schedules are declared in `InitializeBackgroundJobs()` in the same file.
- Hangfire uses MongoDB storage (config key: `Mongo:Hangfire`). Dashboard is at `/jobs` protected by Basic Auth (`Hangfire:Dashboard:Username/Password`).

## DS.Admin.Api Architecture
- Full architecture documentation is at `DS.Admin.Api/ARCHITECTURE.md`. Read it before working on any admin API task.
- All controllers inherit `BaseAPIController` from `DS.Shared.Core.Presentation.Controllers`.
- Permission-based authorization uses `[PermissionAuthorize("MODULE:RESOURCE:ACTION")]` attribute.
- Auth: JWT Bearer (from DS.Identity) + Basic Auth scheme for Swagger. Token exchange via `IOAuthClient`.
- refresh_token is stored in HttpOnly cookie (`CookieConstants.RefreshTokenCookieName`), never in response body.

## DS.Identity Architecture
- Full architecture documentation is at `DS.Identity/ARCHITECTURE.md`. Read it before working on any authentication/OAuth task.
- This is a **Razor Pages** project (not MVC/Blazor) — it is the OAuth2 Authorization Server for the whole system.
- OAuth context (login request) is stored in Redis with short TTL (~10 min), identified by `RequestId` query param.
- JWT signing keys are persisted to `./keys/` directory via DataProtection — must be mounted persistent in containers.
- MongoDB indexes are created on startup via `InitializeIdentityIndexesAsync()`.

## DS.Partner.Api Architecture
- Full architecture documentation is at `DS.Partner.Api/ARCHITECTURE.md`. Read it before working on any partner integration task.
- All controllers inherit `PartnerApiControllerBase` (not `BaseAPIController`), providing `OkResponse`, `BadRequestResponse`, `UnauthorizedResponse`, `SendAsync` helpers.
- No JWT authentication — each endpoint validates its own security token (HMAC/API key).
- API runs under `/partner` path prefix (nginx + `UsePathBase`). Swagger always enabled, protected by Basic Auth.
- OneZoom webhook secured by HMAC SHA-256: `SHA256Hex("{WebhookSecret}:{eventName}:{roomId}")` compared to `secureKey` query param.

## DS.OnLuyen.Api Architecture
- Full architecture documentation is at `DS.OnLuyen.Api/ARCHITECTURE.md`. Read it before working on any Onluyen API task.
- All controllers inherit `OnluyenApiControllerBase` (not `BaseAPIController`), providing `_currentUser`, `OkResponse`, `BadRequestResponse`, `SendAsync` helpers.
- Auth uses **Onluyen JWT** (Issuer: `EDMICRO`, Audience: `ONLUYEN.VN`) — NOT DS.Identity JWT. Validated by `OnluyenTokenValidationMiddleware`.
- Use `[OnluyenAuthorize]` or `[OnluyenAuthorize(OnluyenRoleTypes.Teacher)]` for authorization. Role constants in `OnluyenRoleTypes`.
- API runs under `/onluyen` path prefix. `UseCors` must be placed BEFORE `UsePathBase`.
- `StartTime`/`EndTime` in requests are Unix timestamp milliseconds — use `.ToDateTime()` extension to convert.
