using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace DS.Module.Support.Domain.Entities
{
    /// <summary>
    /// Thông tin liên kết ticket với Crips CRM (external provider)
    /// </summary>
    public class CripsIntegrationInfo
    {
        /// <summary>
        /// ID ticket trong Crips CRM
        /// </summary>
        public string? SessionId { get; set; }

        public string? WebsiteId { get; set; }

        /// <summary>
        /// Thời gian tạo
        /// </summary>
        public DateTime? CreatedAt { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// Dữ liệu bổ sung từ Crips CRM
        /// </summary>
        [BsonRepresentation(BsonType.Document)]
        public Dictionary<string, object>? AdditionalData { get; set; }
    }
}
