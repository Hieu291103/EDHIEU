using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;
using MongoDB.Bson;

namespace DS.Module.Support.Domain.Entities
{
    /// <summary>
    /// Hoạt động / Tương tác trên ticket
    /// Collection: supportTicketActivities
    /// </summary>
    [BsonCollection("supportTicketActivities")]
    public class TicketActivityEntity : BaseAuditableEntity, ICrmEntity
    {
        /// <summary>
        /// ID của ticket
        /// </summary>
        [BsonObjectId]
        public required string TicketId { get; set; }

        /// <summary>
        /// Nội dung hoạt động
        /// </summary>
        public required string Content { get; set; }

        /// <summary>
        /// Loại hoạt động (Note, Call, ...)
        /// </summary>
        public string? ActivityType { get; set; } = "Note";

    }
}
