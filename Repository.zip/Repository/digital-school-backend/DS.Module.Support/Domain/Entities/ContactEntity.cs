using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;
using MongoDB.Bson;

namespace DS.Module.Support.Domain.Entities
{
    /// <summary>
    /// Thông tin khách hàng liên hệ
    /// Lưu thông tin người liên hệ độc lập, có thể được tham chiếu từ nhiều ticket
    /// Collection: supportContacts
    /// </summary>
    [BsonCollection("supportContacts")]
    public class ContactEntity : BaseTenantEntity, ICrmEntity
    {
        /// <summary>
        /// Họ tên của khách hàng liên hệ
        /// </summary>
        public required string FullName { get; set; }

        /// <summary>
        /// Email của khách hàng
        /// </summary>
        public string? Email { get; set; }

        public string? Zalo { get; set; }

        public string? ZaloGroup { get; set; }

        public string? Nickname { get; set; }

        /// <summary>
        /// Số điện thoại của khách hàng
        /// </summary>
        public string? PhoneNumber { get; set; }

        /// <summary>
        /// Tên tổ chức / Trường học của khách hàng
        /// </summary>
        public string? OrganizationName { get; set; }

        /// <summary>
        /// Địa chỉ của khách hàng
        /// </summary>
        public string? Address { get; set; }

        /// <summary>
        /// Ghi chú thêm về khách hàng
        /// </summary>
        public string? Notes { get; set; }

        /// <summary>
        /// Tài khoản liên kết của khách hàng
        /// </summary>
        public string? ProviderAccount { get; set; }

        /// <summary>
        /// Tài khoản liên kết của khách hàng
        /// </summary>
        public string? ProviderCrispId { get; set; }

        /// <summary>
        /// Tài khoản liên kết của khách hàng
        /// </summary>
        public string? UserId { get; set; }


        /// <summary>
        /// Tài khoản liên kết của khách hàng
        /// </summary>
        public string? UserName { get; set; }

        /// <summary>
        /// Loại khách hàng (ví dụ: Teacher, Student, Parent, School Admin, Other)
        /// </summary>
        public ContactType? Type { get; set; } = ContactType.Unknown;

        /// <summary>
        /// Dữ liệu bổ sung tùy chỉnh cho contact
        /// </summary>
        // [BsonRepresentation(BsonType.Document)]
        public BsonDocument? ExtraData { get; set; } = new();

        /// <summary>
        /// Contact đã xác nhận/verified hay chưa
        /// </summary>
        public bool? IsVerified { get; set; } = false;

        public int? TicketCount { get; set; } = 0;

        public int? SchoolId { get; set; }

        /// <summary>
        /// Thời gian xác nhận contact
        /// </summary>
        public DateTime? VerifiedAt { get; set; }
    }
}
