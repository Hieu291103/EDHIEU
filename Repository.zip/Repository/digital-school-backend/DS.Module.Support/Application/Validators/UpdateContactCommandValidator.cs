using FluentValidation;

namespace DS.Module.Support.Application.Commands.Contacts
{
    /// <summary>
    /// Validator cho UpdateContactCommand
    /// </summary>
    public class UpdateContactCommandValidator : AbstractValidator<UpdateContactCommand>
    {
        public UpdateContactCommandValidator()
        {
            RuleFor(x => x.ContactId)
                .NotEmpty()
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidContactIdFormat");

            RuleFor(x => x.FullName)
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.FullName));

            RuleFor(x => x.Email)
                .EmailAddress()
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.Email));

            RuleFor(x => x.PhoneNumber)
                .MaximumLength(20)
                .When(x => !string.IsNullOrEmpty(x.PhoneNumber));

            RuleFor(x => x.OrganizationName)
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.OrganizationName));

            RuleFor(x => x.Address)
                .MaximumLength(500)
                .When(x => !string.IsNullOrEmpty(x.Address));

            RuleFor(x => x.Notes)
                .MaximumLength(1000)
                .When(x => !string.IsNullOrEmpty(x.Notes));

            RuleFor(x => x.Zalo)
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.Zalo));

            RuleFor(x => x.ZaloGroup)
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.ZaloGroup));

            RuleFor(x => x.TenantId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTenantIdFormat")
                .When(x => !string.IsNullOrEmpty(x.TenantId));
        }
    }
}
