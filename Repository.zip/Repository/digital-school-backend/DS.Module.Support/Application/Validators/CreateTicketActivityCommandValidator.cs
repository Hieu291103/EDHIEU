using FluentValidation;

namespace DS.Module.Support.Application.Commands.TicketActivities
{
    /// <summary>
    /// Validator cho CreateTicketActivityCommand
    /// </summary>
    public class CreateTicketActivityCommandValidator : AbstractValidator<CreateTicketActivityCommand>
    {
        public CreateTicketActivityCommandValidator()
        {
            RuleFor(x => x.TicketId)
                .NotEmpty()
                .WithMessage("TicketId là bắt buộc")
                .Matches(@"^[0-9a-fA-F]{24}$|^[0-9]+$")
                .WithMessage("TicketId không hợp lệ");

            RuleFor(x => x.Content)
                .NotEmpty()
                .WithMessage("Nội dung là bắt buộc")
                .MaximumLength(5000)
                .WithMessage("Nội dung không được vượt quá 5000 ký tự");

            RuleFor(x => x.ActivityType)
                .NotEmpty()
                .WithMessage("Loại hoạt động là bắt buộc")
                .MaximumLength(100)
                .WithMessage("Loại hoạt động không được vượt quá 100 ký tự");
        }
    }
}
