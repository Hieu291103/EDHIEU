using FluentValidation;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Validator cho AssignTicketCommand
    /// </summary>
    public class AssignTicketCommandValidator : AbstractValidator<AssignTicketCommand>
    {
        public AssignTicketCommandValidator()
        {
            RuleFor(x => x.TicketId)
                .NotEmpty()
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTicketIdFormat");

            RuleFor(x => x.UserId)
                .NotEmpty()
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidUserIdFormat");

            RuleFor(x => x.TenantId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTenantIdFormat")
                .When(x => !string.IsNullOrEmpty(x.TenantId));
        }
    }
}
