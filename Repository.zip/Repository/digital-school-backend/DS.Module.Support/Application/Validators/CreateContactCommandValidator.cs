using FluentValidation;

namespace DS.Module.Support.Application.Commands.Contacts
{
    /// <summary>
    /// Validator cho CreateContactCommand
    /// </summary>
    public class CreateContactCommandValidator : AbstractValidator<CreateContactCommand>
    {
        public CreateContactCommandValidator()
        {
            RuleFor(x => x.FullName)
                .NotEmpty()
                .MaximumLength(200);

            RuleFor(x => x.Email)
                .EmailAddress().When(x => !string.IsNullOrEmpty(x.Email));

            RuleFor(x => x.PhoneNumber)
                .MaximumLength(20)
                .When(x => !string.IsNullOrEmpty(x.PhoneNumber));

            RuleFor(x => x.OrganizationName)
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.OrganizationName));

            RuleFor(x => x.Address)
                .MaximumLength(500)
                .When(x => !string.IsNullOrEmpty(x.Address));

            RuleFor(x => x.Notes)
                .MaximumLength(1000)
                .When(x => !string.IsNullOrEmpty(x.Notes));

            RuleFor(x => x.Zalo)
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.Zalo));

            RuleFor(x => x.ZaloGroup)
                .MaximumLength(200)
                .When(x => !string.IsNullOrEmpty(x.ZaloGroup));

            RuleFor(x => x.TenantId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTenantIdFormat")
                .When(x => !string.IsNullOrEmpty(x.TenantId));
        }
    }
}
