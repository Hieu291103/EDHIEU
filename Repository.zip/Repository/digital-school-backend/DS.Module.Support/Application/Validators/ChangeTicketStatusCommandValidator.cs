using FluentValidation;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Validator cho ChangeTicketStatusCommand
    /// </summary>
    public class ChangeTicketStatusCommandValidator : AbstractValidator<ChangeTicketStatusCommand>
    {
        public ChangeTicketStatusCommandValidator()
        {
            RuleFor(x => x.TicketId)
                .NotEmpty()
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTicketIdFormat");

            RuleFor(x => x.NewStatus)
                .IsInEnum()
                .WithMessage("InvalidTicketStatus");

            RuleFor(x => x.ChangedByUserId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidUserIdFormat")
                .When(x => !string.IsNullOrEmpty(x.ChangedByUserId));

            RuleFor(x => x.TenantId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTenantIdFormat")
                .When(x => !string.IsNullOrEmpty(x.TenantId));
        }
    }
}
