using FluentValidation;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Validator cho CreateAttachmentTicketCommand
    /// </summary>
    public class CreateAttachmentTicketCommandValidator : AbstractValidator<CreateAttachmentTicketCommand>
    {
        public CreateAttachmentTicketCommandValidator()
        {
            RuleFor(x => x.TicketId)
                .NotEmpty()
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTicketIdFormat");

            RuleFor(x => x.Attachments)
                .NotNull()
                .NotEmpty();

            RuleForEach(x => x.Attachments)
                .ChildRules(attachment =>
                {
                    attachment.RuleFor(a => a.FileName)
                        .NotEmpty()
                        .WithMessage("AttachmentFileNameRequired");

                    attachment.RuleFor(a => a.S3Url)
                        .NotEmpty()
                        .WithMessage("AttachmentS3UrlRequired");

                    attachment.RuleFor(a => a.S3Key)
                        .NotEmpty()
                        .WithMessage("AttachmentS3KeyRequired");

                    attachment.RuleFor(a => a.BucketName)
                        .NotEmpty()
                        .WithMessage("AttachmentBucketNameRequired");

                    attachment.RuleFor(a => a.FileSize)
                        .GreaterThanOrEqualTo(0)
                        .WithMessage("AttachmentFileSizeInvalid");
                });

        }
    }
}
