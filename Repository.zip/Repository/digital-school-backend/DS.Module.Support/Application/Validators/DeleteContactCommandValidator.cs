using FluentValidation;

namespace DS.Module.Support.Application.Commands.Contacts
{
    /// <summary>
    /// Validator cho DeleteContactCommand
    /// </summary>
    public class DeleteContactCommandValidator : AbstractValidator<DeleteContactCommand>
    {
        public DeleteContactCommandValidator()
        {
            RuleFor(x => x.ContactId)
                .NotEmpty()
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidContactIdFormat");

            RuleFor(x => x.TenantId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTenantIdFormat")
                .When(x => !string.IsNullOrEmpty(x.TenantId));
        }
    }
}
