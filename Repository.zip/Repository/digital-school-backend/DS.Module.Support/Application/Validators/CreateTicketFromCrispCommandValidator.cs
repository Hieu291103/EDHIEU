using FluentValidation;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Validator cho CreateTicketFromCrispCommand
    /// - Default validators: Sử dụng messages từ DefaultValidationMessageLocalization
    /// - Custom validators: Sử dụng error codes từ SupportLocalizationProvider
    /// </summary>
    public class CreateTicketFromCrispCommandValidator : AbstractValidator<CreateTicketFromCrispCommand>
    {
        public CreateTicketFromCrispCommandValidator()
        {
            RuleFor(x => x.TicketNumber)
                .NotEmpty();
            //.Matches(@"^TK-\d{6}-[0-9A-Fa-f]{6}$")
            //.WithMessage("InvalidTicketNumberFormat");

            RuleFor(x => x.Subject)
                .NotEmpty()
                .MaximumLength(500);

            RuleFor(x => x.CripsIntegration)
                .NotNull();

            When(x => x.CripsIntegration != null, () =>
            {
                RuleFor(x => x.CripsIntegration.SessionId)
                    .NotEmpty();

                RuleFor(x => x.CripsIntegration.WebsiteId)
                    .NotEmpty();
            });

            RuleFor(x => x.Contact)
                .NotNull();

            RuleFor(x => x.PrimaryAssigneeId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidAssigneeIdFormat")
                .When(x => !string.IsNullOrEmpty(x.PrimaryAssigneeId));

            RuleFor(x => x.TenantId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTenantIdFormat")
                .When(x => !string.IsNullOrEmpty(x.TenantId));
        }
    }
}
