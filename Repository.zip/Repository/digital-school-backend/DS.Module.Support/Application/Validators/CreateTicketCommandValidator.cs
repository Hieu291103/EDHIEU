using FluentValidation;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Validator cho CreateTicketCommand (cấu trúc mới: { Ticket, Contact })
    /// </summary>
    public class CreateTicketCommandValidator : AbstractValidator<CreateTicketCommand>
    {
        public CreateTicketCommandValidator()
        {
            RuleFor(x => x.Ticket)
                .NotNull();
            RuleFor(x => x.Contact)
                .NotNull();

            //Ticket
            RuleFor(x => x.Ticket.Subject)
                .NotEmpty()
                .MaximumLength(500);

            RuleFor(x => x.Ticket.Description)
                .MaximumLength(5000);

            RuleFor(x => x.Ticket.PrimaryAssigneeId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidAssigneeIdFormat")
                .When(x => !string.IsNullOrEmpty(x.Ticket.PrimaryAssigneeId));

            RuleFor(x => x.Ticket.TenantId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTenantIdFormat")
                .When(x => !string.IsNullOrEmpty(x.Ticket.TenantId));

            //Contact
            RuleFor(x => x.Contact.Id)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidContactIdFormat")
                .When(x => !string.IsNullOrEmpty(x.Contact.Id));

            // When creating a new contact (no existing Id),
            // FullName  are required
            When(x => x.Contact != null
                    && string.IsNullOrEmpty(x.Contact.Id), () =>
            {
                RuleFor(x => x.Contact.FullName)
                    .NotEmpty()
                    .MaximumLength(200);
            });
        }
    }
}
