using FluentValidation;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Validator cho DeleteAttachmentTicketCommand
    /// </summary>
    public class DeleteAttachmentTicketCommandValidator : AbstractValidator<DeleteAttachmentTicketCommand>
    {
        public DeleteAttachmentTicketCommandValidator()
        {
            RuleFor(x => x.TicketId)
                .NotEmpty()
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTicketIdFormat");

            RuleFor(x => x.Attachments)
                .NotEmpty()
                .NotNull();

            RuleForEach(x => x.Attachments)
                .Must(a => !string.IsNullOrWhiteSpace(a.Id) || !string.IsNullOrWhiteSpace(a.S3Key))
                .WithMessage("InvalidAttachmentIdFormat");

        }
    }
}
