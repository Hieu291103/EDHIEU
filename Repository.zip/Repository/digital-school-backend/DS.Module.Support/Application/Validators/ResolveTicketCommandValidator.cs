using FluentValidation;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Validator cho ResolveTicketCommand
    /// </summary>
    public class ResolveTicketCommandValidator : AbstractValidator<ResolveTicketCommand>
    {
        public ResolveTicketCommandValidator()
        {
            RuleFor(x => x.TicketId)
                .NotEmpty()
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTicketIdFormat");

            RuleFor(x => x.ResolvedByUserId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidUserIdFormat")
                .When(x => !string.IsNullOrEmpty(x.ResolvedByUserId));

            RuleFor(x => x.TenantId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTenantIdFormat")
                .When(x => !string.IsNullOrEmpty(x.TenantId));
        }
    }
}
