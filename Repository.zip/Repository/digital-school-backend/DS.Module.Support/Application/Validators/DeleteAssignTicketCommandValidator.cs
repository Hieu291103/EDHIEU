using FluentValidation;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Validator cho DeleteAssignTicketCommand
    /// </summary>
    public class DeleteAssignTicketCommandValidator : AbstractValidator<DeleteAssignTicketCommand>
    {
        public DeleteAssignTicketCommandValidator()
        {
            RuleFor(x => x.TicketId)
                .NotEmpty()
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTicketIdFormat");

            RuleFor(x => x.UserId)
                .NotEmpty()
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidUserIdFormat");
        }
    }
}
