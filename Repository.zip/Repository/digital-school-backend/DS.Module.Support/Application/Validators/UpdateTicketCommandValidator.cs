using FluentValidation;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Validator cho UpdateTicketCommand
    /// </summary>
    public class UpdateTicketCommandValidator : AbstractValidator<UpdateTicketCommand>
    {
        public UpdateTicketCommandValidator()
        {
            RuleFor(x => x.TicketId)
                .NotEmpty()
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTicketIdFormat");

            RuleFor(x => x.Ticket)
                .NotNull();

            // Ticket fields
            RuleFor(x => x.Ticket.Subject)
                .MaximumLength(500)
                .When(x => !string.IsNullOrEmpty(x.Ticket.Subject));

            RuleFor(x => x.Ticket.Description)
                .MaximumLength(5000)
                .When(x => !string.IsNullOrEmpty(x.Ticket.Description));

            RuleFor(x => x.Ticket.Channel)
                .MaximumLength(100)
                .When(x => !string.IsNullOrEmpty(x.Ticket.Channel));

            RuleFor(x => x.Ticket.PrimaryAssigneeId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidAssigneeIdFormat")
                .When(x => !string.IsNullOrEmpty(x.Ticket.PrimaryAssigneeId));

            RuleFor(x => x.Ticket.TenantId)
                .Matches(@"^[0-9a-fA-F]{24}$")
                .WithMessage("InvalidTenantIdFormat")
                .When(x => !string.IsNullOrEmpty(x.Ticket.TenantId));

            // Attachments
            When(x => x.Ticket.Attachments != null && x.Ticket.Attachments.Count > 0, () =>
            {
                RuleForEach(x => x.Ticket.Attachments)
                    .ChildRules(attachment =>
                    {
                        attachment.RuleFor(a => a.FileName)
                            .NotEmpty()
                            .MaximumLength(255);

                        attachment.RuleFor(a => a.S3Url)
                            .NotEmpty()
                            .MaximumLength(2048);

                        attachment.RuleFor(a => a.S3Key)
                            .NotEmpty()
                            .MaximumLength(1024);

                        attachment.RuleFor(a => a.BucketName)
                            .NotEmpty()
                            .MaximumLength(255);

                        attachment.RuleFor(a => a.FileSize)
                            .GreaterThan(0);
                    });
            });

            // Contact (optional on update)
            When(x => x.Contact != null, () =>
            {
                RuleFor(x => x.Contact!.Id)
                    .Matches(@"^[0-9a-fA-F]{24}$")
                    .WithMessage("InvalidContactIdFormat")
                    .When(x => !string.IsNullOrEmpty(x.Contact!.Id));

                RuleFor(x => x.Contact!.FullName)
                    .MaximumLength(200)
                    .When(x => !string.IsNullOrEmpty(x.Contact!.FullName));

            });
        }
    }
}
