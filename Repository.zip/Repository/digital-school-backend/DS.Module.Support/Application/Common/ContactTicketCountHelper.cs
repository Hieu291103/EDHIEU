using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Common
{
    internal static class ContactTicketCountHelper
    {
        public static async Task RefreshAsync(
            string? contactId,
            ICrmReadRepository<ContactEntity> contactReadRepository,
            ICrmWriteRepository<ContactEntity> contactWriteRepository,
            ICrmReadRepository<TicketEntity> ticketReadRepository,
            CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(contactId))
                return;

            var contact = await contactReadRepository.GetByIdAsync(
                contactId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken: cancellationToken);

            if (contact == null)
                return;

            var tickets = await ticketReadRepository.FilterAsync(
                t => t.ContactId == contactId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken: cancellationToken);

            var latestCount = tickets.Count;
            if (contact.TicketCount == latestCount)
                return;

            contact.TicketCount = latestCount;
            await contactWriteRepository.UpdateAsync(
                contact,
                tenantId: contact.TenantId,
                cancellationToken: cancellationToken);
        }
    }
}
