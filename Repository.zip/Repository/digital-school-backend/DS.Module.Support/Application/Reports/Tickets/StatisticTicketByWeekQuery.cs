using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Support.Application.Reports.Tickets
{
    /// <summary>
    /// Query để thống kê ticket theo khoảng thời gian
    /// </summary>
    public class StatisticTicketByWeekQuery : IQuery<StatisticTicketByWeekDto>
    {
        /// <summary>
        /// Ngày bắt đầu của khoảng thời gian thống kê
        /// </summary>
        public required DateTime StartDate { get; set; }

        /// <summary>
        /// Ngày kết thúc của khoảng thời gian thống kê
        /// </summary>
        public required DateTime EndDate { get; set; }
    }
}
