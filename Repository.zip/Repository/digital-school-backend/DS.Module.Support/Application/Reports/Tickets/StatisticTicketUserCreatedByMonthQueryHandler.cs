using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using MongoDB.Driver;

namespace DS.Module.Support.Application.Reports.Tickets
{
    /// <summary>
    /// Handler cho StatisticTicketUserCreatedByMonthQuery.
    /// Lấy danh sách thống kê người dùng tạo ticket trong tháng dưới dạng pivot table.
    /// </summary>
    public class StatisticTicketUserCreatedByMonthQueryHandler : IQueryHandler<StatisticTicketUserCreatedByMonthQuery, StatisticTicketUserCreatedByMonthListDto>
    {
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        private readonly IMediator _mediator;

        public StatisticTicketUserCreatedByMonthQueryHandler(
            ICrmReadRepository<TicketEntity> readRepository,
            IMediator mediator)
        {
            _readRepository = readRepository;
            _mediator = mediator;
        }

        public async Task<StatisticTicketUserCreatedByMonthListDto> Handle(StatisticTicketUserCreatedByMonthQuery request, CancellationToken cancellationToken)
        {
            // Validate input
            if (request.Month < 1 || request.Month > 12)
            {
                throw new ArgumentException("Tháng phải từ 1 đến 12", nameof(request.Month));
            }

            // Xác định ngày bắt đầu và kết thúc của tháng
            var startOfMonth = new DateTime(request.Year, request.Month, 1, 0, 0, 0, DateTimeKind.Utc);
            var endOfMonth = startOfMonth.AddMonths(1).AddTicks(-1);

            // Lọc tất cả ticket được tạo trong tháng
            var filterBuilder = Builders<TicketEntity>.Filter;
            var filter = filterBuilder.Gte(x => x.CreatedAt, startOfMonth) &
                         filterBuilder.Lte(x => x.CreatedAt, endOfMonth);

            // Lấy tất cả ticket trong tháng với thông tin người tạo
            var ticketProjections = await _readRepository.PagedFilterAsync(
                filter,
                x => new TicketMonthlyStatisticProjection
                {
                    CreatedBy = x.CreatedBy,
                    CreatedByDisplay = x.CreatedByDisplay,
                    CreatedAt = x.CreatedAt,
                },
                pageIndex: 1,
                pageSize: int.MaxValue,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken: cancellationToken);

            var projectionList = ticketProjections.Items.ToList();

            // Group ticket theo người tạo
            var groupedByUser = projectionList
                .Where(t => !string.IsNullOrEmpty(t.CreatedBy)) // Bỏ qua ticket không có người tạo
                .GroupBy(t => new { t.CreatedBy, t.CreatedByDisplay })
                .OrderBy(g => g.Key.CreatedByDisplay)
                .ToList();

            // Xây dựng danh sách kết quả
            var result = new StatisticTicketUserCreatedByMonthListDto();

            foreach (var userGroup in groupedByUser)
            {
                var userDto = new StatisticTicketUserCreatedByMonthDto
                {
                    UserId = userGroup.Key.CreatedBy!,
                    FullName = ExtractNameFromDisplay(userGroup.Key.CreatedByDisplay) ?? "Unknown",
                    UserName = ExtractEmailFromDisplay(userGroup.Key.CreatedByDisplay) ?? "Unknown",
                    Total = userGroup.Count()
                };

                // Đếm ticket theo từng ngày
                foreach (var ticket in userGroup)
                {
                    var dayOfMonth = ticket.CreatedAt.Day;
                    var currentValue = userDto.GetDayValue(dayOfMonth);
                    userDto.SetDayValue(dayOfMonth, currentValue + 1);
                }

                result.Users.Add(userDto);
            }

            return result;
        }

        /// <summary>
        /// Extract tên từ CreatedByDisplay
        /// Format: "Lê Anh Thư  (thula@edmicro.vn)" => "Lê Anh Thư"
        /// </summary>
        private static string? ExtractNameFromDisplay(string? displayText)
        {
            if (string.IsNullOrWhiteSpace(displayText))
                return null;

            // Tìm dấu mở ngoặc
            var openParen = displayText.IndexOf('(');

            // Nếu tìm thấy dấu ngoặc, lấy phần trước đó
            if (openParen > 0)
            {
                var name = displayText.Substring(0, openParen).Trim();
                return !string.IsNullOrWhiteSpace(name) ? name : null;
            }

            // Nếu không tìm thấy email trong ngoặc, trả về toàn bộ displayText
            return displayText.Trim();
        }

        /// <summary>
        /// Extract email từ CreatedByDisplay
        /// Format: "Lê Anh Thư  (thula@edmicro.vn)" => "thula@edmicro.vn"
        /// </summary>
        private static string? ExtractEmailFromDisplay(string? displayText)
        {
            if (string.IsNullOrWhiteSpace(displayText))
                return null;

            // Tìm dấu mở ngoặc và đóng ngoặc
            var openParen = displayText.IndexOf('(');
            var closeParen = displayText.IndexOf(')');

            // Nếu cả hai dấu ngoặc đều tồn tại và đúng vị trí, extract email
            if (openParen >= 0 && closeParen > openParen)
            {
                var email = displayText.Substring(openParen + 1, closeParen - openParen - 1).Trim();
                return !string.IsNullOrWhiteSpace(email) ? email : null;
            }

            // Nếu không tìm thấy email trong ngoặc, trả về toàn bộ displayText
            return displayText;
        }
    }

    /// <summary>
    /// Projection để lấy thông tin ticket cần thiết cho thống kê theo tháng
    /// </summary>
    internal class TicketMonthlyStatisticProjection
    {
        /// <summary>
        /// ID của người tạo ticket
        /// </summary>
        public string? CreatedBy { get; set; }

        /// <summary>
        /// Tên hiển thị của người tạo
        /// </summary>
        public string? CreatedByDisplay { get; set; }

        /// <summary>
        /// Thời gian tạo ticket
        /// </summary>
        public DateTime CreatedAt { get; set; }
    }
}
