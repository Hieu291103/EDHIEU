using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Support.Application.Reports.Tickets
{
    /// <summary>
    /// Query để thống kê ticket theo ngày
    /// </summary>
    public class StatisticTicketByDayQuery : IQuery<StatisticTicketByDayDto>
    {
        /// <summary>
        /// Ngày cần thống kê
        /// </summary>
        public required DateTime Date { get; set; }
    }
}
