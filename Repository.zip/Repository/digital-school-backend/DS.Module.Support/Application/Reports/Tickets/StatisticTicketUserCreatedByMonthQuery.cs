using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Support.Application.Reports.Tickets
{
    /// <summary>
    /// Query để thống kê ticket theo người dùng tạo trong tháng
    /// Kết quả trả về dạng pivot table với các cột từ ngày 1 đến 31
    /// </summary>
    public class StatisticTicketUserCreatedByMonthQuery : IQuery<StatisticTicketUserCreatedByMonthListDto>
    {
        /// <summary>
        /// Năm thống kê
        /// </summary>
        public required int Year { get; set; }

        /// <summary>
        /// Tháng thống kê
        /// </summary>
        public required int Month { get; set; }
    }
}
