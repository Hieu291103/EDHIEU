using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.DTOs.Tenants;
using DS.Shared.CQRS.Queries.Tenants;
using MediatR;
using MongoDB.Driver;

namespace DS.Module.Support.Application.Reports.Tickets
{
    /// <summary>
    /// Handler cho StatisticTicketByWeekQuery.
    /// Tính toán các thống kê về ticket trong một tuần cụ thể.
    /// </summary>
    public class StatisticTicketByWeekQueryHandler : IQueryHandler<StatisticTicketByWeekQuery, StatisticTicketByWeekDto>
    {
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        private readonly IMediator _mediator;

        public StatisticTicketByWeekQueryHandler(
            ICrmReadRepository<TicketEntity> readRepository,
            IMediator mediator)
        {
            _readRepository = readRepository;
            _mediator = mediator;
        }

        public async Task<StatisticTicketByWeekDto> Handle(StatisticTicketByWeekQuery request, CancellationToken cancellationToken)
        {
            // Lấy khoảng thời gian của tuần hiện tại
            var currentWeekStart = request.StartDate;
            var currentWeekEnd = request.EndDate;

            // Tính khoảng thời gian của tuần trước (7 ngày trước)
            var weekDuration = currentWeekEnd - currentWeekStart;
            var previousWeekStart = currentWeekStart.AddDays(-7);
            var previousWeekEnd = previousWeekStart.Add(weekDuration);

            // Lấy dữ liệu chi tiết cho tuần hiện tại (bao gồm danh sách tickets)
            var currentWeekData = await GetWeekStatisticsWithTickets(currentWeekStart, currentWeekEnd, cancellationToken);

            // Lấy chỉ dữ liệu thống kê cho tuần trước (không cần chi tiết tickets)
            var previousWeekData = await GetWeekStatistics(previousWeekStart, previousWeekEnd, cancellationToken);

            // Tính các chỉ số so sánh
            int currentWeekTotal = currentWeekData.TotalTickets;
            int previousWeekTotal = previousWeekData.TotalTickets;

            string trendWord = currentWeekTotal > previousWeekTotal ? "tăng" :
                              currentWeekTotal < previousWeekTotal ? "giảm" : "không thay đổi";

            int deltaAbs = Math.Abs(currentWeekTotal - previousWeekTotal);
            decimal deltaPercent = previousWeekTotal > 0
                ? Math.Round((decimal)(currentWeekTotal - previousWeekTotal) / previousWeekTotal * 100, 1)
                : 0;

            // Tính tỷ lệ giải quyết
            decimal resolutionRate = currentWeekTotal > 0
                ? Math.Round((currentWeekData.ClosedTickets / (decimal)currentWeekTotal) * 100, 1)
                : 0;

            return new StatisticTicketByWeekDto
            {
                WeekStartDate = currentWeekStart,
                WeekEndDate = currentWeekEnd,
                TotalTickets = currentWeekTotal,
                ClosedTickets = currentWeekData.ClosedTickets,
                ResolutionRate = resolutionRate,
                CurrentWeek = currentWeekTotal,
                PreviousWeek = previousWeekTotal,
                TrendWord = trendWord,
                DeltaAbs = deltaAbs,
                DeltaPercent = deltaPercent,
                UrgentAndHigh = currentWeekData.UrgentAndHigh,
                ZaloTeacherCount = currentWeekData.ZaloTeacherCount,
                ZaloStudentCount = currentWeekData.ZaloStudentCount,
                HotlineTeacherCount = currentWeekData.HotlineTeacherCount,
                HotlineStudentCount = currentWeekData.HotlineStudentCount,
                SoftwareSupportCount = currentWeekData.SoftwareSupportCount,
                ContestCount = currentWeekData.ContestCount,
                MobifoneCount = currentWeekData.MobifoneCount,
                Tickets = currentWeekData.Tickets,
                CrispTeacherCount = currentWeekData.CrispTeacherCount,
                CrispStudentCount = currentWeekData.CrispStudentCount,
            };
        }

        /// <summary>
        /// Tính toán thống kê cho một khoảng thời gian - chỉ lấy số liệu, không lấy danh sách tickets
        /// Sử dụng cho tuần trước để tối ưu performance
        /// </summary>
        private async Task<WeeklyStatisticsData> GetWeekStatistics(DateTime startDate, DateTime endDate, CancellationToken cancellationToken)
        {
            var filterBuilder = Builders<TicketEntity>.Filter;
            var filter = filterBuilder.Gte(x => x.CreatedAt, startDate) &
                         filterBuilder.Lte(x => x.CreatedAt, endDate);

            var ticketProjections = await _readRepository.PagedFilterAsync(
                filter,
                x => new TicketStatisticProjection
                {
                    Status = x.Status,
                    Priority = x.Priority,
                    Source = x.Source,
                    ContactType = x.ContactType ?? ContactType.Unknown,
                    Product = x.Product,
                    TenantId = x.TenantId,
                },
                pageIndex: 1,
                pageSize: int.MaxValue,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken: cancellationToken);

            var projectionList = ticketProjections.Items.ToList();

            // Tính tổng số ticket
            int totalTickets = ticketProjections.Total;

            // Tính số ticket đã giải quyết (status = Resolved hoặc Closed)
            int closedTickets = projectionList.Count(t =>
                t.Status == TicketStatus.Resolved || t.Status == TicketStatus.Closed);

            // Đếm ticket có mức độ ưu tiên Cao (High) và Khẩn cấp (Critical)
            int urgentAndHigh = projectionList.Count(t =>
                t.Priority == TicketPriority.High || t.Priority == TicketPriority.Critical);

            // Đếm ticket từ Zalo và là Giáo viên
            int zaloTeacherCount = projectionList.Count(t =>
                t.Source == TicketSource.Zalo && t.ContactType == ContactType.Teacher);

            // Đếm ticket từ Zalo và là Học sinh
            int zaloStudentCount = projectionList.Count(t =>
                t.Source == TicketSource.Zalo && t.ContactType == ContactType.Student);

            // Đếm ticket từ Hotline và là Giáo viên
            int hotlineTeacherCount = projectionList.Count(t =>
                t.Source == TicketSource.Hotline && t.ContactType == ContactType.Teacher);

            // Đếm ticket từ Hotline và là Học sinh
            int hotlineStudentCount = projectionList.Count(t =>
                t.Source == TicketSource.Hotline && t.ContactType == ContactType.Student);

            // Đếm ticket từ sản phẩm Kỳ thi quốc tế
            int contestCount = projectionList.Count(t => t.Product == TicketProduct.KyThiQuocTe);

            // Đếm ticket từ sản phẩm Onluyen
            int softwareSupportCount = projectionList.Count(t => t.Product == TicketProduct.OnLuyen);

            // Đếm ticket từ sản phẩm Mobifone
            int mobifoneCount = projectionList.Count(t => t.Product == TicketProduct.MBF);

            return new WeeklyStatisticsData
            {
                TotalTickets = totalTickets,
                ClosedTickets = closedTickets,
                UrgentAndHigh = urgentAndHigh,
                ZaloTeacherCount = zaloTeacherCount,
                ZaloStudentCount = zaloStudentCount,
                HotlineTeacherCount = hotlineTeacherCount,
                HotlineStudentCount = hotlineStudentCount,
                ContestCount = contestCount,
                SoftwareSupportCount = softwareSupportCount,
                MobifoneCount = mobifoneCount,
                CrispTeacherCount = 0,
                CrispStudentCount = 0,
                Tickets = new List<StatisticTicketItemDto>()
            };
        }

        /// <summary>
        /// Tính toán thống kê cho một khoảng thời gian - lấy số liệu + danh sách tickets chi tiết
        /// Sử dụng cho tuần hiện tại
        /// </summary>
        private async Task<WeeklyStatisticsData> GetWeekStatisticsWithTickets(DateTime startDate, DateTime endDate, CancellationToken cancellationToken)
        {
            var filterBuilder = Builders<TicketEntity>.Filter;
            var filter = filterBuilder.Gte(x => x.CreatedAt, startDate) &
                         filterBuilder.Lte(x => x.CreatedAt, endDate);

            var ticketProjections = await _readRepository.PagedFilterAsync(
                filter,
                x => new TicketStatisticProjection
                {
                    Subject = x.Subject,
                    Description = x.Description,
                    Status = x.Status,
                    Priority = x.Priority,
                    Source = x.Source,
                    ContactType = x.ContactType ?? ContactType.Unknown,
                    Product = x.Product,
                    CreatedFrom = x.CreatedFrom,
                    TenantId = x.TenantId,
                    TagType = x.TagType
                },
                pageIndex: 1,
                pageSize: 10000,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken: cancellationToken);

            var projectionList = ticketProjections.Items.ToList();

            // Tính tổng số ticket
            int totalTickets = ticketProjections.Total;

            // Tính số ticket đã giải quyết (status = Resolved hoặc Closed)
            int closedTickets = projectionList.Count(t =>
                t.Status == TicketStatus.Resolved || t.Status == TicketStatus.Closed);

            // Đếm ticket có mức độ ưu tiên Cao (High) và Khẩn cấp (Critical)
            int urgentAndHigh = projectionList.Count(t =>
                t.Priority == TicketPriority.High || t.Priority == TicketPriority.Critical);

            // Đếm ticket từ Zalo và là Giáo viên
            int zaloTeacherCount = projectionList.Count(t =>
                t.Source == TicketSource.Zalo && t.ContactType == ContactType.Teacher);

            // Đếm ticket từ Zalo và là Học sinh
            int zaloStudentCount = projectionList.Count(t =>
                t.Source == TicketSource.Zalo && t.ContactType == ContactType.Student);

            // Đếm ticket từ Hotline và là Giáo viên
            int hotlineTeacherCount = projectionList.Count(t =>
                t.Source == TicketSource.Hotline && t.ContactType == ContactType.Teacher);

            // Đếm ticket từ Hotline và là Học sinh
            int hotlineStudentCount = projectionList.Count(t =>
                t.Source == TicketSource.Hotline && t.ContactType == ContactType.Student);

            // Đếm ticket từ sản phẩm Kỳ thi quốc tế
            int contestCount = projectionList.Count(t => t.Product == TicketProduct.KyThiQuocTe);

            // Đếm ticket từ sản phẩm Onluyen
            int softwareSupportCount = projectionList.Count(t => t.Product == TicketProduct.OnLuyen);

            // Đếm ticket từ sản phẩm Mobifone
            int mobifoneCount = projectionList.Count(t => t.Product == TicketProduct.MBF);

            // Đếm ticket từ Crisp VÀ là Giáo viên
            int crispTeacherCount = projectionList.Count(t =>
            t.CreatedFrom == TicketFrom.Crips &&
                t.ContactType == ContactType.Teacher);

            // Đếm ticket từ Crisp VÀ là Học sinh
            int crispStudentCount = projectionList.Count(t =>
                t.CreatedFrom == TicketFrom.Crips &&
                t.ContactType == ContactType.Student);

            // Lấy danh sách tenants và tags
            var tenantIds = projectionList
                .Where(t => !string.IsNullOrEmpty(t.TenantId))
                .Select(t => t.TenantId!)
                .Distinct()
                .ToList();

            var tenantDtos = tenantIds.Any()
                ? await _mediator.Send(
                    new SharedGetNameTenantByIdsQuery { TenantIds = tenantIds },
                    cancellationToken)
                : new List<TenantNameDto>();

            // Chuyển đổi projections thành DTOs
            var ticketItems = projectionList.Select(t => new StatisticTicketItemDto
            {
                TenantName = tenantDtos.FirstOrDefault(_ => _.Id == t.TenantId)?.Name,
                Subject = t.Subject,
                Description = t.Description,
                Status = t.Status.ToString(),
                Priority = t.Priority.ToString(),
                Source = t.Source.ToString(),
                ContactType = t.ContactType.ToString(),
                TagType = t.TagType
            }).ToList();

            return new WeeklyStatisticsData
            {
                TotalTickets = totalTickets,
                ClosedTickets = closedTickets,
                UrgentAndHigh = urgentAndHigh,
                ZaloTeacherCount = zaloTeacherCount,
                ZaloStudentCount = zaloStudentCount,
                HotlineTeacherCount = hotlineTeacherCount,
                HotlineStudentCount = hotlineStudentCount,
                ContestCount = contestCount,
                SoftwareSupportCount = softwareSupportCount,
                MobifoneCount = mobifoneCount,
                CrispTeacherCount = crispTeacherCount,
                CrispStudentCount = crispStudentCount,
                Tickets = ticketItems
            };
        }

        /// <summary>
        /// DTO projection cho thống kê ticket, chỉ lấy các field cần thiết
        /// </summary>
        private class TicketStatisticProjection
        {
            public string? Subject { get; set; }
            public string? Description { get; set; }
            public TicketStatus Status { get; set; }
            public TicketPriority Priority { get; set; }
            public TicketSource Source { get; set; }
            public ContactType ContactType { get; set; }
            public TicketProduct Product { get; set; }
            public TicketFrom? CreatedFrom { get; set; }
            public string? TenantId { get; set; }
            public TicketTagType? TagType { get; set; } = TicketTagType.None;
        }

        /// <summary>
        /// Internal class để lưu dữ liệu thống kê tạm thời
        /// </summary>
        private class WeeklyStatisticsData
        {
            public int TotalTickets { get; set; }
            public int ClosedTickets { get; set; }
            public int UrgentAndHigh { get; set; }
            public int ZaloTeacherCount { get; set; }
            public int ZaloStudentCount { get; set; }
            public int HotlineTeacherCount { get; set; }
            public int HotlineStudentCount { get; set; }
            public int ContestCount { get; set; }
            public int SoftwareSupportCount { get; set; }
            public int MobifoneCount { get; set; }
            public int CrispTeacherCount { get; set; }
            public int CrispStudentCount { get; set; }
            public List<StatisticTicketItemDto> Tickets { get; set; } = new();
        }
    }
}
