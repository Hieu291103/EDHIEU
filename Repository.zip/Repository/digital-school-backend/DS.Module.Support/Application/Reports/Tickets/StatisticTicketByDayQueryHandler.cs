using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Queries.Tenants;
using MediatR;
using MongoDB.Driver;

namespace DS.Module.Support.Application.Reports.Tickets
{
    /// <summary>
    /// Handler cho StatisticTicketByDayQuery.
    /// Tính toán các thống kê về ticket trong một ngày cụ thể.
    /// </summary>
    public class StatisticTicketByDayQueryHandler : IQueryHandler<StatisticTicketByDayQuery, StatisticTicketByDayDto>
    {
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        private readonly IMediator _mediator;

        public StatisticTicketByDayQueryHandler(
            ICrmReadRepository<TicketEntity> readRepository,
            IMediator mediator)
        {
            _readRepository = readRepository;
            _mediator = mediator;
        }

        public async Task<StatisticTicketByDayDto> Handle(StatisticTicketByDayQuery request, CancellationToken cancellationToken)
        {
            // Lấy ngày bắt đầu và kết thúc của ngày cần thống kê
            request.Date = request.Date.ToUniversalTime();

            var startOfDay = request.Date.Date;
            var endOfDay = startOfDay.AddDays(1).AddTicks(-1);

            // Lọc tất cả ticket được tạo trong ngày
            var filterBuilder = Builders<TicketEntity>.Filter;
            var filter = filterBuilder.Gte(x => x.CreatedAt, startOfDay) &
                         filterBuilder.Lte(x => x.CreatedAt, endOfDay);

            var ticketProjections = await _readRepository.PagedFilterAsync(
                filter,
                x => new TicketStatisticProjection
                {
                    Status = x.Status,
                    Priority = x.Priority,
                    Source = x.Source,
                    ContactType = x.ContactType,
                    Product = x.Product,
                    Subject = x.Subject,
                    CreatedFrom = x.CreatedFrom,
                    Description = x.Description,
                    TenantId = x.TenantId,
                    TagType = x.TagType,
                },
                pageIndex: 1,
                pageSize: int.MaxValue, // Một page lớn đủ để lấy hết dữ liệu một ngày
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken: cancellationToken);

            var projectionList = ticketProjections.Items.ToList();

            // Tính tổng số ticket
            int totalTickets = ticketProjections.Total;

            // Tính số ticket đã giải quyết (status = Resolved hoặc Closed)
            int closedTickets = projectionList.Count(t =>
                t.Status == TicketStatus.Resolved || t.Status == TicketStatus.Closed);

            // Tính tỷ lệ giải quyết
            int resolutionRate = totalTickets > 0
                ? (int)Math.Round((closedTickets / (double)totalTickets) * 100)
                : 0;

            // Đếm ticket có mức độ ưu tiên Cao (High) và Khẩn cấp (Critical)
            int urgentAndHigh = projectionList.Count(t =>
                t.Priority == TicketPriority.High || t.Priority == TicketPriority.Critical);

            // Đếm ticket từ Zalo và là Giáo viên
            int zaloTeacherCount = projectionList.Count(t =>
                t.Source == TicketSource.Zalo && t.ContactType == ContactType.Teacher);

            // Đếm ticket từ Zalo và là Học sinh
            int zaloStudentCount = projectionList.Count(t =>
                t.Source == TicketSource.Zalo && t.ContactType == ContactType.Student);

            // Đếm ticket từ Hotline và là Giáo viên
            int hotlineTeacherCount = projectionList.Count(t =>
                t.Source == TicketSource.Hotline && t.ContactType == ContactType.Teacher);

            // Đếm ticket từ Hotline và là Học sinh
            int hotlineStudentCount = projectionList.Count(t =>
                t.Source == TicketSource.Hotline && t.ContactType == ContactType.Student);

            // Đếm ticket từ sản phẩm Kỳ thi quốc tế
            int contestCount = projectionList.Count(t => t.Product == TicketProduct.KyThiQuocTe);

            // Đếm ticket từ sản phẩm Onluyen
            int softwareSupportCount = projectionList.Count(t => t.Product == TicketProduct.OnLuyen);

            // Đếm ticket từ sản phẩm Mobifone
            int mobifoneCount = projectionList.Count(t => t.Product == TicketProduct.MBF);

            //Lấy danh sách trường có ticket trong ngày và đếm số lượng ticket của từng trường
            var tenantTicketCounts = projectionList
                .Where(t => !string.IsNullOrEmpty(t.TenantId))
                .GroupBy(t => t.TenantId)
                .Select(g => new
                {
                    TenantId = g.Key,
                    TicketCount = g.Count()
                })
                .OrderByDescending(x => x.TicketCount)
                .ToList();

            var tenantIds = tenantTicketCounts.Select(g => g.TenantId!).ToList();

            var tenantDtos = await _mediator.Send(
                new SharedGetNameTenantByIdsQuery { TenantIds = tenantIds },
                cancellationToken);

            // Lấy top 5 trường có nhiều yêu cầu
            var topTenants = tenantTicketCounts
                .Take(5)
                .Select(tc => new
                {
                    TenantId = tc.TenantId,
                    TenantName = tenantDtos.FirstOrDefault(t => t.Id == tc.TenantId)?.Name,
                    tc.TicketCount
                })
                .Where(x => x.TenantName != null)
                .Select(x => $"{x.TenantName} ({x.TicketCount})")
                .ToList();

            // Đếm ticket từ Crisp VÀ là Giáo viên
            int crispTeacherCount = projectionList.Count(t =>
            t.CreatedFrom == TicketFrom.Crips &&
                t.ContactType == ContactType.Teacher);

            // Đếm ticket từ Crisp VÀ là Học sinh
            int crispStudentCount = projectionList.Count(t =>
                t.CreatedFrom == TicketFrom.Crips &&
                t.ContactType == ContactType.Student);

            var ticketItems = projectionList.Select(t => new StatisticTicketItemDto
            {
                TenantName = tenantDtos.FirstOrDefault(_ => _.Id == t.TenantId)?.Name,
                Subject = t.Subject,
                Description = t.Description,
                Status = t.Status.ToString(),
                Priority = t.Priority.ToString(),
                Source = t.Source.ToString(),
                ContactType = t.ContactType.ToString(),
                TagType = t.TagType,
            }).ToList();

            return new StatisticTicketByDayDto
            {
                Date = request.Date.Date,
                TotalTickets = totalTickets,
                ClosedTickets = closedTickets,
                ResolutionRate = resolutionRate,
                urgentAndHigh = urgentAndHigh,
                ZaloTeacherCount = zaloTeacherCount,
                ZaloStudentCount = zaloStudentCount,
                HotlineTeacherCount = hotlineTeacherCount,
                HotlineStudentCount = hotlineStudentCount,
                ContestCount = contestCount,
                SoftwareSupportCount = softwareSupportCount,
                MobifoneCount = mobifoneCount,
                TopTenant = topTenants,
                CrispTeacherCount = crispTeacherCount,
                CrispStudentCount = crispStudentCount,
                Tickets = ticketItems
            };
        }
    }

    /// <summary>
    /// DTO projection cho thống kê ticket, chỉ lấy các field cần thiết
    /// Giúp tối ưu hóa performance khi query từ MongoDB
    /// </summary>
    public class TicketStatisticProjection
    {
        public TicketStatus Status { get; set; }
        public TicketPriority Priority { get; set; }
        public TicketSource Source { get; set; }
        public ContactType? ContactType { get; set; }
        public TicketProduct Product { get; set; }
        public TicketFrom? CreatedFrom { get; set; }
        public string? Subject { get; set; }
        public string? Description { get; set; }
        public string? TenantId { get; set; }
        public TicketTagType? TagType { get; set; } = TicketTagType.None;
    }
}
