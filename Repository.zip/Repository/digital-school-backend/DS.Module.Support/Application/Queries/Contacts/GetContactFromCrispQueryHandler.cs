using AutoMapper;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Driver;

namespace DS.Module.Support.Application.Queries.Contacts
{
    public class GetContactFromCrispQueryHandler : IQueryHandler<GetContactFromCrispQuery, ContactDto?>
    {
        private readonly ICrmReadRepository<ContactEntity> _contactReadRepository;
        private readonly IMapper _mapper;

        public GetContactFromCrispQueryHandler(ICrmReadRepository<ContactEntity> contactReadRepository, IMapper mapper)
        {
            _contactReadRepository = contactReadRepository;
            _mapper = mapper;
        }

        public async Task<ContactDto?> Handle(GetContactFromCrispQuery request, CancellationToken cancellationToken)
        {
            var f = Builders<ContactEntity>.Filter;

            // --- Priority 1: UserId or UserName (strongest identifiers) ---
            var priorityOneClauses = new List<FilterDefinition<ContactEntity>>();

            if (!string.IsNullOrEmpty(request.UserId))
                priorityOneClauses.Add(f.Eq(x => x.UserId, request.UserId));

            if (!string.IsNullOrEmpty(request.UserName))
                priorityOneClauses.Add(f.Eq(x => x.UserName, request.UserName));

            if (priorityOneClauses.Count > 0)
            {
                var filter = f.Or(priorityOneClauses);
                var contact = await _contactReadRepository.FilterAsync(
                    filter,
                    tenantId: null,
                    includeSoftDeleted: false,
                    cancellationToken: cancellationToken);

                if (contact?.Count > 0)
                    return _mapper.Map<ContactDto>(contact.FirstOrDefault());
            }

            // --- Priority 2: Email / PhoneNumber / PeopleId (ProviderCrispId) ---
            var fallbackClauses = new List<FilterDefinition<ContactEntity>>();

            if (!string.IsNullOrEmpty(request.Email))
                fallbackClauses.Add(f.Eq(x => x.Email, request.Email));

            if (!string.IsNullOrEmpty(request.PhoneNumber))
                fallbackClauses.Add(f.Eq(x => x.PhoneNumber, request.PhoneNumber));

            if (!string.IsNullOrEmpty(request.PeopleId))
                fallbackClauses.Add(f.Eq(x => x.ProviderCrispId, request.PeopleId));

            if (!string.IsNullOrEmpty(request.Nickname))
                fallbackClauses.Add(f.Eq(x => x.Nickname, request.Nickname));

            if (fallbackClauses.Count > 0)
            {
                var filter = f.Or(fallbackClauses);
                var contact = await _contactReadRepository.FilterAsync(
                    filter,
                    tenantId: null,
                    includeSoftDeleted: false,
                    cancellationToken: cancellationToken);

                if (contact?.Count > 0)
                    return _mapper.Map<ContactDto>(contact.FirstOrDefault());
            }

            // No contact found - return null
            return null;
        }
    }
}
