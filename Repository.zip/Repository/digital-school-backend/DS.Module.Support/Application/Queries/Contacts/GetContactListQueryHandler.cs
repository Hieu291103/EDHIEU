using AutoMapper;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Driver;
using System.Text.RegularExpressions;

namespace DS.Module.Support.Application.Queries.Contacts
{
    /// <summary>
    /// Handler cho GetContactListQuery
    /// </summary>
    public class GetContactListQueryHandler : IQueryHandler<GetContactListQuery, PagedResult<ContactListDto>>
    {
        private readonly ICrmReadRepository<ContactEntity> _readRepository;
        private readonly IMapper _mapper;

        public GetContactListQueryHandler(
            ICrmReadRepository<ContactEntity> readRepository,
            IMapper mapper)
        {
            _readRepository = readRepository;
            _mapper = mapper;
        }

        public async Task<PagedResult<ContactListDto>> Handle(GetContactListQuery request, CancellationToken cancellationToken)
        {
            var filterBuilder = Builders<ContactEntity>.Filter;
            var filter = filterBuilder.Empty;

            // Filter by TenantId nếu có
            if (!string.IsNullOrEmpty(request.TenantId))
                filter = filterBuilder.And(filter, filterBuilder.Eq(c => c.TenantId, request.TenantId));

            // Filter by Type nếu có
            if (!string.IsNullOrEmpty(request.Type) && Enum.TryParse<ContactType>(request.Type, out var contactType))
                filter = filterBuilder.And(filter, filterBuilder.Eq(c => c.Type, contactType));

            // Filter by IsVerified nếu có
            if (request.IsVerified.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Eq(c => c.IsVerified, request.IsVerified.Value));

            // Filter by Keyword (tìm kiếm trong FullName, Email, PhoneNumber, Zalo)
            if (!string.IsNullOrEmpty(request.Keyword))
            {
                var escapedKeyword = Regex.Escape(request.Keyword.Trim());
                var regex = new MongoDB.Bson.BsonRegularExpression(escapedKeyword, "i");
                var keywordFilter = filterBuilder.Or(
                    filterBuilder.Regex(c => c.FullName, regex),
                    filterBuilder.Regex(c => c.Nickname, regex),
                    filterBuilder.Regex(c => c.UserName, regex),
                    filterBuilder.Regex(c => c.Email, regex),
                    filterBuilder.Regex(c => c.PhoneNumber, regex),
                    filterBuilder.Regex(c => c.Zalo, regex)
                );
                filter = filterBuilder.And(filter, keywordFilter);
            }

            var pagedResult = await _readRepository.PagedFilterAsync(
                filter,
                request.PageIndex ?? 1,
                request.PageSize ?? 50,
                tenantId: request.TenantId,
                cancellationToken: cancellationToken);

            var dtos = _mapper.Map<List<ContactListDto>>(pagedResult.Items);

            return new PagedResult<ContactListDto>
            {
                Items = dtos,
                Total = pagedResult.Total,
                Page = pagedResult.Page,
                PageSize = pagedResult.PageSize,
                PageIndex = pagedResult.PageIndex
            };
        }
    }
}
