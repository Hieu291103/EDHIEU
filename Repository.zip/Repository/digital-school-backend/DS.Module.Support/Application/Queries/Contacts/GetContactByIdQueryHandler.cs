using AutoMapper;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Queries.Contacts
{
    /// <summary>
    /// Handler cho GetContactByIdQuery
    /// </summary>
    public class GetContactByIdQueryHandler : IQueryHandler<GetContactByIdQuery, ContactDto?>
    {
        private readonly ICrmReadRepository<ContactEntity> _readRepository;
        private readonly IMapper _mapper;

        public GetContactByIdQueryHandler(
            ICrmReadRepository<ContactEntity> readRepository,
            IMapper mapper)
        {
            _readRepository = readRepository;
            _mapper = mapper;
        }

        public async Task<ContactDto?> Handle(GetContactByIdQuery request, CancellationToken cancellationToken)
        {
            var contact = await _readRepository.GetByIdAsync(
                request.ContactId,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (contact == null)
                return null;

            return _mapper.Map<ContactDto>(contact);
        }
    }
}
