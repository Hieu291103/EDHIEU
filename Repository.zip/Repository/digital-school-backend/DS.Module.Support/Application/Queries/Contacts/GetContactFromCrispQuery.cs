using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Support.Application.Queries.Contacts
{
    /// <summary>
    /// Query để tìm contactId từ thông tin Crisp conversation.
    /// Ưu tiên: UserId / UserName → Email / PhoneNumber / PeopleId (ProviderCrispId)
    /// </summary>
    public class GetContactFromCrispQuery : IQuery<ContactDto?>
    {
        /// <summary>
        /// TenantId để filter contact theo tenant (multi-tenant support)
        /// </summary>
        public string? TenantId { get; set; }

        /// <summary>
        /// Internal userId lấy từ crispInfo.Data.Meta.Data["userId"]
        /// </summary>
        public string? UserId { get; set; }

        /// <summary>
        /// UserName lấy từ crispInfo.Data.Meta.Data["UserName"]
        /// </summary>
        public string? UserName { get; set; }

        /// <summary>
        /// Email lấy từ crispInfo.Data.Meta.Email
        /// </summary>
        public string? Email { get; set; }

        /// <summary>
        /// Số điện thoại lấy từ crispInfo.Data.Meta.Phone
        /// </summary>
        public string? PhoneNumber { get; set; }

        /// <summary>
        /// Crisp PeopleId lấy từ crispInfo.Data.PeopleId
        /// </summary>
        public string? PeopleId { get; set; }
        /// <summary>
        /// Crisp PeopleId lấy từ crispInfo.Data.PeopleId
        /// </summary>
        public string? Nickname { get; set; }
    }
}
