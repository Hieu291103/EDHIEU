using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Requests;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Queries.Contacts
{
    /// <summary>
    /// Query để lấy danh sách contact với bộ lọc và phân trang
    /// </summary>
    public class GetContactListQuery : FilterRequest, IQuery<PagedResult<ContactListDto>>
    {
        public string? TenantId { get; set; }
        public string? Type { get; set; }
        public bool? IsVerified { get; set; }
    }
}
