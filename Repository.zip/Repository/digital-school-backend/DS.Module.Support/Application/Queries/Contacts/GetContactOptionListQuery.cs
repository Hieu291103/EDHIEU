using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Requests;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Queries.Contacts
{
    public class GetContactOptionListQuery : FilterRequest, IQuery<PagedResult<ContactListDto>>
    {
        public string? TenantId { get; set; }
    }
}
