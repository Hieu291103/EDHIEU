using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Support.Application.Queries.Contacts
{
    /// <summary>
    /// Query để lấy contact theo ID
    /// </summary>
    public class GetContactByIdQuery : IQuery<ContactDto?>
    {
        public string ContactId { get; set; } = string.Empty;
    }
}
