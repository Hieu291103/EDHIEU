using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Application.Queries.Contacts;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Module.Support.Infrastructure.Common;
using DS.Module.Support.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;

namespace DS.Module.Support.Application.Queries.Tickets
{
    public class GetTicketInfoFromCrispQueryHandler : IQueryHandler<GetTicketInfoFromCrispQuery, TicketCrispDto>
    {
        private readonly ICrmReadRepository<ContactEntity> _readRepository;
        private readonly ICrispService _crispService;
        private readonly IMediator _mediator;

        public GetTicketInfoFromCrispQueryHandler(
            ICrmReadRepository<ContactEntity> readRepository,
            ICrispService crispService,
            IMediator mediator)
        {
            _readRepository = readRepository;
            _crispService = crispService;
            _mediator = mediator;
        }

        public async Task<TicketCrispDto> Handle(GetTicketInfoFromCrispQuery request, CancellationToken cancellationToken)
        {
            var crispInfo = await _crispService.GetConversationAsync(request.SessionId ?? string.Empty, request.WebsiteId ?? string.Empty);
            var result = new TicketCrispDto();
            if (crispInfo?.Data != null)
            {
                // Normalize Crisp values: "" → null to prevent phantom $or matches
                var peopleId = string.IsNullOrEmpty(crispInfo.Data.PeopleId) ? null : crispInfo.Data.PeopleId;
                var email = string.IsNullOrEmpty(crispInfo.Data.Meta?.Email) ? null : crispInfo.Data.Meta?.Email;
                var phone = string.IsNullOrEmpty(crispInfo.Data.Meta?.Phone) ? null : crispInfo.Data.Meta?.Phone;
                var nickname = string.IsNullOrEmpty(crispInfo.Data.Meta?.Nickname) ? null : crispInfo.Data.Meta?.Nickname;

                // Extract UserId & UserName from Crisp meta.data dictionary
                // There're more data in meta.data that unhandled
                var metaData = crispInfo.Data.Meta?.Data;
                var crispUserId = metaData?.TryGetValue("UserId", out var uid) == true ? uid?.ToString() : null;
                var crispUserName = metaData?.TryGetValue("UserName", out var uname) == true ? uname?.ToString() : null;
                var crispEmail = metaData?.TryGetValue("Email", out var cemail) == true ? cemail?.ToString() : null;
                var crispContactType = metaData?.TryGetValue("Role", out var ctype) == true ? ctype?.ToString() : null;

                // Build $or dynamically — only include non-empty values

                var contactQuery = new GetContactFromCrispQuery
                {
                    UserId = crispUserId,
                    UserName = crispUserName,
                    Email = email ?? crispEmail,
                    PhoneNumber = phone,
                    PeopleId = peopleId,
                    Nickname = nickname,
                };

                // Step 3: Resolve contact via MediatR
                var contactResult = await _mediator.Send(contactQuery, cancellationToken);

                result.Contact = contactResult ?? new ContactDto
                {
                    PhoneNumber = phone,
                    Email = email ?? crispEmail ?? string.Empty,
                    ProviderCrispId = peopleId,
                    UserId = crispUserId,
                    UserName = crispUserName,
                };

                result.Contact.Nickname = nickname;
                result.Contact.FullName = nickname ?? crispUserName ?? email ?? phone ?? crispEmail ?? "";

                //Kiêm tra role của crisp để gán ContactType phù hợp, không có là Unknown
                if (crispContactType == "TEACHER")
                    result.Contact.Type = ContactType.Teacher;
                else if (crispContactType == "STUDENT")
                    result.Contact.Type = ContactType.Student;
                else
                    result.Contact.Type = ContactType.Unknown;

                result.ReceiptTime = DateTime.UtcNow;
                result.Status = TicketStatus.New;
                result.Product = TicketProduct.OnLuyen;
                result.TicketNumber = TicketHelper.GenerateTicketCode();
                result.Priority = TicketPriority.Normal;
                result.Subject = "";
                result.Source = TicketSource.WebForm;
                result.CreatedFrom = TicketFrom.Crips;
                result.FlowChatIds = new List<string>();
                result.TagIds = new List<string>();
                result.Assignments = new List<TicketAssignmentDto>();
                result.ExtraData = crispInfo.Data.Meta?.Data?.Count > 0
                                    ? crispInfo.Data.Meta.Data
                                    : new();
                result.Channel = "";
                result.ActivityType = "";
                result.Description = "";
                result.CripsIntegration = new CripsIntegrationInfo()
                {
                    WebsiteId = request.WebsiteId,
                    SessionId = request.SessionId,
                };
            }

            return result;
        }


    }
}

