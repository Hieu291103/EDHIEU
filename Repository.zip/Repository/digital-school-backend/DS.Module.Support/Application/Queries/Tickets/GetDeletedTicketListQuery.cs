using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Queries.Tickets
{
    /// <summary>
    /// Query để lấy danh sách ticket đã xóa mềm
    /// </summary>
    public class GetDeletedTicketListQuery : GetTicketListQuery, IQuery<PagedResult<TicketListDto>>
    {
    }
}
