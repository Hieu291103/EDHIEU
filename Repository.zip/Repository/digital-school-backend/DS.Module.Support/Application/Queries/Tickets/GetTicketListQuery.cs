using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Requests;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Queries.Tickets
{
    /// <summary>
    /// Query để lấy danh sách ticket với bộ lọc và phân trang
    /// </summary>
    public class GetTicketListQuery : FilterRequest, IQuery<PagedResult<TicketListDto>>
    {
        public string? TenantId { get; set; }
        public TicketStatus? Status { get; set; }
        public TicketPriority? Priority { get; set; }
        public TicketProduct? Product { get; set; }
        public TicketSource? Source { get; set; }
        public string? PrimaryAssigneeId { get; set; }
        public string? CreatedBy { get; set; }
        public string? ContactId { get; set; }
        public string? ActivityType { get; set; }
        public TicketFrom? CreatedFrom { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }

        /// <summary>
        /// Chỉ định loại tìm kiếm keyword (mặc định: Ticket)
        /// </summary>
        public KeywordSearchBy KeywordBy { get; set; } = KeywordSearchBy.Ticket;
    }

    /// <summary>
    /// Xác định loại keyword search (Ticket hoặc Contact)
    /// </summary>
    public enum KeywordSearchBy
    {
        /// <summary>
        /// Tìm kiếm theo Ticket (Subject, TicketNumber)
        /// </summary>
        Ticket = 0,

        /// <summary>
        /// Tìm kiếm theo Contact (FullName, Email, PhoneNumber)
        /// </summary>
        Contact = 1
    }
}
