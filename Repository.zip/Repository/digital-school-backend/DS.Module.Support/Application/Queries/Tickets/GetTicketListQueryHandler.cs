using AutoMapper;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using MongoDB.Bson;
using MongoDB.Driver;
using System.Linq.Expressions;
using System.Text.RegularExpressions;

namespace DS.Module.Support.Application.Queries.Tickets
{
    /// <summary>
    /// Handler cho GetTicketListQuery
    /// </summary>
    public class GetTicketListQueryHandler :
        IQueryHandler<GetTicketListQuery, PagedResult<TicketListDto>>,
        IQueryHandler<GetDeletedTicketListQuery, PagedResult<TicketListDto>>
    {
        private readonly ICrmReadRepository<TicketEntity> _ticketRepository;
        private readonly ICrmReadRepository<ContactEntity> _contactRepository;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetTicketListQueryHandler(
            ICrmReadRepository<TicketEntity> ticketRepository,
            ICrmReadRepository<ContactEntity> contactRepository,
            IMediator mediator,
            IMapper mapper)
        {
            _ticketRepository = ticketRepository;
            _contactRepository = contactRepository;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<PagedResult<TicketListDto>> Handle(GetTicketListQuery request, CancellationToken cancellationToken)
        {
            return await HandleInternal(request, deletedOnly: false, cancellationToken);
        }

        public async Task<PagedResult<TicketListDto>> Handle(GetDeletedTicketListQuery request, CancellationToken cancellationToken)
        {
            return await HandleInternal(request, deletedOnly: true, cancellationToken);
        }

        private async Task<PagedResult<TicketListDto>> HandleInternal(GetTicketListQuery request, bool deletedOnly, CancellationToken cancellationToken)
        {
            var filterBuilder = Builders<TicketEntity>.Filter;
            var filter = filterBuilder.Empty;

            // ============ BƯỚC 1: XỬ LÝ KEYWORD TÌM KIẾM ============
            List<string> matchingContactIds = new();

            if (!string.IsNullOrEmpty(request.Keyword))
            {
                if (request.KeywordBy == KeywordSearchBy.Contact)
                {
                    // Tìm Contact theo keyword (FullName, Email, PhoneNumber)
                    var escapedKeyword = Regex.Escape(request.Keyword.Trim());
                    var contactRegex = new BsonRegularExpression(escapedKeyword, "i");
                    var contactFilterBuilder = Builders<ContactEntity>.Filter;
                    var contactFilter = contactFilterBuilder.Or(
                        contactFilterBuilder.Regex(c => c.Nickname, contactRegex),
                        contactFilterBuilder.Regex(c => c.FullName, contactRegex),
                        contactFilterBuilder.Regex(c => c.Email, contactRegex),
                        contactFilterBuilder.Regex(c => c.PhoneNumber, contactRegex),
                        contactFilterBuilder.Regex(c => c.Zalo, contactRegex));

                    var matchingContacts = await _contactRepository.FilterAsync(
                        contactFilter,
                        tenantId: request.TenantId,
                        includeSoftDeleted: false,
                        cancellationToken);

                    matchingContactIds = matchingContacts.Select(c => c.Id).ToList();

                    // Nếu không tìm thấy Contact nào, trả về kết quả rỗng
                    if (matchingContactIds.Count == 0)
                    {
                        return new PagedResult<TicketListDto>
                        {
                            Items = new List<TicketListDto>(),
                            Total = 0,
                            Page = request.PageIndex ?? 1,
                            PageSize = request.PageSize ?? 50,
                            PageIndex = request.PageIndex ?? 1
                        };
                    }

                    // Thêm filter để chỉ lấy ticket của những Contact tìm được
                    filter = filterBuilder.And(filter, filterBuilder.In(t => t.ContactId, matchingContactIds));
                }
                else
                {
                    // Tìm kiếm theo Ticket (Subject, TicketNumber) - mặc định
                    var escapedKeyword = Regex.Escape(request.Keyword.Trim());
                    var regex = new BsonRegularExpression(escapedKeyword, "i");
                    var keywordFilter = filterBuilder.Or(
                        filterBuilder.Regex(t => t.Subject, regex),
                        filterBuilder.Regex(t => t.TicketNumber, regex));
                    filter = filterBuilder.And(filter, keywordFilter);
                }
            }

            if (request.Status.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Eq(t => t.Status, request.Status.Value));

            if (request.Priority.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Eq(t => t.Priority, request.Priority.Value));

            if (request.Product.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Eq(t => t.Product, request.Product.Value));

            if (request.Source.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Eq(t => t.Source, request.Source.Value));

            if (!string.IsNullOrEmpty(request.PrimaryAssigneeId))
                filter = filterBuilder.And(filter, filterBuilder.Eq(t => t.PrimaryAssigneeId, request.PrimaryAssigneeId));

            if (!string.IsNullOrEmpty(request.CreatedBy))
                filter = filterBuilder.And(filter, filterBuilder.Eq(t => t.CreatedBy, request.CreatedBy));

            if (!string.IsNullOrEmpty(request.ContactId))
                filter = filterBuilder.And(filter, filterBuilder.Eq(t => t.ContactId, request.ContactId));

            if (!string.IsNullOrEmpty(request.ActivityType))
                filter = filterBuilder.And(filter, filterBuilder.Eq(t => t.ActivityType, request.ActivityType));

            if (request.CreatedFrom.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Eq(t => t.CreatedFrom, request.CreatedFrom.Value));

            if (request.FromDate.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Gte(t => t.CreatedAt, request.FromDate.Value));

            if (request.ToDate.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Lte(t => t.CreatedAt, request.ToDate.Value));

            if (deletedOnly)
                filter = filterBuilder.And(filter, filterBuilder.Eq(t => t.IsDeleted, true));

            if (!string.IsNullOrEmpty(request.TenantId))
                filter = filterBuilder.And(filter, filterBuilder.Eq(t => t.TenantId, request.TenantId));

            Expression<Func<TicketEntity, TicketListDto>> ticketProjection = t => new TicketListDto
            {
                Id = t.Id,
                TicketNumber = t.TicketNumber,
                Subject = t.Subject,
                Product = t.Product,
                Source = t.Source,
                Status = t.Status,
                Priority = t.Priority,
                Channel = t.Channel,
                ActivityType = t.ActivityType,
                PrimaryAssigneeId = t.PrimaryAssigneeId,
                CommentCount = t.CommentCount,
                ReceiptTime = t.ReceiptTime,
                ExpectedResolutionTime = t.ExpectedResolutionTime,
                ContactId = t.ContactId,
                CreatedFrom = t.CreatedFrom,
                TenantId = t.TenantId,
                CreatedAt = t.CreatedAt,
                CreatedByDisplay = t.CreatedByDisplay,
                TagType = t.TagType,
            };
            if (deletedOnly)
            {
                ticketProjection = t => new TicketListDto
                {
                    Id = t.Id,
                    TicketNumber = t.TicketNumber,
                    Subject = t.Subject,
                    Product = t.Product,
                    Source = t.Source,
                    Status = t.Status,
                    Priority = t.Priority,
                    Channel = t.Channel,
                    ActivityType = t.ActivityType,
                    PrimaryAssigneeId = t.PrimaryAssigneeId,
                    CommentCount = t.CommentCount,
                    ReceiptTime = t.ReceiptTime,
                    ExpectedResolutionTime = t.ExpectedResolutionTime,
                    ContactId = t.ContactId,
                    CreatedFrom = t.CreatedFrom,
                    TenantId = t.TenantId,
                    CreatedAt = t.CreatedAt,
                    CreatedByDisplay = t.CreatedByDisplay,
                    TagType = t.TagType,
                    DeletedAt = t.DeletedAt,
                    DeletedByDisplay = t.DeletedByDisplay,
                };
            }

            //Page the tickets
            var pagedResult = await _ticketRepository.PagedFilterAsync(
                filter,
                ticketProjection,
                request.PageIndex ?? 1,
                request.PageSize ?? 50,
                orderByDescending: true,
                tenantId: null,
                includeSoftDeleted: deletedOnly,
                cancellationToken);

            var dtos = pagedResult.Items.ToList();

            //fetch contacts
            var contactIds = dtos
                .Select(t => t.ContactId)
                .Where(id => !string.IsNullOrEmpty(id))
                .Distinct()
                .ToList();

            if (contactIds.Count > 0)
            {
                var contactFilter = Builders<ContactEntity>.Filter.In(c => c.Id, contactIds!);
                var contacts = await _contactRepository.FilterAsync(
                    contactFilter,
                    tenantId: null,
                    includeSoftDeleted: false,
                    cancellationToken);

                var contactMap = contacts
                    .ToDictionary(c => c.Id, c => _mapper.Map<ContactDto>(c));

                foreach (var dto in dtos)
                {
                    if (dto.ContactId is not null && contactMap.TryGetValue(dto.ContactId, out var summary))
                        dto.Contact = summary;
                }
            }

            return new PagedResult<TicketListDto>
            {
                Items = dtos,
                Total = pagedResult.Total,
                Page = pagedResult.Page,
                PageSize = pagedResult.PageSize,
                PageIndex = pagedResult.PageIndex
            };
        }
    }
}
