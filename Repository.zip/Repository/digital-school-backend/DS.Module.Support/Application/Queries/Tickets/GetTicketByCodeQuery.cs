using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Support.Application.Queries.Tickets
{
    /// <summary>
    /// Query để lấy ticket theo Code (mã ticket)
    /// </summary>
    public class GetTicketByCodeQuery : IQuery<TicketDetailDto?>
    {
        /// <summary>
        /// Mã ticket (code)
        /// </summary>
        public required string Code { get; set; }
    }
}
