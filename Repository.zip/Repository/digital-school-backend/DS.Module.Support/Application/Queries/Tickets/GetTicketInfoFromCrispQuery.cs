using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Support.Application.Queries.Tickets
{
    public class GetTicketInfoFromCrispQuery : IQuery<TicketCrispDto>
    {
        public string? WebsiteId { get; set; }
        public string? SessionId { get; set; }
    }
}
