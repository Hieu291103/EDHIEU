using AutoMapper;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Application.Queries.Contacts;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using MongoDB.Driver;

namespace DS.Module.Support.Application.Queries.Tickets
{
    public class GetTicketHistoryFromCrispQueryHandler : IQueryHandler<GetTicketHistoryFromCrispQuery, TicketHistoryCrispDto>
    {
        private readonly ICrispService _crispService;
        private readonly ICrmReadRepository<TicketEntity> _ticketReadRepository;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetTicketHistoryFromCrispQueryHandler(
            ICrispService crispService,
            ICrmReadRepository<TicketEntity> ticketReadRepository,
            IMediator mediator,
            IMapper mapper)
        {
            _crispService = crispService;
            _ticketReadRepository = ticketReadRepository;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<TicketHistoryCrispDto> Handle(GetTicketHistoryFromCrispQuery request, CancellationToken cancellationToken)
        {
            var result = new TicketHistoryCrispDto
            {
                WebsiteId = request.WebsiteId,
                SessionId = request.SessionId
            };

            // Step 1: Call Crisp API to get conversation metadata
            var crispInfo = await _crispService.GetConversationAsync(
                request.SessionId ?? string.Empty,
                request.WebsiteId,
                cancellationToken);

            if (crispInfo?.Data == null)
                return result;

            var peopleId = string.IsNullOrEmpty(crispInfo.Data.PeopleId) ? null : crispInfo.Data.PeopleId;
            var email = string.IsNullOrEmpty(crispInfo.Data.Meta?.Email) ? null : crispInfo.Data.Meta?.Email;
            var phone = string.IsNullOrEmpty(crispInfo.Data.Meta?.Phone) ? null : crispInfo.Data.Meta?.Phone;
            var nickname = string.IsNullOrEmpty(crispInfo.Data.Meta?.Nickname) ? null : crispInfo.Data.Meta?.Nickname;

            var metaData = crispInfo.Data.Meta?.Data;
            var crispUserId = metaData?.TryGetValue("UserId", out var uid) == true ? uid?.ToString() : null;
            var crispUserName = metaData?.TryGetValue("UserName", out var uname) == true ? uname?.ToString() : null;
            var crispEmail = metaData?.TryGetValue("Email", out var cemail) == true ? cemail?.ToString() : null;

            // Step 2: Extract identity fields from Crisp response

            var contactQuery = new GetContactFromCrispQuery
            {
                UserId = crispUserId,
                UserName = crispUserName,
                Email = email ?? crispEmail,
                PhoneNumber = phone,
                PeopleId = peopleId,
                Nickname = nickname,
            };

            // Step 3: Resolve contact via MediatR
            var contactResult = await _mediator.Send(contactQuery, cancellationToken);

            // Guard: no contact or empty ContactId → return empty list
            if (string.IsNullOrEmpty(contactResult?.Id))
                return result;

            // Step 4: Query tickets by ContactId
            var filter = Builders<TicketEntity>.Filter.Eq(t => t.ContactId, contactResult.Id);

            var tickets = await _ticketReadRepository.FilterAsync(filter, orderByDescending: true, cancellationToken: cancellationToken);

            // Step 5: Map to TicketCrispListDto via AutoMapper
            result.Tickets = _mapper.Map<List<TicketCrispDto>>(tickets);
            return result;
        }
    }
}
