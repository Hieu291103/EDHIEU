using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Support.Application.Queries.Tickets
{
    /// <summary>
    /// Query để lấy ticket theo ID
    /// </summary>
    public class GetTicketByIdQuery : IQuery<TicketDetailDto?>
    {
        public string TicketId { get; set; } = string.Empty;
    }
}
