using AutoMapper;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Application.Queries.Contacts;
using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using MongoDB.Driver;

namespace DS.Module.Support.Application.Queries.Tickets
{
    /// <summary>
    /// Handler cho GetTicketByCodeQuery.
    /// Trả về TicketDetailDto gồm TicketDto và ContactDto liên quan (nếu có).
    /// </summary>
    public class GetTicketByCodeQueryHandler : IQueryHandler<GetTicketByCodeQuery, TicketDetailDto?>
    {
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;

        public GetTicketByCodeQueryHandler(
            ICrmReadRepository<TicketEntity> readRepository,
            IMapper mapper,
            IMediator mediator)
        {
            _readRepository = readRepository;
            _mapper = mapper;
            _mediator = mediator;
        }

        public async Task<TicketDetailDto?> Handle(GetTicketByCodeQuery request, CancellationToken cancellationToken)
        {
            // Tìm ticket theo TicketNumber
            var filterBuilder = Builders<TicketEntity>.Filter;
            var filter = filterBuilder.Eq(x => x.TicketNumber, request.Code.Trim());

            var tickets = await _readRepository.FilterAsync(
                filter,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken: cancellationToken);

            var ticket = tickets.FirstOrDefault();
            if (ticket == null)
                return null;

            ticket.Attachments = ticket.Attachments?.Where(_ => !_.IsDeleted).ToList();

            var ticketDto = _mapper.Map<TicketDto>(ticket);

            // Fetch linked contact if ContactId is present
            ContactDto? contactDto = null;
            if (!string.IsNullOrEmpty(ticket.ContactId))
            {
                contactDto = await _mediator.Send(
                    new GetContactByIdQuery
                    {
                        ContactId = ticket.ContactId,
                    },
                    cancellationToken);
            }

            return new TicketDetailDto
            {
                Ticket = ticketDto,
                Contact = contactDto
            };
        }
    }
}
