using AutoMapper;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Queries.TicketTags
{
    /// <summary>
    /// Handler cho GetTicketTagByIdQuery
    /// </summary>
    public class GetTicketTagByIdQueryHandler : IQueryHandler<GetTicketTagByIdQuery, TicketTagDto?>
    {
        private readonly ICrmReadRepository<TicketTagEntity> _readRepository;
        private readonly IMapper _mapper;

        public GetTicketTagByIdQueryHandler(
            ICrmReadRepository<TicketTagEntity> readRepository,
            IMapper mapper)
        {
            _readRepository = readRepository;
            _mapper = mapper;
        }

        public async Task<TicketTagDto?> Handle(GetTicketTagByIdQuery request, CancellationToken cancellationToken)
        {
            var ticketTag = await _readRepository.GetByIdAsync(
                request.TicketTagId,
                cancellationToken: cancellationToken);

            if (ticketTag == null)
                return null;

            return _mapper.Map<TicketTagDto>(ticketTag);
        }
    }
}
