using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Requests;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Queries.TicketTags
{
    /// <summary>
    /// Query để lấy danh sách TicketTag với bộ lọc và phân trang
    /// </summary>
    public class GetTicketTagListQuery : FilterRequest, IQuery<PagedResult<TicketTagListDto>>
    {
        public string? TagType { get; set; }
        public string? TagProduct { get; set; }
    }
}
