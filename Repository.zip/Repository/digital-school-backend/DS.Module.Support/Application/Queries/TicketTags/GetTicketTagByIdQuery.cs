using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Support.Application.Queries.TicketTags
{
    /// <summary>
    /// Query để lấy TicketTag theo ID
    /// </summary>
    public class GetTicketTagByIdQuery : IQuery<TicketTagDto?>
    {
        public string TicketTagId { get; set; } = string.Empty;
    }
}
