using AutoMapper;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Driver;

namespace DS.Module.Support.Application.Queries.TicketTags
{
    /// <summary>
    /// Handler cho GetTicketTagListQuery
    /// </summary>
    public class GetTicketTagListQueryHandler : IQueryHandler<GetTicketTagListQuery, PagedResult<TicketTagListDto>>
    {
        private readonly ICrmReadRepository<TicketTagEntity> _readRepository;
        private readonly IMapper _mapper;

        public GetTicketTagListQueryHandler(
            ICrmReadRepository<TicketTagEntity> readRepository,
            IMapper mapper)
        {
            _readRepository = readRepository;
            _mapper = mapper;
        }

        public async Task<PagedResult<TicketTagListDto>> Handle(GetTicketTagListQuery request, CancellationToken cancellationToken)
        {
            var filterBuilder = Builders<TicketTagEntity>.Filter;
            var filter = filterBuilder.Empty;

            if (!string.IsNullOrEmpty(request.TagType) && Enum.TryParse<TicketTagType>(request.TagType, out var tagType))
                filter = filterBuilder.And(filter, filterBuilder.Eq(t => t.TagType, tagType));

            if (!string.IsNullOrEmpty(request.TagProduct) && Enum.TryParse<TicketProduct>(request.TagProduct, out var tagProduct))
                filter = filterBuilder.And(filter, filterBuilder.Eq(t => t.TagProduct, tagProduct));

            if (!string.IsNullOrEmpty(request.Keyword))
            {
                var regex = new MongoDB.Bson.BsonRegularExpression(request.Keyword.Trim(), "i");
                filter = filterBuilder.And(filter, filterBuilder.Regex(t => t.Name, regex));
            }

            var pagedResult = await _readRepository.PagedFilterAsync(
                filter,
                request.PageIndex ?? 1,
                request.PageSize ?? 50,
                null,
                false,
                cancellationToken);

            var dtos = _mapper.Map<List<TicketTagListDto>>(pagedResult.Items);

            return new PagedResult<TicketTagListDto>
            {
                Items = dtos,
                Total = pagedResult.Total,
                Page = pagedResult.Page,
                PageSize = pagedResult.PageSize,
                PageIndex = pagedResult.PageIndex
            };
        }
    }
}
