using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Support.Application.Queries.TicketActivities
{
    /// <summary>
    /// Query để lấy danh sách hoạt động (activities) của một ticket
    /// </summary>
    public class GetTicketActivitiesQuery : IQuery<List<TicketActivityDto>>
    {
        /// <summary>
        /// ID của ticket
        /// </summary>
        public string TicketId { get; set; } = string.Empty;
    }
}
