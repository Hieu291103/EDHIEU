using AutoMapper;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Driver;

namespace DS.Module.Support.Application.Queries.TicketActivities
{
    /// <summary>
    /// Handler cho GetTicketActivitiesQuery
    /// </summary>
    public class GetTicketActivitiesQueryHandler : IQueryHandler<GetTicketActivitiesQuery, List<TicketActivityDto>>
    {
        private readonly ICrmReadRepository<TicketActivityEntity> _repository;
        private readonly IMapper _mapper;

        public GetTicketActivitiesQueryHandler(
            ICrmReadRepository<TicketActivityEntity> repository,
            IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<List<TicketActivityDto>> Handle(GetTicketActivitiesQuery request, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(request.TicketId))
                return new();

            var filterBuilder = Builders<TicketActivityEntity>.Filter;
            var filter = filterBuilder.Eq(a => a.TicketId, request.TicketId);

            var activities = await _repository.FilterAsync(
                filter,
                cancellationToken: cancellationToken);

            var activityDtos = activities
                .OrderByDescending(a => a.CreatedAt)
                .ToList()
                .ConvertAll(a => _mapper.Map<TicketActivityDto>(a));

            return activityDtos;
        }
    }
}
