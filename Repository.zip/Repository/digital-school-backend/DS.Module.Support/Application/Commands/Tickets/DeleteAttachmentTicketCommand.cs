using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Dtos;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Command để xóa attachment khỏi ticket
    /// </summary>
    public class DeleteAttachmentTicketCommand : ICommand<Result>
    {
        public string TicketId { get; set; } = string.Empty;
        public List<S3AttachmentDto> Attachments { get; set; } = new();
        public string? Notes { get; set; }
    }
}
