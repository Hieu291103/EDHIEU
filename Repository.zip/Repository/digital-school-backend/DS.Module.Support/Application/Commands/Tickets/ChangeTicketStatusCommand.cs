using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Command để thay đổi trạng thái ticket
    /// </summary>
    public class ChangeTicketStatusCommand : ICommand<Result>
    {
        public string TicketId { get; set; } = string.Empty;
        public TicketStatus NewStatus { get; set; }
        public string? Notes { get; set; }
        public string? ChangedByUserId { get; set; }
        public string? ChangedByUserDisplay { get; set; }
        public string? TenantId { get; set; }
    }
}
