using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Handler cho ResolveTicketCommand
    /// </summary>
    public class ResolveTicketCommandHandler : ICommandHandler<ResolveTicketCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        protected readonly ICurrentUser _currentUser;

        public ResolveTicketCommandHandler(
            ICrmWriteRepository<TicketEntity> writeRepository,
            ICrmReadRepository<TicketEntity> readRepository,
            ICurrentUser currentUser)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _currentUser = currentUser;
        }

        public async Task<Result> Handle(ResolveTicketCommand request, CancellationToken cancellationToken)
        {
            var ticket = await _readRepository.GetByIdAsync(
                request.TicketId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (ticket == null)
                throw new DSException("TicketNotFound");

            if (ticket.Status == TicketStatus.Resolved || ticket.Status == TicketStatus.Closed)
                throw new DSException("TicketAlreadyResolved");

            var oldStatus = ticket.Status.ToString();
            ticket.Status = TicketStatus.Resolved;
            ticket.ResolvedAt = DateTime.UtcNow;
            ticket.ResolvedByUserId = _currentUser.UserId;
            ticket.ResolvedByUserDisplay = _currentUser.DisplayName;
            ticket.ResolutionNotes = request.ResolutionNotes;

            ticket.AuditHistory ??= new();
            ticket.AuditHistory.AddEntry(TicketAuditEntryBuilder.CreateStatusChange(
                oldStatus: oldStatus,
                newStatus: TicketStatus.Resolved.ToString(),
                userId: _currentUser.UserId,
                userDisplay: _currentUser.DisplayName,
                userType: _currentUser.UserType,
                notes: request.ResolutionNotes));

            await _writeRepository.UpdateAsync(ticket, tenantId: request.TenantId, cancellationToken);

            return Result.Success();
        }
    }
}
