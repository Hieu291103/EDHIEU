using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Handler cho DeleteAttachmentTicketCommand
    /// </summary>
    public class DeleteAttachmentTicketCommandHandler : ICommandHandler<DeleteAttachmentTicketCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        private readonly ICurrentUser _currentUser;

        public DeleteAttachmentTicketCommandHandler(
            ICrmWriteRepository<TicketEntity> writeRepository,
            ICrmReadRepository<TicketEntity> readRepository,
            ICurrentUser currentUser)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _currentUser = currentUser;
        }

        public async Task<Result> Handle(DeleteAttachmentTicketCommand request, CancellationToken cancellationToken)
        {
            var ticket = await _readRepository.GetByIdAsync(
                request.TicketId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (ticket == null)
                throw new DSException("TicketNotFound");

            if (ticket.Attachments == null || ticket.Attachments.Count == 0)
                throw new DSException("AttachmentNotFound");

            foreach (var requestAttachment in request.Attachments)
            {
                var attachment = ticket.Attachments.FirstOrDefault(x =>
                    !x.IsDeleted &&
                    (( !string.IsNullOrWhiteSpace(requestAttachment.Id) && x.Id == requestAttachment.Id) ||
                     (!string.IsNullOrWhiteSpace(requestAttachment.S3Key) &&
                      !string.IsNullOrWhiteSpace(x.S3Key) &&
                      x.S3Key.Equals(requestAttachment.S3Key, StringComparison.OrdinalIgnoreCase))));

                if (attachment == null)
                    throw DSException.WithParam("AttachmentNotFound", requestAttachment.Id ?? requestAttachment.S3Key ?? string.Empty);

                attachment.IsDeleted = true;
                attachment.DeletedAt = DateTime.UtcNow;

                ticket.AuditHistory ??= new();
                ticket.AuditHistory.AddEntry(TicketAuditEntryBuilder.CreateCustomEntry(
                    actionType: "AttachmentRemoved",
                    description: $"Xóa tệp đính kèm: {attachment.FileName}",
                    userId: _currentUser.UserId,
                    userDisplay: _currentUser.DisplayName,
                    userType: _currentUser.UserType,
                    propertyName: "Attachments",
                    oldValue: attachment.Id,
                    notes: request.Notes));
            }

            await _writeRepository.UpdateAsync(ticket, tenantId: null, cancellationToken);

            return Result.Success();
        }
    }
}
