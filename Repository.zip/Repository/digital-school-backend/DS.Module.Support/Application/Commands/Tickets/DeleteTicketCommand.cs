using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Command để xóa ticket (soft delete)
    /// </summary>
    public class DeleteTicketCommand : ICommand<Result>
    {
        public string TicketId { get; set; } = string.Empty;
        public string? TenantId { get; set; }
        public string? Notes { get; set; } = string.Empty;
    }
}
