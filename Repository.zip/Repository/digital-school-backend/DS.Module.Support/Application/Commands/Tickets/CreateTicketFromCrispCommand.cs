using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Command để tạo ticket hỗ trợ mới từ Crisp CRM.
    /// <para>
    /// - <see cref="CripsIntegration"/> và <see cref="Contact"/> là bắt buộc
    ///   vì mọi ticket Crisp đều phải có context phiên làm việc và thông tin khách hàng.
    /// - <see cref="CreatedFrom"/> luôn được gán cứng là <see cref="TicketFrom.Crips"/> trong handler.
    /// - <see cref="Status"/> không được expose — handler luôn gán <see cref="TicketStatus.New"/>.
    /// </para>
    /// </summary>
    public class CreateTicketFromCrispCommand : ICommand<Result>
    {
        // ── Ticket fields ─────────────────────────────────────────
        public required string TicketNumber { get; set; }
        public required string Subject { get; set; }
        public string? Description { get; set; }
        public string? Channel { get; set; }

        public TicketProduct Product { get; set; } = TicketProduct.None;
        public TicketSource Source { get; set; } = TicketSource.WebForm;
        public TicketPriority Priority { get; set; } = TicketPriority.Normal;
        public TicketStatus Status { get; set; } = TicketStatus.New;
        public TicketTagType? TagType { get; set; }

        public string? PrimaryAssigneeId { get; set; }
        public List<TicketAssignmentDto>? Assignments { get; set; }
        public DateTime? ExpectedResolutionTime { get; set; }
        public DateTime? ReceiptTime { get; set; }

        public List<string>? TagIds { get; set; }
        public List<string>? FlowChatIds { get; set; }

        public string? InternalNotes { get; set; }
        public string? ParentTicketCode { get; set; }
        public Dictionary<string, object>? ExtraData { get; set; }

        // ── Crisp-specific ────────────────────────────────────────
        public required CripsIntegrationInfo CripsIntegration { get; set; }

        // ── Contact ───────────────────────────────────────────────
        /// <summary>
        /// Thông tin khách hàng gửi từ client. Nếu <see cref="ContactDto.Id"/> trống,
        /// handler sẽ tự động tạo mới contact trong DB trước khi tạo ticket.
        /// </summary>
        public required ContactDto Contact { get; set; }

        // ── Tenant ────────────────────────────────────────────────
        public string? TenantId { get; set; }
    }
}
