using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Command để đánh dấu ticket đã được giải quyết
    /// </summary>
    public class ResolveTicketCommand : ICommand<Result>
    {
        public string TicketId { get; set; } = string.Empty;
        public string? ResolutionNotes { get; set; }
        public string? ResolvedByUserId { get; set; }
        public string? ResolvedByUserDisplay { get; set; }
        public string? TenantId { get; set; }
    }
}
