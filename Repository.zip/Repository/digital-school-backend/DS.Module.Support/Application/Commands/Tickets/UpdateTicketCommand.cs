using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Command để cập nhật thông tin ticket
    /// </summary>
    public class UpdateTicketCommand : ICommand<Result>
    {
        public string TicketId { get; set; } = string.Empty;
        public required TicketDto Ticket { get; set; }
        public ContactDto? Contact { get; set; }
    }
}
