using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Command để khôi phục ticket đã xóa mềm
    /// </summary>
    public class RestoreTicketCommand : ICommand<Result>
    {
        public string TicketId { get; set; } = string.Empty;
        public string? TenantId { get; set; }
    }
}
