using DS.Module.Support.Application.Common;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Infrastructure.Common;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Handler cho CreateTicketCommand
    /// </summary>
    public class CreateTicketCommandHandler : ICommandHandler<CreateTicketCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketEntity> _ticketReadRepository;
        private readonly ICrmReadRepository<ContactEntity> _contactReadRepository;
        private readonly ICrmWriteRepository<ContactEntity> _contactWriteRepository;
        protected readonly ICurrentUser _currentUser;
        private readonly IMediator _mediator;

        public CreateTicketCommandHandler(
            ICrmWriteRepository<TicketEntity> writeRepository,
            ICrmReadRepository<TicketEntity> ticketReadRepository,
            ICrmReadRepository<ContactEntity> contactReadRepository,
            ICrmWriteRepository<ContactEntity> contactWriteRepository,
            ICurrentUser currentUser,
            IMediator mediator)
        {
            _writeRepository = writeRepository;
            _ticketReadRepository = ticketReadRepository;
            _contactReadRepository = contactReadRepository;
            _contactWriteRepository = contactWriteRepository;
            _currentUser = currentUser;
            _mediator = mediator;
        }

        public async Task<Result> Handle(CreateTicketCommand request, CancellationToken cancellationToken)
        {
            // Step 1: Upsert contact
            var contactId = await _mediator.Send(
                new Contacts.UpdateAndCreateContactCommand { Contact = request.Contact },
                cancellationToken);

            // Step 2: Build and persist ticket
            var ticket = new TicketEntity
            {
                TicketNumber = TicketHelper.GenerateTicketCode(),
                Subject = request.Ticket.Subject,
                Description = request.Ticket.Description,
                Channel = request.Ticket.Channel,
                Product = request.Ticket.Product,
                Source = request.Ticket.Source,
                Priority = request.Ticket.Priority,
                Status = request.Ticket.Status,
                TagType = request.Ticket.TagType,
                PrimaryAssigneeId = request.Ticket.PrimaryAssigneeId,
                ReceiptTime = request.Ticket.ReceiptTime,
                ExpectedResolutionTime = request.Ticket.ExpectedResolutionTime,
                TagIds = request.Ticket.TagIds ?? new(),
                FlowChatIds = request.Ticket.FlowChatIds ?? new(),
                //Attachments = request.Ticket.Attachments ?? new(),
                InternalNotes = request.Ticket.InternalNotes,
                ParentTicketCode = request.Ticket.ParentTicketCode,
                RelatedTicketCodes = request.Ticket.RelatedTicketCodes ?? new(),
                RelatedTaskCodes = request.Ticket.RelatedTaskCodes ?? new(),
                ContactId = contactId,
                ContactType = request.Contact.Type,
                CreatedFrom = request.Ticket.CreatedFrom,
                TenantId = request.Ticket.TenantId,
                ExtraData = request.Ticket.ExtraData?.Count > 0
                    ? request.Ticket.ExtraData.ToBsonDocumentSafe()
                    : new(),
                CripsIntegration = request.Ticket.CripsIntegration,
            };

            //Kiểm tra Assignments
            if (request.Ticket.Assignments.Count == 0 && _currentUser.UserId != null)
            {
                //Thêm người tạo ticket là người được giao
                ticket.PrimaryAssigneeId = _currentUser.UserId;
                ticket.Assignments = new List<TicketAssignment>()
                {
                    new TicketAssignment
                    {
                        UserId = _currentUser.UserId,
                        UserDisplay = _currentUser.DisplayName,
                        AssignedAt = DateTime.UtcNow
                    }
                };
            }
            else
            {
                ticket.Assignments = new List<TicketAssignment>();
                //kiểm tra và gán lại tên cho chính xác
                foreach (var assignment in request.Ticket.Assignments)
                {
                    if (!string.IsNullOrEmpty(assignment.UserId))
                    {
                        ticket.Assignments.Add(new TicketAssignment
                        {
                            UserId = assignment.UserId,
                            UserDisplay = assignment.UserDisplay,
                            AssignedAt = DateTime.UtcNow,
                            AssignerDisplay = assignment.AssignerDisplay,
                            Notes = assignment.Notes,
                        });
                    }
                }
                ticket.PrimaryAssigneeId ??= ticket.Assignments.FirstOrDefault()?.UserId;
            }

            ticket.AuditHistory!.AddEntry(TicketAuditEntryBuilder.CreateTicketCreated(
                userId: _currentUser.UserId,
                userDisplay: _currentUser.DisplayName,
                userType: _currentUser.UserType));

            // Pre-check: if this TicketNumber is already taken, regenerate before inserting
            var existing = await _ticketReadRepository.FilterAsync(
                t => t.TicketNumber == ticket.TicketNumber,
                cancellationToken: cancellationToken);

            if (existing.Any())
                ticket.TicketNumber = TicketHelper.GenerateTicketCode();

            await _writeRepository.InsertAsync(ticket, cancellationToken);

            await ContactTicketCountHelper.RefreshAsync(
                contactId,
                _contactReadRepository,
                _contactWriteRepository,
                _ticketReadRepository,
                cancellationToken);

            return Result.Success();
        }
    }
}
