using DS.Module.Support.Application.Common;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Handler cho UpdateTicketCommand
    /// </summary>
    public class UpdateTicketCommandHandler : ICommandHandler<UpdateTicketCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        private readonly ICrmReadRepository<ContactEntity> _contactReadRepository;
        private readonly ICrmWriteRepository<ContactEntity> _contactWriteRepository;
        protected readonly ICurrentUser _currentUser;
        private readonly IMediator _mediator;

        public UpdateTicketCommandHandler(
            ICrmWriteRepository<TicketEntity> writeRepository,
            ICrmReadRepository<TicketEntity> readRepository,
            ICrmReadRepository<ContactEntity> contactReadRepository,
            ICrmWriteRepository<ContactEntity> contactWriteRepository,
            ICurrentUser currentUser,
            IMediator mediator)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _contactReadRepository = contactReadRepository;
            _contactWriteRepository = contactWriteRepository;
            _currentUser = currentUser;
            _mediator = mediator;
        }

        public async Task<Result> Handle(UpdateTicketCommand request, CancellationToken cancellationToken)
        {
            var ticket = await _readRepository.GetByIdAsync(
                request.TicketId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (ticket == null)
                throw new DSException("TicketNotFound");

            if (ticket.Status == TicketStatus.Closed || ticket.Status == TicketStatus.Rejected)
                throw new DSException("TicketAlreadyClosed");

            var originalContactId = ticket.ContactId;

            if (request.Contact != null)
            {
                // If the client provided a Contact block, upsert it.
                var newContactId = await _mediator.Send(
                    new Contacts.UpdateAndCreateContactCommand { Contact = request.Contact },
                    cancellationToken);
                ticket.ContactId = newContactId;
                ticket.ContactType = request.Contact.Type;
            }

            var entries = new List<TicketAuditEntry>();

            if (request.Ticket.Subject.IsNotNull() && request.Ticket.Subject != ticket.Subject)
            {
                var old = ticket.Subject;
                ticket.Subject = request.Ticket.Subject;
                entries.Add(TicketAuditEntryBuilder.CreatePropertyUpdate(
                    "Subject", old, request.Ticket.Subject,
                    _currentUser.UserId, _currentUser.DisplayName, _currentUser.UserType));
            }

            if (request.Ticket.Description.IsNotNull() && request.Ticket.Description != ticket.Description)
            {
                var old = ticket.Description;
                ticket.Description = request.Ticket.Description;
                entries.Add(TicketAuditEntryBuilder.CreatePropertyUpdate(
                    "Description", old, request.Ticket.Description,
                    _currentUser.UserId, _currentUser.DisplayName, _currentUser.UserType));
            }

            if (request.Ticket.Channel.IsNotNull())
                ticket.Channel = request.Ticket.Channel;

            if (request.Ticket.Product != default)
                ticket.Product = request.Ticket.Product;

            if (request.Ticket.Source != default)
                ticket.Source = request.Ticket.Source;

            if (request.Ticket.Priority != default)
                ticket.Priority = request.Ticket.Priority;

            if (request.Ticket.TagType.HasValue && request.Ticket.TagType != default)
                ticket.TagType = request.Ticket.TagType;

            if (!string.IsNullOrEmpty(request.Ticket.PrimaryAssigneeId))
                ticket.PrimaryAssigneeId = request.Ticket.PrimaryAssigneeId;

            if (request.Ticket.ReceiptTime.HasValue)
                ticket.ReceiptTime = request.Ticket.ReceiptTime;

            if (request.Ticket.ExpectedResolutionTime.HasValue)
                ticket.ExpectedResolutionTime = request.Ticket.ExpectedResolutionTime;

            if (request.Ticket.TagIds != null)
                ticket.TagIds = request.Ticket.TagIds;

            if (request.Ticket.FlowChatIds != null)
                ticket.FlowChatIds = request.Ticket.FlowChatIds;

            //if (request.Ticket.Attachments != null)
            //    ticket.Attachments = request.Ticket.Attachments;

            if (request.Ticket.InternalNotes != null)
                ticket.InternalNotes = request.Ticket.InternalNotes;

            if (request.Ticket.ParentTicketCode != null)
                ticket.ParentTicketCode = request.Ticket.ParentTicketCode;

            if (request.Ticket.RelatedTicketCodes != null)
                ticket.RelatedTicketCodes = request.Ticket.RelatedTicketCodes;

            if (request.Ticket.RelatedTaskCodes != null)
                ticket.RelatedTaskCodes = request.Ticket.RelatedTaskCodes;

            if (request.Ticket.ContactId != null)
                ticket.ContactId = request.Ticket.ContactId;

            if (request.Ticket.ExtraData != null)
                ticket.ExtraData = request.Ticket.ExtraData.ToBsonDocumentSafe();

            if (request.Ticket.CripsIntegration != null)
                ticket.CripsIntegration = request.Ticket.CripsIntegration;

            if (entries.Count > 0)
            {
                ticket.AuditHistory ??= new();
                foreach (var entry in entries)
                    ticket.AuditHistory.AddEntry(entry);
            }

            await _writeRepository.UpdateAsync(ticket, tenantId: request.Ticket.TenantId, cancellationToken);

            await ContactTicketCountHelper.RefreshAsync(
                ticket.ContactId,
                _contactReadRepository,
                _contactWriteRepository,
                _readRepository,
                cancellationToken);

            if (!string.Equals(originalContactId, ticket.ContactId, StringComparison.Ordinal))
            {
                await ContactTicketCountHelper.RefreshAsync(
                    originalContactId,
                    _contactReadRepository,
                    _contactWriteRepository,
                    _readRepository,
                    cancellationToken);
            }

            return Result.Success();
        }
    }
}
