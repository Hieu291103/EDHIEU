using DS.Module.Support.Application.Commands.Contacts;
using DS.Module.Support.Application.Common;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Module.Support.Infrastructure.Common;
using DS.Module.Support.Infrastructure.Configuration;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.Core.Infrastructure.Services;
using DS.Shared.Core.Infrastructure.Services.Mail;
using DS.Shared.Core.Infrastructure.Services.Mail.Models;
using MediatR;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Job handler: lấy mail chưa đọc từ hộp thư receipt, tạo ticket, đánh dấu mail đã xử lý.
    /// <para>
    /// Flow:
    /// 1. Fetch unseen emails từ IMAP (MailReceipt).
    /// 2. Mail hệ thống (noreply, google, ...) → chỉ mark Seen, không tạo ticket, không tag.
    /// 3. Với mail hợp lệ: upsert contact → tạo TicketEntity → insert DB.
    /// 4. Gán Seen + Tag (Processed / Processed-Dev tuỳ môi trường) trong 1 IMAP connection.
    /// </para>
    /// </summary>
    public class JobCreateTicketFromMailReceiptCommandHandler(
        IMailService mailService,
        IOptions<CrmSettings> crmOptions,
        IHostEnvironment env,
        ICrmWriteRepository<TicketEntity> ticketWriteRepository,
        ICrmReadRepository<TicketEntity> ticketReadRepository,
        ICrmReadRepository<ContactEntity> contactReadRepository,
        ICrmWriteRepository<ContactEntity> contactWriteRepository,
        IMediator mediator,
        ILogger<JobCreateTicketFromMailReceiptCommandHandler> logger)
        : ICommandHandler<JobCreateTicketFromMailReceiptCommand, bool>
    {
        public async Task<bool> Handle(
            JobCreateTicketFromMailReceiptCommand request,
            CancellationToken cancellationToken)
        {
            var ticketSettings = crmOptions.Value.Ticket;

            if (string.IsNullOrWhiteSpace(ticketSettings.MailReceipt) ||
                string.IsNullOrWhiteSpace(ticketSettings.MailReceiptPassword))
            {
                logger.LogWarning("CRM MailReceipt chưa được cấu hình, bỏ qua job.");
                return false;
            }

            var account = new MailAccountConfig
            {
                Email = ticketSettings.MailReceipt,
                AppPassword = ticketSettings.MailReceiptPassword
            };

            var mails = await mailService.FetchAsync(account, new MailFetchOptions
            {
                Folder = "INBOX",
                UnseenOnly = true,
                MaxCount = 50,
                MarkAsRead = false
            }, cancellationToken);

            if (mails.Count == 0)
            {
                return true;
            }

            var processedTag = MailTags.ForEnvironment(env);
            var successUids = new List<uint>();
            var skipUids = new List<uint>();

            foreach (var mail in mails)
            {
                // Mail hệ thống: chỉ mark Seen, không tạo ticket, không gán tag
                if (IsSystemMail(mail.From))
                {
                    skipUids.Add(mail.Uid);
                    continue;
                }

                try
                {
                    // Step 1: Upsert contact từ thông tin người gửi
                    var contactId = await mediator.Send(new UpdateAndCreateContactCommand
                    {
                        Contact = new ContactDto
                        {
                            FullName = string.IsNullOrWhiteSpace(mail.FromName) ? mail.From : mail.FromName,
                            Email = mail.From,
                            Type = ContactType.Unknown
                        }
                    }, cancellationToken);

                    // Step 2: Tạo ticket từ nội dung email
                    // Note: mail.HtmlBody được sanitize bởi MailService.SanitizeHtml() trước khi trả về
                    // → An toàn lưu vào database (XSS protection đã áp dụng)
                    var ticket = new TicketEntity
                    {
                        TicketNumber = TicketHelper.GenerateTicketCode(),
                        Subject = mail.From + " | " + mail.Subject,
                        Description = mail.TextBody,
                        DescriptionHtml = mail.HtmlBody,  // ← Already sanitized by MailService
                        IsHtmlDescription = !string.IsNullOrWhiteSpace(mail.HtmlBody),
                        Source = TicketSource.Email,
                        Status = TicketStatus.New,
                        Priority = TicketPriority.Normal,
                        CreatedFrom = TicketFrom.MailService,
                        ReceiptTime = mail.Date.UtcDateTime,
                        ContactId = contactId,
                        ContactType = ContactType.Unknown,
                        ExtraData = new(),
                        Product = ResolveProductByRecipient(mail.To.FirstOrDefault() ?? string.Empty),
                        ReceiptEmailId = mail.MessageId,
                    };

                    ticket.AuditHistory!.AddEntry(TicketAuditEntryBuilder.CreateTicketCreated(
                        userId: SystemCurrentUser.SystemUserId,
                        userDisplay: SystemCurrentUser.SystemName,
                        userType: SystemCurrentUser.SystemType,
                        description: $"Ticket tự động tạo từ email | From: {mail.From} | To: {mail.To.FirstOrDefault()}"));

                    // Step 3: Đảm bảo TicketNumber không trùng
                    var existing = await ticketReadRepository.FilterAsync(
                        t => t.TicketNumber == ticket.TicketNumber,
                        cancellationToken: cancellationToken);

                    if (existing.Any())
                        ticket.TicketNumber = TicketHelper.GenerateTicketCode();

                    await ticketWriteRepository.InsertAsync(ticket, cancellationToken);

                    // Step 4: Cập nhật số lượng ticket của contact
                    await ContactTicketCountHelper.RefreshAsync(
                        contactId,
                        contactReadRepository,
                        contactWriteRepository,
                        ticketReadRepository,
                        cancellationToken);

                    successUids.Add(mail.Uid);

                }
                catch (Exception ex)
                {
                    // Không đánh dấu seen → job sẽ retry lần chạy tiếp theo
                    logger.LogError(ex,
                        "Lỗi xử lý mail uid={Uid} | From: {From} | Subject: {Subject}",
                        mail.Uid, mail.From, mail.Subject);
                }
            }

            // Mark Seen các mail hệ thống — không gán tag
            if (skipUids.Count > 0)
                await mailService.MarkAsSeenAsync(account, skipUids, cancellationToken: cancellationToken);

            // Mark Seen + Tag các mail đã tạo ticket thành công — 1 IMAP connection
            if (successUids.Count > 0)
                await mailService.MarkAsProcessedAsync(account, successUids, processedTag, cancellationToken: cancellationToken);

            return true;
        }

        /// <summary>
        /// Xác định TicketProduct dựa theo địa chỉ email nhận (MailReceipt).
        /// </summary>
        private static TicketProduct ResolveProductByRecipient(string mailReceipt)
        {
            var address = mailReceipt.Trim().ToLowerInvariant();

            return address switch
            {
                "hotro@onluyen.vn" => TicketProduct.OnLuyen,
                "veo@onluyen.vn"
                    or "bebras@onluyen.vn"
                    or "amc@onluyen.vn" => TicketProduct.KyThiQuocTe,
                _ => TicketProduct.OnLuyen
            };
        }

        /// <summary>
        /// Xác định mail hệ thống cần bỏ qua (không tạo ticket).
        /// Các pattern: noreply, no-reply, no.reply, google, mailer-daemon, donotreply, ...
        /// </summary>
        private static bool IsSystemMail(string fromAddress)
        {
            if (string.IsNullOrWhiteSpace(fromAddress)) return true;

            var address = fromAddress.ToLowerInvariant();

            return _systemMailPatterns.Any(pattern => address.Contains(pattern));
        }

        private static readonly string[] _systemMailPatterns =
        [
            "noreply",
            "no-reply",
            "no.reply",
            "donotreply",
            "do-not-reply",
            "do.not.reply",
            "google",
            "mailer-daemon",
            "postmaster",
            "bounce",
            "notification",
            "notifications",
            "automated",
            "auto-confirm",
        ];
    }
}
