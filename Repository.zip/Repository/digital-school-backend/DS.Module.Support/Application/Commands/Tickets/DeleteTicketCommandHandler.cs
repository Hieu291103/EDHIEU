using DS.Module.Support.Application.Common;
using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Handler cho DeleteTicketCommand
    /// </summary>
    public class DeleteTicketCommandHandler : ICommandHandler<DeleteTicketCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        private readonly ICrmReadRepository<ContactEntity> _contactReadRepository;
        private readonly ICrmWriteRepository<ContactEntity> _contactWriteRepository;

        public DeleteTicketCommandHandler(
            ICrmWriteRepository<TicketEntity> writeRepository,
            ICrmReadRepository<TicketEntity> readRepository,
            ICrmReadRepository<ContactEntity> contactReadRepository,
            ICrmWriteRepository<ContactEntity> contactWriteRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _contactReadRepository = contactReadRepository;
            _contactWriteRepository = contactWriteRepository;
        }

        public async Task<Result> Handle(DeleteTicketCommand request, CancellationToken cancellationToken)
        {
            var ticket = await _readRepository.GetByIdAsync(
                request.TicketId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (ticket == null)
                throw new DSException("TicketNotFound");

            var contactId = ticket.ContactId;

            await _writeRepository.SoftDeleteAsync(
                request.TicketId,
                tenantId: null,
                cancellationToken: cancellationToken);

            //cập nhật notes
            if (!string.IsNullOrEmpty(request.Notes))
            {
                ticket.InternalNotes = ticket.InternalNotes + "\n-" + request.Notes;
                await _writeRepository.UpdateAsync(ticket);
            }

            await ContactTicketCountHelper.RefreshAsync(
                contactId,
                _contactReadRepository,
                _contactWriteRepository,
                _readRepository,
                cancellationToken);

            return Result.Success();
        }
    }
}
