using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Command để tạo ticket hỗ trợ mới nội bộ
    /// </summary>
    public class CreateTicketCommand : ICommand<Result>
    {
        public required TicketDto Ticket { get; set; }
        public required ContactDto Contact { get; set; }
    }
}
