using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Command để xóa người xử lý khỏi ticket
    /// </summary>
    public class DeleteAssignTicketCommand : ICommand<Result>
    {
        public string TicketId { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;
        public string? Notes { get; set; }
    }
}
