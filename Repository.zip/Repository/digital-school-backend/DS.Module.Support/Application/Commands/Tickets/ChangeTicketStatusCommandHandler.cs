using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Handler cho ChangeTicketStatusCommand
    /// </summary>
    public class ChangeTicketStatusCommandHandler : ICommandHandler<ChangeTicketStatusCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        protected readonly ICurrentUser _currentUser;

        public ChangeTicketStatusCommandHandler(
            ICrmWriteRepository<TicketEntity> writeRepository,
            ICrmReadRepository<TicketEntity> readRepository,
            ICurrentUser currentUser)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _currentUser = currentUser;
        }

        public async Task<Result> Handle(ChangeTicketStatusCommand request, CancellationToken cancellationToken)
        {
            var ticket = await _readRepository.GetByIdAsync(
                request.TicketId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (ticket == null)
                throw new DSException("TicketNotFound");

            if (ticket.Status == request.NewStatus)
                throw new DSException("TicketStatusUnchanged");

            var oldStatus = ticket.Status.ToString();
            ticket.Status = request.NewStatus;

            ticket.AuditHistory ??= new();
            ticket.AuditHistory.AddEntry(TicketAuditEntryBuilder.CreateStatusChange(
                oldStatus: oldStatus,
                newStatus: request.NewStatus.ToString(),
                userId: _currentUser.UserId,
                userDisplay: _currentUser.DisplayName,
                userType: _currentUser.UserType,
                notes: request.Notes));

            await _writeRepository.UpdateAsync(ticket, tenantId: request.TenantId, cancellationToken);

            return Result.Success();
        }
    }
}
