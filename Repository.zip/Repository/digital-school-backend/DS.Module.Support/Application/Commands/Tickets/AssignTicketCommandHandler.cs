using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Queries.Users;
using MediatR;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Handler cho AssignTicketCommand
    /// </summary>
    public class AssignTicketCommandHandler : ICommandHandler<AssignTicketCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        protected readonly ICurrentUser _currentUser;
        protected readonly IMediator _mediator;

        public AssignTicketCommandHandler(
            ICrmWriteRepository<TicketEntity> writeRepository,
            ICrmReadRepository<TicketEntity> readRepository,
            ICurrentUser currentUser,
            IMediator mediator)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _currentUser = currentUser;
            _mediator = mediator;
        }

        public async Task<Result> Handle(AssignTicketCommand request, CancellationToken cancellationToken)
        {
            var ticket = await _readRepository.GetByIdAsync(
                request.TicketId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (ticket == null)
                throw new DSException("TicketNotFound");

            ticket.Assignments ??= new();

            var existing = ticket.Assignments.FirstOrDefault(a => a.UserId == request.UserId);
            if (existing != null)
                throw DSException.WithParam("UserAlreadyAssigned", request.UserId);

            var userAssignments = await _mediator.Send(new SharedGetUserByIdQuery
            {
                UserId = request.UserId,
            }, cancellationToken);

            if (userAssignments == null)
                throw DSException.WithParam("UserAssignedNotFound", request.AssignerDisplay ?? request.UserId);

            var assignment = new TicketAssignment
            {
                UserId = request.UserId,
                UserDisplay = userAssignments.DisplayName,
                AssignerDisplay = _currentUser.DisplayName,
                Notes = request.Notes,
                AssignedAt = DateTime.UtcNow
            };

            ticket.Assignments.Add(assignment);

            if (request.SetAsPrimary || ticket.PrimaryAssigneeId == null)
                ticket.PrimaryAssigneeId = request.UserId;

            ticket.AuditHistory ??= new();
            ticket.AuditHistory.AddEntry(TicketAuditEntryBuilder.CreateAssignmentAdded(
                assigneeId: request.UserId,
                assigneeName: request.UserDisplay ?? request.UserId,
                userId: _currentUser.UserId,
                userDisplay: _currentUser.DisplayName,
                userType: _currentUser.UserType,
                notes: request.Notes));

            await _writeRepository.UpdateAsync(ticket, tenantId: request.TenantId, cancellationToken);

            return Result.Success();
        }
    }
}
