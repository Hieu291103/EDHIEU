using DS.Module.Support.Application.Commands.Contacts;
using DS.Module.Support.Application.Common;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Module.Support.Infrastructure.Common;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Queries.Tenants;
using MediatR;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Handler cho <see cref="CreateTicketFromCrispCommand"/>.
    /// <para>
    /// Flow:
    /// 1. Gửi <see cref="UpdateAndCreateContactFromCrispCommand"/> qua MediatR để upsert contact.
    /// 2. Tạo TicketEntity với số ticket từ request (pre-check duplicate).
    /// </para>
    /// </summary>
    public class CreateTicketFromCrispCommandHandler : ICommandHandler<CreateTicketFromCrispCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketEntity> _ticketWriteRepository;
        private readonly ICrmReadRepository<TicketEntity> _ticketReadRepository;
        private readonly ICrmReadRepository<ContactEntity> _contactReadRepository;
        private readonly ICrmWriteRepository<ContactEntity> _contactWriteRepository;
        private readonly ICurrentUser _currentUser;
        private readonly IMediator _mediator;

        public CreateTicketFromCrispCommandHandler(
            ICrmWriteRepository<TicketEntity> ticketWriteRepository,
            ICrmReadRepository<TicketEntity> ticketReadRepository,
            ICrmReadRepository<ContactEntity> contactReadRepository,
            ICrmWriteRepository<ContactEntity> contactWriteRepository,
            ICurrentUser currentUser,
            IMediator mediator)
        {
            _ticketWriteRepository = ticketWriteRepository;
            _ticketReadRepository = ticketReadRepository;
            _contactReadRepository = contactReadRepository;
            _contactWriteRepository = contactWriteRepository;
            _currentUser = currentUser;
            _mediator = mediator;
        }

        public async Task<Result> Handle(CreateTicketFromCrispCommand request, CancellationToken cancellationToken)
        {


            //Check dữ liệu extra có SchoolId hay không, nếu có thì gán vào ticket
            if (request.ExtraData != null && request.ExtraData.ContainsKey("School"))
            {
                var schoolId = request.ExtraData["School"]?.ToString();
                if (!string.IsNullOrEmpty(schoolId) && int.TryParse(schoolId, out var schoolIdInt))
                {
                    var tenant = await _mediator.Send(new SharedGetTenantBySchoolIdQuery { SchoolId = schoolIdInt }, cancellationToken);
                    if (tenant != null)
                    {
                        request.TenantId = tenant.Id;
                        request.Contact.TenantId = tenant.Id;
                        request.Contact.SchoolId = schoolIdInt;
                        request.Contact.OrganizationName = tenant.Name;
                    }
                }
            }
            request.Contact.ExtraData = request.ExtraData;

            //cập nhật thêm thông tin contact vào extra data của ticket để tiện cho việc sử dụng sau này
            if (request?.ExtraData?.Count > 0)
            {
                request.Contact.UserId = request.Contact.UserId ?? (request.ExtraData.TryGetValue("UserId", out var userId) ? userId?.ToString() : null);
                request.Contact.UserName = request.Contact.UserName ?? (request.ExtraData.TryGetValue("UserName", out var userName) ? userName?.ToString() : null);
                request.Contact.Email = request.Contact.Email ?? (request.ExtraData.TryGetValue("Email", out var email) ? email?.ToString() : null);
            }

            // Step 1: Resolve (or create) the contact via dedicated command
            var contactCmd = new UpdateAndCreateContactFromCrispCommand
            {
                Contact = request!.Contact
            };
            var resolvedContact = await _mediator.Send(contactCmd, cancellationToken);
            var resolvedContactId = resolvedContact?.ContactId;

            // Step 2: Build and persist the ticket
            var ticket = new TicketEntity
            {
                TicketNumber = request.TicketNumber,
                Subject = request.Subject,
                Description = request.Description,
                Channel = request.Channel,
                Product = request.Product,
                Source = request.Source,
                Priority = request.Priority,
                Status = request.Status,
                TagType = request.TagType,
                CreatedFrom = TicketFrom.Crips,
                PrimaryAssigneeId = request.PrimaryAssigneeId,
                TagIds = request.TagIds ?? new(),
                FlowChatIds = request.FlowChatIds ?? new(),
                InternalNotes = request.InternalNotes,
                ParentTicketCode = request.ParentTicketCode,
                ExpectedResolutionTime = request.ExpectedResolutionTime,
                ReceiptTime = request.ReceiptTime ?? DateTime.UtcNow,
                ContactId = resolvedContactId,
                ContactType = request.Contact.Type,
                TenantId = request.TenantId,
                CripsIntegration = request.CripsIntegration,
                ExtraData = request.ExtraData?.Count > 0
                    ? request.ExtraData.ToBsonDocumentSafe()
                    : new()
            };
            //Thêm người tạo ticket là người được giao
            if (!string.IsNullOrEmpty(_currentUser.UserId))
            {
                ticket.PrimaryAssigneeId = _currentUser.UserId;
                ticket.Assignments = new List<TicketAssignment>()
                {
                    new TicketAssignment
                    {
                        UserId = _currentUser.UserId,
                        UserDisplay = _currentUser.DisplayName,
                        AssignedAt = DateTime.UtcNow
                    }
                };
            }

            ticket.AuditHistory!.AddEntry(TicketAuditEntryBuilder.CreateTicketCreated(
                userId: _currentUser.UserId,
                userDisplay: _currentUser.DisplayName,
                userType: _currentUser.UserType,
                description: "Ticket đã được tạo từ Crisp CRM"));

            // Pre-check: if this TicketNumber is already taken, regenerate before inserting
            var existing = await _ticketReadRepository.FilterAsync(
                t => t.TicketNumber == ticket.TicketNumber,
                cancellationToken: cancellationToken);

            if (existing.Any())
                ticket.TicketNumber = TicketHelper.GenerateTicketCode();

            await _ticketWriteRepository.InsertAsync(ticket, cancellationToken);

            await ContactTicketCountHelper.RefreshAsync(
                resolvedContactId,
                _contactReadRepository,
                _contactWriteRepository,
                _ticketReadRepository,
                cancellationToken);

            return Result.Success();
        }
    }
}
