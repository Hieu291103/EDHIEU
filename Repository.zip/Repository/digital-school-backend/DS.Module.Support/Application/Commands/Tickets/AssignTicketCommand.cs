using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Command để gán người xử lý cho ticket
    /// </summary>
    public class AssignTicketCommand : ICommand<Result>
    {
        public string TicketId { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;
        public string? UserDisplay { get; set; }
        public string? AssignerDisplay { get; set; }
        public string? Notes { get; set; }

        /// <summary>
        /// Đặt người này làm primary assignee
        /// </summary>
        public bool SetAsPrimary { get; set; } = false;

        public string? TenantId { get; set; }
    }
}
