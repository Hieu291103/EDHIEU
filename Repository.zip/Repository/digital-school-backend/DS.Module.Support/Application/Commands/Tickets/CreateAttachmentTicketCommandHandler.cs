using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Bson;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Handler cho CreateAttachmentTicketCommand
    /// </summary>
    public class CreateAttachmentTicketCommandHandler : ICommandHandler<CreateAttachmentTicketCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        private readonly ICurrentUser _currentUser;

        public CreateAttachmentTicketCommandHandler(
            ICrmWriteRepository<TicketEntity> writeRepository,
            ICrmReadRepository<TicketEntity> readRepository,
            ICurrentUser currentUser)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _currentUser = currentUser;
        }

        public async Task<Result> Handle(CreateAttachmentTicketCommand request, CancellationToken cancellationToken)
        {
            var ticket = await _readRepository.GetByIdAsync(
                request.TicketId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (ticket == null)
                throw new DSException("TicketNotFound");

            ticket.Attachments ??= new();

            foreach (var requestAttachment in request.Attachments)
            {
                var attachment = new S3AttachmentInfo
                {
                    FileName = requestAttachment.FileName ?? string.Empty,
                    S3Url = requestAttachment.S3Url ?? string.Empty,
                    S3Key = requestAttachment.S3Key ?? string.Empty,
                    BucketName = requestAttachment.BucketName ?? string.Empty,
                    ContentType = requestAttachment.ContentType,
                    FileSize = requestAttachment.FileSize,
                    ETag = requestAttachment.ETag,
                    Description = requestAttachment.Description,
                    FileType = requestAttachment.FileType,
                    IsMainAttachment = requestAttachment.IsMainAttachment
                };

                var hasDuplicate = ticket.Attachments.Any(x =>
                    !x.IsDeleted &&
                    (!string.IsNullOrWhiteSpace(x.S3Key) &&
                     !string.IsNullOrWhiteSpace(attachment.S3Key) &&
                     x.S3Key.Equals(attachment.S3Key, StringComparison.OrdinalIgnoreCase)));

                if (hasDuplicate)
                    throw DSException.WithParam("AttachmentAlreadyExists", attachment.S3Key ?? attachment.FileName);

                attachment.Id ??= ObjectId.GenerateNewId().ToString();
                attachment.UploadedAt ??= DateTime.UtcNow;
                attachment.UploadedByUserId ??= _currentUser.UserId;
                attachment.UploadedByUserDisplay ??= _currentUser.DisplayName;
                attachment.IsDeleted = false;
                attachment.DeletedAt = null;

                ticket.Attachments.Add(attachment);

                ticket.AuditHistory ??= new();
                ticket.AuditHistory.AddEntry(TicketAuditEntryBuilder.CreateCustomEntry(
                    actionType: "AttachmentAdded",
                    description: $"Thêm tệp đính kèm: {attachment.FileName}",
                    userId: _currentUser.UserId,
                    userDisplay: _currentUser.DisplayName,
                    userType: _currentUser.UserType,
                    propertyName: "Attachments",
                    newValue: attachment.Id,
                    notes: request.Notes));
            }

            await _writeRepository.UpdateAsync(ticket, tenantId: null, cancellationToken);

            return Result.Success();
        }
    }
}
