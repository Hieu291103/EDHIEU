using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Command để xóa hoàn toàn ticket
    /// </summary>
    public class HardDeleteTicketCommand : ICommand<Result>
    {
        public string TicketId { get; set; } = string.Empty;
        public string? TenantId { get; set; }
    }
}
