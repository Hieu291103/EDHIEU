using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Handler cho DeleteAssignTicketCommand
    /// </summary>
    public class DeleteAssignTicketCommandHandler : ICommandHandler<DeleteAssignTicketCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        protected readonly ICurrentUser _currentUser;

        public DeleteAssignTicketCommandHandler(
            ICrmWriteRepository<TicketEntity> writeRepository,
            ICrmReadRepository<TicketEntity> readRepository,
            ICurrentUser currentUser)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _currentUser = currentUser;
        }

        public async Task<Result> Handle(DeleteAssignTicketCommand request, CancellationToken cancellationToken)
        {
            // Lấy thông tin ticket theo TicketId trong phạm vi tenant hiện tại
            var ticket = await _readRepository.GetByIdAsync(
                request.TicketId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            // Không tìm thấy ticket thì dừng xử lý
            if (ticket == null)
                throw new DSException("TicketNotFound");

            // Ticket chưa có danh sách phân công thì không thể xóa assignee
            if (ticket.Assignments == null || ticket.Assignments.Count == 0)
                throw DSException.WithParam("UserAssignmentNotFound", request.UserId);

            // Tìm đúng assignee cần xóa theo UserId
            var assignmentToRemove = ticket.Assignments.FirstOrDefault(x => x.UserId == request.UserId);
            if (assignmentToRemove == null)
                throw DSException.WithParam("UserAssignmentNotFound", request.UserId);

            // Không cho phép xóa nếu đây là assignee cuối cùng
            if (ticket.Assignments.Count == 1)
                throw new DSException("CannotRemoveLastAssignment");

            // Lưu lại thông tin primary hiện tại để phục vụ logic chuyển primary và audit
            var oldPrimaryAssigneeId = ticket.PrimaryAssigneeId;
            var oldPrimaryAssigneeName = assignmentToRemove.UserDisplay ?? assignmentToRemove.UserId;

            // Thực hiện xóa assignee khỏi danh sách phân công
            ticket.Assignments.Remove(assignmentToRemove);

            // Nếu người bị xóa đang là primary thì chuyển primary sang người còn lại
            if (oldPrimaryAssigneeId == request.UserId)
            {
                var newPrimary = ticket.Assignments.FirstOrDefault();
                ticket.PrimaryAssigneeId = newPrimary?.UserId;

                // Ghi audit cho thay đổi người xử lý chính
                ticket.AuditHistory ??= new();
                ticket.AuditHistory.AddEntry(TicketAuditEntryBuilder.CreatePrimaryAssignmentChange(
                    oldAssigneeId: oldPrimaryAssigneeId,
                    newAssigneeId: newPrimary?.UserId,
                    oldAssigneeName: oldPrimaryAssigneeName,
                    newAssigneeName: newPrimary?.UserDisplay ?? newPrimary?.UserId,
                    userId: _currentUser.UserId,
                    userDisplay: _currentUser.DisplayName,
                    userType: _currentUser.UserType));
            }

            // Ghi audit cho hành động xóa assignee
            ticket.AuditHistory ??= new();
            ticket.AuditHistory.AddEntry(TicketAuditEntryBuilder.CreateAssignmentRemoved(
                assigneeId: assignmentToRemove.UserId,
                assigneeName: assignmentToRemove.UserDisplay ?? assignmentToRemove.UserId,
                userId: _currentUser.UserId,
                userDisplay: _currentUser.DisplayName,
                userType: _currentUser.UserType,
                notes: request.Notes));

            // Cập nhật lại ticket sau khi thay đổi assignments/primary/audit
            await _writeRepository.UpdateAsync(ticket, tenantId: null, cancellationToken);

            // Trả kết quả thành công
            return Result.Success();
        }
    }
}
