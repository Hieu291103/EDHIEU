using DS.Module.Support.Application.Common;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Handler cho ChangeTicketCommand
    /// Cập nhật các trường của ticket có giá trị khác null (partial update)
    /// </summary>
    public class ChangeTicketCommandHandler : ICommandHandler<ChangeTicketCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        private readonly ICrmReadRepository<ContactEntity> _contactReadRepository;
        private readonly ICrmWriteRepository<ContactEntity> _contactWriteRepository;
        protected readonly ICurrentUser _currentUser;

        public ChangeTicketCommandHandler(
            ICrmWriteRepository<TicketEntity> writeRepository,
            ICrmReadRepository<TicketEntity> readRepository,
            ICrmReadRepository<ContactEntity> contactReadRepository,
            ICrmWriteRepository<ContactEntity> contactWriteRepository,
            ICurrentUser currentUser)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _contactReadRepository = contactReadRepository;
            _contactWriteRepository = contactWriteRepository;
            _currentUser = currentUser;
        }

        public async Task<Result> Handle(ChangeTicketCommand request, CancellationToken cancellationToken)
        {
            // Lấy ticket hiện tại từ database
            var ticket = await _readRepository.GetByIdAsync(
                request.Id,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (ticket == null)
                throw new DSException("TicketNotFound");

            // Không cho phép cập nhật ticket đã đóng hoặc từ chối
            if (ticket.Status == TicketStatus.Closed || ticket.Status == TicketStatus.Rejected)
                throw new DSException("TicketAlreadyClosed");

            var entries = new List<TicketAuditEntry>();
            var originalContactId = ticket.ContactId;

            // Cập nhật Subject nếu có giá trị
            if (request.Subject.IsNotNullOrEmpty() && request.Subject != ticket.Subject)
            {
                var old = ticket.Subject;
                ticket.Subject = request.Subject;
                entries.Add(TicketAuditEntryBuilder.CreatePropertyUpdate(
                    "Subject", old, request.Subject,
                    _currentUser.UserId, _currentUser.DisplayName, _currentUser.UserType));
            }

            // Cập nhật Description nếu có giá trị
            if (request.Description.IsNotNullOrEmpty() && request.Description != ticket.Description)
            {
                var old = ticket.Description;
                ticket.Description = request.Description;
                entries.Add(TicketAuditEntryBuilder.CreatePropertyUpdate(
                    "Description", old, request.Description,
                    _currentUser.UserId, _currentUser.DisplayName, _currentUser.UserType));
            }

            // Cập nhật Status nếu có giá trị khác
            if (request.Status != default && request.Status != ticket.Status)
            {
                var oldStatus = ticket.Status.ToString();
                var newStatus = request.Status.ToString();
                ticket.Status = request.Status;
                entries.Add(TicketAuditEntryBuilder.CreateStatusChange(
                    oldStatus, newStatus,
                    _currentUser.UserId, _currentUser.DisplayName, _currentUser.UserType));
            }

            // Cập nhật Priority nếu có giá trị khác
            if (request.Priority != default && request.Priority != ticket.Priority)
            {
                var oldPriority = ticket.Priority.ToString();
                var newPriority = request.Priority.ToString();
                ticket.Priority = request.Priority;
                entries.Add(TicketAuditEntryBuilder.CreatePriorityChange(
                    oldPriority, newPriority,
                    _currentUser.UserId, _currentUser.DisplayName, _currentUser.UserType));
            }

            // Cập nhật Channel nếu có giá trị
            if (request.Channel.IsNotNullOrEmpty() && request.Channel != ticket.Channel)
                ticket.Channel = request.Channel;

            // Cập nhật Product nếu có giá trị khác
            if (request.Product != default && request.Product != ticket.Product)
                ticket.Product = request.Product;

            // Cập nhật Source nếu có giá trị khác
            if (request.Source != default && request.Source != ticket.Source)
                ticket.Source = request.Source;

            // Cập nhật TagType nếu có giá trị khác
            if (request.TagType.HasValue && request.TagType != ticket.TagType)
                ticket.TagType = request.TagType;

            // Cập nhật PrimaryAssigneeId nếu có giá trị
            if (request.PrimaryAssigneeId.IsNotNullOrEmpty() && request.PrimaryAssigneeId != ticket.PrimaryAssigneeId)
            {
                var oldAssigneeId = ticket.PrimaryAssigneeId;
                ticket.PrimaryAssigneeId = request.PrimaryAssigneeId;
                entries.Add(TicketAuditEntryBuilder.CreatePrimaryAssignmentChange(
                    oldAssigneeId, request.PrimaryAssigneeId,
                    null, null,
                    _currentUser.UserId, _currentUser.DisplayName, _currentUser.UserType));
            }

            // Cập nhật ExpectedResolutionTime nếu có giá trị
            if (request.ExpectedResolutionTime.HasValue && request.ExpectedResolutionTime != ticket.ExpectedResolutionTime)
                ticket.ExpectedResolutionTime = request.ExpectedResolutionTime;

            // Cập nhật ResolutionNotes nếu có giá trị
            if (request.ResolutionNotes.IsNotNullOrEmpty() && request.ResolutionNotes != ticket.ResolutionNotes)
                ticket.ResolutionNotes = request.ResolutionNotes;

            // Cập nhật SatisfactionRating nếu có giá trị
            if (request.SatisfactionRating.HasValue && request.SatisfactionRating != ticket.SatisfactionRating)
                ticket.SatisfactionRating = request.SatisfactionRating;

            // Cập nhật CustomerFeedback nếu có giá trị
            if (request.CustomerFeedback.IsNotNullOrEmpty() && request.CustomerFeedback != ticket.CustomerFeedback)
                ticket.CustomerFeedback = request.CustomerFeedback;

            // Cập nhật TagIds nếu có giá trị
            if (request.TagIds != null && request.TagIds.Count > 0)
                ticket.TagIds = request.TagIds;

            // Cập nhật FlowChatIds nếu có giá trị
            if (request.FlowChatIds != null && request.FlowChatIds.Count > 0)
                ticket.FlowChatIds = request.FlowChatIds;

            // Cập nhật InternalNotes nếu có giá trị
            if (request.InternalNotes.IsNotNullOrEmpty())
                ticket.InternalNotes = request.InternalNotes;

            // Cập nhật ParentTicketCode nếu có giá trị
            if (request.ParentTicketCode.IsNotNullOrEmpty())
                ticket.ParentTicketCode = request.ParentTicketCode;

            // Cập nhật RelatedTicketCodes nếu có giá trị
            if (request.RelatedTicketCodes != null && request.RelatedTicketCodes.Count > 0)
                ticket.RelatedTicketCodes = request.RelatedTicketCodes;

            // Cập nhật RelatedTaskCode nếu có giá trị
            if (request.RelatedTaskCodes != null && request.RelatedTaskCodes.Count > 0)
                ticket.RelatedTaskCodes = request.RelatedTaskCodes;

            // Cập nhật ContactId nếu có giá trị
            if (request.ContactId.IsNotNullOrEmpty() && request.ContactId != ticket.ContactId)
            {
                var contact = await _contactReadRepository.GetByIdAsync(
                    request.ContactId,
                    tenantId: null,
                    includeSoftDeleted: false,
                    cancellationToken);
                ticket.ContactId = request.ContactId;
                ticket.ContactType = contact?.Type;
            }

            // Cập nhật ExtraData nếu có giá trị
            if (request.ExtraData != null)
                ticket.ExtraData = request.ExtraData.ToBsonDocumentSafe();

            // Cập nhật CripsIntegration nếu có giá trị
            if (request.CripsIntegration != null)
                ticket.CripsIntegration = request.CripsIntegration;

            // Thêm audit entries vào ticket
            if (entries.Count > 0)
            {
                ticket.AuditHistory ??= new();
                foreach (var entry in entries)
                    ticket.AuditHistory.AddEntry(entry);
            }

            // Lưu ticket vào database
            await _writeRepository.UpdateAsync(ticket, tenantId: request.TenantId, cancellationToken);

            // Cập nhật count ticket cho contact nếu contact thay đổi
            if (!string.Equals(originalContactId, ticket.ContactId, StringComparison.Ordinal))
            {
                await ContactTicketCountHelper.RefreshAsync(
                    ticket.ContactId,
                    _contactReadRepository,
                    _contactWriteRepository,
                    _readRepository,
                    cancellationToken);

                await ContactTicketCountHelper.RefreshAsync(
                    originalContactId,
                    _contactReadRepository,
                    _contactWriteRepository,
                    _readRepository,
                    cancellationToken);
            }

            return Result.Success();
        }
    }
}
