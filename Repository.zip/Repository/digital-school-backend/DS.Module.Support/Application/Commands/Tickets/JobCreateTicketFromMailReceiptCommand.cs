using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Support.Application.Commands.Tickets
{
    public class JobCreateTicketFromMailReceiptCommand : ICommand<bool>
    {
    }
}
