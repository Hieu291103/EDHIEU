using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Application.Common;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.Tickets
{
    /// <summary>
    /// Handler cho RestoreTicketCommand
    /// </summary>
    public class RestoreTicketCommandHandler : ICommandHandler<RestoreTicketCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketEntity> _readRepository;
        private readonly ICrmReadRepository<ContactEntity> _contactReadRepository;
        private readonly ICrmWriteRepository<ContactEntity> _contactWriteRepository;

        public RestoreTicketCommandHandler(
            ICrmWriteRepository<TicketEntity> writeRepository,
            ICrmReadRepository<TicketEntity> readRepository,
            ICrmReadRepository<ContactEntity> contactReadRepository,
            ICrmWriteRepository<ContactEntity> contactWriteRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _contactReadRepository = contactReadRepository;
            _contactWriteRepository = contactWriteRepository;
        }

        public async Task<Result> Handle(RestoreTicketCommand request, CancellationToken cancellationToken)
        {
            var ticket = await _readRepository.GetByIdAsync(
                request.TicketId,
                tenantId: null,
                includeSoftDeleted: true,
                cancellationToken);

            if (ticket == null)
                throw new DSException("TicketNotFound");

            ticket.IsDeleted = false;
            ticket.DeletedAt = null;
            ticket.DeletedBy = null;
            ticket.DeletedByDisplay = null;

            await _writeRepository.UpdateAsync(ticket, request.TenantId, cancellationToken);

            await ContactTicketCountHelper.RefreshAsync(
                ticket.ContactId,
                _contactReadRepository,
                _contactWriteRepository,
                _readRepository,
                cancellationToken);

            return Result.Success();
        }
    }
}
