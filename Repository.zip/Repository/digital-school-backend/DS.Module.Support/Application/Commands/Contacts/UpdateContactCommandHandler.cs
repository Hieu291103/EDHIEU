using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.Contacts
{
    /// <summary>
    /// Handler cho UpdateContactCommand
    /// </summary>
    public class UpdateContactCommandHandler : ICommandHandler<UpdateContactCommand, Result>
    {
        private readonly ICrmWriteRepository<ContactEntity> _writeRepository;
        private readonly ICrmReadRepository<ContactEntity> _readRepository;
        protected readonly ICurrentUser _currentUser;

        public UpdateContactCommandHandler(
            ICrmWriteRepository<ContactEntity> writeRepository,
            ICrmReadRepository<ContactEntity> readRepository,
            ICurrentUser currentUser)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _currentUser = currentUser;
        }

        public async Task<Result> Handle(UpdateContactCommand request, CancellationToken cancellationToken)
        {
            var contact = await _readRepository.GetByIdAsync(
                request.ContactId,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (contact == null)
                throw new DSException("ContactNotFound");

            if (request.FullName.IsNotNullOrEmpty())
                contact.FullName = request.FullName!;

            if (request.Email.IsNotNull())
                contact.Email = request.Email;

            if (request.Nickname.IsNotNull())
                contact.Nickname = request.Nickname;

            if (request.PhoneNumber.IsNotNull())
                contact.PhoneNumber = request.PhoneNumber;

            if (request.OrganizationName.IsNotNull())
                contact.OrganizationName = request.OrganizationName;

            if (request.Address.IsNotNull())
                contact.Address = request.Address;

            if (request.Notes.IsNotNull())
                contact.Notes = request.Notes;

            if (request.Zalo.IsNotNull())
                contact.Zalo = request.Zalo;

            if (request.ZaloGroup.IsNotNull())
                contact.ZaloGroup = request.ZaloGroup;

            if (request.ProviderAccount.IsNotNull())
                contact.ProviderAccount = request.ProviderAccount;

            if (request.ProviderCrispId.IsNotNull())
                contact.ProviderCrispId = request.ProviderCrispId;

            if (request.Type.IsNotNull() && Enum.TryParse<ContactType>(request.Type, out var contactType))
                contact.Type = contactType;

            if (request.ExtraData != null)
                contact.ExtraData = request.ExtraData.ToBsonDocumentSafe();

            if (request.IsVerified.HasValue)
            {
                contact.IsVerified = request.IsVerified.Value;
                if (request.IsVerified.Value && contact.VerifiedAt == null)
                    contact.VerifiedAt = DateTime.UtcNow;
            }
            if (request.TenantId != null)
                contact.TenantId = request.TenantId;

            if (request.SchoolId.HasValue)
                contact.SchoolId = request.SchoolId;

            await _writeRepository.UpdateAsync(contact, tenantId: null, cancellationToken);

            return Result.Success();
        }
    }
}
