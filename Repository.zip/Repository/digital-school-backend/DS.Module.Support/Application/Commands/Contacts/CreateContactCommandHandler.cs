using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.Contacts
{
    /// <summary>
    /// Handler cho CreateContactCommand
    /// </summary>
    public class CreateContactCommandHandler : ICommandHandler<CreateContactCommand, Result>
    {
        private readonly ICrmWriteRepository<ContactEntity> _writeRepository;
        private readonly ICrmReadRepository<ContactEntity> _readRepository;
        protected readonly ICurrentUser _currentUser;

        public CreateContactCommandHandler(
            ICrmWriteRepository<ContactEntity> writeRepository,
            ICrmReadRepository<ContactEntity> readRepository,
            ICurrentUser currentUser)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _currentUser = currentUser;
        }

        public async Task<Result> Handle(CreateContactCommand request, CancellationToken cancellationToken)
        {
            if (!string.IsNullOrEmpty(request.Email))
            {
                var existingEmail = await _readRepository.FilterAsync(
             c => c.Email == request.Email,
             tenantId: null,
             cancellationToken: cancellationToken);

                if (existingEmail.Any())
                    throw DSException.WithParam("ContactEmailAlreadyExists", request.Email ?? "");
            }
            if (!string.IsNullOrEmpty(request.PhoneNumber))
            {
                var existingPhone = await _readRepository.FilterAsync(
             c => c.PhoneNumber == request.PhoneNumber,
             tenantId: null,
             cancellationToken: cancellationToken);

                if (existingPhone.Any())
                    throw DSException.WithParam("ContactPhoneAlreadyExists", request.PhoneNumber ?? "");
            }

            if (!string.IsNullOrEmpty(request.TenantId))
            {
                var existingFullName = await _readRepository.FilterAsync(
                   c => c.FullName == request.FullName && c.TenantId == request.TenantId,
                   tenantId: null,
                   cancellationToken: cancellationToken);

                if (existingFullName.Any())
                    throw DSException.WithParam("ContactFullNameTenantAlreadyExists", request.FullName);
            }

            var contact = new ContactEntity
            {
                FullName = request.FullName,
                Email = request.Email,
                Nickname = request.Nickname,
                PhoneNumber = request.PhoneNumber,
                OrganizationName = request.OrganizationName,
                Address = request.Address,
                Notes = request.Notes,
                Zalo = request.Zalo,
                ZaloGroup = request.ZaloGroup,
                ProviderAccount = request.ProviderAccount,
                ProviderCrispId = request.ProviderCrispId,
                Type = request.Type ?? ContactType.Unknown,
                ExtraData = request.ExtraData?.Count > 0
                    ? request.ExtraData.ToBsonDocumentSafe()
                    : new(),
                TenantId = request.TenantId,
                SchoolId = request.SchoolId,
            };

            await _writeRepository.InsertAsync(contact, cancellationToken);

            return Result.Success();
        }
    }
}
