using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.Contacts
{
    public class UpdateAndCreateContactCommandHandler : ICommandHandler<UpdateAndCreateContactCommand, string>
    {
        private readonly ICrmWriteRepository<ContactEntity> _writeRepository;
        private readonly ICrmReadRepository<ContactEntity> _readRepository;

        public UpdateAndCreateContactCommandHandler(
            ICrmWriteRepository<ContactEntity> writeRepository,
            ICrmReadRepository<ContactEntity> readRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
        }

        public async Task<string> Handle(UpdateAndCreateContactCommand request, CancellationToken cancellationToken)
        {
            var contact = request.Contact;

            if (!string.IsNullOrEmpty(contact.Id))
            {
                var entity = await _readRepository.GetByIdAsync(
                    contact.Id,
                    tenantId: null,
                    cancellationToken: cancellationToken);

                if (entity == null)
                    throw new DSException("ContactNotFound");

                await PartialUpdateAsync(entity, contact, cancellationToken);
                return contact.Id;
            }

            if (!string.IsNullOrEmpty(contact.UserId))
            {
                var byUserId = await _readRepository.FilterAsync(
                    c => c.UserId == contact.UserId,
                    tenantId: null,
                    cancellationToken: cancellationToken);

                if (byUserId.Any())
                    return byUserId.First().Id;
            }

            if (!string.IsNullOrEmpty(contact.Email))
            {
                var byEmail = await _readRepository.FilterAsync(
                    c => c.Email == contact.Email,
                    tenantId: null,
                    cancellationToken: cancellationToken);

                if (byEmail.Any())
                    return byEmail.First().Id;
            }

            var newContactId = await CreateNewContactAsync(contact, cancellationToken);
            return newContactId;
        }

        private async Task PartialUpdateAsync(ContactEntity entity, ContactDto dto, CancellationToken cancellationToken)
        {
            if (!string.IsNullOrEmpty(dto.FullName))
                entity.FullName = dto.FullName;

            if (!string.IsNullOrEmpty(dto.Email))
                entity.Email = dto.Email;

            if (!string.IsNullOrEmpty(dto.Nickname))
                entity.Nickname = dto.Nickname;

            if (!string.IsNullOrEmpty(dto.PhoneNumber))
                entity.PhoneNumber = dto.PhoneNumber;

            if (!string.IsNullOrEmpty(dto.OrganizationName))
                entity.OrganizationName = dto.OrganizationName;

            if (!string.IsNullOrEmpty(dto.Address))
                entity.Address = dto.Address;

            if (!string.IsNullOrEmpty(dto.Notes))
                entity.Notes = dto.Notes;

            if (!string.IsNullOrEmpty(dto.Zalo))
                entity.Zalo = dto.Zalo;

            if (!string.IsNullOrEmpty(dto.ZaloGroup))
                entity.ZaloGroup = dto.ZaloGroup;

            if (!string.IsNullOrEmpty(dto.ProviderAccount))
                entity.ProviderAccount = dto.ProviderAccount;

            if (!string.IsNullOrEmpty(dto.UserId))
                entity.UserId = dto.UserId;

            if (!string.IsNullOrEmpty(dto.UserName))
                entity.UserName = dto.UserName;

            if (dto.Type.HasValue)
                entity.Type = dto.Type;

            if (dto.SchoolId.HasValue)
                entity.SchoolId = dto.SchoolId.Value;

            if (!string.IsNullOrEmpty(dto.TenantId))
                entity.TenantId = dto.TenantId;

            if (dto.ExtraData != null && dto.ExtraData.Count > 0)
                entity.ExtraData = dto.ExtraData.ToBsonDocumentSafe();

            await _writeRepository.UpdateAsync(entity, tenantId: null, cancellationToken);
        }

        private async Task<string> CreateNewContactAsync(ContactDto contact, CancellationToken cancellationToken)
        {
            var resolvedFullName = !string.IsNullOrEmpty(contact.FullName)
                ? contact.FullName
                : !string.IsNullOrEmpty(contact.Nickname)
                    ? contact.Nickname
                    : contact.Email ?? "";

            var newContact = new ContactEntity
            {
                FullName = resolvedFullName,
                Email = contact.Email,
                Nickname = string.IsNullOrEmpty(contact.Nickname) ? null : contact.Nickname,
                PhoneNumber = string.IsNullOrEmpty(contact.PhoneNumber) ? null : contact.PhoneNumber,
                OrganizationName = string.IsNullOrEmpty(contact.OrganizationName) ? null : contact.OrganizationName,
                Address = string.IsNullOrEmpty(contact.Address) ? null : contact.Address,
                Notes = string.IsNullOrEmpty(contact.Notes) ? null : contact.Notes,
                Zalo = string.IsNullOrEmpty(contact.Zalo) ? null : contact.Zalo,
                ZaloGroup = string.IsNullOrEmpty(contact.ZaloGroup) ? null : contact.ZaloGroup,
                ProviderAccount = string.IsNullOrEmpty(contact.ProviderAccount) ? null : contact.ProviderAccount,
                ProviderCrispId = string.IsNullOrEmpty(contact.ProviderCrispId) ? null : contact.ProviderCrispId,
                UserId = string.IsNullOrEmpty(contact.UserId) ? null : contact.UserId,
                UserName = string.IsNullOrEmpty(contact.UserName) ? null : contact.UserName,
                IsVerified = contact.IsVerified,
                VerifiedAt = contact.IsVerified == true ? DateTime.UtcNow : null,
                TenantId = string.IsNullOrEmpty(contact.TenantId) ? null : contact.TenantId,
                ExtraData = contact.ExtraData?.Count > 0 ? contact.ExtraData?.ToBsonDocumentSafe() : new(),
                Type = contact.Type ?? Domain.Enums.ContactType.Unknown,
                SchoolId = contact.SchoolId,
            };

            await _writeRepository.InsertAsync(newContact, cancellationToken);
            return newContact.Id;
        }
    }
}
