using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Driver;

namespace DS.Module.Support.Application.Commands.Contacts
{
    /// <summary>
    /// Handler cho DeleteContactCommand
    /// </summary>
    public class DeleteContactCommandHandler : ICommandHandler<DeleteContactCommand, Result>
    {
        private readonly ICrmWriteRepository<ContactEntity> _writeRepository;
        private readonly ICrmReadRepository<ContactEntity> _readRepository;
        private readonly ICrmReadRepository<TicketEntity> _ticketReadRepository;

        public DeleteContactCommandHandler(
            ICrmWriteRepository<ContactEntity> writeRepository,
            ICrmReadRepository<ContactEntity> readRepository,
            ICrmReadRepository<TicketEntity> ticketReadRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _ticketReadRepository = ticketReadRepository;
        }

        public async Task<Result> Handle(DeleteContactCommand request, CancellationToken cancellationToken)
        {
            // Kiểm tra contact có tồn tại không
            var contact = await _readRepository.GetByIdAsync(
                request.ContactId,
                tenantId: request.TenantId,
                cancellationToken: cancellationToken);

            if (contact == null)
                throw new DSException("ContactNotFound");

            // Kiểm tra contact đã được sử dụng trong ticket chưa
            var filterBuilder = Builders<TicketEntity>.Filter;
            var filter = filterBuilder.Eq(x => x.ContactId, request.ContactId);

            if (!string.IsNullOrEmpty(request.TenantId))
            {
                filter = filter & filterBuilder.Eq(x => x.TenantId, request.TenantId);
            }

            var tickets = await _ticketReadRepository.PagedFilterAsync(
                filter,
                pageIndex: 1,
                pageSize: 1,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken: cancellationToken);

            if (tickets.Total > 0)
                throw new DSException("ContactIsBeingUsedInTicket");

            // Xóa contact
            await _writeRepository.DeleteAsync(
                request.ContactId,
                tenantId: request.TenantId,
                cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}
