using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.Contacts
{
    public class UpdateAndCreateContactFromCrispCommandHandler : ICommandHandler<UpdateAndCreateContactFromCrispCommand, ContactIdCrispDto>
    {
        private readonly ICrmWriteRepository<ContactEntity> _writeRepository;
        private readonly ICrmReadRepository<ContactEntity> _readRepository;

        public UpdateAndCreateContactFromCrispCommandHandler(
            ICrmWriteRepository<ContactEntity> writeRepository,
            ICrmReadRepository<ContactEntity> readRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
        }

        public async Task<ContactIdCrispDto> Handle(UpdateAndCreateContactFromCrispCommand request, CancellationToken cancellationToken)
        {
            var contact = request.Contact;

            // ── Path 1: Existing contact → partial update ─────────────────────
            if (!string.IsNullOrEmpty(contact.Id))
            {
                await PartialUpdateAsync(contact, cancellationToken);
                return new ContactIdCrispDto { ContactId = contact.Id };
            }

            // ── Path 2: New contact → check UserId first, then email ────────
            if (!string.IsNullOrEmpty(contact.UserId))
            {
                var byUserId = await _readRepository.FilterAsync(
                    c => c.UserId == contact.UserId,
                    tenantId: null,
                    cancellationToken: cancellationToken);

                if (byUserId.Any())
                {
                    var existingContact = byUserId.First();
                    return new ContactIdCrispDto { ContactId = existingContact.Id };
                }
            }

            if (!string.IsNullOrEmpty(contact.Email))
            {
                var byEmail = await _readRepository.FilterAsync(
                    c => c.Email == contact.Email,
                    tenantId: null,
                    cancellationToken: cancellationToken);

                if (byEmail.Any())
                {
                    var existingContact = byEmail.First();
                    return new ContactIdCrispDto { ContactId = existingContact.Id };
                }
            }

            // ── Path 3: Create new contact ───────────────────────────────────
            var newContactId = await CreateNewContactAsync(contact, cancellationToken);
            return new ContactIdCrispDto { ContactId = newContactId };
        }

        /// <summary>
        /// Partial update: only overwrite fields that carry a non-empty / non-null value
        /// from Crisp. Fields absent in the incoming DTO are left untouched on the entity.
        /// </summary>
        private async Task PartialUpdateAsync(ContactDto dto, CancellationToken cancellationToken)
        {
            var entity = await _readRepository.GetByIdAsync(
                dto.Id,
                null,
                cancellationToken: cancellationToken);

            if (entity == null)
                return; // Contact not found — skip silently, caller keeps the existing Id

            if (!string.IsNullOrEmpty(dto.FullName))
                entity.FullName = dto.FullName;

            if (!string.IsNullOrEmpty(dto.Email))
                entity.Email = dto.Email;

            if (!string.IsNullOrEmpty(dto.Nickname))
                entity.Nickname = dto.Nickname;

            if (!string.IsNullOrEmpty(dto.PhoneNumber))
                entity.PhoneNumber = dto.PhoneNumber;

            if (!string.IsNullOrEmpty(dto.OrganizationName))
                entity.OrganizationName = dto.OrganizationName;

            if (!string.IsNullOrEmpty(dto.Address))
                entity.Address = dto.Address;

            if (!string.IsNullOrEmpty(dto.Notes))
                entity.Notes = dto.Notes;

            if (!string.IsNullOrEmpty(dto.Zalo))
                entity.Zalo = dto.Zalo;

            if (!string.IsNullOrEmpty(dto.ZaloGroup))
                entity.ZaloGroup = dto.ZaloGroup;

            if (!string.IsNullOrEmpty(dto.ProviderAccount))
                entity.ProviderAccount = dto.ProviderAccount;

            if (!string.IsNullOrEmpty(dto.ProviderCrispId))
                entity.ProviderCrispId = dto.ProviderCrispId;

            if (!string.IsNullOrEmpty(dto.TenantId))
                entity.TenantId = dto.TenantId;

            if (!string.IsNullOrEmpty(dto.UserId))
                entity.UserId = dto.UserId;

            if (!string.IsNullOrEmpty(dto.UserName))
                entity.UserName = dto.UserName;

            if (dto.Type.HasValue)
                entity.Type = dto.Type.Value;

            if (dto.SchoolId.HasValue)
                entity.SchoolId = dto.SchoolId.Value;

            await _writeRepository.UpdateAsync(entity, null, cancellationToken);
        }

        /// <summary>
        /// Create a new ContactEntity from the incoming DTO.
        /// FullName resolution: FullName → Nickname → Email (last resort).
        /// Null-normalize all optional strings: "" → null.
        /// </summary>
        private async Task<string> CreateNewContactAsync(ContactDto contact, CancellationToken cancellationToken)
        {
            var resolvedFullName = !string.IsNullOrEmpty(contact.FullName)
                ? contact.FullName
                : !string.IsNullOrEmpty(contact.Nickname)
                    ? contact.Nickname
                    : contact.Email;

            var newContact = new ContactEntity
            {
                FullName = resolvedFullName ?? "",
                Email = contact.Email,
                Nickname = string.IsNullOrEmpty(contact.Nickname) ? null : contact.Nickname,
                PhoneNumber = string.IsNullOrEmpty(contact.PhoneNumber) ? null : contact.PhoneNumber,
                OrganizationName = string.IsNullOrEmpty(contact.OrganizationName) ? null : contact.OrganizationName,
                Address = string.IsNullOrEmpty(contact.Address) ? null : contact.Address,
                Notes = string.IsNullOrEmpty(contact.Notes) ? null : contact.Notes,
                Zalo = string.IsNullOrEmpty(contact.Zalo) ? null : contact.Zalo,
                ZaloGroup = string.IsNullOrEmpty(contact.ZaloGroup) ? null : contact.ZaloGroup,
                ProviderAccount = string.IsNullOrEmpty(contact.ProviderAccount) ? null : contact.ProviderAccount,
                ProviderCrispId = string.IsNullOrEmpty(contact.ProviderCrispId) ? null : contact.ProviderCrispId,
                UserId = string.IsNullOrEmpty(contact.UserId) ? null : contact.UserId,
                UserName = string.IsNullOrEmpty(contact.UserName) ? null : contact.UserName,
                IsVerified = contact.IsVerified,
                TenantId = string.IsNullOrEmpty(contact.TenantId) ? null : contact.TenantId,
                ExtraData = contact.ExtraData?.Count > 0 ? contact.ExtraData?.ToBsonDocumentSafe() : new(),
                Type = contact.Type ?? ContactType.Unknown,
                SchoolId = contact.SchoolId
            };

            await _writeRepository.InsertAsync(newContact, cancellationToken);
            return newContact.Id;
        }
    }
}
