using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.Contacts
{
    /// <summary>
    /// Command để xóa contact (hard delete)
    /// </summary>
    public class DeleteContactCommand : ICommand<Result>
    {
        public string ContactId { get; set; } = string.Empty;
        public string? TenantId { get; set; }
    }
}
