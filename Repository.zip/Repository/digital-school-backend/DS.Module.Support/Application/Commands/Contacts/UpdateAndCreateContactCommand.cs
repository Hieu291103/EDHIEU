using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Support.Application.Commands.Contacts
{
    /// <summary>
    /// Command để upsert contact (tạo mới hoặc cập nhật nếu đã tồn tại).
    /// </summary>
    public class UpdateAndCreateContactCommand : ICommand<string>
    {
        public required ContactDto Contact { get; set; }
    }
}
