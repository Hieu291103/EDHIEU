using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.Contacts
{
    /// <summary>
    /// Command để tạo contact mới
    /// </summary>
    public class CreateContactCommand : ICommand<Result>
    {
        public required string FullName { get; set; }
        public string? Email { get; set; }
        public string? Nickname { get; set; }
        public string? PhoneNumber { get; set; }
        public string? OrganizationName { get; set; }
        public string? Address { get; set; }
        public string? Notes { get; set; }
        public string? Zalo { get; set; }
        public string? ZaloGroup { get; set; }
        public string? ProviderAccount { get; set; }
        public string? ProviderCrispId { get; set; }
        public ContactType? Type { get; set; }
        public Dictionary<string, object>? ExtraData { get; set; }
        public string? TenantId { get; set; }
        public int? SchoolId { get; set; }
    }
}
