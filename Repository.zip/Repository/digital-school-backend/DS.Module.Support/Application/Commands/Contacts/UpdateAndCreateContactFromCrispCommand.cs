using DS.Module.Support.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.Support.Application.Commands.Contacts
{
    public class UpdateAndCreateContactFromCrispCommand : ICommand<ContactIdCrispDto>
    {
        public required ContactDto Contact { get; set; }
    }
}
