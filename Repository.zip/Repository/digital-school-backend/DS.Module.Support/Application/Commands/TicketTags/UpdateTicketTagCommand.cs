using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Module.Support.Domain.Enums;

namespace DS.Module.Support.Application.Commands.TicketTags
{
    /// <summary>
    /// Command để cập nhật thông tin TicketTag
    /// </summary>
    public class UpdateTicketTagCommand : ICommand<Result>
    {
        public string TicketTagId { get; set; } = string.Empty;
        public string? Name { get; set; }
        public string? Description { get; set; }
        public TicketProduct? TagProduct { get; set; }
        public TicketTagType? TagType { get; set; }
        public string? Color { get; set; }
        public int? DisplayOrder { get; set; }
    }
}
