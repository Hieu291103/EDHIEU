using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Module.Support.Domain.Enums;

namespace DS.Module.Support.Application.Commands.TicketTags
{
    /// <summary>
    /// Command để tạo TicketTag mới
    /// </summary>
    public class CreateTicketTagCommand : ICommand<Result>
    {
        public required string Name { get; set; }
        public string? Description { get; set; }
        public TicketProduct TagProduct { get; set; } = TicketProduct.None;
        public TicketTagType TagType { get; set; } = TicketTagType.None;
        public string? Color { get; set; } = "#808080";
        public int? DisplayOrder { get; set; }
    }
}
