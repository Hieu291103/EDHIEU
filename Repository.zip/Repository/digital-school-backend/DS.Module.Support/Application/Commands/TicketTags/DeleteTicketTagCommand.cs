using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.TicketTags
{
    /// <summary>
    /// Command để xóa TicketTag (hard delete)
    /// </summary>
    public class DeleteTicketTagCommand : ICommand<Result>
    {
        public string TicketTagId { get; set; } = string.Empty;
    }
}
