using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.TicketTags
{
    /// <summary>
    /// Handler cho DeleteTicketTagCommand
    /// </summary>
    public class DeleteTicketTagCommandHandler : ICommandHandler<DeleteTicketTagCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketTagEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketTagEntity> _readRepository;

        public DeleteTicketTagCommandHandler(
            ICrmWriteRepository<TicketTagEntity> writeRepository,
            ICrmReadRepository<TicketTagEntity> readRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
        }

        public async Task<Result> Handle(DeleteTicketTagCommand request, CancellationToken cancellationToken)
        {
            var ticketTag = await _readRepository.GetByIdAsync(
                request.TicketTagId,
                cancellationToken: cancellationToken);

            if (ticketTag == null)
                throw new DSException("TicketTagNotFound");

            await _writeRepository.DeleteAsync(request.TicketTagId, cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}
