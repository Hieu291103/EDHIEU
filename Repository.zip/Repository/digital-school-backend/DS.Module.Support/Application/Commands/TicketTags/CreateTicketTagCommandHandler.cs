using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.TicketTags
{
    /// <summary>
    /// Handler cho CreateTicketTagCommand
    /// </summary>
    public class CreateTicketTagCommandHandler : ICommandHandler<CreateTicketTagCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketTagEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketTagEntity> _readRepository;
        protected readonly ICurrentUser _currentUser;

        public CreateTicketTagCommandHandler(
            ICrmWriteRepository<TicketTagEntity> writeRepository,
            ICrmReadRepository<TicketTagEntity> readRepository,
            ICurrentUser currentUser)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _currentUser = currentUser;
        }

        public async Task<Result> Handle(CreateTicketTagCommand request, CancellationToken cancellationToken)
        {
            var existing = await _readRepository.FilterAsync(
                t => t.Name == request.Name,
                cancellationToken: cancellationToken);

            if (existing.Any())
                throw DSException.WithParam("TicketTagNameAlreadyExists", request.Name);

            var ticketTag = new TicketTagEntity
            {
                Name = request.Name,
                Description = request.Description,
                TagProduct = request.TagProduct,
                TagType = request.TagType,
                Color = request.Color ?? "#808080",
                DisplayOrder = request.DisplayOrder,
                UsageCount = 0
            };

            await _writeRepository.InsertAsync(ticketTag, cancellationToken);

            return Result.Success();
        }
    }
}
