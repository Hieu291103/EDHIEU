using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.TicketTags
{
    /// <summary>
    /// Handler cho UpdateTicketTagCommand
    /// </summary>
    public class UpdateTicketTagCommandHandler : ICommandHandler<UpdateTicketTagCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketTagEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketTagEntity> _readRepository;
        protected readonly ICurrentUser _currentUser;

        public UpdateTicketTagCommandHandler(
            ICrmWriteRepository<TicketTagEntity> writeRepository,
            ICrmReadRepository<TicketTagEntity> readRepository,
            ICurrentUser currentUser)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _currentUser = currentUser;
        }

        public async Task<Result> Handle(UpdateTicketTagCommand request, CancellationToken cancellationToken)
        {
            var ticketTag = await _readRepository.GetByIdAsync(
                request.TicketTagId,
                cancellationToken: cancellationToken);

            if (ticketTag == null)
                throw new DSException("TicketTagNotFound");

            if (request.Name.IsNotNull())
                ticketTag.Name = request.Name;

            if (request.Description != null)
                ticketTag.Description = request.Description;

            if (request.TagProduct.HasValue)
                ticketTag.TagProduct = request.TagProduct.Value;

            if (request.TagType.HasValue)
                ticketTag.TagType = request.TagType.Value;

            if (request.Color != null)
                ticketTag.Color = request.Color;

            if (request.DisplayOrder.HasValue)
                ticketTag.DisplayOrder = request.DisplayOrder;

            await _writeRepository.UpdateAsync(ticketTag, null, cancellationToken);

            return Result.Success();
        }
    }
}
