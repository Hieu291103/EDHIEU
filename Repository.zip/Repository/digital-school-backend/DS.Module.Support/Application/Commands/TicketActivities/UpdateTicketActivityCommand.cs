using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.TicketActivities
{
    /// <summary>
    /// Command để cập nhật hoạt động của ticket
    /// </summary>
    public class UpdateTicketActivityCommand : ICommand<Result>
    {
        /// <summary>
        /// ID của hoạt động
        /// </summary>
        public string ActivityId { get; set; } = string.Empty;

        /// <summary>
        /// ID của ticket
        /// </summary>
        public required string TicketId { get; set; }

        /// <summary>
        /// Nội dung hoạt động
        /// </summary>
        public required string Content { get; set; }

        /// <summary>
        /// Loại hoạt động
        /// </summary>
        public string ActivityType { get; set; } = "Done";
    }
}
