using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.TicketActivities
{
    /// <summary>
    /// Handler cho CreateTicketActivityCommand
    /// </summary>
    public class CreateTicketActivityCommandHandler : ICommandHandler<CreateTicketActivityCommand, Result>
    {
        private readonly ICrmWriteRepository<TicketActivityEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketEntity> _ticketReadRepository;
        private readonly ICrmWriteRepository<TicketEntity> _ticketWriteRepository;
        protected readonly ICurrentUser _currentUser;

        public CreateTicketActivityCommandHandler(
            ICrmWriteRepository<TicketActivityEntity> writeRepository,
            ICrmReadRepository<TicketEntity> ticketReadRepository,
            ICrmWriteRepository<TicketEntity> ticketWriteRepository,
            ICurrentUser currentUser)
        {
            _writeRepository = writeRepository;
            _ticketReadRepository = ticketReadRepository;
            _ticketWriteRepository = ticketWriteRepository;
            _currentUser = currentUser;
        }

        public async Task<Result> Handle(CreateTicketActivityCommand request, CancellationToken cancellationToken)
        {
            var activity = new TicketActivityEntity
            {
                TicketId = request.TicketId,
                Content = request.Content,
                ActivityType = request.ActivityType
            };

            await _writeRepository.InsertAsync(
                activity,
                cancellationToken: cancellationToken);

            // Update ActivityType in TicketEntity
            var ticket = await _ticketReadRepository.GetByIdAsync(
                request.TicketId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (ticket != null)
            {
                ticket.ActivityType = request.ActivityType;
                await _ticketWriteRepository.UpdateAsync(
                    ticket,
                    null,
                    cancellationToken);
            }

            return Result.Success();
        }
    }
}
