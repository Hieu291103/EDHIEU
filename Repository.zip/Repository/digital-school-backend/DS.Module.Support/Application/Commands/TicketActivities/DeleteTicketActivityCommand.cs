using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.TicketActivities
{
    /// <summary>
    /// Command để xóa hoạt động của ticket (soft delete)
    /// </summary>
    public class DeleteTicketActivityCommand : ICommand<Result>
    {
        /// <summary>
        /// ID của hoạt động
        /// </summary>
        public string ActivityId { get; set; } = string.Empty;

        /// <summary>
        /// ID của ticket (để verify)
        /// </summary>
        public string TicketId { get; set; } = string.Empty;
    }
}
