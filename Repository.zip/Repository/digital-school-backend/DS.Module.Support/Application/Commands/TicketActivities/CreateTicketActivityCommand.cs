using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.Support.Application.Commands.TicketActivities
{
    /// <summary>
    /// Command để tạo hoạt động (activity) cho ticket
    /// </summary>
    public class CreateTicketActivityCommand : ICommand<Result>
    {
        /// <summary>
        /// ID của ticket
        /// </summary>
        public required string TicketId { get; set; }

        /// <summary>
        /// Nội dung hoạt động
        /// </summary>
        public required string Content { get; set; }

        /// <summary>
        /// Loại hoạt động (mặc định: Note)
        /// </summary>
        public string ActivityType { get; set; } = "Note";
    }
}
