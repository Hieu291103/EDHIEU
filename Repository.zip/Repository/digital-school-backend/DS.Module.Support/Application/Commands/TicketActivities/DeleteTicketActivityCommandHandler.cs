using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.TicketActivities
{
    /// <summary>
    /// Handler cho DeleteTicketActivityCommand
    /// </summary>
    public class DeleteTicketActivityCommandHandler : ICommandHandler<DeleteTicketActivityCommand, Result>
    {
        private readonly ICrmReadRepository<TicketActivityEntity> _readRepository;
        private readonly ICrmWriteRepository<TicketActivityEntity> _writeRepository;

        public DeleteTicketActivityCommandHandler(
            ICrmReadRepository<TicketActivityEntity> readRepository,
            ICrmWriteRepository<TicketActivityEntity> writeRepository)
        {
            _readRepository = readRepository;
            _writeRepository = writeRepository;
        }

        public async Task<Result> Handle(DeleteTicketActivityCommand request, CancellationToken cancellationToken)
        {
            // Lấy hoạt động hiện tại
            var activity = await _readRepository.GetByIdAsync(
                request.ActivityId,
                cancellationToken: cancellationToken);

            if (activity == null)
                throw new DSException("TicketActivityNotFound");

            // Kiểm tra TicketId khớp
            if (activity.TicketId != request.TicketId)
                throw new DSException("TicketActivityTicketIdMismatch");

            // Thực hiện soft delete
            await _writeRepository.DeleteAsync(
                request.ActivityId,
                cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}
