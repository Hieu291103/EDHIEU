using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.Support.Application.Commands.TicketActivities
{
    /// <summary>
    /// Handler cho UpdateTicketActivityCommand
    /// </summary>
    public class UpdateTicketActivityCommandHandler : ICommandHandler<UpdateTicketActivityCommand, Result>
    {
        private readonly ICrmReadRepository<TicketActivityEntity> _readRepository;
        private readonly ICrmWriteRepository<TicketActivityEntity> _writeRepository;
        private readonly ICrmReadRepository<TicketEntity> _ticketReadRepository;
        private readonly ICrmWriteRepository<TicketEntity> _ticketWriteRepository;
        protected readonly ICurrentUser _currentUser;

        public UpdateTicketActivityCommandHandler(
            ICrmReadRepository<TicketActivityEntity> readRepository,
            ICrmWriteRepository<TicketActivityEntity> writeRepository,
            ICrmReadRepository<TicketEntity> ticketReadRepository,
            ICrmWriteRepository<TicketEntity> ticketWriteRepository,
            ICurrentUser currentUser)
        {
            _readRepository = readRepository;
            _writeRepository = writeRepository;
            _ticketReadRepository = ticketReadRepository;
            _ticketWriteRepository = ticketWriteRepository;
            _currentUser = currentUser;
        }

        public async Task<Result> Handle(UpdateTicketActivityCommand request, CancellationToken cancellationToken)
        {
            // Lấy hoạt động hiện tại
            var activity = await _readRepository.GetByIdAsync(
                request.ActivityId,
                cancellationToken: cancellationToken);

            if (activity == null)
                throw new DSException("TicketActivityNotFound");

            // Kiểm tra TicketId khớp
            if (activity.TicketId != request.TicketId)
                throw new DSException("TicketActivityTicketIdMismatch");

            //Nếu đã quá 3 giờ kể từ khi tạo hoạt động, không cho phép cập nhật
            if (activity.CreatedAt.AddHours(3) < DateTime.UtcNow)
                throw new DSException("TicketActivityUpdateTimeExpired");

            // Cập nhật thông tin activity
            activity.Content = request.Content;
            activity.ActivityType = request.ActivityType;
            activity.UpdatedAt = DateTime.UtcNow;

            await _writeRepository.UpdateAsync(
                activity,
                null,
                cancellationToken: cancellationToken);

            // Update ActivityType in TicketEntity
            var ticket = await _ticketReadRepository.GetByIdAsync(
                request.TicketId,
                tenantId: null,
                includeSoftDeleted: false,
                cancellationToken);

            if (ticket != null)
            {
                ticket.ActivityType = request.ActivityType;
                await _ticketWriteRepository.UpdateAsync(
                    ticket,
                    null,
                    cancellationToken);
            }

            return Result.Success();
        }
    }
}
