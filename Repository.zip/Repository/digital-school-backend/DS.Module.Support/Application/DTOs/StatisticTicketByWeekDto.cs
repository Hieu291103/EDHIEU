namespace DS.Module.Support.Application.DTOs
{
    public class StatisticTicketByWeekDto
    {
        /// <summary>
        /// Ngày bắt đầu tuần (dd/mm/yyyy)
        /// </summary>
        public DateTime WeekStartDate { get; set; }

        /// <summary>
        /// Ngày kết thúc tuần (dd/mm/yyyy)
        /// </summary>
        public DateTime WeekEndDate { get; set; }

        /// <summary>
        /// Tổng số lượng ticket trong tuần
        /// </summary>
        public int TotalTickets { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket có trạng thái là Đã giải quyết
        /// </summary>
        public int ClosedTickets { get; set; } = 0;

        /// <summary>
        /// Tỷ lệ giải quyết (%) - làm tròn lấy phần nguyên hoặc 1 chữ số thập phân
        /// </summary>
        public decimal ResolutionRate { get; set; } = 0;

        /// <summary>
        /// Số ticket của tuần hiện tại
        /// </summary>
        public int CurrentWeek { get; set; } = 0;

        /// <summary>
        /// Số ticket của tuần liền trước
        /// </summary>
        public int PreviousWeek { get; set; } = 0;

        /// <summary>
        /// Từ mô tả xu hướng: "tăng" hoặc "giảm"
        /// </summary>
        public string TrendWord { get; set; } = string.Empty;

        /// <summary>
        /// Số lượng ticket tăng hoặc giảm so với tuần trước (giá trị tuyệt đối)
        /// </summary>
        public int DeltaAbs { get; set; } = 0;

        /// <summary>
        /// Phần trăm chênh lệch số với tuần trước
        /// </summary>
        public decimal DeltaPercent { get; set; } = 0;

        /// <summary>
        /// Tổng số ticket có mức độ ưu tiên là Cao (High) và Khẩn cấp (Critical)
        /// </summary>
        public int UrgentAndHigh { get; set; } = 0;

        /// <summary>
        /// Tổng số ticket từ nguồn Zalo VÀ là Giáo viên
        /// </summary>
        public int ZaloTeacherCount { get; set; } = 0;

        /// <summary>
        /// Tổng số ticket từ nguồn Zalo VÀ là Học sinh
        /// </summary>
        public int ZaloStudentCount { get; set; } = 0;

        /// <summary>
        /// Tổng số ticket từ nguồn Hotline VÀ là Giáo viên
        /// </summary>
        public int HotlineTeacherCount { get; set; } = 0;

        /// <summary>
        /// Tổng số ticket từ nguồn Hotline VÀ là Học sinh
        /// </summary>
        public int HotlineStudentCount { get; set; } = 0;

        /// <summary>
        /// Tổng số ticket từ sản phẩm Onluyen
        /// </summary>
        public int SoftwareSupportCount { get; set; } = 0;

        /// <summary>
        /// Tổng số lượng ticket từ sản phẩm Kỳ thi quốc tế
        /// </summary>
        public int ContestCount { get; set; } = 0;

        /// <summary>
        /// Tổng số lượng ticket từ nguồn Mobifone
        /// </summary>
        public int MobifoneCount { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket từ các nguồn Crisp (Web Form, Email, Facebook) VÀ là Giáo viên
        /// </summary>
        public int CrispTeacherCount { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket từ các nguồn Crisp (Web Form, Email, Facebook) VÀ là Học sinh
        /// </summary>
        public int CrispStudentCount { get; set; } = 0;

        public List<StatisticTicketItemDto> Tickets { get; set; } = new();
    }
}
