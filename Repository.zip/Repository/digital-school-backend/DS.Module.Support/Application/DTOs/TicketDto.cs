using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;
using DS.Shared.Core.Contracts.Dtos;

namespace DS.Module.Support.Application.DTOs
{
    /// <summary>
    /// DTO đầy đủ cho Ticket entity (dùng cho GetById)
    /// </summary>
    public class TicketDto
    {
        public string Id { get; set; } = string.Empty;
        public string TicketNumber { get; set; } = string.Empty;
        public string Subject { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string? DescriptionHtml { get; set; } = string.Empty;
        public bool? IsHtmlDescription { get; set; } = false;
        public TicketProduct Product { get; set; }
        public TicketSource Source { get; set; }
        public TicketStatus Status { get; set; }
        public TicketPriority Priority { get; set; }
        public TicketTagType? TagType { get; set; } = TicketTagType.None;
        public string? Channel { get; set; } = string.Empty;
        public string? ActivityType { get; set; } = string.Empty;
        public string? PrimaryAssigneeId { get; set; }
        public List<TicketAssignmentDto> Assignments { get; set; } = new();
        public DateTime? ReceiptTime { get; set; }
        public DateTime? ExpectedResolutionTime { get; set; }
        public DateTime? ResolvedAt { get; set; }
        public string? ResolvedByUserId { get; set; }
        public string? ResolvedByUserDisplay { get; set; }
        public string? ResolutionNotes { get; set; }
        public int CommentCount { get; set; }
        public float? SatisfactionRating { get; set; }
        public string? CustomerFeedback { get; set; }
        public List<string> TagIds { get; set; } = new();
        public List<string> FlowChatIds { get; set; } = new();
        public List<S3AttachmentDto> Attachments { get; set; } = new();
        public string? InternalNotes { get; set; }
        public string? ParentTicketCode { get; set; }
        public List<string> RelatedTicketCodes { get; set; } = new();
        public List<string> RelatedTaskCodes { get; set; } = new();
        public string? ContactId { get; set; }
        public CripsIntegrationInfo? CripsIntegration { get; set; }
        public Dictionary<string, object>? ExtraData { get; set; }
        public TicketAuditHistory? AuditHistory { get; set; } = new();
        public TicketFrom? CreatedFrom { get; set; }
        public string? TenantId { get; set; }
        public DateTime? CreatedAt { get; set; }
        public string? CreatedByDisplay { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string? UpdatedByDisplay { get; set; }
    }

    /// <summary>
    /// DTO rút gọn cho danh sách Ticket
    /// </summary>
    public class TicketListDto
    {
        public string Id { get; set; } = string.Empty;
        public string TicketNumber { get; set; } = string.Empty;
        public string Subject { get; set; } = string.Empty;
        public TicketProduct Product { get; set; }
        public TicketSource Source { get; set; }
        public TicketStatus Status { get; set; }
        public TicketPriority Priority { get; set; }
        public TicketTagType? TagType { get; set; } = TicketTagType.None;
        public string? Channel { get; set; } = string.Empty;
        public string? ActivityType { get; set; } = string.Empty;
        public string? PrimaryAssigneeId { get; set; }
        public int? CommentCount { get; set; }
        public DateTime? ReceiptTime { get; set; }
        public DateTime? ExpectedResolutionTime { get; set; }
        public string? ContactId { get; set; }
        public ContactDto? Contact { get; set; }
        public TicketFrom? CreatedFrom { get; set; }
        public string? TenantId { get; set; }
        public DateTime? CreatedAt { get; set; }
        public string? CreatedByDisplay { get; set; }
        public DateTime? DeletedAt { get; set; }
        public string? DeletedByDisplay { get; set; }
    }

    /// <summary>
    /// DTO cho thông tin người được gán xử lý ticket
    /// </summary>
    public class TicketAssignmentDto
    {
        public string UserId { get; set; } = string.Empty;
        public string? UserDisplay { get; set; }
        public DateTime? AssignedAt { get; set; }
        public string? AssignerDisplay { get; set; }
        public string? Notes { get; set; }
    }

    /// <summary>
    /// DTO tổng hợp cho endpoint GetTicketById: bao gồm Ticket và Contact liên quan
    /// </summary>
    public class TicketDetailDto
    {
        public TicketDto Ticket { get; set; } = null!;
        public ContactDto? Contact { get; set; }
    }
}
