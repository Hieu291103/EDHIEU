using DS.Module.Support.Domain.Entities;
using DS.Module.Support.Domain.Enums;

namespace DS.Module.Support.Application.DTOs
{
    public class TicketCrispDto
    {
        public string Id { get; set; } = string.Empty;
        public string TicketNumber { get; set; } = string.Empty;
        public string Subject { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public TicketProduct Product { get; set; }
        public TicketSource Source { get; set; }
        public TicketStatus Status { get; set; }
        public TicketPriority Priority { get; set; }
        public TicketTagType? TagType { get; set; } = TicketTagType.None;
        public string Channel { get; set; } = string.Empty;
        public string? ActivityType { get; set; } = string.Empty;
        public string? PrimaryAssigneeId { get; set; }
        public List<TicketAssignmentDto> Assignments { get; set; } = new();
        public CripsIntegrationInfo? CripsIntegration { get; set; }
        public List<string> TagIds { get; set; } = new();
        public List<string> FlowChatIds { get; set; } = new();
        public Dictionary<string, object> ExtraData { get; set; } = new();
        public ContactDto? Contact { get; set; }
        public TicketFrom? CreatedFrom { get; set; }
        public DateTime? ReceiptTime { get; set; }
        public string? TenantId { get; set; }
        public DateTime CreatedAt { get; set; }
        public string? CreatedByDisplay { get; set; }
    }

    /// <summary>
    /// Wrapper cho lịch sử ticket được truy vấn từ Crisp session
    /// </summary>
    public class TicketHistoryCrispDto
    {
        public string? WebsiteId { get; set; }
        public string? SessionId { get; set; }
        public List<TicketCrispDto> Tickets { get; set; } = new();
    }
}
