namespace DS.Module.Support.Application.DTOs
{
    /// <summary>
    /// DTO cho danh sách TicketTag (dùng cho GetList)
    /// </summary>
    public class TicketTagListDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string TagProduct { get; set; } = string.Empty;
        public string TagType { get; set; } = string.Empty;
        public string? Color { get; set; }
        public int UsageCount { get; set; }
        public int? DisplayOrder { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
