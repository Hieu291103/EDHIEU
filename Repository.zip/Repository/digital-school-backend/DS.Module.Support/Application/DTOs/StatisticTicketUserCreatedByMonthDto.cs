namespace DS.Module.Support.Application.DTOs
{
    /// <summary>
    /// DTO chứa thống kê ticket theo người dùng tạo trong tháng
    /// Cấu trúc pivot table với các cột từ ngày 1 đến 31
    /// </summary>
    public class StatisticTicketUserCreatedByMonthDto
    {
        /// <summary>
        /// ID của người dùng
        /// </summary>
        public required string UserId { get; set; }

        /// <summary>
        /// Họ tên đầy đủ
        /// </summary>
        public string? FullName { get; set; }

        /// <summary>
        /// Tên đăng nhập
        /// </summary>
        public string? UserName { get; set; }

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 1
        /// </summary>
        public int Day1 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 2
        /// </summary>
        public int Day2 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 3
        /// </summary>
        public int Day3 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 4
        /// </summary>
        public int Day4 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 5
        /// </summary>
        public int Day5 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 6
        /// </summary>
        public int Day6 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 7
        /// </summary>
        public int Day7 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 8
        /// </summary>
        public int Day8 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 9
        /// </summary>
        public int Day9 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 10
        /// </summary>
        public int Day10 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 11
        /// </summary>
        public int Day11 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 12
        /// </summary>
        public int Day12 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 13
        /// </summary>
        public int Day13 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 14
        /// </summary>
        public int Day14 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 15
        /// </summary>
        public int Day15 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 16
        /// </summary>
        public int Day16 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 17
        /// </summary>
        public int Day17 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 18
        /// </summary>
        public int Day18 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 19
        /// </summary>
        public int Day19 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 20
        /// </summary>
        public int Day20 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 21
        /// </summary>
        public int Day21 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 22
        /// </summary>
        public int Day22 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 23
        /// </summary>
        public int Day23 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 24
        /// </summary>
        public int Day24 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 25
        /// </summary>
        public int Day25 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 26
        /// </summary>
        public int Day26 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 27
        /// </summary>
        public int Day27 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 28
        /// </summary>
        public int Day28 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 29
        /// </summary>
        public int Day29 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 30
        /// </summary>
        public int Day30 { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket được tạo vào ngày 31
        /// </summary>
        public int Day31 { get; set; } = 0;

        /// <summary>
        /// Tổng số lượng ticket được tạo trong tháng
        /// </summary>
        public int Total { get; set; } = 0;

        /// <summary>
        /// Lấy giá trị số lượng ticket cho một ngày nhất định (1-31)
        /// </summary>
        public int GetDayValue(int day)
        {
            return day switch
            {
                1 => Day1,
                2 => Day2,
                3 => Day3,
                4 => Day4,
                5 => Day5,
                6 => Day6,
                7 => Day7,
                8 => Day8,
                9 => Day9,
                10 => Day10,
                11 => Day11,
                12 => Day12,
                13 => Day13,
                14 => Day14,
                15 => Day15,
                16 => Day16,
                17 => Day17,
                18 => Day18,
                19 => Day19,
                20 => Day20,
                21 => Day21,
                22 => Day22,
                23 => Day23,
                24 => Day24,
                25 => Day25,
                26 => Day26,
                27 => Day27,
                28 => Day28,
                29 => Day29,
                30 => Day30,
                31 => Day31,
                _ => 0
            };
        }

        /// <summary>
        /// Thiết lập giá trị số lượng ticket cho một ngày nhất định (1-31)
        /// </summary>
        public void SetDayValue(int day, int value)
        {
            switch (day)
            {
                case 1: Day1 = value; break;
                case 2: Day2 = value; break;
                case 3: Day3 = value; break;
                case 4: Day4 = value; break;
                case 5: Day5 = value; break;
                case 6: Day6 = value; break;
                case 7: Day7 = value; break;
                case 8: Day8 = value; break;
                case 9: Day9 = value; break;
                case 10: Day10 = value; break;
                case 11: Day11 = value; break;
                case 12: Day12 = value; break;
                case 13: Day13 = value; break;
                case 14: Day14 = value; break;
                case 15: Day15 = value; break;
                case 16: Day16 = value; break;
                case 17: Day17 = value; break;
                case 18: Day18 = value; break;
                case 19: Day19 = value; break;
                case 20: Day20 = value; break;
                case 21: Day21 = value; break;
                case 22: Day22 = value; break;
                case 23: Day23 = value; break;
                case 24: Day24 = value; break;
                case 25: Day25 = value; break;
                case 26: Day26 = value; break;
                case 27: Day27 = value; break;
                case 28: Day28 = value; break;
                case 29: Day29 = value; break;
                case 30: Day30 = value; break;
                case 31: Day31 = value; break;
            }
        }
    }

    /// <summary>
    /// Wrapper cho danh sách kết quả thống kê ticket theo người dùng trong tháng
    /// </summary>
    public class StatisticTicketUserCreatedByMonthListDto
    {
        /// <summary>
        /// Danh sách người dùng với số lượng ticket tạo theo ngày
        /// </summary>
        public List<StatisticTicketUserCreatedByMonthDto> Users { get; set; } = new();

        /// <summary>
        /// Tổng số người dùng đã tạo ticket trong tháng
        /// </summary>
        public int TotalUsers => Users.Count;

        /// <summary>
        /// Tổng số lượng ticket được tạo trong tháng
        /// </summary>
        public int TotalTickets => Users.Sum(u => u.Total);
    }
}
