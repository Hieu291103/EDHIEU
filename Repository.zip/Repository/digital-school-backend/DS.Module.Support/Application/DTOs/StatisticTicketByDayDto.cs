using DS.Module.Support.Domain.Enums;

namespace DS.Module.Support.Application.DTOs
{
    /// <summary>
    /// DTO chứa thống kê ticket theo ngày
    /// </summary>
    public class StatisticTicketByDayDto
    {
        /// <summary>
        /// Ngày thống kê
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Tổng số lượng ticket được tạo trong ngày
        /// </summary>
        public int TotalTickets { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket đã giải quyết (trạng thái: Resolved hoặc Closed)
        /// </summary>
        public int ClosedTickets { get; set; } = 0;

        /// <summary>
        /// Tỷ lệ giải quyết (%) - Tính bằng (ClosedTickets / TotalTickets) * 100, làm tròn lấy phần nguyên
        /// </summary>
        public int ResolutionRate { get; set; } = 0;

        /// <summary>
        /// Tổng số ticket có mức độ ưu tiên là Cao (High) hoặc Khẩn cấp (Critical)
        /// </summary>
        public int urgentAndHigh { get; set; } = 0;

        /// <summary>
        /// Tổng số ticket từ nguồn Zalo VÀ loại liên hệ là Giáo viên
        /// </summary>
        public int ZaloTeacherCount { get; set; } = 0;

        /// <summary>
        /// Tổng số ticket từ nguồn Zalo VÀ loại liên hệ là Học sinh
        /// </summary>
        public int ZaloStudentCount { get; set; } = 0;

        /// <summary>
        /// Tổng số ticket từ nguồn Hotline VÀ loại liên hệ là Giáo viên
        /// </summary>
        public int HotlineTeacherCount { get; set; } = 0;

        /// <summary>
        /// Tổng số ticket từ nguồn Hotline VÀ loại liên hệ là Học sinh
        /// </summary>
        public int HotlineStudentCount { get; set; } = 0;

        /// <summary>
        /// Tổng số lượng ticket từ sản phẩm Kỳ thi quốc tế (KyThiQuocTe)
        /// </summary>
        public int ContestCount { get; set; } = 0;

        /// <summary>
        /// Tổng số ticket từ sản phẩm OnLuyện (SoftwareSupport)
        /// </summary>
        public int SoftwareSupportCount { get; set; } = 0;

        /// <summary>
        /// Tổng số lượng ticket từ nguồn Mobifone (MBF)
        /// </summary>
        public int MobifoneCount { get; set; } = 0;


        /// <summary>
        /// Số lượng ticket từ các nguồn Crisp (Web Form, Email, Facebook) VÀ là Giáo viên
        /// </summary>
        public int CrispTeacherCount { get; set; } = 0;

        /// <summary>
        /// Số lượng ticket từ các nguồn Crisp (Web Form, Email, Facebook) VÀ là Học sinh
        /// </summary>
        public int CrispStudentCount { get; set; } = 0;

        /// <summary>
        /// Danh sách tên các trường hợp tác (tenant) có số lượng ticket nhiều nhất trong ngày (Top 5)
        /// </summary>
        public List<string> TopTenant { get; set; } = new();

        public List<StatisticTicketItemDto> Tickets { get; set; } = new();
    }

    /// <summary>
    /// DTO chứa thông tin chi tiết một ticket trong báo cáo thống kê
    /// </summary>
    public class StatisticTicketItemDto
    {
        /// <summary>
        /// Tên trường
        /// </summary>
        public string? TenantName { get; set; }
        /// <summary>
        /// Tiêu đề / Chủ đề của ticket
        /// </summary>
        public string? Subject { get; set; }

        /// <summary>
        /// Mô tả chi tiết vấn đề
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// Nguồn gốc tạo ticket (Zalo, Hotline, Email, WebForm, Facebook, etc.)
        /// </summary>
        public string? Source { get; set; }

        /// <summary>
        /// Trạng thái ticket (New, InProgress, Resolved, Closed, ...)
        /// </summary>
        public string? Status { get; set; }

        /// <summary>
        /// Mức độ ưu tiên (Low, Normal, High, Critical)
        /// </summary>
        public string? Priority { get; set; }

        /// <summary>
        /// Loại liên hệ (Giáo viên, Học sinh, Phụ huynh, etc.)
        /// </summary>
        public string? ContactType { get; set; }

        /// <summary>
        /// Loại tag của ticket
        /// </summary>
        public TicketTagType? TagType { get; set; } = TicketTagType.None;
    }
}
