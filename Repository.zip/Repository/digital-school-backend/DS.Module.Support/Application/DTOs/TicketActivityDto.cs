namespace DS.Module.Support.Application.DTOs
{
    /// <summary>
    /// DTO cho TicketActivity
    /// </summary>
    public class TicketActivityDto
    {
        public string Id { get; set; } = string.Empty;

        public string TicketId { get; set; } = string.Empty;

        /// <summary>
        /// Nội dung hoạt động
        /// </summary>
        public string Content { get; set; } = string.Empty;

        /// <summary>
        /// Loại hoạt động (Note, Call, ...)
        /// </summary>
        public string ActivityType { get; set; } = "Note";

        /// <summary>
        /// Thời gian tạo
        /// </summary>
        public DateTime CreatedAt { get; set; }

        /// <summary>
        /// ID người tạo
        /// </summary>
        public string? CreatedBy { get; set; }

        /// <summary>
        /// Tên người tạo
        /// </summary>
        public string? CreatedByDisplay { get; set; }

        /// <summary>
        /// Thời gian cập nhật
        /// </summary>
        public DateTime? UpdatedAt { get; set; }

        /// <summary>
        /// ID người cập nhật
        /// </summary>
        public string? UpdatedBy { get; set; }

        /// <summary>
        /// Tên người cập nhật
        /// </summary>
        public string? UpdatedByDisplay { get; set; }
    }
}
