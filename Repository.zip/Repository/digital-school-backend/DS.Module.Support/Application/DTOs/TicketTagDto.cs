namespace DS.Module.Support.Application.DTOs
{
    /// <summary>
    /// DTO đầy đủ cho TicketTag entity (dùng cho GetById)
    /// </summary>
    public class TicketTagDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string TagProduct { get; set; } = string.Empty;
        public string TagType { get; set; } = string.Empty;
        public string? Color { get; set; }
        public int UsageCount { get; set; }
        public int? DisplayOrder { get; set; }
        public DateTime CreatedAt { get; set; }
        public string? CreatedByDisplay { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string? UpdatedByDisplay { get; set; }
    }
}
