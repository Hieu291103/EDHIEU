using DS.Module.Support.Domain.Enums;

namespace DS.Module.Support.Application.DTOs
{
    /// <summary>
    /// DTO đầy đủ cho Contact entity (dùng cho GetById)
    /// </summary>
    public class ContactDto
    {
        public string Id { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string? Email { get; set; }
        public string? Nickname { get; set; }
        public string? PhoneNumber { get; set; }
        public string? OrganizationName { get; set; }
        public string? Address { get; set; }
        public string? Notes { get; set; }
        public string? Zalo { get; set; }
        public string? ZaloGroup { get; set; }
        public string? ProviderAccount { get; set; }
        public string? ProviderCrispId { get; set; }
        public string? UserId { get; set; }
        public string? UserName { get; set; }
        public int? SchoolId { get; set; }
        public ContactType? Type { get; set; } = ContactType.Unknown;
        public Dictionary<string, object>? ExtraData { get; set; }
        public bool? IsVerified { get; set; }
        public int? TicketCount { get; set; }
        public DateTime? VerifiedAt { get; set; }
        public string? TenantId { get; set; }
        public DateTime CreatedAt { get; set; }
        public string? CreatedByDisplay { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string? UpdatedByDisplay { get; set; }
    }

    /// <summary>
    /// DTO rút gọn cho danh sách Contact (không chứa ExtraData để tiết kiệm bandwidth)
    /// </summary>
    public class ContactListDto
    {
        public string Id { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string? Email { get; set; }
        public string? Nickname { get; set; }
        public string? PhoneNumber { get; set; }
        public string? OrganizationName { get; set; }
        public string? Address { get; set; }
        public string? Notes { get; set; }
        public string? Zalo { get; set; }
        public string? ZaloGroup { get; set; }
        public string? ProviderAccount { get; set; }
        public string? ProviderCrispId { get; set; }
        public string? UserId { get; set; }
        public string? UserName { get; set; }
        public ContactType? Type { get; set; }
        public bool? IsVerified { get; set; }
        public int? TicketCount { get; set; }
        public DateTime? VerifiedAt { get; set; }
        public string? TenantId { get; set; }
        public DateTime CreatedAt { get; set; }
        public string? CreatedByDisplay { get; set; }
        public DateTime UpdatedAt { get; set; }
        public string? UpdatedByDisplay { get; set; }
    }

    public class ContactIdCrispDto
    {
        public string ContactId { get; set; } = string.Empty;
    }
}
