using AutoMapper;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Contracts.Dtos;
using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;

namespace DS.Module.Support.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho Ticket entity
    /// </summary>
    public class TicketMappingProfile : Profile
    {
        public TicketMappingProfile()
        {
            CreateMap<TicketEntity, TicketDto>()
                .ForMember(dest => dest.ExtraData,
                           opt => opt.MapFrom(src => src.ExtraData != null
                               ? src.ExtraData.ToDictionarySafe()
                               : null));
            CreateMap<TicketDto, TicketEntity>()
             .ForMember(dest => dest.ExtraData,
                        opt => opt.MapFrom(src => src.ExtraData != null
                            ? src.ExtraData.ToBsonDocumentSafe()
                            : null));
            CreateMap<TicketEntity, TicketListDto>();
            CreateMap<TicketEntity, TicketCrispDto>().ForMember(dest => dest.ExtraData,
                           opt => opt.MapFrom(src => src.ExtraData != null
                               ? src.ExtraData.ToDictionarySafe()
                               : null));
            CreateMap<TicketCrispDto, TicketDto>().ForMember(dest => dest.ExtraData,
                         opt => opt.MapFrom(src => src.ExtraData != null
                             ? src.ExtraData.ToBsonDocumentSafe()
                             : null));
            CreateMap<TicketAssignment, TicketAssignmentDto>();
            CreateMap<S3AttachmentInfo, S3AttachmentDto>();
            CreateMap<S3AttachmentDto, S3AttachmentInfo>();
        }
    }
}
