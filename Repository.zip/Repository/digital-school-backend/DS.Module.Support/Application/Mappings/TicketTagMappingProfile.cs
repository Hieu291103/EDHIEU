using AutoMapper;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;

namespace DS.Module.Support.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho TicketTag entity
    /// </summary>
    public class TicketTagMappingProfile : Profile
    {
        public TicketTagMappingProfile()
        {
            CreateMap<TicketTagEntity, TicketTagDto>()
                .ForMember(dest => dest.TagProduct, opt => opt.MapFrom(src => src.TagProduct.ToString()))
                .ForMember(dest => dest.TagType, opt => opt.MapFrom(src => src.TagType.ToString()));
            
            CreateMap<TicketTagEntity, TicketTagListDto>()
                .ForMember(dest => dest.TagProduct, opt => opt.MapFrom(src => src.TagProduct.ToString()))
                .ForMember(dest => dest.TagType, opt => opt.MapFrom(src => src.TagType.ToString()));
        }
    }
}
