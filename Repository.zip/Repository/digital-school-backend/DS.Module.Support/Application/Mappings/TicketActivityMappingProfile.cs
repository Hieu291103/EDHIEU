using AutoMapper;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;

namespace DS.Module.Support.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho TicketActivity
    /// </summary>
    public class TicketActivityMappingProfile : Profile
    {
        public TicketActivityMappingProfile()
        {
            CreateMap<TicketActivityEntity, TicketActivityDto>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.TicketId, opt => opt.MapFrom(src => src.TicketId))
                .ForMember(dest => dest.Content, opt => opt.MapFrom(src => src.Content))
                .ForMember(dest => dest.ActivityType, opt => opt.MapFrom(src => src.ActivityType ?? "Note"))
                .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(src => src.CreatedAt))
                .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom(src => src.CreatedBy))
                .ForMember(dest => dest.CreatedByDisplay, opt => opt.MapFrom(src => src.CreatedByDisplay))
                .ForMember(dest => dest.UpdatedAt, opt => opt.MapFrom(src => src.UpdatedAt))
                .ForMember(dest => dest.UpdatedBy, opt => opt.MapFrom(src => src.UpdatedBy))
                .ForMember(dest => dest.UpdatedByDisplay, opt => opt.MapFrom(src => src.UpdatedByDisplay))
                .ReverseMap();
        }
    }
}
