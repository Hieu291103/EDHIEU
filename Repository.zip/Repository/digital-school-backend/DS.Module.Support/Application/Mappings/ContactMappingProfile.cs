using AutoMapper;
using DS.Module.Support.Application.DTOs;
using DS.Module.Support.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;

namespace DS.Module.Support.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho Contact entity
    /// </summary>
    public class ContactMappingProfile : Profile
    {
        public ContactMappingProfile()
        {
            CreateMap<ContactEntity, ContactDto>()
                .ForMember(dest => dest.ExtraData,
                           opt => opt.MapFrom(src => src.ExtraData != null
                               ? src.ExtraData.ToDictionarySafe()
                               : null));
            CreateMap<ContactDto, ContactEntity>()
              .ForMember(dest => dest.ExtraData,
                         opt => opt.MapFrom(src => src.ExtraData != null
                             ? src.ExtraData.ToBsonDocumentSafe()
                             : null));
            CreateMap<ContactEntity, ContactListDto>();
        }
    }
}
