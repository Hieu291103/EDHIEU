using DS.Module.Hrm.Infrastructure.Extensions;
using DS.Module.Identity.Infrastructure.Extensions;
using DS.Module.OnlineClass.Infrastructure.Extensions;
using DS.Module.Support.Infrastructure.Extensions;
using DS.Module.Tenant.Infrastructure.Extensions;
using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Infrastructure.Configuration;
using DS.Shared.Core.Infrastructure.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Configuration;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Context;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.Redis.Extensions;
using DS.Shared.Core.Infrastructure.Services;
using DS.Shared.Core.Presentation.Authentication;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.IdentityModel.Tokens;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

MongoDbConventions.RegisterConventions();

var builder = WebApplication.CreateBuilder(args);
// Tự động load appsettings.{ENVIRONMENT}.json
builder.Configuration
    .AddJsonFile("appsettings.json", optional: false)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true)
    .AddEnvironmentVariables();

// Serilog
builder.Host.AddSerilogLogging(builder.Configuration);

//ForwardedHeader
builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    // Chỉ định các header cần đọc
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    // xóa danh sách mặc định (thường chỉ tin loopback 127.0.0.1)
    options.KnownIPNetworks.Clear();
    options.KnownProxies.Clear();
});

// Add controllers with JSON options
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });

builder.Services.AddDefaultCors(builder.Configuration);

// Redis distributed cache
builder.Services.AddRedisCache(builder.Configuration);

// Swagger/OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new()
    {
        Title = "Admin API",
        Version = "v1",
        Description = "Admin API Documentation"
    });

    // Enable XML documentation comments
    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    if (File.Exists(xmlPath))
    {
        options.IncludeXmlComments(xmlPath);
    }
});

// Đăng ký dịch vụ RequestContext
builder.Services.AddRequestContext();

// Register Admin Mongo database
builder.Services.AddMongoDatabases(builder.Configuration);

// Localization (Core)
builder.Services.AddCoreLocalization();

// Tenant module services
builder.Services.AddTenantModule();

// Excel export services (EPPlus)
builder.Services.AddExcelServices();

// OnlineClass module services
builder.Services.AddOnlineClassModule(builder.Configuration);

// AutoMapper with auto-discovery
builder.Services.AddAutoMapperWithAutoDiscovery();

// MediatR with auto-discovery
// Default: Chỉ enable Validation, các behaviors khác off
builder.Services.AddMediatRWithAutoDiscovery(options =>
{
    // Override default nếu cần
    options.EnableTenantContext = true; // Admin API cần tenant context
    options.EnableCaching = true; // Enable caching cho queries
    options.EnableValidation = true; // Enable validation cho commands
});
builder.Services.AddIdentityModule();
builder.Services.AddSupportModule(builder.Configuration);
builder.Services.AddHrmModule();

// S3 Upload Service
builder.Services.AddS3UploadService(builder.Configuration);

// Onluyen integration
builder.Services.AddOnluyenIntegration(builder.Configuration);

// OAuth settings (shared in DS.Shared.Core)
builder.Services.Configure<OAuthSettings>(builder.Configuration.GetSection(OAuthSettings.SectionName));
builder.Services.Configure<JwtSettings>(builder.Configuration.GetSection(JwtSettings.SectionName));
builder.Services.AddHttpClient<IOAuthClient, OAuthClientService>();

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>("BasicAuthentication", options => { })
    .AddJwtBearer(options =>
    {
        var oauthSettings = builder.Configuration.GetSection(OAuthSettings.SectionName).Get<OAuthSettings>() ?? new OAuthSettings();
        options.RequireHttpsMetadata = false;
        if (!string.IsNullOrWhiteSpace(oauthSettings.Url))
        {
            options.Authority = oauthSettings.Url;
        }
        options.RefreshOnIssuerKeyNotFound = true;
        options.AutomaticRefreshInterval = TimeSpan.FromHours(12);
        options.RefreshInterval = TimeSpan.FromMinutes(30);
        options.Backchannel = new HttpClient(new SocketsHttpHandler
        {
            PooledConnectionLifetime = TimeSpan.FromMinutes(10),
            MaxConnectionsPerServer = 50
        });
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = !string.IsNullOrWhiteSpace(oauthSettings.Issuer),
            ValidIssuer = oauthSettings.Issuer,
            ValidateAudience = !string.IsNullOrWhiteSpace(oauthSettings.Audience),
            ValidAudience = oauthSettings.Audience,
            ValidateIssuerSigningKey = true,
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromSeconds(30)
        };
    });

builder.Services.AddPermissionAuthorization();
builder.Services.AddAuthorization();

// Health checks
builder.Services.AddDefaultHealthChecks();

var app = builder.Build();

// Use ForwardedHeaders middleware BEFORE other middleware (recommended order)
app.UseForwardedHeaders();

// Add Exception Handling Middleware (must be first)
app.UseExceptionHandling();

// Add Request Context Middleware
app.UseRequestContext();

// Add Response Time Header Middleware (thêm X-Time-Server và X-Time-Client headers)
app.UseResponseTimeHeaders();

app.UseCors(CorsSettings.DefaultPolicyName);

// Swagger middleware
if (app.Environment.IsDevelopment())
{
    app.Use(async (context, next) =>
    {
        if (context.Request.Path.StartsWithSegments("/swagger"))
        {
            var authHeader = context.Request.Headers.Authorization.ToString();
            if (string.IsNullOrWhiteSpace(authHeader) || !authHeader.StartsWith("Basic "))
            {
                context.Response.Headers["WWW-Authenticate"] = "Basic";
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                return;
            }

            var encoded = authHeader["Basic ".Length..].Trim();
            var credential = Encoding.UTF8.GetString(Convert.FromBase64String(encoded));
            var parts = credential.Split(':', 2);

            var user = builder.Configuration["SwaggerAuth:Username"];
            var pass = builder.Configuration["SwaggerAuth:Password"];

            if (parts.Length != 2 || parts[0] != user || parts[1] != pass)
            {
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                return;
            }
        }

        await next();
    });
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "DS Admin API v1");
        options.RoutePrefix = "swagger";
    });
}

app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.UseDefaultHealthChecks();

await app.Services.InitializeMongoIndexesAsync<IAdminMongoDbContext>();
await app.Services.InitializeMongoIndexesAsync<ICrmMongoDbContext>();
await app.Services.InitializeMongoIndexesAsync<IHrmMongoDbContext>();

app.Run();
