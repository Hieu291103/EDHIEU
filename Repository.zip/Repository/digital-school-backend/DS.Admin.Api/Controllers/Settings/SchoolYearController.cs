using DS.Module.Tenant.Application.Commands.SchoolYears;
using DS.Module.Tenant.Application.Queries.SchoolYears;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Settings
{
    [Route("api/setting/school-years")]
    [Authorize]
    [ApiController]
    public class SchoolYearController : BaseAPIController
    {
        public SchoolYearController(IMediator mediator) : base(mediator)
        {
        }

        [HttpPost("list")]
        [PermissionAuthorize("SETTING:SCHOOL_YEAR:VIEW")]
        public async Task<IActionResult> GetList([FromBody] GetSchoolYearListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        [HttpGet("{schoolYearId}")]
        [PermissionAuthorize("SETTING:SCHOOL_YEAR:VIEW")]
        public async Task<IActionResult> GetById(string schoolYearId, CancellationToken cancellationToken = default)
        {
            var query = new GetSchoolYearByIdQuery { SchoolYearId = schoolYearId };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        [HttpPost]
        [PermissionAuthorize("SETTING:SCHOOL_YEAR:CREATE")]
        public async Task<IActionResult> Create([FromBody] CreateSchoolYearCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        [HttpPut("{schoolYearId}")]
        [PermissionAuthorize("SETTING:SCHOOL_YEAR:UPDATE")]
        public async Task<IActionResult> Update(string schoolYearId, [FromBody] UpdateSchoolYearCommand command, CancellationToken cancellationToken = default)
        {
            command.SchoolYearId = schoolYearId;
            return await SendAsync(command);
        }

        [HttpDelete("{schoolYearId}")]
        [PermissionAuthorize("SETTING:SCHOOL_YEAR:DELETE")]
        public async Task<IActionResult> Delete(string schoolYearId, CancellationToken cancellationToken = default)
        {
            var command = new DeleteSchoolYearCommand { SchoolYearId = schoolYearId };
            return await SendAsync(command);
        }
    }
}
