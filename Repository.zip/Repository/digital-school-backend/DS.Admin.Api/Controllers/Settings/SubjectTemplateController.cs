using DS.Module.Tenant.Application.Commands.SubjectTemplates;
using DS.Module.Tenant.Application.Queries.SubjectTemplates;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Settings
{
    [Route("api/setting/subject-templates")]
    [Authorize]
    [ApiController]
    public class SubjectTemplateController : BaseAPIController
    {
        public SubjectTemplateController(IMediator mediator) : base(mediator)
        {
        }

        [HttpPost("list")]
        [PermissionAuthorize("SETTING:SUBJECT_TEMPLATE:VIEW")]
        public async Task<IActionResult> GetList([FromBody] GetSubjectTemplateListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        [HttpGet("{subjectTemplateId}")]
        [PermissionAuthorize("SETTING:SUBJECT_TEMPLATE:VIEW")]
        public async Task<IActionResult> GetById(string subjectTemplateId, CancellationToken cancellationToken = default)
        {
            var query = new GetSubjectTemplateByIdQuery { SubjectTemplateId = subjectTemplateId };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        [HttpPost]
        [PermissionAuthorize("SETTING:SUBJECT_TEMPLATE:CREATE")]
        public async Task<IActionResult> Create([FromBody] CreateSubjectTemplateCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        [HttpPut("{subjectTemplateId}")]
        [PermissionAuthorize("SETTING:SUBJECT_TEMPLATE:UPDATE")]
        public async Task<IActionResult> Update(string subjectTemplateId, [FromBody] UpdateSubjectTemplateCommand command, CancellationToken cancellationToken = default)
        {
            command.SubjectTemplateId = subjectTemplateId;
            return await SendAsync(command);
        }

        [HttpDelete("{subjectTemplateId}")]
        [PermissionAuthorize("SETTING:SUBJECT_TEMPLATE:DELETE")]
        public async Task<IActionResult> Delete(string subjectTemplateId, CancellationToken cancellationToken = default)
        {
            var command = new DeleteSubjectTemplateCommand { SubjectTemplateId = subjectTemplateId };
            return await SendAsync(command);
        }
    }
}
