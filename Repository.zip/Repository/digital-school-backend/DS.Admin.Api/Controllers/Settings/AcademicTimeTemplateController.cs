using DS.Module.Tenant.Application.Commands.AcademicTimeTemplates;
using DS.Module.Tenant.Application.Queries.AcademicTimeTemplates;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Settings
{
    [Route("api/setting/academic-time-templates")]
    [Authorize]
    [ApiController]
    public class AcademicTimeTemplateController : BaseAPIController
    {
        public AcademicTimeTemplateController(IMediator mediator) : base(mediator)
        {
        }

        [HttpPost("list")]
        [PermissionAuthorize("SETTING:ACADEMIC_TIME_TEMPLATE:VIEW")]
        public async Task<IActionResult> GetList([FromBody] GetAcademicTimeTemplateListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        [HttpGet("{academicTimeTemplateId}")]
        [PermissionAuthorize("SETTING:ACADEMIC_TIME_TEMPLATE:VIEW")]
        public async Task<IActionResult> GetById(string academicTimeTemplateId, CancellationToken cancellationToken = default)
        {
            var query = new GetAcademicTimeTemplateByIdQuery { AcademicTimeTemplateId = academicTimeTemplateId };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        [HttpPost]
        [PermissionAuthorize("SETTING:ACADEMIC_TIME_TEMPLATE:CREATE")]
        public async Task<IActionResult> Create([FromBody] CreateAcademicTimeTemplateCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        [HttpPut("{academicTimeTemplateId}")]
        [PermissionAuthorize("SETTING:ACADEMIC_TIME_TEMPLATE:UPDATE")]
        public async Task<IActionResult> Update(string academicTimeTemplateId, [FromBody] UpdateAcademicTimeTemplateCommand command, CancellationToken cancellationToken = default)
        {
            command.AcademicTimeTemplateId = academicTimeTemplateId;
            return await SendAsync(command);
        }

        [HttpDelete("{academicTimeTemplateId}")]
        [PermissionAuthorize("SETTING:ACADEMIC_TIME_TEMPLATE:DELETE")]
        public async Task<IActionResult> Delete(string academicTimeTemplateId, CancellationToken cancellationToken = default)
        {
            var command = new DeleteAcademicTimeTemplateCommand { AcademicTimeTemplateId = academicTimeTemplateId };
            return await SendAsync(command);
        }
    }
}
