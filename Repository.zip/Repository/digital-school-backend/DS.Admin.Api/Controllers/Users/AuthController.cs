using DS.Shared.Core.Application.Abstractions.OAuth;
using DS.Shared.Core.Common.Constants;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Users
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : BaseAPIController
    {
        private readonly IOAuthClient _oAuthClient;

        public AuthController(IMediator mediator, IOAuthClient oAuthClient)
            : base(mediator)
        {
            _oAuthClient = oAuthClient;
        }

        [HttpGet("test")]
        public async Task<IActionResult> GetTest()
        {
            return SuccessResponse(new { Message = "AuthController is working!" });
        }

        public sealed record TokenRequest(string GrantType, string? Code, string? RedirectUri, string? RefreshToken, string? CodeVerifier);

        [HttpPost("token")]
        public async Task<IActionResult> Token([FromBody] TokenRequest request, CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(request.GrantType))
            {
                throw new DSException("InvalidRequest");
            }

            if (string.Equals(request.GrantType, OAuthQueryParameters.AuthorizationCode, StringComparison.Ordinal))
            {
                if (string.IsNullOrWhiteSpace(request.Code) || string.IsNullOrWhiteSpace(request.RedirectUri))
                {
                    throw new DSException("InvalidRequest");
                }

                var result = await _oAuthClient.ExchangeCodeForTokenAsync(
                    request.Code,
                    request.RedirectUri,
                    request.CodeVerifier,
                    cancellationToken);

                if (result is null)
                {
                    throw new DSException("OAuthExchangeFailed");
                }

                if (!string.IsNullOrWhiteSpace(result.RefreshToken))
                {
                    Response.Cookies.Append(
                        CookieConstants.RefreshTokenCookieName,
                        result.RefreshToken,
                        new CookieOptions
                        {
                            HttpOnly = true,
                            Secure = true,
                            SameSite = SameSiteMode.None,
                            Expires = DateTimeOffset.UtcNow.AddSeconds(CookieConstants.RefreshTokenExpirationSeconds)
                        });
                }
                result.RefreshToken = null;
                return SuccessResponse(result);
            }

            if (string.Equals(request.GrantType, OAuthQueryParameters.RefreshToken, StringComparison.Ordinal))
            {
                var refreshToken = request.RefreshToken;

                if (string.IsNullOrWhiteSpace(refreshToken))
                {
                    if (!Request.Cookies.TryGetValue(CookieConstants.RefreshTokenCookieName, out var cookieRefreshToken))
                    {
                        throw new DSException("InvalidRequest");
                    }
                    refreshToken = cookieRefreshToken;
                }

                var result = await _oAuthClient.RefreshTokenAsync(refreshToken, cancellationToken);
                if (result is null)
                {
                    throw new DSException("OAuthRefreshFailed");
                }

                if (!string.IsNullOrWhiteSpace(result.RefreshToken))
                {
                    Response.Cookies.Append(
                        CookieConstants.RefreshTokenCookieName,
                        result.RefreshToken,
                        new CookieOptions
                        {
                            HttpOnly = CookieConstants.CookieHttpOnly,
                            Secure = CookieConstants.CookieSecure,
                            SameSite = SameSiteMode.None,
                            Expires = DateTimeOffset.UtcNow.AddSeconds(CookieConstants.RefreshTokenExpirationSeconds)
                        });
                }
                result.RefreshToken = null;
                return SuccessResponse(result);
            }

            throw new DSException("UnsupportedGrantType");
        }

        public sealed record LogoutRequest(string? ReturnUrl);

        [HttpPost("logout")]
        [Authorize]
        public async Task<IActionResult> Logout([FromBody] LogoutRequest request, CancellationToken cancellationToken)
        {
            var url = await _oAuthClient.BuildLogoutUrlAsync(request.ReturnUrl, cancellationToken);

            Response.Cookies.Delete(OAuthQueryParameters.RefreshToken);

            return SuccessResponse(new { url });
        }

        [HttpPost("userinfo")]
        [Authorize]
        public async Task<IActionResult> UserInfo(CancellationToken cancellationToken)
        {
            var authHeader = Request.Headers.Authorization.ToString();
            if (string.IsNullOrWhiteSpace(authHeader) || !authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            {
                throw new DSException("Unauthorized");
            }

            var accessToken = authHeader["Bearer ".Length..].Trim();
            if (string.IsNullOrWhiteSpace(accessToken))
            {
                throw new DSException("Unauthorized");
            }

            var json = await _oAuthClient.GetUserInfoAsync(accessToken, cancellationToken);
            return Content(json, "application/json");
        }
    }
}
