using DS.Module.Identity.Application.Commands.Users;
using DS.Module.Identity.Application.Queries.Users;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using DS.Shared.CQRS.Queries.Users;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Users
{
    [Route("api/users")]
    [Authorize]
    [ApiController]
    public class UserController : BaseAPIController
    {
        public UserController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách users với phân trang và filter
        /// </summary>
        [HttpPost("list")]
        [PermissionAuthorize("USER:USER:VIEW")]
        public async Task<IActionResult> GetList([FromBody] SharedGetUserListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy thông tin chi tiết user theo ID
        /// </summary>
        [HttpGet("{userId}")]
        [PermissionAuthorize("USER:USER:VIEW")]
        public async Task<IActionResult> GetById(string userId, CancellationToken cancellationToken = default)
        {
            var query = new SharedGetUserByIdQuery { UserId = userId };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
                return NotFound();

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo user mới
        /// </summary>
        [HttpPost]
        [PermissionAuthorize("USER:USER:CREATE")]
        public async Task<IActionResult> Create([FromBody] CreateUserCommand command, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(command, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Cập nhật thông tin user
        /// </summary>
        [HttpPut("{userId}")]
        [PermissionAuthorize("USER:USER:UPDATE")]
        public async Task<IActionResult> Update(string userId, [FromBody] UpdateUserCommand command, CancellationToken cancellationToken = default)
        {
            command.UserId = userId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa user (soft delete)
        /// </summary>
        [HttpDelete("{userId}")]
        [PermissionAuthorize("USER:USER:DELETE")]
        public async Task<IActionResult> Delete(string userId, CancellationToken cancellationToken = default)
        {
            var command = new DeleteUserCommand { UserId = userId };
            return await SendAsync(command);
        }

        /// <summary>
        /// Admin đặt lại mật khẩu cho user (không cần mật khẩu cũ)
        /// </summary>
        [HttpPost("{userId}/reset-password")]
        [PermissionAuthorize("USER:USER:RESET_PASSWORD")]
        public async Task<IActionResult> ResetPassword(string userId, [FromBody] AdminResetPasswordCommand command, CancellationToken cancellationToken = default)
        {
            command.UserId = userId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Lấy danh sách tất cả roles (không phân trang)
        /// </summary>
        [HttpGet("{userId}/roles")]
        [PermissionAuthorize("USER:USER:VIEW")]
        public async Task<IActionResult> GetUserRoles(string userId, CancellationToken cancellationToken = default)
        {
            var query = new GetUserRolesByUserIdQuery() { UserId = userId };
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Gán role cho user
        /// </summary>
        [HttpPost("{userId}/assign-roles")]
        [PermissionAuthorize("USER:USER:UPDATE")]
        public async Task<IActionResult> AssignRoles(string userId, [FromBody] AssignUserRoleCommand command, CancellationToken cancellationToken = default)
        {
            command.UserId = userId;
            return await SendAsync(command);
        }
    }
}
