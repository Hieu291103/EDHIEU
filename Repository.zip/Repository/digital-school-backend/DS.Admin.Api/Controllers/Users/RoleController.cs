using DS.Module.Identity.Application.Commands.Roles;
using DS.Module.Identity.Application.Queries.Permissions;
using DS.Module.Identity.Application.Queries.Roles;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Users
{
    [Route("api/roles")]
    [Authorize]
    [ApiController]
    public class RoleController : BaseAPIController
    {
        public RoleController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách roles với phân trang
        /// </summary>
        [HttpPost("list")]
        [PermissionAuthorize("USER:ROLE:VIEW")]
        public async Task<IActionResult> GetList([FromBody] GetRoleListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy role theo ID
        /// </summary>
        [HttpGet("{roleId}")]
        [PermissionAuthorize("USER:ROLE:VIEW")]
        public async Task<IActionResult> GetById(string roleId, CancellationToken cancellationToken = default)
        {
            var query = new GetRoleByIdQuery { RoleId = roleId };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo role mới
        /// </summary>
        [HttpPost]
        [PermissionAuthorize("USER:ROLE:CREATE")]
        public async Task<IActionResult> Create([FromBody] CreateRoleCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Cập nhật role
        /// </summary>
        [HttpPut("{roleId}")]
        [PermissionAuthorize("USER:ROLE:UPDATE")]
        public async Task<IActionResult> Update(string roleId, [FromBody] UpdateRoleCommand command, CancellationToken cancellationToken = default)
        {
            command.RoleId = roleId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa role
        /// </summary>
        [HttpDelete("{roleId}")]
        [PermissionAuthorize("USER:ROLE:DELETE")]
        public async Task<IActionResult> Delete(string roleId, CancellationToken cancellationToken = default)
        {
            var command = new DeleteRoleCommand { RoleId = roleId };
            return await SendAsync(command);
        }

        /// <summary>
        /// Lấy danh sách quyền dành cho role
        /// </summary>
        [HttpGet("list/permissions/{clientId}")]
        [PermissionAuthorize("USER:ROLE:VIEW")]
        public async Task<IActionResult> GetListPermissions(string clientId, CancellationToken cancellationToken = default)
        {
            var query = new GetPermissionListByClientQuery(clientId);
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }
    }
}
