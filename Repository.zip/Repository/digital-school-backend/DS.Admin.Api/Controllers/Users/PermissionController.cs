using DS.Module.Identity.Application.Commands.Permissions;
using DS.Module.Identity.Application.Queries.Permissions;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Users
{
    [Route("api/permissions")]
    [Authorize]
    [ApiController]
    public class PermissionController : BaseAPIController
    {
        public PermissionController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách permissions với phân trang
        /// </summary>
        [HttpPost("list")]
        [PermissionAuthorize("USER:PERMISSION:VIEW")]
        public async Task<IActionResult> GetList([FromBody] GetPermissionListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy permission theo ID
        /// </summary>
        [HttpGet("{permissionId}")]
        [PermissionAuthorize("USER:PERMISSION:VIEW")]
        public async Task<IActionResult> GetById(string permissionId, CancellationToken cancellationToken = default)
        {
            var query = new GetPermissionByIdQuery { PermissionId = permissionId };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo permission mới
        /// </summary>
        [HttpPost]
        [PermissionAuthorize("USER:PERMISSION:CREATE")]
        public async Task<IActionResult> Create([FromBody] CreatePermissionCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Cập nhật permission
        /// </summary>
        [HttpPut("{permissionId}")]
        [PermissionAuthorize("USER:PERMISSION:UPDATE")]
        public async Task<IActionResult> Update(string permissionId, [FromBody] UpdatePermissionCommand command, CancellationToken cancellationToken = default)
        {
            command.PermissionId = permissionId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa permission
        /// </summary>
        [HttpDelete("{permissionId}")]
        [PermissionAuthorize("USER:PERMISSION:DELETE")]
        public async Task<IActionResult> Delete(string permissionId, CancellationToken cancellationToken = default)
        {
            var command = new DeletePermissionCommand { PermissionId = permissionId };
            return await SendAsync(command);
        }
    }
}
