using DS.Module.Tenant.Application.Commands.Students;
using DS.Module.Tenant.Application.Queries.Students;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Tenants
{
    [Route("api/tenants/students")]
    [Authorize]
    [ApiController]
    public class StudentController : BaseAPIController
    {
        public StudentController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách học sinh của một trường
        /// </summary>
        /// <remarks>
        /// POST /api/tenants/students/list
        /// </remarks>
        [HttpPost("list")]
        [PermissionAuthorize("TENANT:STUDENT:VIEW")]
        public async Task<IActionResult> GetStudentList([FromBody] GetStudentListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy chi tiết một học sinh
        /// </summary>
        /// <remarks>
        /// GET /api/tenants/students/{studentId}?tenantId={tenantId}
        /// </remarks>
        [HttpGet("{studentId}")]
        [PermissionAuthorize("TENANT:STUDENT:VIEW")]
        public async Task<IActionResult> GetStudentById(
            string studentId,
            [FromQuery] string tenantId,
            CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrEmpty(tenantId))
            {
                return BadRequest("TenantId is required");
            }

            var query = new GetStudentByIdQuery
            {
                StudentId = studentId,
                TenantId = tenantId
            };

            var result = await _mediator.Send(query, cancellationToken);
            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo học sinh mới
        /// </summary>
        /// <remarks>
        /// POST /api/tenants/students
        /// 
        /// Request body:
        /// {
        ///   "tenantId": "string",
        ///   "classId": "string",
        ///   "fullName": "string",
        ///   "email": "string",
        ///   "password": "string",
        ///   "educationCode": "string",
        ///   "phoneNumber": "string",
        ///   "startDate": "2024-01-01" (optional)
        /// }
        /// </remarks>
        [HttpPost]
        [PermissionAuthorize("TENANT:STUDENT:CREATE")]
        public async Task<IActionResult> CreateStudent([FromBody] CreateStudentCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Cập nhật thông tin học sinh
        /// </summary>
        /// <remarks>
        /// PUT /api/tenants/students/{studentId}
        /// 
        /// Request body:
        /// {
        ///   "studentId": "string",
        ///   "userTenantMappingId": "string",
        ///   "studentClassMappingId": "string",
        ///   "tenantId": "string",
        ///   "classId": "string",
        ///   "fullName": "string",
        ///   "email": "string",
        ///   "educationCode": "string",
        ///   "phoneNumber": "string",
        ///   "dateOfBirth": "2024-01-01",
        ///   "avatarUrl": "string",
        ///   "startDate": "2024-01-01",
        ///   "isActive": true,
        ///   "endReason": "string"
        /// }
        /// </remarks>
        [HttpPut("{studentId}")]
        [PermissionAuthorize("TENANT:STUDENT:UPDATE")]
        public async Task<IActionResult> UpdateStudent(
            string studentId,
            [FromBody] UpdateStudentCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Đổi lớp cho một hoặc nhiều học sinh
        /// </summary>
        /// <remarks>
        /// POST /api/tenants/students/change-class
        /// 
        /// Request body:
        /// {
        ///   "tenantId": "string",
        ///   "oldClassId": "string",
        ///   "newClassId": "string",
        ///   "studentIds": ["id1", "id2", "id3"]
        /// }
        /// </remarks>
        [HttpPost("change-class")]
        [PermissionAuthorize("TENANT:STUDENT:UPDATE")]
        public async Task<IActionResult> ChangeStudentClass(
            [FromBody] ChangeStudentClassCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Gán nhiều học sinh vào lớp Subject (lớp bộ môn)
        /// </summary>
        /// <remarks>
        /// POST /api/tenants/students/subject-classes/add
        /// 
        /// Request body:
        /// {
        ///   "tenantId": "string",
        ///   "classId": "string",
        ///   "studentIds": ["id1", "id2", "id3"]
        /// }
        /// </remarks>
        [HttpPost("subject-classes/add")]
        [PermissionAuthorize("TENANT:STUDENT:UPDATE")]
        public async Task<IActionResult> AddStudentsToSubjectClass(
            [FromBody] AddStudentsToSubjectClassCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa nhiều học sinh khỏi lớp Subject (lớp bộ môn)
        /// </summary>
        /// <remarks>
        /// POST /api/tenants/students/subject-classes/remove
        /// 
        /// Request body:
        /// {
        ///   "tenantId": "string",
        ///   "classId": "string",
        ///   "studentIds": ["id1", "id2", "id3"]
        /// }
        /// </remarks>
        [HttpPost("subject-classes/remove")]
        [PermissionAuthorize("TENANT:STUDENT:UPDATE")]
        public async Task<IActionResult> RemoveStudentsFromSubjectClass(
            [FromBody] RemoveStudentFromSubjectClassCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa một hoặc nhiều học sinh (soft delete hoàn toàn)
        /// </summary>
        /// <remarks>
        /// POST /api/tenants/students/delete
        /// 
        /// Request body:
        /// {
        ///   "tenantId": "string",
        ///   "studentIds": ["id1", "id2", "id3"]
        /// }
        /// </remarks>
        [HttpPost("delete")]
        [PermissionAuthorize("TENANT:STUDENT:DELETE")]
        public async Task<IActionResult> DeleteStudents(
            [FromBody] DeleteStudentCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Đổi password học sinh
        /// </summary>
        /// <remarks>
        /// POST /api/tenants/students/{studentId}/change-password
        /// 
        /// Request body:
        /// {
        ///   "tenantId": "string",
        ///   "newPassword": "string"
        /// }
        /// </remarks>
        [HttpPost("{studentId}/change-password")]
        [PermissionAuthorize("TENANT:STUDENT:UPDATE")]
        public async Task<IActionResult> ChangeStudentPassword(
            string studentId,
            [FromBody] ChangeStudentPasswordCommand command,
            CancellationToken cancellationToken = default)
        {
            command.StudentId = studentId;
            return await SendAsync(command);
        }
    }
}
