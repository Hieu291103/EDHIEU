using DS.Module.Tenant.Application.Commands.TenantClasses;
using DS.Module.Tenant.Application.Queries.TenantClasses;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Tenants
{
    /// <summary>
    /// API Controller quản lý lớp học của Tenant (cả lớp hành chính và lớp bộ môn)
    /// </summary>
    [Route("api/tenant-classes")]
    [Authorize]
    [ApiController]
    public class TenantClassController : BaseAPIController
    {
        public TenantClassController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách lớp học với phân trang, lọc theo loại, khối, năm học, trạng thái
        /// </summary>
        /// <remarks>
        /// POST /api/tenant-classes/list
        /// 
        /// Request body:
        /// {
        ///   "tenantId": "string (required)",
        ///   "classType": 0 or 1 (optional, 0=Regular, 1=Subject),
        ///   "gradeLevel": 10, 11, 12 (optional, chỉ cho Regular),
        ///   "year": 2024 (optional),
        ///   "isActive": true (optional, mặc định=true),
        ///   "keyword": "string (optional, tìm kiếm Code, Name)",
        ///   "pageIndex": 0,
        ///   "pageSize": 10
        /// }
        /// </remarks>
        [HttpPost("list")]
        [PermissionAuthorize("TENANT:CLASS:VIEW")]
        public async Task<IActionResult> GetList([FromBody] GetTenantClassListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy chi tiết một lớp học
        /// </summary>
        /// <remarks>
        /// GET /api/tenant-classes/{tenantClassId}?tenantId={tenantId}
        /// </remarks>
        [HttpGet("{tenantClassId}")]
        [PermissionAuthorize("TENANT:CLASS:VIEW")]
        public async Task<IActionResult> GetById(
            string tenantClassId,
            CancellationToken cancellationToken = default)
        {
            var query = new GetTenantClassByIdQuery
            {
                TenantClassId = tenantClassId
            };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo lớp học mới (Regular hoặc Subject)
        /// </summary>
        /// <remarks>
        /// POST /api/tenant-classes?tenantId={tenantId}
        /// 
        /// Request body (Regular class):
        /// {
        ///   "classType": 0,
        ///   "code": "10A1",
        ///   "name": "Lớp 10A1",
        ///   "description": "string",
        ///   "gradeLevel": 10,
        ///   "year": 2024,
        ///   "schoolId": 1,
        ///   "room": "P101",
        ///   "maxStudents": 35,
        ///   "teacherId": "string",
        ///   "note": "string"
        /// }
        /// 
        /// Request body (Subject class):
        /// {
        ///   "classType": 1,
        ///   "code": "ANH_NC",
        ///   "name": "Tiếng Anh Nâng Cao",
        ///   "description": "string",
        ///   "subjectId": "string",
        ///   "year": 2024,
        ///   "schoolId": 1,
        ///   "room": "P102",
        ///   "maxStudents": 40,
        ///   "teacherId": "string",
        ///   "assistantTeacherId": "string",
        ///   "periodsPerWeek": 2,
        ///   "note": "string"
        /// }
        /// </remarks>
        [HttpPost]
        [PermissionAuthorize("TENANT:CLASS:CREATE")]
        public async Task<IActionResult> Create(
            [FromBody] CreateTenantClassCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Tạo nhiều lớp học cùng lúc (Bulk Create)
        /// </summary>
        /// <remarks>
        /// POST /api/tenant-classes/bulk
        /// 
        /// Request body (array of CreateTenantClassCommand):
        /// [
        ///   {
        ///     "tenantId": "string (required)",
        ///     "classType": 0,
        ///     "code": "10A1",
        ///     "name": "Lớp 10A1",
        ///     "description": "string",
        ///     "gradeLevel": 10,
        ///     "year": 2024,
        ///     "schoolId": 1,
        ///     "room": "P101",
        ///     "maxStudents": 35,
        ///     "teacherId": "string",
        ///     "note": "string"
        ///   },
        ///   {
        ///     "tenantId": "string (required)",
        ///     "classType": 0,
        ///     "code": "10A2",
        ///     "name": "Lớp 10A2",
        ///     "year": 2024,
        ///     "gradeLevel": 10,
        ///     "schoolId": 1,
        ///     "maxStudents": 35
        ///   }
        /// ]
        /// </remarks>
        [HttpPost("bulk")]
        [PermissionAuthorize("TENANT:CLASS:CREATE")]
        public async Task<IActionResult> CreateMultiple(
            [FromBody] List<CreateTenantClassCommand> commands,
            CancellationToken cancellationToken = default)
        {
            var command = new CreateBulkTenantClassesCommand { Commands = commands };
            var result = await _mediator.Send(command, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Cập nhật thông tin lớp học
        /// </summary>
        /// <remarks>
        /// PUT /api/tenant-classes/{tenantClassId}?tenantId={tenantId}
        /// 
        /// Request body (cập nhật một phần):
        /// {
        ///   "name": "Lớp 10A1 - Chuyên",
        ///   "description": "string",
        ///   "room": "P101",
        ///   "maxStudents": 35,
        ///   "teacherId": "string",
        ///   "isActive": true,
        ///   "note": "string"
        /// }
        /// </remarks>
        [HttpPut("{tenantClassId}")]
        [PermissionAuthorize("TENANT:CLASS:UPDATE")]
        public async Task<IActionResult> Update(
            string tenantClassId,
            [FromBody] UpdateTenantClassCommand command,
            CancellationToken cancellationToken = default)
        {
            command.TenantClassId = tenantClassId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa lớp học (soft delete)
        /// </summary>
        /// <remarks>
        /// DELETE /api/tenant-classes/{tenantClassId}?tenantId={tenantId}
        /// </remarks>
        [HttpDelete("{tenantClassId}")]
        [PermissionAuthorize("TENANT:CLASS:DELETE")]
        public async Task<IActionResult> Delete(
            string tenantClassId,
            CancellationToken cancellationToken = default)
        {
            var command = new DeleteTenantClassCommand
            {
                TenantClassId = tenantClassId
            };
            return await SendAsync(command);
        }
    }
}
