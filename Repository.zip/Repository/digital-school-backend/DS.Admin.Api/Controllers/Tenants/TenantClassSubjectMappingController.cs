using DS.Module.Tenant.Application.Commands.TenantClassSubjectMappings;
using DS.Module.Tenant.Application.Queries.TenantClassSubjectMappings;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Tenants
{
    /// <summary>
    /// API Controller quản lý phân công môn học và giáo viên cho lớp học
    /// </summary>
    [Route("api/tenant-classes/{classId}/subject-mappings")]
    [Authorize]
    [ApiController]
    public class TenantClassSubjectMappingController : BaseAPIController
    {
        public TenantClassSubjectMappingController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách phân công môn học cho lớp theo năm học
        /// </summary>
        /// <remarks>
        /// GET /api/tenant-classes/{classId}/subject-mappings?tenantId={tenantId}&year={year}
        /// </remarks>
        [HttpGet]
        [PermissionAuthorize("TENANT:CLASS:VIEW")]
        public async Task<IActionResult> GetList(
            string classId,
            [FromQuery] string tenantId,
            [FromQuery] int year,
            CancellationToken cancellationToken = default)
        {
            var query = new GetTenantClassSubjectMappingListQuery
            {
                TenantId = tenantId,
                Year = year,
                ClassId = classId
            };
            var result = await _mediator.Send(query, cancellationToken);
            if (result == null)
            {
                return NotFound();
            }
            return SuccessResponse(result);
        }

        /// <summary>
        /// CreateOrUpdate danh sách phân công môn học cho lớp
        /// </summary>
        /// <remarks>
        /// POST /api/tenant-classes/{classId}/subject-mappings
        /// 
        /// Request body:
        /// {
        ///   "year": 2025,
        ///   "mappings": [
        ///     {
        ///       "id": null,
        ///       "classSubjectCode": "10A1-TOAN",
        ///       "classId": "class123",
        ///       "classCode": "10A1",
        ///       "subjectId": "subject456",
        ///       "subjectCode": "TOAN",
        ///       "teacherId": "teacher789",
        ///       "teacherDisplay": "Nguyễn Văn A",
        ///       "assistantTeacherId": "teacher790",
        ///       "assistantTeacherDisplay": "Trần Thị B",
        ///       "periodsPerWeek": 3,
        ///       "note": "Phân công môn Toán"
        ///     },
        ///     {
        ///       "id": "mapping123",
        ///       "classSubjectCode": "10A1-VAN",
        ///       "classId": "class123",
        ///       "classCode": "10A1",
        ///       "subjectId": "subject789",
        ///       "subjectCode": "VAN",
        ///       "teacherId": "teacher791",
        ///       "teacherDisplay": "Lê Văn C",
        ///       "assistantTeacherId": null,
        ///       "assistantTeacherDisplay": null,
        ///       "periodsPerWeek": 2,
        ///       "note": null
        ///     }
        ///   ]
        /// }
        /// </remarks>
        [HttpPost]
        [PermissionAuthorize("TENANT:CLASS:UPDATE")]
        public async Task<IActionResult> CreateOrUpdate(
            string classId,
            [FromBody] CreateOrUpdateTenantClassSubjectMappingCommand command,
            CancellationToken cancellationToken = default)
        {
            command.ClassId = classId;
            return await SendAsync(command);
        }
    }
}
