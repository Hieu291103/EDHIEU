using DS.Module.Tenant.Application.Commands.Teachers;
using DS.Module.Tenant.Application.Queries.Teachers;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Tenants
{
    [Route("api/tenants/teachers")]
    [Authorize]
    [ApiController]
    public class TeacherController : BaseAPIController
    {
        public TeacherController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách giáo viên của một trường
        /// </summary>
        /// <remarks>
        /// GET /api/tenants/teachers/list
        /// POST /api/tenants/teachers/list
        /// </remarks>
        [HttpPost("list")]
        [PermissionAuthorize("TENANT:TEACHER:VIEW")]
        public async Task<IActionResult> GetTeacherList([FromBody] GetTeacherListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy chi tiết một giáo viên
        /// </summary>
        /// <remarks>
        /// GET /api/tenants/teachers/{teacherId}?tenantId={tenantId}&year={year}
        /// </remarks>
        [HttpGet("{teacherId}")]
        [PermissionAuthorize("TENANT:TEACHER:VIEW")]
        public async Task<IActionResult> GetTeacherById(
            string teacherId,
            [FromQuery] string tenantId,
            [FromQuery] int? year = null,
            CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrEmpty(tenantId))
            {
                return BadRequest("TenantId is required");
            }

            var query = new GetTeacherByIdQuery
            {
                TeacherId = teacherId,
                TenantId = tenantId,
                Year = year
            };

            var result = await _mediator.Send(query, cancellationToken);
            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo giáo viên mới (kèm phân công môn học)
        /// </summary>
        /// <remarks>
        /// POST /api/tenants/teachers
        /// 
        /// Request body:
        /// {
        ///   "tenantId": "string",
        ///   "fullName": "string",
        ///   "email": "string",
        ///   "password": "string (optional if userId provided)",
        ///   "title": "string",
        ///   "phoneNumber": "string",
        ///   "dateOfBirth": "2024-01-01",
        ///   "avatarUrl": "string",
        ///   "schoolId": 1,
        ///   "subjectAssignments": [
        ///     {
        ///       "subjectId": "string",
        ///       "position": "Trưởng BM",
        ///       "year": 2024,
        ///       "startDate": "2024-01-01",
        ///       "endDate": "2025-05-31"
        ///     }
        ///   ]
        /// }
        /// </remarks>
        [HttpPost]
        [PermissionAuthorize("TENANT:TEACHER:CREATE")]
        public async Task<IActionResult> CreateTeacher([FromBody] CreateTeacherCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Cập nhật thông tin giáo viên (kèm phân công môn học)
        /// </summary>
        /// <remarks>
        /// PUT /api/tenants/teachers/{teacherId}
        /// 
        /// Request body:
        /// {
        ///   "teacherId": "string",
        ///   "userTenantMappingId": "string",
        ///   "tenantId": "string",
        ///   "fullName": "string",
        ///   "email": "string",
        ///   "title": "string",
        ///   "phoneNumber": "string",
        ///   "dateOfBirth": "2024-01-01",
        ///   "avatarUrl": "string",
        ///   "schoolId": 1,
        ///   "isActive": true,
        ///   "subjectAssignments": [
        ///     {
        ///       "id": "string (null for new)",
        ///       "subjectId": "string",
        ///       "position": "Trưởng BM",
        ///       "year": 2024,
        ///       "startDate": "2024-01-01",
        ///       "endDate": "2025-05-31"
        ///     }
        ///   ],
        ///   "deletedSubjectMappingIds": ["string"]
        /// }
        /// </remarks>
        [HttpPut("{teacherId}")]
        [PermissionAuthorize("TENANT:TEACHER:UPDATE")]
        public async Task<IActionResult> UpdateTeacher(
            string teacherId,
            [FromBody] UpdateTeacherCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa giáo viên (soft delete - xóa hoàn toàn)
        /// </summary>
        /// <remarks>
        /// DELETE /api/tenants/teachers/{teacherId}?tenantId={tenantId}&userTenantMappingId={userTenantMappingId}
        /// </remarks>
        [HttpDelete("{teacherId}")]
        [PermissionAuthorize("TENANT:TEACHER:DELETE")]
        public async Task<IActionResult> DeleteTeacher(
            string teacherId,
            [FromQuery] string tenantId,
            [FromQuery] string userTenantMappingId,
            CancellationToken cancellationToken = default)
        {
            var command = new DeleteTeacherCommand
            {
                TeacherId = teacherId,
                TenantId = tenantId,
                UserTenantMappingId = userTenantMappingId
            };

            return await SendAsync(command);
        }

        /// <summary>
        /// Đổi password giáo viên
        /// </summary>
        /// <remarks>
        /// POST /api/tenants/teachers/{teacherId}/change-password
        /// 
        /// Request body:
        /// {
        ///   "tenantId": "string",
        ///   "newPassword": "string"
        /// }
        /// </remarks>
        [HttpPost("{teacherId}/change-password")]
        [PermissionAuthorize("TENANT:TEACHER:UPDATE")]
        public async Task<IActionResult> ChangeTeacherPassword(
            string teacherId,
            [FromBody] ChangeTeacherPasswordCommand command,
            CancellationToken cancellationToken = default)
        {
            command.TeacherId = teacherId;
            return await SendAsync(command);
        }
    }
}
