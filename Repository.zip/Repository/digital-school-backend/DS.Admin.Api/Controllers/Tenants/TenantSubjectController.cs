using DS.Module.Tenant.Application.Commands.TenantSubjects;
using DS.Module.Tenant.Application.DTOs;
using DS.Module.Tenant.Application.Queries.TenantSubjects;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Tenants
{
    /// <summary>
    /// API Controller quản lý môn học của Tenant
    /// </summary>
    [Route("api/tenant-subjects")]
    [Authorize]
    [ApiController]
    public class TenantSubjectController : BaseAPIController
    {
        public TenantSubjectController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách môn học của Tenant
        /// </summary>
        [HttpPost("list")]
        [PermissionAuthorize("TENANT:SUBJECT:VIEW")]
        public async Task<IActionResult> GetList(
            [FromBody] GetTenantSubjectListQuery query,
            CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy danh sách môn học hệ thống để import vào Tenant
        /// Kết quả bao gồm flag IsImported để biết môn nào đã import
        /// </summary>
        [HttpPost("for-import")]
        [PermissionAuthorize("TENANT:SUBJECT:VIEW")]
        public async Task<IActionResult> GetSystemSubjectsForImport(
            [FromBody] GetSystemSubjectsForImportQuery query,
            CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Import các môn học hệ thống vào Tenant
        /// </summary>
        [HttpPost("import")]
        [PermissionAuthorize("TENANT:SUBJECT:CREATE")]
        public async Task<IActionResult> ImportSystemSubjects(
            [FromBody] ImportSystemSubjectsCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Lấy thông tin chi tiết một môn học
        /// </summary>
        [HttpGet("{tenantSubjectId}")]
        [PermissionAuthorize("TENANT:SUBJECT:VIEW")]
        public async Task<IActionResult> GetById(
            string tenantSubjectId,
            [FromQuery] string? tenantId,
            CancellationToken cancellationToken = default)
        {
            var query = new GetTenantSubjectByIdQuery { Id = tenantSubjectId, TenantId = tenantId };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo mới một môn học cho Tenant
        /// </summary>
        [HttpPost]
        [PermissionAuthorize("TENANT:SUBJECT:CREATE")]
        public async Task<IActionResult> Create(
            [FromBody] CreateTenantSubjectCommand command,
            CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(command, cancellationToken);
            return Ok(Result<TenantSubjectDto>.Success(result));
        }

        /// <summary>
        /// Cập nhật thông tin môn học
        /// </summary>
        [HttpPut("{tenantSubjectId}")]
        [PermissionAuthorize("TENANT:SUBJECT:UPDATE")]
        public async Task<IActionResult> Update(
            string tenantSubjectId,
            [FromBody] UpdateTenantSubjectCommand command,
            CancellationToken cancellationToken = default)
        {
            command.TenantSubjectId = tenantSubjectId;
            var result = await _mediator.Send(command, cancellationToken);
            return Ok(Result<TenantSubjectDto>.Success(result));
        }

        /// <summary>
        /// Xóa một môn học
        /// </summary>
        [HttpDelete("{tenantSubjectId}")]
        [PermissionAuthorize("TENANT:SUBJECT:DELETE")]
        public async Task<IActionResult> Delete(
            string tenantSubjectId,
            [FromQuery] string tenantId,
            CancellationToken cancellationToken = default)
        {
            var command = new DeleteTenantSubjectCommand
            {
                Id = tenantSubjectId,
                TenantId = tenantId
            };
            var result = await _mediator.Send(command, cancellationToken);
            if (result == true)
                return Ok(Result.Success());
            return BadRequest(Result.Failure());
        }
    }
}
