using DS.Module.Tenant.Application.Commands.Tenants;
using DS.Module.Tenant.Application.Queries.Tenants;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using DS.Shared.CQRS.Queries.Tenants;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Tenants
{
    [Route("api/tenants")]
    [Authorize]
    [ApiController]
    public class TenantController : BaseAPIController
    {
        public TenantController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách tenants với phân trang
        /// </summary>
        [HttpPost("list")]
        [PermissionAuthorize("TENANT:TENANT:VIEW")]
        public async Task<IActionResult> GetList([FromBody] GetTenantListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy danh sách tenants đã xóa (soft deleted)
        /// </summary>
        [HttpPost("deleted-list")]
        [PermissionAuthorize("TENANT:TENANT:VIEW_DELETED")]
        public async Task<IActionResult> GetDeletedList([FromBody] GetDeletedTenantListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy tenant theo ID
        /// </summary>
        [HttpGet("{tenantId}")]
        [PermissionAuthorize("TENANT:TENANT:VIEW")]
        public async Task<IActionResult> GetById(string tenantId, CancellationToken cancellationToken = default)
        {
            var query = new SharedGetTenantByIdQuery { TenantId = tenantId };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo tenant mới
        /// </summary>
        [HttpPost]
        [PermissionAuthorize("TENANT:TENANT:CREATE")]
        public async Task<IActionResult> Create([FromBody] CreateTenantCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Cập nhật tenant
        /// </summary>
        [HttpPut("{tenantId}")]
        [PermissionAuthorize("TENANT:TENANT:UPDATE")]
        public async Task<IActionResult> Update(string tenantId, [FromBody] UpdateTenantCommand command, CancellationToken cancellationToken = default)
        {
            command.TenantId = tenantId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa tenant (soft delete)
        /// </summary>
        [HttpDelete("{tenantId}")]
        [PermissionAuthorize("TENANT:TENANT:DELETE")]
        public async Task<IActionResult> Delete(string tenantId, CancellationToken cancellationToken = default)
        {
            var command = new DeleteTenantCommand { TenantId = tenantId };
            return await SendAsync(command);
        }
    }
}

