using DS.Shared.Core.Enums;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Tenants
{
    [Route("api/tenant-users")]
    [Authorize]
    [ApiController]
    public class UserTenantManagementController : BaseAPIController
    {
        private static readonly List<UserType> SchoolStaffAllowedTypes = [UserType.Principal, UserType.SchoolStaff];

        public UserTenantManagementController(IMediator mediator) : base(mediator)
        {
        }

        //[HttpPost("students/list")]
        //[PermissionAuthorize("TENANT:STUDENT:VIEW")]
        //public async Task<IActionResult> GetStudentList([FromBody] GetListUserTenantMapping data, CancellationToken cancellationToken = default)
        //{
        //    var result = await _mediator.Send(new GetUserTenantMappingListQuery
        //    {
        //        Types = new List<UserType>() { UserType.Student },
        //        TenantId = data.TenantId,
        //        Year = data.Year,
        //        IsActive = data.IsActive
        //    }, cancellationToken);
        //    return SuccessResponse(result);
        //}

        //[HttpGet("students/{id}")]
        //[PermissionAuthorize("TENANT:STUDENT:VIEW")]
        //public async Task<IActionResult> GetStudentById(string id, CancellationToken cancellationToken = default)
        //{
        //    var result = await _mediator.Send(new GetUserTenantMappingByIdQuery
        //    {
        //        UserTenantMappingId = id,
        //        ExpectedType = UserType.Student
        //    }, cancellationToken);
        //    if (result is null)
        //    {
        //        return NotFound();
        //    }
        //    return SuccessResponse(result);
        //};

        //[HttpPost("students")]
        //[PermissionAuthorize("TENANT:STUDENT:CREATE")]
        //public async Task<IActionResult> CreateStudent([FromBody] CreateUserTenantMappingCommand command, CancellationToken cancellationToken = default)
        //   => await CreateByType(command, UserType.Student, cancellationToken);

        //[HttpPut("students/{userTenantMappingId}")]
        //[PermissionAuthorize("TENANT:STUDENT:UPDATE")]
        //public async Task<IActionResult> UpdateStudent(string userTenantMappingId, [FromBody] UpdateUserTenantMappingCommand command, CancellationToken cancellationToken = default)
        //   => await UpdateByType(userTenantMappingId, command, UserType.Student);

        //    [HttpPost("teachers/list")]
        //    [PermissionAuthorize("TENANT:TEACHER:VIEW")]
        //    public async Task<IActionResult> GetTeacherList([FromBody] GetUserTenantMappingListQuery query, CancellationToken cancellationToken = default)
        //        => await GetListByType(query, UserType.Teacher, cancellationToken);

        //    [HttpPost("school-staffs/list")]
        //    [PermissionAuthorize("TENANT:SCHOOL_STAFF:VIEW")]
        //    public async Task<IActionResult> GetSchoolStaffList([FromBody] GetUserTenantMappingListQuery query, CancellationToken cancellationToken = default)
        //        => await GetSchoolStaffListByType(query, cancellationToken);



        //    [HttpGet("teachers/{userTenantMappingId}")]
        //    [PermissionAuthorize("TENANT:TEACHER:VIEW")]
        //    public async Task<IActionResult> GetTeacherById(string userTenantMappingId, CancellationToken cancellationToken = default)
        //        => await GetByIdWithType(userTenantMappingId, UserType.Teacher, cancellationToken);

        //    [HttpGet("school-staffs/{userTenantMappingId}")]
        //    [PermissionAuthorize("TENANT:SCHOOL_STAFF:VIEW")]
        //    public async Task<IActionResult> GetSchoolStaffById(string userTenantMappingId, [FromQuery] UserType? userType = null, CancellationToken cancellationToken = default)
        //        => await GetSchoolStaffByIdWithType(userTenantMappingId, userType, cancellationToken);



        //    [HttpPost("teachers")]
        //    [PermissionAuthorize("TENANT:TEACHER:UPDATE")]
        //    public async Task<IActionResult> CreateTeacher([FromBody] CreateUserTenantMappingCommand command, CancellationToken cancellationToken = default)
        //        => await CreateByType(command, UserType.Teacher, cancellationToken);

        //    [HttpPost("school-staffs")]
        //    [PermissionAuthorize("TENANT:SCHOOL_STAFF:UPDATE")]
        //    public async Task<IActionResult> CreateSchoolStaff([FromBody] CreateUserTenantMappingCommand command, CancellationToken cancellationToken = default)
        //        => await CreateSchoolStaffByType(command, cancellationToken);

        //    [HttpPut("teachers/{userTenantMappingId}")]
        //    [PermissionAuthorize("TENANT:TEACHER:UPDATE")]
        //    public async Task<IActionResult> UpdateTeacher(string userTenantMappingId, [FromBody] UpdateUserTenantMappingCommand command, CancellationToken cancellationToken = default)
        //        => await UpdateByType(userTenantMappingId, command, UserType.Teacher);

        //    [HttpPut("school-staffs/{userTenantMappingId}")]
        //    [PermissionAuthorize("TENANT:SCHOOL_STAFF:UPDATE")]
        //    public async Task<IActionResult> UpdateSchoolStaff(string userTenantMappingId, [FromBody] UpdateUserTenantMappingCommand command, [FromQuery] UserType? userType = null, CancellationToken cancellationToken = default)
        //        => await UpdateSchoolStaffByType(userTenantMappingId, command, userType);

        //    [HttpDelete("students/{userTenantMappingId}")]
        //    [PermissionAuthorize("TENANT:STUDENT:UPDATE")]
        //    public async Task<IActionResult> DeleteStudent(string userTenantMappingId, CancellationToken cancellationToken = default)
        //        => await DeleteByType(userTenantMappingId, UserType.Student);

        //    [HttpDelete("teachers/{userTenantMappingId}")]
        //    [PermissionAuthorize("TENANT:TEACHER:UPDATE")]
        //    public async Task<IActionResult> DeleteTeacher(string userTenantMappingId, CancellationToken cancellationToken = default)
        //        => await DeleteByType(userTenantMappingId, UserType.Teacher);

        //    [HttpDelete("school-staffs/{userTenantMappingId}")]
        //    [PermissionAuthorize("TENANT:SCHOOL_STAFF:UPDATE")]
        //    public async Task<IActionResult> DeleteSchoolStaff(string userTenantMappingId, [FromQuery] UserType? userType = null, CancellationToken cancellationToken = default)
        //        => await DeleteSchoolStaffByType(userTenantMappingId, userType);

        //    private async Task<IActionResult> GetListByType(GetUserTenantMappingListQuery query, UserType type, CancellationToken cancellationToken)
        //    {
        //        query.Type = type;
        //        query.Types = null;
        //        var result = await _mediator.Send(query, cancellationToken);
        //        return SuccessResponse(result);
        //    }

        //    private async Task<IActionResult> GetSchoolStaffListByType(GetUserTenantMappingListQuery query, CancellationToken cancellationToken)
        //    {
        //        if (query.Type.HasValue && !IsSchoolStaffType(query.Type.Value))
        //        {
        //            throw DSException.WithParam("InvalidSchoolStaffUserType", query.Type.Value.ToString());
        //        }

        //        query.Types = query.Type.HasValue
        //            ? [query.Type.Value]
        //            : [.. SchoolStaffAllowedTypes];
        //        query.Type = null;

        //        var result = await _mediator.Send(query, cancellationToken);
        //        return SuccessResponse(result);
        //    }

        //    private async Task<IActionResult> GetByIdWithType(string userTenantMappingId, UserType type, CancellationToken cancellationToken)
        //    {
        //        var query = new GetUserTenantMappingByIdQuery
        //        {
        //            UserTenantMappingId = userTenantMappingId,
        //            ExpectedType = type,
        //            ExpectedTypes = null
        //        };

        //        var result = await _mediator.Send(query, cancellationToken);
        //        if (result is null)
        //        {
        //            return NotFound();
        //        }

        //        return SuccessResponse(result);
        //    }

        //    private async Task<IActionResult> GetSchoolStaffByIdWithType(string userTenantMappingId, UserType? userType, CancellationToken cancellationToken)
        //    {
        //        if (userType.HasValue && !IsSchoolStaffType(userType.Value))
        //        {
        //            throw DSException.WithParam("InvalidSchoolStaffUserType", userType.Value.ToString());
        //        }

        //        var query = new GetUserTenantMappingByIdQuery
        //        {
        //            UserTenantMappingId = userTenantMappingId,
        //            ExpectedType = null,
        //            ExpectedTypes = userType.HasValue ? [userType.Value] : [.. SchoolStaffAllowedTypes]
        //        };

        //        var result = await _mediator.Send(query, cancellationToken);
        //        if (result is null)
        //        {
        //            return NotFound();
        //        }

        //        return SuccessResponse(result);
        //    }

        //    private async Task<IActionResult> CreateByType(CreateUserTenantMappingCommand command, UserType type, CancellationToken cancellationToken)
        //    {
        //        command.Type = type;
        //        return await SendAsync(command);
        //    }

        //    private async Task<IActionResult> CreateSchoolStaffByType(CreateUserTenantMappingCommand command, CancellationToken cancellationToken)
        //    {
        //        if (!IsSchoolStaffType(command.Type))
        //        {
        //            throw DSException.WithParam("InvalidSchoolStaffUserType", command.Type.ToString());
        //        }

        //        return await CreateByType(command, command.Type, cancellationToken);
        //    }

        //    private async Task<IActionResult> UpdateByType(string userTenantMappingId, UpdateUserTenantMappingCommand command, UserType type)
        //    {
        //        command.Id = userTenantMappingId;
        //        command.Type = type;
        //        return await SendAsync(command);
        //    }

        //    private async Task<IActionResult> UpdateSchoolStaffByType(string userTenantMappingId, UpdateUserTenantMappingCommand command, UserType? userType)
        //    {
        //        if (userType.HasValue && !IsSchoolStaffType(userType.Value))
        //        {
        //            throw DSException.WithParam("InvalidSchoolStaffUserType", userType.Value.ToString());
        //        }

        //        if (command.Type.HasValue && !IsSchoolStaffType(command.Type.Value))
        //        {
        //            throw DSException.WithParam("InvalidSchoolStaffUserType", command.Type.Value.ToString());
        //        }

        //        command.Id = userTenantMappingId;
        //        return await SendAsync(command);
        //    }

        //    private async Task<IActionResult> DeleteByType(string userTenantMappingId, UserType type)
        //    {
        //        var command = new DeleteUserTenantMappingCommand
        //        {
        //            UserTenantMappingId = userTenantMappingId,
        //            ExpectedType = type,
        //            ExpectedTypes = null
        //        };
        //        return await SendAsync(command);
        //    }

        //    private async Task<IActionResult> DeleteSchoolStaffByType(string userTenantMappingId, UserType? userType)
        //    {
        //        if (userType.HasValue && !IsSchoolStaffType(userType.Value))
        //        {
        //            throw DSException.WithParam("InvalidSchoolStaffUserType", userType.Value.ToString());
        //        }

        //        var command = new DeleteUserTenantMappingCommand
        //        {
        //            UserTenantMappingId = userTenantMappingId,
        //            ExpectedType = null,
        //            ExpectedTypes = userType.HasValue ? [userType.Value] : [.. SchoolStaffAllowedTypes]
        //        };

        //        return await SendAsync(command);
        //    }

        //    private static bool IsSchoolStaffType(UserType userType)
        //        => userType is UserType.Principal or UserType.SchoolStaff;
    }

    public record GetListUserTenantMapping
    {
        public int? Year { get; init; }
        public string? TenantId { get; init; }
        public UserType? Type { get; init; }
        public bool? IsActive { get; set; }
    }
}
