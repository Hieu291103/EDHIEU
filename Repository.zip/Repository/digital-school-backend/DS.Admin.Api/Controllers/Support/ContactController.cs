using DS.Module.Support.Application.Commands.Contacts;
using DS.Module.Support.Application.Queries.Contacts;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Support
{
    [Route("api/contact")]
    [Authorize]
    [ApiController]
    public class ContactController : BaseAPIController
    {
        public ContactController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách contact với phân trang và bộ lọc
        /// </summary>
        [HttpPost("list")]
        [PermissionAuthorize("SUPPORT:CONTACT:VIEW")]
        public async Task<IActionResult> GetList([FromBody] GetContactListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy chi tiết contact theo ID
        /// </summary>
        [HttpGet("{contactId}")]
        [PermissionAuthorize("SUPPORT:CONTACT:VIEW")]
        public async Task<IActionResult> GetById(string contactId, CancellationToken cancellationToken = default)
        {
            var query = new GetContactByIdQuery { ContactId = contactId };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo contact mới
        /// </summary>
        [HttpPost]
        [PermissionAuthorize("SUPPORT:CONTACT:CREATE")]
        public async Task<IActionResult> Create([FromBody] CreateContactCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Cập nhật thông tin contact
        /// </summary>
        [HttpPut("{contactId}")]
        [PermissionAuthorize("SUPPORT:CONTACT:UPDATE")]
        public async Task<IActionResult> Update(string contactId, [FromBody] UpdateContactCommand command, CancellationToken cancellationToken = default)
        {
            command.ContactId = contactId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa contact
        /// </summary>
        [HttpDelete("{contactId}")]
        [PermissionAuthorize("SUPPORT:CONTACT:DELETE")]
        public async Task<IActionResult> Delete(string contactId, [FromQuery] string? tenantId, CancellationToken cancellationToken = default)
        {
            var command = new DeleteContactCommand { ContactId = contactId, TenantId = tenantId };
            return await SendAsync(command);
        }
    }
}
