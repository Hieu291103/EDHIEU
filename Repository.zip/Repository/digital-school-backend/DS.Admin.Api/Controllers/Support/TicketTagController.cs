using DS.Module.Support.Application.Commands.TicketTags;
using DS.Module.Support.Application.Queries.TicketTags;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Support
{
    [Route("api/ticket-tag")]
    [Authorize]
    [ApiController]
    public class TicketTagController : BaseAPIController
    {
        public TicketTagController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách ticket tag với phân trang và bộ lọc
        /// </summary>
        [HttpPost("list")]
        [PermissionAuthorize("SUPPORT:TICKETTAG:VIEW")]
        public async Task<IActionResult> GetList([FromBody] GetTicketTagListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy chi tiết ticket tag theo ID
        /// </summary>
        [HttpGet("{ticketTagId}")]
        [PermissionAuthorize("SUPPORT:TICKETTAG:VIEW")]
        public async Task<IActionResult> GetById(string ticketTagId, CancellationToken cancellationToken = default)
        {
            var query = new GetTicketTagByIdQuery { TicketTagId = ticketTagId };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo ticket tag mới
        /// </summary>
        [HttpPost]
        [PermissionAuthorize("SUPPORT:TICKETTAG:CREATE")]
        public async Task<IActionResult> Create([FromBody] CreateTicketTagCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Cập nhật thông tin ticket tag
        /// </summary>
        [HttpPut("{ticketTagId}")]
        [PermissionAuthorize("SUPPORT:TICKETTAG:UPDATE")]
        public async Task<IActionResult> Update(string ticketTagId, [FromBody] UpdateTicketTagCommand command, CancellationToken cancellationToken = default)
        {
            command.TicketTagId = ticketTagId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa ticket tag
        /// </summary>
        [HttpDelete("{ticketTagId}")]
        [PermissionAuthorize("SUPPORT:TICKETTAG:DELETE")]
        public async Task<IActionResult> Delete(string ticketTagId, CancellationToken cancellationToken = default)
        {
            var command = new DeleteTicketTagCommand { TicketTagId = ticketTagId };
            return await SendAsync(command);
        }
    }
}
