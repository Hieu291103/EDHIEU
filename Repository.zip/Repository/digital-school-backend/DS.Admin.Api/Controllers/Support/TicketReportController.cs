using DS.Module.Support.Application.Reports.Tickets;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Support
{
    [Route("api/ticket/report")]
    [ApiController]
    public class TicketReportController : BaseAPIController
    {
        public TicketReportController(IMediator mediator) : base(mediator)
        {

        }

        /// <summary>
        /// Lấy thống kê ticket theo ngày
        /// </summary>
        [HttpGet("statistic-by-day")]
        [BasicAuthorize]
        public async Task<IActionResult> GetStatisticByDay([FromQuery] DateTime date, CancellationToken cancellationToken = default)
        {
            var query = new StatisticTicketByDayQuery { Date = date };
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy thống kê ticket theo tuần
        /// </summary>
        [HttpGet("statistic-by-week")]
        [BasicAuthorize]
        public async Task<IActionResult> GetStatisticByWeek([FromQuery] DateTime startDate, [FromQuery] DateTime endDate, CancellationToken cancellationToken = default)
        {
            var query = new StatisticTicketByWeekQuery { StartDate = startDate, EndDate = endDate };
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy thống kê ticket theo người dùng tạo trong tháng
        /// Kết quả trả về dạng pivot table với các cột từ ngày 1 đến 31
        /// </summary>
        [HttpGet("statistic-user-created-by-month")]
        [BasicAuthorize]
        public async Task<IActionResult> GetStatisticUserCreatedByMonth([FromQuery] int year, [FromQuery] int month, CancellationToken cancellationToken = default)
        {
            var query = new StatisticTicketUserCreatedByMonthQuery { Year = year, Month = month };
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }
    }
}
