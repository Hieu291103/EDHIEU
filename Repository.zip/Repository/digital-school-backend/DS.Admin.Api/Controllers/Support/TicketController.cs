using DS.Module.Support.Application.Commands.TicketActivities;
using DS.Module.Support.Application.Commands.Tickets;
using DS.Module.Support.Application.Queries.TicketActivities;
using DS.Module.Support.Application.Queries.Tickets;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Support
{
    [Route("api/ticket")]
    [Authorize]
    [ApiController]
    public class TicketController : BaseAPIController
    {
        public TicketController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách ticket với phân trang và bộ lọc
        /// </summary>
        [HttpPost("list")]
        [PermissionAuthorize("SUPPORT:TICKET:VIEW")]
        public async Task<IActionResult> GetList([FromBody] GetTicketListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy danh sách ticket đã xóa mềm
        /// </summary>
        [HttpPost("list-deleted")]
        [PermissionAuthorize("SUPPORT:TICKET:SOFT_DELETE")]
        public async Task<IActionResult> GetDeletedList([FromBody] GetDeletedTicketListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy chi tiết ticket theo ID
        /// </summary>
        [HttpGet("{ticketId}")]
        [PermissionAuthorize("SUPPORT:TICKET:VIEW")]
        public async Task<IActionResult> GetById(string ticketId, CancellationToken cancellationToken = default)
        {
            var query = new GetTicketByIdQuery { TicketId = ticketId };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy chi tiết ticket theo Code (mã ticket)
        /// </summary>
        [HttpGet("code/{code}")]
        [PermissionAuthorize("SUPPORT:TICKET:VIEW")]
        public async Task<IActionResult> GetByCode(string code, CancellationToken cancellationToken = default)
        {
            var query = new GetTicketByCodeQuery { Code = code };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo ticket mới
        /// </summary>
        [HttpPost]
        [PermissionAuthorize("SUPPORT:TICKET:CREATE")]
        public async Task<IActionResult> Create([FromBody] CreateTicketCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Cập nhật thông tin ticket
        /// </summary>
        [HttpPut("{ticketId}")]
        [PermissionAuthorize("SUPPORT:TICKET:UPDATE")]
        public async Task<IActionResult> Update(string ticketId, [FromBody] UpdateTicketCommand command, CancellationToken cancellationToken = default)
        {
            command.TicketId = ticketId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Cập nhật partial thông tin ticket (chỉ những trường khác null)
        /// </summary>
        [HttpPut("{ticketId}/change")]
        [PermissionAuthorize("SUPPORT:TICKET:UPDATE")]
        public async Task<IActionResult> Change(string ticketId, [FromBody] ChangeTicketCommand command, CancellationToken cancellationToken = default)
        {
            command.Id = ticketId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa ticket (soft delete)
        /// </summary>
        [HttpDelete("{ticketId}")]
        [PermissionAuthorize("SUPPORT:TICKET:DELETE")]
        public async Task<IActionResult> Delete(string ticketId, CancellationToken cancellationToken = default)
        {
            var command = new DeleteTicketCommand { TicketId = ticketId };
            return await SendAsync(command);
        }

        /// <summary>
        /// Khôi phục ticket đã xóa mềm
        /// </summary>
        [HttpPut("{ticketId}/restore")]
        [PermissionAuthorize("SUPPORT:TICKET:SOFT_DELETE")]
        public async Task<IActionResult> Restore(string ticketId, CancellationToken cancellationToken = default)
        {
            var command = new RestoreTicketCommand { TicketId = ticketId };
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa hoàn toàn ticket
        /// </summary>
        [HttpDelete("{ticketId}/permanent")]
        [PermissionAuthorize("SUPPORT:TICKET:SOFT_DELETE")]
        public async Task<IActionResult> HardDelete(string ticketId, CancellationToken cancellationToken = default)
        {
            var command = new HardDeleteTicketCommand { TicketId = ticketId };
            return await SendAsync(command);
        }

        /// <summary>
        /// Gán người xử lý cho ticket
        /// </summary>
        [HttpPost("{ticketId}/assign")]
        [PermissionAuthorize("SUPPORT:TICKET:UPDATE")]
        public async Task<IActionResult> Assign(string ticketId, [FromBody] AssignTicketCommand command, CancellationToken cancellationToken = default)
        {
            command.TicketId = ticketId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa người xử lý khỏi ticket
        /// </summary>
        [HttpDelete("{ticketId}/assign/{userId}")]
        [PermissionAuthorize("SUPPORT:TICKET:UPDATE")]
        public async Task<IActionResult> DeleteAssign(string ticketId, string userId, CancellationToken cancellationToken = default)
        {
            var command = new DeleteAssignTicketCommand
            {
                TicketId = ticketId,
                UserId = userId
            };

            return await SendAsync(command);
        }

        /// <summary>
        /// Thêm attachment vào ticket
        /// </summary>
        [HttpPost("{ticketId}/attachments")]
        [PermissionAuthorize("SUPPORT:TICKET:UPDATE")]
        public async Task<IActionResult> CreateAttachment(string ticketId, [FromBody] CreateAttachmentTicketCommand command, CancellationToken cancellationToken = default)
        {
            command.TicketId = ticketId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa attachment khỏi ticket
        /// </summary>
        [HttpDelete("{ticketId}/attachments")]
        [PermissionAuthorize("SUPPORT:TICKET:UPDATE")]
        public async Task<IActionResult> DeleteAttachment(string ticketId, [FromBody] DeleteAttachmentTicketCommand command, CancellationToken cancellationToken = default)
        {
            command.TicketId = ticketId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Thay đổi trạng thái ticket
        /// </summary>
        [HttpPut("{ticketId}/status")]
        [PermissionAuthorize("SUPPORT:TICKET:UPDATE")]
        public async Task<IActionResult> ChangeStatus(string ticketId, [FromBody] ChangeTicketStatusCommand command, CancellationToken cancellationToken = default)
        {
            command.TicketId = ticketId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Đánh dấu ticket đã được giải quyết
        /// </summary>
        [HttpPut("{ticketId}/resolve")]
        [PermissionAuthorize("SUPPORT:TICKET:UPDATE")]
        public async Task<IActionResult> Resolve(string ticketId, [FromBody] ResolveTicketCommand command, CancellationToken cancellationToken = default)
        {
            command.TicketId = ticketId;
            return await SendAsync(command);
        }


        /// <summary>
        /// Tạo ticket mới từ crisp
        /// </summary>
        [HttpPost("crisp/create")]
        [PermissionAuthorize("SUPPORT:TICKET:CREATE")]
        public async Task<IActionResult> CreateFromCrisp([FromBody] CreateTicketFromCrispCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Lấy thông tin ticket mới từ crisp
        /// </summary>
        [HttpPost("crisp/create-request")]
        [PermissionAuthorize("SUPPORT:TICKET:CREATE")]
        public async Task<IActionResult> CreateFromRequestCrisp([FromBody] GetTicketInfoFromCrispQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy lịch sử ticket của khách hàng từ Crisp session
        /// </summary>
        [HttpPost("crisp/history")]
        [PermissionAuthorize("SUPPORT:TICKET:VIEW")]
        public async Task<IActionResult> GetHistoryFromCrisp([FromBody] GetTicketHistoryFromCrispQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        #region TicketActivity Management

        /// <summary>
        /// Lấy danh sách hoạt động (activities) của một ticket
        /// </summary>
        /// <remarks>
        /// GET /api/ticket/{ticketId}/activities
        /// </remarks>
        [HttpGet("{ticketId}/activities")]
        [PermissionAuthorize("SUPPORT:TICKET:VIEW")]
        public async Task<IActionResult> GetTicketActivities(string ticketId, CancellationToken cancellationToken = default)
        {
            var query = new GetTicketActivitiesQuery { TicketId = ticketId };
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo hoạt động (activity) mới cho ticket
        /// </summary>
        /// <remarks>
        /// POST /api/ticket/{ticketId}/activities
        /// 
        /// Request body:
        /// {
        ///   "content": "Ghi chú hoặc bình luận",
        ///   "activityType": "Note" (or "Call", etc.)
        /// }
        /// </remarks>
        [HttpPost("{ticketId}/activities")]
        [PermissionAuthorize("SUPPORT:TICKET:UPDATE")]
        public async Task<IActionResult> CreateTicketActivity(string ticketId, [FromBody] CreateTicketActivityCommand command, CancellationToken cancellationToken = default)
        {
            command.TicketId = ticketId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Cập nhật hoạt động (activity) của ticket
        /// </summary>
        /// <remarks>
        /// PUT /api/ticket/{ticketId}/activities/{activityId}
        /// 
        /// Request body:
        /// {
        ///   "content": "Nội dung mới",
        ///   "activityType": "Note"
        /// }
        /// </remarks>
        [HttpPut("{ticketId}/activities/{activityId}")]
        [PermissionAuthorize("SUPPORT:TICKET:UPDATE")]
        public async Task<IActionResult> UpdateTicketActivity(string ticketId, string activityId, [FromBody] UpdateTicketActivityCommand command, CancellationToken cancellationToken = default)
        {
            command.ActivityId = activityId;
            command.TicketId = ticketId;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa hoạt động (activity) của ticket
        /// </summary>
        /// <remarks>
        /// DELETE /api/ticket/{ticketId}/activities/{activityId}
        /// </remarks>
        //[HttpDelete("{ticketId}/activities/{activityId}")]
        //[PermissionAuthorize("SUPPORT:TICKET:UPDATE")]
        //public async Task<IActionResult> DeleteTicketActivity(string ticketId, string activityId, CancellationToken cancellationToken = default)
        //{
        //    var command = new DeleteTicketActivityCommand
        //    {
        //        ActivityId = activityId,
        //        TicketId = ticketId
        //    };
        //    return await SendAsync(command);
        //}

        #endregion
    }
}
