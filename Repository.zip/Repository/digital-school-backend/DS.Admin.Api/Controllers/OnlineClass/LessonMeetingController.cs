using DS.Module.OnlineClass.Application.Commands.LessonMeetings;
using DS.Module.OnlineClass.Application.Queries.LessonMeetings;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.OnlineClass
{
    /// <summary>
    /// API for managing lesson meetings in online classes
    /// Handles CRUD operations for LessonMeeting
    /// </summary>
    [Route("api/lesson-meeting")]
    [Authorize]
    [ApiController]
    public class LessonMeetingController : BaseAPIController
    {
        public LessonMeetingController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Get list of lesson meetings for a tenant with filtering and search
        /// </summary>
        /// <param name="query">Query parameters containing TenantId, Status, Keyword and pagination</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Paginated list of lesson meetings</returns>
        /// <remarks>
        /// Example: POST /api/lesson-meeting/list
        /// {
        ///     "tenantId": "tenant-123",
        ///     "status": 0,
        ///     "keyword": "Toán học",
        ///     "page": 1,
        ///     "pageSize": 10
        /// }
        /// Status: 0=Active, 1=Ended, 2=Cancelled (optional)
        /// Keyword searches in Title and Description
        /// </remarks>
        [HttpPost("list")]
        [PermissionAuthorize("ONLINE_CLASS:LESSON_MEETING:VIEW")]
        public async Task<IActionResult> GetList(
            [FromBody] GetLessonMeetingListQuery query,
            CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Get lesson meeting details by ID
        /// </summary>
        /// <param name="id">Lesson meeting ID</param>
        /// <param name="tenantId">Tenant ID</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Lesson meeting details</returns>
        /// <remarks>
        /// Example: GET /api/lesson-meeting/lesson-123?tenantId=tenant-456
        /// </remarks>
        [HttpGet("{id}")]
        [PermissionAuthorize("ONLINE_CLASS:LESSON_MEETING:VIEW")]
        public async Task<IActionResult> GetById(
            [FromRoute] string id,
            CancellationToken cancellationToken = default)
        {
            var query = new GetLessonMeetingByIdQuery
            {
                Id = id,
            };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Create a new lesson meeting
        /// </summary>
        /// <param name="command">Command containing lesson meeting details</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result of creation operation with created lesson meeting details</returns>
        /// <remarks>
        /// Example: POST /api/lesson-meeting
        /// {
        ///     "tenantId": "tenant-123",
        ///     "title": "Buổi học Toán",
        ///     "description": "Chương 1: Phương trình bậc nhất",
        ///     "classId": "class-456",
        ///     "subject": "Mathematics",
        ///     "startTime": "2024-01-15T09:00:00Z",
        ///     "endTime": "2024-01-15T10:30:00Z",
        ///     "timeZone": "SE Asia Standard Time",
        ///     "allowRecording": true
        /// }
        /// </remarks>
        [HttpPost]
        [PermissionAuthorize("ONLINE_CLASS:LESSON_MEETING:CREATE")]
        public async Task<IActionResult> Create(
            [FromBody] CreateLessonMeetingCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Update an existing lesson meeting
        /// </summary>
        /// <param name="command">Command containing updated lesson meeting details</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result of update operation</returns>
        /// <remarks>
        /// Example: PUT /api/lesson-meeting
        /// {
        ///     "id": "lesson-123",
        ///     "tenantId": "tenant-456",
        ///     "title": "Updated lesson title",
        ///     "description": "Updated description",
        ///     "startTime": "2024-01-16T09:00:00Z",
        ///     "endTime": "2024-01-16T10:30:00Z",
        ///     "allowRecording": false
        /// }
        /// </remarks>
        [HttpPut]
        [PermissionAuthorize("ONLINE_CLASS:LESSON_MEETING:UPDATE")]
        public async Task<IActionResult> Update(
            [FromBody] UpdateLessonMeetingCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Cancel a lesson meeting
        /// </summary>
        /// <param name="command">Command containing ID and TenantId of the lesson to cancel</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result of cancellation operation</returns>
        /// <remarks>
        /// Example: PATCH /api/lesson-meeting/cancel
        /// {
        ///     "id": "lesson-123",
        ///     "tenantId": "tenant-456",
        ///     "reason": "Lý do hủy bỏ"
        /// }
        /// Note: Can only cancel lessons that haven't ended yet
        /// </remarks>
        [HttpPatch("cancel")]
        [PermissionAuthorize("ONLINE_CLASS:LESSON_MEETING:UPDATE")]
        public async Task<IActionResult> Cancel(
            [FromBody] CancelLessonMeetingCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Delete a lesson meeting permanently
        /// </summary>
        /// <param name="id">Lesson meeting ID</param>
        /// <param name="tenantId">Tenant ID</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result of deletion operation</returns>
        /// <remarks>
        /// Example: DELETE /api/lesson-meeting/lesson-123?tenantId=tenant-456
        /// Permanently removes the lesson from the database and cancels associated Teams meeting
        /// </remarks>
        [HttpDelete("{id}")]
        [PermissionAuthorize("ONLINE_CLASS:LESSON_MEETING:DELETE")]
        public async Task<IActionResult> Delete(
            [FromRoute] string id,
            CancellationToken cancellationToken = default)
        {
            var command = new DeleteLessonMeetingCommand
            {
                Id = id
            };
            return await SendAsync(command);
        }

    }
}
