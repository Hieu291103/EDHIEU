using DS.Module.OnlineClass.Application.Commands.PartnerOneZoomMeetingEntitys;
using DS.Module.OnlineClass.Application.Queries.OnlineClassTenants;
using DS.Module.OnlineClass.Application.Queries.PartnerOneZoomMeetingEntitys;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.OnlineClass
{
    [Route("api/one-zoom-partner")]
    [ApiController]
    public class OneZoomPartnerController : BaseAPIController
    {
        public OneZoomPartnerController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách thống kê buổi học Zoom theo từng trường sử dụng Zoom (realtime)
        /// </summary>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Danh sách thống kê: số buổi học đang hoạt động, hôm nay, chưa bắt đầu hôm nay, trong 2h tới, đã kết thúc hôm nay</returns>
        [HttpGet("tenant")]
        [PermissionAuthorize("ONLINE_CLASS:ONE_ZOOM:VIEW")]
        public async Task<IActionResult> GetZoomMeetingOnlineClassTenantList(CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(new GetZoomMeetingOnlineClassTenantListQuery(), cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy thông tin license OneZoom và danh sách meeting theo khoảng thời gian
        /// </summary>
        /// <param name="query">Tham số lọc: FromDate, ToDate, ZoomCode (tuỳ chọn)</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Thông tin license (TotalLicenses, CurrentActiveRooms) và danh sách meeting</returns>
        /// <remarks>
        /// Example: GET /api/lesson-meeting/onezoom-license?FromDate=2024-01-01&amp;ToDate=2024-01-31
        /// </remarks>
        [HttpGet()]
        [PermissionAuthorize("ONLINE_CLASS:ONE_ZOOM:VIEW")]
        public async Task<IActionResult> GetOneZoomLicenseInfo(
            [FromQuery] GetLicenseInfoOneZoomMeetingQuery query,
            CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Xóa OneZoom meeting và lesson meeting tương ứng
        /// </summary>
        /// <param name="lessonMeetingId">Id buổi học cần xóa</param>
        /// <param name="cancellationToken">Cancellation token</param>
        [HttpDelete("lesson-meeting/{lessonMeetingId}")]
        [PermissionAuthorize("ONLINE_CLASS:ONE_ZOOM:DELETE")]
        public async Task<IActionResult> DeleteOneZoomMeeting(
            [FromRoute] string lessonMeetingId,
            CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(
                new DeleteOneZoomMeetingAndLessionMeetingCommand { LessonMeetingId = lessonMeetingId },
                cancellationToken);
            return SuccessResponse(result);
        }
    }
}
