using DS.Module.OnlineClass.Application.Commands.AccountMeetings;
using DS.Module.OnlineClass.Application.Commands.OnlineClassTenantClass;
using DS.Module.OnlineClass.Application.Commands.OnlineClassTenants;
using DS.Module.OnlineClass.Application.Queries.AccountMeetings;
using DS.Module.OnlineClass.Application.Queries.OnlineClassTenantClass;
using DS.Module.OnlineClass.Application.Queries.OnlineClassTenants;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.OnlineClass
{
    /// <summary>
    /// API for managing online class configurations
    /// Handles CRUD operations for OnlineClassTenant
    /// </summary>
    [Route("api/online-class-tenant")]
    [Authorize]
    [ApiController]
    public class OnlineClassTenantController : BaseAPIController
    {
        public OnlineClassTenantController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Get list of online class configurations with pagination
        /// </summary>
        /// <param name="query">Query parameters for filtering and pagination</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Paginated list of online class configurations</returns>
        /// <remarks>
        /// Filter by TenantId, SchoolId, ProviderMeetingType, IsActive status
        /// Example: POST /api/online-classes/list
        /// </remarks>
        [HttpPost("list")]
        [PermissionAuthorize("ONLINE_CLASS:TENANT:VIEW")]
        public async Task<IActionResult> GetList(
            [FromBody] GetOnlineClassTenantListQuery query,
            CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Get online class configuration by TenantId
        /// </summary>
        /// <param name="tenantId">Tenant ID</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Online class configuration details</returns>
        /// <remarks>
        /// Example: GET /api/online-class-tenant?tenantId=tenant-456
        /// </remarks>
        [HttpGet]
        [PermissionAuthorize("ONLINE_CLASS:TENANT:VIEW")]
        public async Task<IActionResult> GetById(
            [FromQuery] string tenantId,
            CancellationToken cancellationToken = default)
        {
            var query = new GetOnlineClassTenantByIdQuery
            {
                TenantId = tenantId
            };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Create new online class configuration
        /// </summary>
        /// <param name="command">Command containing configuration details</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result of creation operation</returns>
        /// <remarks>
        /// Example: POST /api/online-classes
        /// {
        ///     "tenantId": "tenant-123",
        ///     "providerMeetingType": 0,
        ///     "providerConnect": "teams.microsoft.com",
        ///     "schoolId": 456,
        ///     "startDate": "2024-01-01T00:00:00Z",
        ///     "expireDate": "2025-01-01T00:00:00Z"
        /// }
        /// </remarks>
        [HttpPost]
        [PermissionAuthorize("ONLINE_CLASS:TENANT:CREATE")]
        public async Task<IActionResult> Create(
            [FromBody] CreateOnlineClassTenantCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Update existing online class configuration for a tenant
        /// </summary>
        /// <param name="command">Command containing updated values</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result of update operation</returns>
        /// <remarks>
        /// Example: PUT /api/online-class-tenant
        /// {
        ///     "tenantId": "tenant-123",
        ///     "providerMeetingType": 1,
        ///     "providerConnect": "zoom.us",
        ///     "expireDate": "2026-01-01T00:00:00Z"
        /// }
        /// </remarks>
        [HttpPut]
        [PermissionAuthorize("ONLINE_CLASS:TENANT:UPDATE")]
        public async Task<IActionResult> Update(
            [FromBody] UpdateOnlineClassTenantCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Delete all online class configurations for a tenant (soft delete)
        /// </summary>
        /// <param name="tenantId">Tenant ID to delete</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result of deletion operation</returns>
        /// <remarks>
        /// Example: DELETE /api/online-class-tenant?tenantId=tenant-123
        /// Soft deletes all configurations for the tenant (marks as deleted, doesn't remove from database)
        /// </remarks>
        [HttpDelete]
        [PermissionAuthorize("ONLINE_CLASS:TENANT:DELETE")]
        public async Task<IActionResult> Delete(
            [FromQuery] string tenantId,
            CancellationToken cancellationToken = default)
        {
            var command = new DeleteOnlineClassTenantCommand
            {
                TenantId = tenantId
            };
            return await SendAsync(command);
        }

        /// <summary>
        /// Update the active status of online class configuration for a tenant
        /// When IsActive is set to false, all associated AccountMeetings will be deleted
        /// </summary>
        /// <param name="command">Command containing TenantId and IsActive status</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result of status update operation</returns>
        /// <remarks>
        /// Example: PATCH /api/online-class-tenant/status
        /// {
        ///     "tenantId": "tenant-123",
        ///     "isActive": false
        /// }
        /// Note: When IsActive is false, all AccountMeetings for this tenant will be deleted from MSTeams and database
        /// </remarks>
        [HttpPatch("status")]
        [PermissionAuthorize("ONLINE_CLASS:TENANT:UPDATE")]
        public async Task<IActionResult> UpdateStatus(
            [FromBody] UpdateOnlineClassTenantStatusCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        #region Account Meeting Endpoints

        /// <summary>
        /// Get list of account meetings for a tenant
        /// </summary>
        /// <param name="query">Query parameters for filtering</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>List of account meetings</returns>
        /// <remarks>
        /// Example: POST /api/online-class-tenant/account-meeting/list
        /// {
        ///     "tenantId": "tenant-123"
        /// }
        /// </remarks>
        [HttpPost("account-meeting/list")]
        [PermissionAuthorize("ONLINE_CLASS:TENANT:VIEW")]
        public async Task<IActionResult> GetAccountMeetingList(
            [FromBody] GetAccountMeetingTeacherListQuery query,
            CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Create or update account meetings for multiple users
        /// </summary>
        /// <param name="command">Command containing user IDs and tenant information</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result of creation/update operation</returns>
        /// <remarks>
        /// Example: POST /api/online-class-tenant/account-meeting
        /// {
        ///     "userId": ["user-1", "user-2", "user-3"],
        ///     "tenantId": "tenant-123"
        /// }
        /// Creates accounts in MSTeams if they don't exist, otherwise updates existing ones
        /// </remarks>
        [HttpPost("account-meeting")]
        [PermissionAuthorize("ONLINE_CLASS:TENANT:UPDATE")]
        public async Task<IActionResult> CreateOrUpdateAccountMeeting(
            [FromBody] CreateOrUpdateAccountMeetingTeacherCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Delete account meetings for multiple users
        /// </summary>
        /// <param name="tenantId">Tenant ID</param>
        /// <param name="userIds">List of user IDs to delete</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result of deletion operation</returns>
        /// <remarks>
        /// Example: DELETE /api/online-class-tenant/account-meeting?tenantId=tenant-123
        /// Body: ["user-1", "user-2"]
        /// Deletes accounts from MSTeams and database
        /// </remarks>
        [HttpPut("account-meeting/delete")]
        [PermissionAuthorize("ONLINE_CLASS:TENANT:DELETE")]
        public async Task<IActionResult> DeleteAccountMeeting(
            [FromBody] DeleteAccountMeetingCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Reset password for an account meeting
        /// </summary>
        /// <param name="command">Command containing user ID and tenant information</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result of password reset operation</returns>
        /// <remarks>
        /// Example: PATCH /api/online-class-tenant/account-meeting/reset-password
        /// {
        ///     "userId": "user-123",
        ///     "tenantId": "tenant-456"
        /// }
        /// Generates new password and updates it in MSTeams
        /// </remarks>
        [HttpPatch("account-meeting/reg-teams")]
        [PermissionAuthorize("ONLINE_CLASS:TENANT:UPDATE")]
        public async Task<IActionResult> RegTeamsAccountMeeting(
            [FromBody] RegTeamsAccountMeetingCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        #endregion

        #region OnlineClassTenantClass Endpoints

        /// <summary>
        /// Get list of online class tenant classes for a specific school year
        /// </summary>
        /// <param name="query">Query parameters containing TenantId and SchoolYear</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>List of online class tenant classes</returns>
        /// <remarks>
        /// Example: POST /api/online-class-tenant/online-class-tenant-class/list
        /// {
        ///     "tenantId": "school-tenant-123",
        ///     "schoolYear": 2024
        /// }
        /// </remarks>
        [HttpPost("tenant-class/list")]
        [PermissionAuthorize("ONLINE_CLASS:TENANT:VIEW")]
        public async Task<IActionResult> GetOnlineClassTenantClassList(
            [FromBody] GetOnlineClassTenantClassListQuery query,
            CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Create or update online class tenant classes from Onluyen data
        /// Syncs classes from Onluyen and creates/updates them in the system
        /// Deactivates classes from other school years
        /// </summary>
        /// <param name="command">Command containing TenantId, SchoolYear, and optional ClassIds</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result of creation/update operation</returns>
        /// <remarks>
        /// Example: POST /api/online-class-tenant/online-class-tenant-class
        /// {
        ///     "tenantId": "tenant-123",
        ///     "schoolYear": 2024,
        ///     "classIds": ["class-1", "class-2"],
        ///     "isActive": true
        /// }
        /// If ClassIds is empty, all classes for the school year will be synced
        /// Classes from other school years will be deactivated
        /// </remarks>
        [HttpPost("tenant-class")]
        [PermissionAuthorize("ONLINE_CLASS:TENANT:UPDATE")]
        public async Task<IActionResult> CreateOrUpdateOnlineClassTenantClass(
            [FromBody] CreateOrUpdateOnlineClassTenantClassCommand command,
            CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        #endregion



    }
}
