using DS.Module.Hrm.Application.Commands.Departments;
using DS.Module.Hrm.Application.Queries.Departments;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Hrm
{
    [Route("api/hrm/department")]
    [Authorize]
    [ApiController]
    public class DepartmentController : BaseAPIController
    {
        public DepartmentController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách phòng ban với phân trang và bộ lọc
        /// </summary>
        [HttpPost("list")]
        [PermissionAuthorize("HRM:DEPARTMENT:VIEW")]
        public async Task<IActionResult> GetList([FromBody] GetDepartmentListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy chi tiết phòng ban theo ID
        /// </summary>
        [HttpGet("{id}")]
        [PermissionAuthorize("HRM:DEPARTMENT:VIEW")]
        public async Task<IActionResult> GetById(string id, CancellationToken cancellationToken = default)
        {
            var query = new GetDepartmentByIdQuery { Id = id };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo phòng ban mới
        /// </summary>
        [HttpPost]
        [PermissionAuthorize("HRM:DEPARTMENT:CREATE")]
        public async Task<IActionResult> Create([FromBody] CreateDepartmentCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Cập nhật thông tin phòng ban
        /// </summary>
        [HttpPut("{id}")]
        [PermissionAuthorize("HRM:DEPARTMENT:UPDATE")]
        public async Task<IActionResult> Update(string id, [FromBody] UpdateDepartmentCommand command, CancellationToken cancellationToken = default)
        {
            command.Id = id;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa phòng ban
        /// </summary>
        [HttpDelete("{id}")]
        [PermissionAuthorize("HRM:DEPARTMENT:DELETE")]
        public async Task<IActionResult> Delete(string id, CancellationToken cancellationToken = default)
        {
            var command = new DeleteDepartmentCommand { Id = id };
            return await SendAsync(command);
        }
    }
}
