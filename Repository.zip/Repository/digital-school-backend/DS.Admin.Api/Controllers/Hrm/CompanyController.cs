using DS.Module.Hrm.Application.Commands.Companies;
using DS.Module.Hrm.Application.Queries.Companies;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Hrm
{
    [Route("api/hrm/company")]
    [Authorize]
    [ApiController]
    public class CompanyController : BaseAPIController
    {
        public CompanyController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách công ty với phân trang và bộ lọc
        /// </summary>
        [HttpPost("list")]
        [PermissionAuthorize("HRM:COMPANY:VIEW")]
        public async Task<IActionResult> GetList([FromBody] GetCompanyListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy chi tiết công ty theo ID
        /// </summary>
        [HttpGet("{id}")]
        [PermissionAuthorize("HRM:COMPANY:VIEW")]
        public async Task<IActionResult> GetById(string id, CancellationToken cancellationToken = default)
        {
            var query = new GetCompanyByIdQuery { Id = id };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo công ty mới
        /// </summary>
        [HttpPost]
        [PermissionAuthorize("HRM:COMPANY:CREATE")]
        public async Task<IActionResult> Create([FromBody] CreateCompanyCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Cập nhật thông tin công ty
        /// </summary>
        [HttpPut("{id}")]
        [PermissionAuthorize("HRM:COMPANY:UPDATE")]
        public async Task<IActionResult> Update(string id, [FromBody] UpdateCompanyCommand command, CancellationToken cancellationToken = default)
        {
            command.Id = id;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa công ty
        /// </summary>
        [HttpDelete("{id}")]
        [PermissionAuthorize("HRM:COMPANY:DELETE")]
        public async Task<IActionResult> Delete(string id, CancellationToken cancellationToken = default)
        {
            var command = new DeleteCompanyCommand { Id = id };
            return await SendAsync(command);
        }
    }
}
