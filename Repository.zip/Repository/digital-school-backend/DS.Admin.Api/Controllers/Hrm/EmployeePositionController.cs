using DS.Module.Hrm.Application.Commands.Positions;
using DS.Module.Hrm.Application.Queries.Positions;
using DS.Shared.Core.Infrastructure.Attributes;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Hrm
{
    [Route("api/hrm/employee-position")]
    [Authorize]
    [ApiController]
    public class EmployeePositionController : BaseAPIController
    {
        public EmployeePositionController(IMediator mediator) : base(mediator)
        {
        }

        /// <summary>
        /// Lấy danh sách chức vụ với phân trang và bộ lọc
        /// </summary>
        [HttpPost("list")]
        [PermissionAuthorize("HRM:POSITION:VIEW")]
        public async Task<IActionResult> GetList([FromBody] GetEmployeePositionListQuery query, CancellationToken cancellationToken = default)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        /// <summary>
        /// Lấy chi tiết chức vụ theo ID
        /// </summary>
        [HttpGet("{id}")]
        [PermissionAuthorize("HRM:POSITION:VIEW")]
        public async Task<IActionResult> GetById(string id, CancellationToken cancellationToken = default)
        {
            var query = new GetEmployeePositionByIdQuery { Id = id };
            var result = await _mediator.Send(query, cancellationToken);

            if (result is null)
            {
                return NotFound();
            }

            return SuccessResponse(result);
        }

        /// <summary>
        /// Tạo chức vụ mới
        /// </summary>
        [HttpPost]
        [PermissionAuthorize("HRM:POSITION:CREATE")]
        public async Task<IActionResult> Create([FromBody] CreateEmployeePositionCommand command, CancellationToken cancellationToken = default)
        {
            return await SendAsync(command);
        }

        /// <summary>
        /// Cập nhật thông tin chức vụ
        /// </summary>
        [HttpPut("{id}")]
        [PermissionAuthorize("HRM:POSITION:UPDATE")]
        public async Task<IActionResult> Update(string id, [FromBody] UpdateEmployeePositionCommand command, CancellationToken cancellationToken = default)
        {
            command.Id = id;
            return await SendAsync(command);
        }

        /// <summary>
        /// Xóa chức vụ
        /// </summary>
        [HttpDelete("{id}")]
        [PermissionAuthorize("HRM:POSITION:DELETE")]
        public async Task<IActionResult> Delete(string id, CancellationToken cancellationToken = default)
        {
            var command = new DeleteEmployeePositionCommand { Id = id };
            return await SendAsync(command);
        }
    }
}
