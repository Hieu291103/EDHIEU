using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Hrm
{
    [Route("api/hrm/employee")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
    }
}
