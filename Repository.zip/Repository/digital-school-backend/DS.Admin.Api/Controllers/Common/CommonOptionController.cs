using DS.Module.Support.Application.Queries.TicketTags;
using DS.Module.Tenant.Application.Queries.SchoolYears;
using DS.Module.Tenant.Application.Queries.Teachers;
using DS.Module.Tenant.Application.Queries.TenantClasses;
using DS.Module.Tenant.Application.Queries.TenantSubjects;
using DS.Module.Tenant.Domain.Enums;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Enums;
using DS.Shared.Core.Presentation.Controllers;
using DS.Shared.CQRS.Queries.Users;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Common
{
    [Route("api/common-options")]
    [Authorize]
    [ApiController]
    public class CommonOptionController : BaseAPIController
    {
        public CommonOptionController(IMediator mediator) : base(mediator)
        {

        }

        [HttpGet("ticket-tags")]
        public async Task<IActionResult> GetTicketTagOptions(CancellationToken cancellationToken)
        {
            var query = new GetTicketTagListQuery { PageSize = 1000 };
            var result = await _mediator.Send(query, cancellationToken);

            var options = result.Items.Select(t => new ValueLabelDataDto
            {
                Value = t.Id,
                Label = t.Name,
                Group = t.TagType,
                IsActive = true,
                ExtraData = new
                {
                    t.TagProduct,
                    t.DisplayOrder,
                    t.Color,
                    t.UsageCount
                }
            }).ToList();

            return SuccessResponse(options);
        }

        [HttpGet("school-year")]
        public async Task<IActionResult> GetSchoolYearOptions(CancellationToken cancellationToken)
        {
            var query = new GetSchoolYearListQuery { PageSize = 1000 };
            var result = await _mediator.Send(query, cancellationToken);

            var options = result.Items.Select(t => new ValueIntLabelDataDto
            {
                Value = t.Year,
                Label = t.YearName,
                IsActive = t.IsActive,
                ExtraData = new
                {
                    t.Id,
                    t.YearCode,
                    t.StartDate,
                    t.EndDate,
                    t.IsClosed,
                }
            }).ToList();

            return SuccessResponse(options);
        }

        [HttpGet("user-employee")]
        public async Task<IActionResult> GetUserOptions(CancellationToken cancellationToken)
        {
            var query = new SharedGetUserListQuery { UserType = UserType.Employee, PageSize = 1000 };
            var result = await _mediator.Send(query, cancellationToken);

            var options = result.Items.Select(u => new ValueLabelDataDto
            {
                Value = u.Id,
                Label = u.DisplayName,
                IsActive = true,
                ExtraData = new
                {
                    u.FullName,
                    u.Email,
                    u.Username,
                    u.UserType,
                    u.AvatarUrl,
                }
            }).ToList();

            return SuccessResponse(options);
        }

        [HttpGet("online-class/provider-connect")]
        public async Task<IActionResult> GetOnlineClassProviderConnectOptions(CancellationToken cancellationToken)
        {


            var options = new List<ValueLabelDataDto>()
            { new ValueLabelDataDto{
                 Value = "MS_TEAMS_EDMICRO_EDU_VN",
                 Label = "MS Teams edmicro.edu.vn",
                    IsActive = true,
                    ExtraData = new
                    {
                        type = "FREE",
                        provider="Teams"
                    }
            },
            new ValueLabelDataDto{
                 Value = "ZOOM_ONE_ZOOM",
                 Label = "ONE ZOOM",
                    IsActive = true,
                    ExtraData = new
                    {
                        type = "CHARGE",
                        provider="Zoom"
                    }
            }};

            return SuccessResponse(options);
        }

        [HttpGet("tenant-teacher")]
        public async Task<IActionResult> GetUserTeacherOptions([FromQuery] string tenantId,
            [FromQuery] int? year, CancellationToken cancellationToken)
        {
            var query = new GetTeacherListQuery { TenantId = tenantId, Year = year, PageSize = 1000, PageIndex = 1 };
            var result = await _mediator.Send(query, cancellationToken);
            var options = result.Items.Select(u => new ValueLabelDataDto
            {
                Value = u.UserId,
                Label = u.FullName ?? u.Username ?? u.EducationCode ?? u.UserId,
                IsActive = u.IsActive,
                ExtraData = new
                {
                    u.Username,
                    u.FullName,
                    u.Email,
                    u.DateOfBirth,
                    u.EducationCode,
                    u.Title,
                    u.Year,
                    u.AvatarUrl,
                    u.Subjects,
                }
            }).ToList();

            return SuccessResponse(options);
        }

        [HttpGet("tenant-student")]
        public async Task<IActionResult> GetUserStudentOptions([FromQuery] string tenantId,
            [FromQuery] int year, CancellationToken cancellationToken)
        {
            //var query = new GetUserListQuery { UserType = UserType.Student, PageSize = 1000 };
            //var result = await _mediator.Send(query, cancellationToken);

            //var options = result.Items.Select(u => new ValueLabelDataDto
            //{
            //    Value = u.Id,
            //    Label = u.DisplayName,
            //    IsActive = true,
            //    ExtraData = new
            //    {
            //        u.FullName,
            //        u.Email,
            //        u.Username,
            //        u.UserType
            //    }
            //}).ToList();

            return SuccessResponse(new List<ValueLabelDataDto>());
        }

        [HttpGet("tenant-school-staff")]
        public async Task<IActionResult> GetUserSchoolStaffOptions([FromQuery] string tenantId,
            [FromQuery] int? year, CancellationToken cancellationToken)
        {
            //var query = new GetUserListQuery { UserType = UserType.SchoolStaff, PageSize = 1000 };
            //var result = await _mediator.Send(query, cancellationToken);

            //var options = result.Items.Select(u => new ValueLabelDataDto
            //{
            //    Value = u.Id,
            //    Label = u.DisplayName,
            //    IsActive = true,
            //    ExtraData = new
            //    {
            //        u.FullName,
            //        u.Email,
            //        u.Username,
            //        u.UserType
            //    }
            //}).ToList();

            return SuccessResponse(new List<ValueLabelDataDto>());
        }

        [HttpGet("tenant-subject")]
        public async Task<IActionResult> GetTenantSubjectOptions(
            [FromQuery] string tenantId,
            CancellationToken cancellationToken)
        {
            var query = new GetTenantSubjectListQuery
            {
                PageSize = 1000,
                TenantId = tenantId
            };
            var result = await _mediator.Send(query, cancellationToken);

            var options = result.Items.Select(s => new ValueLabelDataDto
            {
                Value = s.Code!,
                Label = s.Name ?? s.Code!,
                IsActive = s.IsActive ?? false,
                ExtraData = new
                {
                    s.Id,
                    s.Code,
                    s.Description,
                    s.GradeLevels,
                    s.PeriodsPerWeek,
                    s.Credits,
                    s.IsRequired,
                    s.SubjectGroup,
                    s.IsSystem
                }
            }).ToList();

            return SuccessResponse(options);
        }

        [HttpGet("tenant-class")]
        public async Task<IActionResult> GetTenantClassOptions(
           [FromQuery] string tenantId,
            [FromQuery] int year,
             [FromQuery] ClassType? ClassType,
              [FromQuery] GradeLevel? GradeLevel,
           CancellationToken cancellationToken)
        {
            var query = new GetTenantClassListQuery
            {
                PageSize = 1000,
                TenantId = tenantId,
                Year = year,
                ClassType = ClassType,
                GradeLevel = GradeLevel
            };
            var result = await _mediator.Send(query, cancellationToken);

            var options = result.Items.Select(s => new ValueLabelDataDto
            {
                Value = s.Code!,
                Label = s.Name ?? s.Code!,
                IsActive = s.IsActive,
                ExtraData = new
                {
                    s.Id,
                    s.Code,
                    s.Description,
                    s.GradeLevel,
                    s.PeriodsPerWeek,
                    s.ClassType,
                    s.TenantId,
                    s.TeacherDisplay,
                    s.AssistantTeacherId,
                    s.AssistantTeacherDisplay
                }
            }).ToList();

            return SuccessResponse(options);
        }
    }
}
