using DS.Module.Support.Application.Queries.Contacts;
using DS.Module.Tenant.Application.Queries.Tenants;
using DS.Shared.Core.Presentation.Controllers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DS.Admin.Api.Controllers.Common
{
    [Route("api/common-option-list")]
    [Authorize]
    [ApiController]
    public class CommonOptionListController : BaseAPIController
    {
        public CommonOptionListController(IMediator mediator) : base(mediator)
        {

        }

        [HttpPost("tenant")]
        public async Task<IActionResult> GetTenantList([FromBody] GetTenantOptionListQuery query, CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }

        [HttpPost("contact")]
        public async Task<IActionResult> GetContactList([FromBody] GetContactOptionListQuery query, CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(query, cancellationToken);
            return SuccessResponse(result);
        }
    }
}
