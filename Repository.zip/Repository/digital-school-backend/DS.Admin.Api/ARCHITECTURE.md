# DS.Admin.Api — Architecture Overview

## Mục đích
`DS.Admin.Api` là **ASP.NET Core Web API** dành cho **Admin/Super-admin** quản lý toàn bộ hệ thống Digital School. Đây là API trung tâm xử lý quản lý tenant, người dùng, cấu hình hệ thống, và tích hợp các module nghiệp vụ.

---

## Cấu trúc thư mục

```
DS.Admin.Api/
├── Program.cs                                    # Entry point, DI setup, middleware pipeline
├── ARCHITECTURE.md                               # Tài liệu kiến trúc (file này)
└── Controllers/
    ├── Users/
    │   ├── AuthController.cs                     # OAuth2 token exchange, refresh token
    │   ├── UserController.cs                     # Quản lý người dùng hệ thống
    │   ├── RoleController.cs                     # Quản lý vai trò
    │   ├── PermissionController.cs               # Quản lý quyền hạn
    │   └── MeController.cs                       # Thông tin user hiện tại
    ├── Tenants/
    │   ├── TenantController.cs                   # CRUD tenant (trường/đơn vị)
    │   ├── StudentController.cs                  # Quản lý học sinh trong tenant
    │   ├── TeacherController.cs                  # Quản lý giáo viên trong tenant
    │   ├── TenantClassController.cs              # Quản lý lớp học
    │   ├── TenantSubjectController.cs            # Quản lý môn học trong tenant
    │   ├── TenantClassSubjectMappingController.cs # Ánh xạ lớp - môn học
    │   └── UserTenantManagementController.cs     # Quản lý người dùng thuộc tenant
    ├── Settings/
    │   ├── AcademicTimeTemplateController.cs     # Mẫu thời khóa biểu học thuật
    │   ├── SubjectTemplateController.cs          # Mẫu môn học toàn cục
    │   └── SchoolYearController.cs               # Năm học
    ├── Support/
    │   ├── TicketController.cs                   # Quản lý ticket hỗ trợ
    │   ├── TicketTagController.cs                # Thẻ tag cho ticket
    │   ├── TicketReportController.cs             # Báo cáo ticket
    │   └── ContactController.cs                  # Liên hệ
    ├── OnlineClass/
    │   ├── OnlineClassTenantController.cs        # Lớp học trực tuyến theo tenant
    │   └── LessonMeetingController.cs            # Buổi học/meeting
    ├── Storage/
    │   └── S3Controller.cs                       # Upload file lên S3
    └── Common/
        ├── CommonOptionController.cs             # Danh mục tùy chọn
        └── CommonOptionListController.cs         # Danh sách nhóm tùy chọn
```

---

## Authentication & Authorization

### JWT Bearer (chính)
- Validate token từ `DS.Identity` (OAuth2 Authorization Server)
- `Authority` = URL của `DS.Identity` service (config: `OAuth:Url`)
- Tự động refresh JWKS key mỗi 30 phút, hard refresh sau 12 giờ

### Basic Auth (phụ - Swagger)
- Scheme: `BasicAuthentication` via `BasicAuthenticationHandler`
- Dùng để bảo vệ `/swagger` endpoint
- Config: `SwaggerAuth:Username` / `SwaggerAuth:Password`

### Permission Authorization
- Attribute `[PermissionAuthorize("MODULE:RESOURCE:ACTION")]`
- Đăng ký qua `builder.Services.AddPermissionAuthorization()`
- Ví dụ: `[PermissionAuthorize("TENANT:TENANT:VIEW")]`

---

## Module Dependencies

| Module / Service | Mục đích |
|---|---|
| `DS.Module.Tenant` | Quản lý tenant, student, teacher, class, subject |
| `DS.Module.Identity` | User, role, permission |
| `DS.Module.OnlineClass` | Lớp học trực tuyến, lesson meeting |
| `DS.Module.Support` | Ticket, tag, contact |
| `DS.Shared.Core` (MongoDB, Redis) | Persistence layer |
| `IOAuthClient` | Gọi tới DS.Identity để exchange/refresh token |
| `IOnluyenService` | Tích hợp Onluyen external API |
| `S3UploadService` | Upload file lên AWS S3 |
| `IMediator` (MediatR) | Dispatch command/query |

---

## Base Controller Pattern
Tất cả controllers kế thừa `BaseAPIController` từ `DS.Shared.Core.Presentation.Controllers`:
```csharp
public class MyController : BaseAPIController
{
    public MyController(IMediator mediator) : base(mediator) { }
}
```
Cung cấp helper: `SuccessResponse(data)`, `ErrorResponse(...)`, etc.

---

## Luồng khởi động (Program.cs)

```
1.  Load config (appsettings.json + appsettings.{ENV}.json + env vars)
2.  Serilog logging
3.  ForwardedHeaders config
4.  Controllers + JSON options (camelCase, enum as string, skip null)
5.  CORS (AddDefaultCors)
6.  Redis distributed cache
7.  Swagger/OpenAPI (Basic Auth protected)
8.  RequestContext middleware registration
9.  MongoDB (Admin + School databases)
10. Core Localization
11. Tenant module
12. OnlineClass module
13. AutoMapper + MediatR (EnableTenantContext + Caching + Validation)
14. Identity module
15. Support module
16. S3 Upload service
17. Onluyen integration
18. OAuth settings + JWT settings
19. HttpClient cho IOAuthClient
20. Authentication: BasicAuth + JWT Bearer (với dynamic JWKS từ DS.Identity)
21. PermissionAuthorization + Authorization
--- app.Build() ---
22. UseForwardedHeaders
23. UseExceptionHandling
24. UseRequestContext
25. UseResponseTimeHeaders (X-Time-Server, X-Time-Client)
26. UseCors
27. Swagger (Basic Auth middleware inline)
28. UseAuthentication → UseAuthorization
29. MapControllers
30. app.Run()
```

---

## MediatR Pipeline Behaviors
| Behavior | Trạng thái |
|---|---|
| TenantContext | ✅ Enabled |
| Caching | ✅ Enabled |
| Validation (FluentValidation) | ✅ Enabled |

---

## AuthController — OAuth Token Flow
1. `POST /api/auth/token` với `grant_type=authorization_code`: exchange code → token qua `IOAuthClient`
2. `POST /api/auth/token` với `grant_type=refresh_token`: lấy refresh token từ body **hoặc cookie** `refresh_token`
3. `refresh_token` được lưu vào **HttpOnly, Secure, SameSite=None cookie** (không expose trong response body)

---

## Cấu hình `appsettings.json` cần có
```json
{
  "OAuth": {
    "Url": "https://identity.domain.com",
    "Issuer": "...",
    "Audience": "..."
  },
  "Jwt": {
    "Issuer": "...",
    "Audience": "..."
  },
  "SwaggerAuth": {
    "Username": "admin",
    "Password": "secret"
  },
  "S3": { ... },
  "Cors": { "AllowedOrigins": ["..."] }
}
```

---

## Lưu ý quan trọng
- Mọi controller nghiệp vụ đều yêu cầu `[Authorize]` trừ endpoint test
- Permission dạng `"MODULE:RESOURCE:ACTION"` phải khớp với permission đăng ký trong Identity
- Không thêm `TenantId` trực tiếp vào entity — đã kế thừa từ base class
- `UserTenantMappingEntity` là canonical entity cho tenant users, phân biệt vai trò bằng `Type` field
