using DS.Module.OnlineClass.Domain.Enums;
using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.OnlineClass.Domain.Entities
{
    [BsonCollection("onlineClassAccountMeetings")]
    public class AccountMeetingEntity : BaseTenantEntity, ISchoolCommonEntity
    {
        /// <summary>
        /// UserId của người dùng onluyen
        /// </summary>
        public string? UserId { get; set; } = string.Empty;
        /// <summary>
        /// Tên đầy đủ trên Meet
        /// </summary>
        public string? FullName { get; set; } = string.Empty;
        /// <summary>
        /// Tài khoản meet
        /// </summary>
        public string? UserName { get; set; } = string.Empty;
        /// <summary>
        /// Mã cung cấp dịch vụ tạo tài khoản
        /// </summary>
        public string? ProviderConnect { get; set; } = string.Empty;
        /// <summary>
        /// UserId liên quan đến tài khoản meet
        /// </summary>
        public string? MeetUserId { get; set; } = string.Empty;
        /// <summary>
        /// Email liên quan đến tài khoản meet
        /// </summary>
        public string? MeetEmail { get; set; } = string.Empty;
        /// <summary>
        /// Mật khẩu đăng nhập tài khoản meet
        /// </summary>
        public string? MeetPassword { get; set; } = string.Empty;

        /// <summary>
        /// Tài khoản đã đăng ký policy để sử dụng các dịch vụ của Microsoft Teams hay chưa
        /// </summary>
        public bool? MeetRegPolicy { get; set; } = false;
        /// <summary>
        /// Id của trường học
        /// </summary>
        public int? SchoolId { get; set; } = 0;
        /// <summary>
        /// Tài khoản dành cho trường/ lớp / giáo viên
        /// </summary>
        public AccountMeetingType AccountMeetingType { get; set; }

    }
}
