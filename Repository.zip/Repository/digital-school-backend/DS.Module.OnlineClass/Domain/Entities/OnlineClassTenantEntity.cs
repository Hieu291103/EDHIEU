using DS.Module.OnlineClass.Domain.Enums;
using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.OnlineClass.Domain.Entities
{
    [BsonCollection("onlineClassTenants")]
    public class OnlineClassTenantEntity : BaseTenantEntity, ISchoolCommonEntity
    {
        /// <summary>
        /// Loại tài khoản sử dụng (MSTeams vs Zoom vs GGMeet)
        /// </summary>
        public ProviderMeetingType ProviderMeetingType { get; set; }

        /// <summary>
        /// Nhà cung cấp kết nối, ví dụ: Microsoft Teams Edmicro, Microsoft Teams xxx,
        /// </summary>
        public string? ProviderConnect { get; set; }

        /// <summary>
        /// Lưu id trường cùng tenant
        /// </summary>
        public int? SchoolId { get; set; } = 0;
        /// <summary>
        /// Ngày bắt đầu được sử dụng
        /// </summary>
        public DateTime? StartDate { get; set; }
        /// <summary>
        /// Ngày hết hạn sử dụng
        /// </summary>
        public DateTime? ExpireDate { get; set; }
        /// <summary>
        /// Hoạt động
        /// </summary>
        public bool IsActive { get; set; } = true;
        /// <summary>
        /// Số phút mở buổi học thực tế cho giáo viên (khi người tạo bắt đầu buổi học)
        /// </summary>
        public int? TeacherOpenMinutes { get; set; }
        /// <summary>
        /// Số phút mở buổi học thực tế cho học sinh (khi người tạo bắt đầu buổi học)
        /// </summary>
        public int? StudentOpenMinutes { get; set; }

        /// <summary>
        /// Số lượng license Zoom (nếu có, chỉ áp dụng với Zoom)
        /// </summary>
        public int? ZoomLicense { get; set; } = 0;

        /// <summary>
        /// Số phút tối đa cho phép buổi học
        /// </summary>
        public int? MeetingMinutes { get; set; } = 0;

    }
}
