using DS.Module.OnlineClass.Domain.Enums;
using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Enums;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;
using MongoDB.Bson;

namespace DS.Module.OnlineClass.Domain.Entities
{
    /// <summary>
    /// Lưu thông tin người tham gia từng buổi học trực tuyến
    /// Dùng để điểm danh, theo dõi thời lượng tham gia, v.v.
    /// Collection: onlineClassLessonParticipants
    /// </summary>
    [BsonCollection("onlineClassLessonParticipants")]
    public class LessonParticipantEntity : BaseTenantEntity, ISchoolCommonEntity
    {
        /// <summary>
        /// ID của buổi học trực tuyến
        /// Tham chiếu tới LessonMeetingEntity
        /// </summary>
        [BsonObjectId]
        public required string LessonMeetingId { get; set; }

        /// <summary>
        /// Xác nhận là user hay là guest (tham gia bằng link không đăng nhập)
        /// </summary>
        public bool IsUser { get; set; } = false;

        /// <summary>
        /// Loại tài khoản người tham gia (Học sinh, Giáo viên)
        /// </summary>
        public UserType? UserType { get; set; }

        /// <summary>
        /// ID của người tham gia (học sinh, giáo viên, v.v.)
        /// </summary>
        [BsonObjectId]
        public string? UserId { get; set; }

        /// <summary>
        /// Tên đăng nhập
        /// </summary>
        public string? Username { get; set; }

        /// <summary>
        /// Tên người tham gia (snapshot tại thời điểm tham gia)
        /// </summary>
        public string? UserFullName { get; set; }

        /// <summary>
        /// Tên hiển thị trên zoom, teams (snapshot tại thời điểm tham gia)
        /// UserFullName - Username
        /// </summary>
        public string? UserDisplayName { get; set; }

        /// <summary>
        /// Lưu id trường cùng tenant
        /// </summary>
        public int? SchoolId { get; set; } = 0;

        /// <summary>
        /// Email của người tham gia
        /// </summary>
        public string? UserEmail { get; set; }

        /// <summary>
        /// Ngày sinh của người tham gia (snapshot tại thời điểm tham gia)
        /// </summary>
        public string? UserBirthDay { get; set; }

        /// <summary>
        /// Thời gian tham gia buổi học khi nhấn vào link
        /// </summary>
        public DateTime? JoinTimeClick { get; set; }

        /// <summary>
        /// Thời gian tham gia buổi học thực tế lấy từ nhà cung cấp (MS Teams, Zoom, v.v.)
        /// </summary>
        public DateTime? JoinTimeActual { get; set; }

        /// <summary>
        /// Thời gian rời khỏi buổi học
        /// </summary>
        public DateTime? LeaveTime { get; set; }

        /// <summary>
        /// Thời gian rời khỏi buổi học thực tế lấy từ nhà cung cấp (MS Teams, Zoom, v.v.)
        /// </summary>
        public DateTime? LeaveTimeActual { get; set; }

        /// <summary>
        /// Thời lượng tham gia thực tế (tính bằng phút)
        /// </summary>
        public int? DurationInMinutes { get; set; }

        /// <summary>
        /// Trạng thái điểm danh (Attended/Absent/Late/EarlyLeave)
        /// </summary>
        public MeetingAttendanceStatus AttendanceStatus { get; set; } = MeetingAttendanceStatus.Absent;

        /// <summary>
        /// Ghi chú về sự tham gia (vắng mặt không phép, v.v.)
        /// </summary>
        public string? Notes { get; set; }

        /// <summary>
        /// ID từ nhà cung cấp (MS Teams, Zoom, v.v.) để kết nối thông tin
        /// </summary>
        public string? ProviderParticipantId { get; set; }

        /// <summary>
        /// Phần trăm tham gia (dựa trên thời lượng)
        /// </summary>
        public decimal? ParticipationPercentage { get; set; }

        /// <summary>
        /// IP address khi tham gia
        /// </summary>
        public string? JoinIpAddress { get; set; }

        /// <summary>
        /// Device/Browser được sử dụng
        /// </summary>
        public string? DeviceInfo { get; set; }
        /// <summary>
        /// Địa điểm thực tế khi tham gia (nếu có)
        /// </summary>
        public string? Location { get; set; }

        public List<AttendanceInterval>? AttendanceIntervals { get; set; } = new List<AttendanceInterval>();

    }

    public class AttendanceInterval
    {
        /// <summary>
        /// Thời gian bắt đầu tham gia
        /// </summary>
        public DateTime? StartTime { get; set; }
        /// <summary>
        /// Thời gian kết thúc tham gia
        /// </summary>
        public DateTime? EndTime { get; set; }

        public int? DurationInSeconds
        {
            get
            {
                if (StartTime.HasValue && EndTime.HasValue)
                {
                    return (int)(EndTime.Value - StartTime.Value).TotalSeconds;
                }
                return null;
            }
        }
    }
}
