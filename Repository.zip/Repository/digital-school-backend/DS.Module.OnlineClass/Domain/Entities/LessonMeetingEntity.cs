using DS.Module.OnlineClass.Domain.Constants;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.OnlineClass.Domain.Entities
{
    [BsonCollection("onlineClassLessonMeetings")]
    public class LessonMeetingEntity : BaseTenantEntity, ISchoolCommonEntity
    {
        /// <summary>
        /// Tên buổi học / Tiêu đề cuộc họp
        /// Tự động tạo theo tên lớp + môn học + tên người tạo
        /// </summary>
        public string? Title { get; set; }

        /// <summary>
        /// Mô tả buổi học
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// Ngày tổ chức buổi học (chỉ ngày, không bao gồm thời gian)
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Thời gian bắt đầu buổi học
        /// </summary>
        public DateTime? StartTime { get; set; }

        /// <summary>
        /// Thời gian kết thúc buổi học
        /// </summary>
        public DateTime? EndTime { get; set; }

        /// <summary>
        /// Múi giờ của buổi học
        /// </summary>
        public string? TimeZone { get; set; }

        /// <summary>
        /// Tiết học
        /// </summary>
        public LessonPeriod? LessonPeriod { get; set; }

        /// <summary>
        /// Thời gian mở buổi học thực tế (khi người tạo bắt đầu buổi học)
        /// </summary>
        public DateTime? ActualStartTime { get; set; }

        /// <summary>
        /// Thời gian kết thúc buổi học thực tế (khi người tạo kết thúc buổi học)
        /// </summary>
        public DateTime? ActualEndTime { get; set; }

        /// <summary>
        /// Đường dẫn tham gia buổi học
        /// </summary>
        public string? JoinUrl { get; set; } = null;

        /// <summary>
        /// Đường dẫn tham gia buổi học dành cho co-host (nếu có, đối với Zoom)
        /// </summary>
        public string? JoinCoHostUrl { get; set; } = null;

        /// <summary>
        /// Trạng thái đã tạo phòng học ảo thành công chưa, nếu chưa có nghĩa là buổi học đã được lên lịch nhưng chưa thể tham gia được (zoom)
        /// </summary>
        public bool? JoinUrlActive { get; set; } = false;

        /// <summary>
        /// Mã/Id buổi học
        /// </summary>
        public string? JoinMeetingId { get; set; }
        /// <summary>
        /// Mật khẩu buổi học (đối với Zoom)
        /// </summary>
        public string? JoinMeetingPassword { get; set; }

        /// <summary>
        /// ID cuộc họp từ nhà cung cấp (MS Teams, Zoom, v.v.)
        /// </summary>
        public string? ProviderMeetingId { get; set; }

        /// <summary>
        /// Nhà cung cấp dịch vụ (TeamsFree, ZoomCommercial)
        /// </summary>
        public ProviderMeetingType ProviderMeetingType { get; set; } = ProviderMeetingType.None;

        /// <summary>
        /// Mã cung cấp dịch vụ tạo tài khoản
        /// </summary>
        public string? ProviderConnect { get; set; }

        /// <summary>
        /// ID của lớp học 
        /// </summary>
        public string ClassId { get; set; } = string.Empty;
        /// <summary>
        /// Tên của lớp học 
        /// </summary>
        public string ClassName { get; set; } = string.Empty;

        /// <summary>
        /// Cấp học của lớp học
        /// </summary>
        public string GradeId { get; set; } = string.Empty;

        /// <summary>
        /// Mã môn dạy
        /// </summary>
        public string? Subject { get; set; }

        /// <summary>
        /// Tên môn học
        /// </summary>
        public string? SubjectName { get; set; }

        /// <summary>
        /// ID của người tạo buổi học (onluyen)
        /// </summary>
        public string? UserId { get; set; }

        /// <summary>
        /// Tên của người tạo buổi học (onluyen)
        /// </summary>
        public string? FullName { get; set; }

        /// <summary>
        /// ID của tài khoản Meet được sử dụng (nhà cung cấp)
        /// </summary>
        public string? MeetUserId { get; set; }

        /// <summary>
        /// Email của người tạo buổi học (nhà cung cấp)
        /// </summary>
        public string? MeetEmail { get; set; }

        /// <summary>
        /// Trạng thái buổi học (Active, Ended, Cancelled)
        /// </summary>
        public MeetingStatus Status { get; set; } = MeetingStatus.NotStarted;

        /// <summary>
        /// Số lượng người tham gia hiện tại
        /// </summary>
        public int? CurrentParticipantCount { get; set; } = 0;

        /// <summary>
        /// Số lượng người tham gia tối đa
        /// </summary>
        public int? MaxParticipantCount { get; set; }

        /// <summary>
        /// URL bản ghi lại buổi học (nếu có)
        /// </summary>
        public string? RecordingUrl { get; set; }

        /// <summary>
        /// ID bản ghi lại từ nhà cung cấp
        /// </summary>
        public string? ProviderRecordingId { get; set; }

        /// <summary>
        /// Ghi chú bổ sung về buổi học
        /// </summary>
        public string? Notes { get; set; }

        /// <summary>
        /// Có cho phép ghi lại không
        /// </summary>
        public bool AllowRecording { get; set; } = false;

        /// <summary>
        /// Đã xóa liên kết chưa
        /// </summary>
        public bool? MeetLinkDeleted { get; set; }

        /// <summary>
        /// Lưu id trường cùng tenant
        /// </summary>
        public int? SchoolId { get; set; } = 0;

        /// <summary>
        /// Năm học
        /// </summary>
        public int? SchoolYear { get; set; } = 0;

        /// <summary>
        /// Đã lấy dữ liệu từ bên onluyen chua, nếu chưa thì sẽ lấy dữ liệu từ onluyen để tạo danh sách người tham gia
        /// </summary>
        public bool? FetchParticipant { get; set; } = false;

        /// <summary>
        /// Đã lấy thông tin người tham gia từ nhà cung cấp chưa
        /// </summary>
        public bool? HasParticipant { get; set; } = false;

        /// <summary>
        /// Số lần thử cập nhật thông tin người tham gia từ nhà cung cấp (quá 10 lần thì thôi)
        /// </summary>
        public int? ParticipantTryCount { get; set; } = 0;

    }
}
