using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.OnlineClass.Domain.Entities
{
    [BsonCollection("partnerOneZoomMeetings")]
    public class PartnerOneZoomMeetingEntity : BaseTenantEntity, ISchoolCommonEntity
    {
        public long OneZoomId { get; set; }
        public long ZoomRoomId { get; set; }
        public string? Topic { get; set; }
        public string? Agenda { get; set; }
        public int? DurationInMinute { get; set; }
        public string? RoomPassword { get; set; }
        public string? JoinUrl { get; set; }
        public string? StartUrl { get; set; }
        public DateTime? CreateAt { get; set; }
        public int? Status { get; set; }
        public DateTime? Date { get; set; }
        public DateTime? EndAt { get; set; }
        public DateTime? DeleteAt { get; set; }
        /// <summary>
        /// Đã xóa chưa
        /// </summary>
        public bool? IsDeleted { get; set; } = false;
        /// <summary>
        /// ID của buổi học trực tuyến
        /// Tham chiếu tới LessonMeetingEntity
        /// </summary>
        [BsonObjectId]
        public string? LessonMeetingId { get; set; }
        /// <summary>
        /// Mã cung cấp dịch vụ tạo tài khoản
        /// </summary>
        public string? ProviderConnect { get; set; }
    }
}
