using DS.Shared.Core.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Attributes;

namespace DS.Module.OnlineClass.Domain.Entities
{
    [BsonCollection("onlineClassTenantClasses")]
    public class OnlineClassTenantClassEntity : BaseTenantEntity, ISchoolCommonEntity
    {
        /// <summary>
        /// Lưu id trường cùng tenant
        /// </summary>
        public int? SchoolId { get; set; } = 0;

        public string ClassId { get; set; } = string.Empty;

        public string ClassName { get; set; } = string.Empty;

        public int SchoolYear { get; set; }

        public string GradeName { get; set; } = string.Empty;

        public string GradeId { get; set; } = string.Empty;

        public int? CountStudent { get; set; } = 0;

        public bool IsActive { get; set; } = false;
    }
}
