namespace DS.Module.OnlineClass.Domain.Enums
{
    public enum MeetingStatus
    {
        /// <summary>
        /// Chưa bắt đầu
        /// </summary>
        NotStarted = 0,

        /// <summary>
        /// Đang diễn ra
        /// </summary>
        Active = 1,

        /// <summary>
        /// Đã kết thúc
        /// </summary>
        Ended = 2,

        /// <summary>
        /// Đã hủy
        /// </summary>
        Cancelled = 3,
    }
}
