namespace DS.Module.OnlineClass.Domain.Enums
{
    public enum AccountMeetingType
    {
        None = 0,
        /// <summary>
        /// Tài khoản Trường
        /// </summary>
        School = 1,
        /// <summary>
        /// Tài khoản Lớp
        /// </summary>
        Class = 2,
        /// <summary>
        /// Tài khoản Giáo viên
        /// </summary>
        Teacher = 3,
        /// <summary>
        /// Tài khoản Học sinh
        /// </summary>
        Student = 4,
    }
}
