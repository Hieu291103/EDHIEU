namespace DS.Module.OnlineClass.Domain.Enums
{
    public enum ProviderMeetingType
    {
        None,
        Teams,
        Zoom,
        GoogleMeet
    }
}
