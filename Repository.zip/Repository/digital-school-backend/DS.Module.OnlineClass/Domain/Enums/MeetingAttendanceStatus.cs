namespace DS.Module.OnlineClass.Domain.Enums
{
    public enum MeetingAttendanceStatus
    {
        /// <summary>
        /// Vắng mặt (chưa tham gia)
        /// </summary>
        Absent = 0,

        /// <summary>
        /// Có mặt (tham gia đầy đủ)
        /// </summary>
        Attended = 1,

        /// <summary>
        /// Đến muộn
        /// </summary>
        Late = 2,

        /// <summary>
        /// Rời sớm
        /// </summary>
        EarlyLeave = 3,

        /// <summary>
        /// Phép/Xin phép
        /// </summary>
        Excused = 4
    }
}
