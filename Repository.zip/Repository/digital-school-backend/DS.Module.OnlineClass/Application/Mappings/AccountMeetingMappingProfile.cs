using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;

namespace DS.Module.OnlineClass.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho AccountMeeting entity
    /// </summary>
    public class AccountMeetingMappingProfile : Profile
    {
        public AccountMeetingMappingProfile()
        {
            CreateMap<AccountMeetingEntity, AccountMeetingDto>()
                .ReverseMap();
        }
    }
}
