using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;

namespace DS.Module.OnlineClass.Application.Mappings
{
    /// <summary>
    /// Mapping profile cho OnlineClassTenant entity
    /// </summary>
    public class OnlineClassTenantMappingProfile : Profile
    {
        public OnlineClassTenantMappingProfile()
        {
            CreateMap<OnlineClassTenantEntity, OnlineClassTenantDto>()
                .ReverseMap();
        }
    }
}
