using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Common.Helpers;

namespace DS.Module.OnlineClass.Application.Mappings
{
    /// <summary>
    /// AutoMapper Profile cho LessonMeeting
    /// </summary>
    public class LessonMeetingMappingProfile : Profile
    {
        public LessonMeetingMappingProfile()
        {

            CreateMap<LessonMeetingEntity, LessonMeetingDetailDto>()
                .ForMember(dest => dest.ProviderMeetingType,
                    opt => opt.MapFrom(src => src.ProviderMeetingType.ToString()))
                .ForMember(dest => dest.Status,
                    opt => opt.MapFrom(src => src.Status.ToString()))
                .ReverseMap();
            CreateMap<LessonMeetingEntity, LessonMeetingListDto>()
              .ForMember(dest => dest.ProviderMeetingType,
                  opt => opt.MapFrom(src => src.ProviderMeetingType.ToString()))
              .ForMember(dest => dest.Status,
                  opt => opt.MapFrom(src => src.Status.ToString()))
              .ReverseMap();

            CreateMap<LessonMeetingListDto, OnLuyenLessonMeetingListDto>()
             .ForMember(dest => dest.Date, opt => opt.MapFrom(src => src.Date.HasValue ? src.Date.Value.ToTimestamp() : (long?)null))
             .ForMember(dest => dest.StartTime, opt => opt.MapFrom(src => src.StartTime.HasValue ? src.StartTime.Value.ToTimestamp() : (long?)null))
             .ForMember(dest => dest.EndTime, opt => opt.MapFrom(src => src.EndTime.HasValue ? src.EndTime.Value.ToTimestamp() : (long?)null))
             .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(src => src.CreatedAt.HasValue ? src.CreatedAt.Value.ToTimestamp() : (long?)null))
             .ReverseMap()
             .ForMember(dest => dest.Date, opt => opt.MapFrom(src => src.Date.HasValue ? DatetimeHelper.FromTimestamp(src.Date.Value) : (DateTime?)null))
             .ForMember(dest => dest.StartTime, opt => opt.MapFrom(src => src.StartTime.HasValue ? DatetimeHelper.FromTimestamp(src.StartTime.Value) : (DateTime?)null))
             .ForMember(dest => dest.EndTime, opt => opt.MapFrom(src => src.EndTime.HasValue ? DatetimeHelper.FromTimestamp(src.EndTime.Value) : (DateTime?)null))
             .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(src => src.CreatedAt.HasValue ? DatetimeHelper.FromTimestamp(src.CreatedAt.Value) : (DateTime?)null));

            // LessonMeetingDetailDto → OnLuyenLessonMeetingTeacherDto (dành cho giáo viên)
            // DateTime fields → Unix ms; JoinDisplayName/OpenMinutes/MeetingOpenTime đã được set trong QueryHandler
            CreateMap<LessonMeetingDetailDto, OnLuyenLessonMeetingTeacherDto>()
                .ForMember(dest => dest.Date, opt => opt.MapFrom(src => src.Date.HasValue ? src.Date.Value.ToTimestamp() : (long?)null))
                .ForMember(dest => dest.StartTime, opt => opt.MapFrom(src => src.StartTime.HasValue ? src.StartTime.Value.ToTimestamp() : (long?)null))
                .ForMember(dest => dest.EndTime, opt => opt.MapFrom(src => src.EndTime.HasValue ? src.EndTime.Value.ToTimestamp() : (long?)null))
                .ForMember(dest => dest.ActualStartTime, opt => opt.MapFrom(src => src.ActualStartTime.HasValue ? src.ActualStartTime.Value.ToTimestamp() : (long?)null))
                .ForMember(dest => dest.ActualEndTime, opt => opt.MapFrom(src => src.ActualEndTime.HasValue ? src.ActualEndTime.Value.ToTimestamp() : (long?)null));
            // LessonMeetingDetailDto → OnLuyenLessonMeetingStudentDto (dành cho học sinh)
            // Không expose các field nhạy cảm: JoinCoHostUrl, JoinMeetingId, JoinMeetingPassword, MeetEmail, MeetPassword
            CreateMap<LessonMeetingDetailDto, OnLuyenLessonMeetingStudentDto>()
                .ForMember(dest => dest.Date, opt => opt.MapFrom(src => src.Date.HasValue ? src.Date.Value.ToTimestamp() : (long?)null))
                .ForMember(dest => dest.StartTime, opt => opt.MapFrom(src => src.StartTime.HasValue ? src.StartTime.Value.ToTimestamp() : (long?)null))
                .ForMember(dest => dest.EndTime, opt => opt.MapFrom(src => src.EndTime.HasValue ? src.EndTime.Value.ToTimestamp() : (long?)null))
                .ForMember(dest => dest.ActualStartTime, opt => opt.MapFrom(src => src.ActualStartTime.HasValue ? src.ActualStartTime.Value.ToTimestamp() : (long?)null))
                .ForMember(dest => dest.ActualEndTime, opt => opt.MapFrom(src => src.ActualEndTime.HasValue ? src.ActualEndTime.Value.ToTimestamp() : (long?)null))
                .ForMember(dest => dest.JoinUrl, opt => opt.MapFrom(src => src.JoinUrl));
        }
    }
}
