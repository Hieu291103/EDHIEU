using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Common.Helpers;

namespace DS.Module.OnlineClass.Application.Mappings
{
    /// <summary>
    /// AutoMapper Profile cho LessonParticipant
    /// </summary>
    public class LessonParticipantMappingProfile : Profile
    {
        public LessonParticipantMappingProfile()
        {
            // Entity → DTO
            CreateMap<LessonParticipantEntity, LessonParticipantDto>().ReverseMap();

            // DTO → OnLuyenDto: DateTime? → Unix timestamp (ms) dạng long?
            CreateMap<LessonParticipantDto, OnLuyenLessonParticipantDto>()
                .ForMember(dest => dest.UserType,
                    opt => opt.MapFrom(src => src.UserType.HasValue ? src.UserType.Value.ToString() : null))
                .ForMember(dest => dest.AttendanceStatus,
                    opt => opt.MapFrom(src => src.AttendanceStatus.ToString()))
                .ForMember(dest => dest.JoinTimeClick,
                    opt => opt.MapFrom(src => src.JoinTimeClick.HasValue ? src.JoinTimeClick.Value.ToTimestamp() : (long?)null))
                .ForMember(dest => dest.JoinTimeActual,
                    opt => opt.MapFrom(src => src.JoinTimeActual.HasValue ? src.JoinTimeActual.Value.ToTimestamp() : (long?)null))
                .ForMember(dest => dest.LeaveTime,
                    opt => opt.MapFrom(src => src.LeaveTime.HasValue ? src.LeaveTime.Value.ToTimestamp() : (long?)null))
                .ForMember(dest => dest.LeaveTimeActual,
                    opt => opt.MapFrom(src => src.LeaveTimeActual.HasValue ? src.LeaveTimeActual.Value.ToTimestamp() : (long?)null));
        }
    }
}
