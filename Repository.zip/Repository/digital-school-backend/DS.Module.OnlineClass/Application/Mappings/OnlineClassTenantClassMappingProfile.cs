using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;

namespace DS.Module.OnlineClass.Application.Mappings
{
    /// <summary>
    /// AutoMapper Profile cho OnlineClassTenantClass
    /// </summary>
    public class OnlineClassTenantClassMappingProfile : Profile
    {
        public OnlineClassTenantClassMappingProfile()
        {
            CreateMap<OnlineClassTenantClassEntity, OnlineClassTenantClassDto>()
                .ReverseMap();

        }
    }
}
