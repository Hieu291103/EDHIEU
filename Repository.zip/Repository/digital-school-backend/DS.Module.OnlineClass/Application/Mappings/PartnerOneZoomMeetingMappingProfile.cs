using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;

namespace DS.Module.OnlineClass.Application.Mappings
{
    /// <summary>
    /// AutoMapper Profile cho PartnerOneZoomMeeting
    /// </summary>
    public class PartnerOneZoomMeetingMappingProfile : Profile
    {
        public PartnerOneZoomMeetingMappingProfile()
        {
            CreateMap<PartnerOneZoomMeetingEntity, PartnerOneZoomMeetingDto>();
        }
    }
}
