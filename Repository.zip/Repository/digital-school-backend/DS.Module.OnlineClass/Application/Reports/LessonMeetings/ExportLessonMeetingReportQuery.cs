using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Reports.LessonMeetings
{
    /// <summary>
    /// Query để export báo cáo kết quả buổi học ra file Excel
    /// </summary>
    public class ExportLessonMeetingReportQuery : IQuery<byte[]>
    {
        /// <summary>ID buổi học cần xuất báo cáo</summary>
        public required string LessonMeetingId { get; set; }
    }
}
