using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Enums;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.Core.Infrastructure.Services.Excel;
using DS.Shared.Core.Infrastructure.Services.Excel.Models;

namespace DS.Module.OnlineClass.Application.Reports.LessonMeetings
{
    /// <summary>
    /// Xử lý query export báo cáo kết quả buổi học ra file Excel.
    /// Sheet 1: Thông tin tổng quan buổi học (môn, lớp, giáo viên, thời gian).
    /// Sheet 2: Danh sách học sinh tham gia (IsUser = true).
    /// Sheet 3: Danh sách guest tham gia (IsUser = false).
    /// </summary>
    public class ExportLessonMeetingReportQueryHandler
        : IQueryHandler<ExportLessonMeetingReportQuery, byte[]>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _meetingRepository;
        private readonly ISchoolCommonReadRepository<LessonParticipantEntity> _participantRepository;
        private readonly IExcelExportService _excelExportService;

        public ExportLessonMeetingReportQueryHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> meetingRepository,
            ISchoolCommonReadRepository<LessonParticipantEntity> participantRepository,
            IExcelExportService excelExportService)
        {
            _meetingRepository = meetingRepository;
            _participantRepository = participantRepository;
            _excelExportService = excelExportService;
        }

        public async Task<byte[]> Handle(ExportLessonMeetingReportQuery request, CancellationToken cancellationToken)
        {
            // 1. Lấy thông tin buổi học
            var meetings = await _meetingRepository.FilterAsync(x => x.Id == request.LessonMeetingId);
            var meeting = meetings.FirstOrDefault();

            // 2. Lấy danh sách người tham gia (học sinh + guest, bỏ giáo viên)
            var allParticipants = await _participantRepository.FilterAsync(
                x => x.LessonMeetingId == request.LessonMeetingId
                     && x.UserType != UserType.Teacher);

            var students = allParticipants.Where(p => p.IsUser).OrderBy(p => p.UserFullName).ToList();
            var guests = allParticipants.Where(p => !p.IsUser).OrderBy(p => p.UserFullName).ToList();

            // 3. Chuẩn bị dữ liệu sheet thông tin buổi học
            var infoRows = new List<LessonMeetingReportInfoDto>
            {
                new()
                {
                    SubjectName = meeting?.SubjectName,
                    ClassName   = meeting?.ClassName,
                    TeacherName = meeting?.FullName,
                    StartTime   = meeting?.StartTime?.ToLocalTime(),
                    EndTime     = meeting?.EndTime?.ToLocalTime(),
                }
            };

            var infoColumns = new List<ExcelColumnDefinition>
            {
                new() { Header = "Lớp",              PropertyName = nameof(LessonMeetingReportInfoDto.ClassName),   Width = 25 },
                new() { Header = "Môn học",          PropertyName = nameof(LessonMeetingReportInfoDto.SubjectName), Width = 25 },
                new() { Header = "Giáo viên",        PropertyName = nameof(LessonMeetingReportInfoDto.TeacherName), Width = 25 },
                new() { Header = "Thời gian bắt đầu", PropertyName = nameof(LessonMeetingReportInfoDto.StartTime),  Width = 25, Format = "dd/MM/yyyy HH:mm", HorizontalAlign = ExcelHorizontalAlign.Center },
                new() { Header = "Thời gian kết thúc", PropertyName = nameof(LessonMeetingReportInfoDto.EndTime),   Width = 25, Format = "dd/MM/yyyy HH:mm", HorizontalAlign = ExcelHorizontalAlign.Center },
            };

            var infoStyle = new ExcelSheetStyle
            {
                SheetName = "Thông tin buổi học",
                ReportTitle = $"Báo cáo kết quả buổi học - {meeting?.ClassName} - {meeting?.SubjectName} - {meeting?.StartTime?.ToLocalTime().ToString("dd/MM/yyyy")}",
                FreezeHeader = true
            };

            // 4. Chuẩn bị dữ liệu sheet danh sách học sinh
            var studentRows = students.Select(p => new LessonMeetingParticipantReportRowDto
            {
                ClassName = meeting?.ClassName,
                FullName = p.UserFullName,
                BirthDay = p.UserBirthDay,
                JoinTime = p.JoinTimeClick,
                LeaveTime = p.LeaveTime,
                JoinTimeActual = p.JoinTimeActual,
                LeaveTimeActual = p.LeaveTimeActual,
                IpAddress = p.JoinIpAddress,
                DeviceInfo = p.DeviceInfo
            }).Cast<object>().ToList();

            var participantColumns = new List<ExcelColumnDefinition>
            {
                new() { Header = "Lớp",                        PropertyName = nameof(LessonMeetingParticipantReportRowDto.ClassName),       Width = 15 },
                new() { Header = "Họ và tên",                  PropertyName = nameof(LessonMeetingParticipantReportRowDto.FullName),         Width = 30 },
                new() { Header = "Ngày sinh",                  PropertyName = nameof(LessonMeetingParticipantReportRowDto.BirthDay),         Width = 15, HorizontalAlign = ExcelHorizontalAlign.Center },
                new() { Header = "Thời gian vào",              PropertyName = nameof(LessonMeetingParticipantReportRowDto.JoinTime),         Width = 25, Format = "dd/MM/yyyy HH:mm", HorizontalAlign = ExcelHorizontalAlign.Center },
                new() { Header = "Thời gian kết thúc",         PropertyName = nameof(LessonMeetingParticipantReportRowDto.LeaveTime),        Width = 25, Format = "dd/MM/yyyy HH:mm", HorizontalAlign = ExcelHorizontalAlign.Center },
                new() { Header = "Thời gian vào thực tế",      PropertyName = nameof(LessonMeetingParticipantReportRowDto.JoinTimeActual),   Width = 25, Format = "dd/MM/yyyy HH:mm", HorizontalAlign = ExcelHorizontalAlign.Center },
                new() { Header = "Thời gian kết thúc thực tế", PropertyName = nameof(LessonMeetingParticipantReportRowDto.LeaveTimeActual),  Width = 25, Format = "dd/MM/yyyy HH:mm", HorizontalAlign = ExcelHorizontalAlign.Center },
                new() { Header = "Địa chỉ IP",                 PropertyName = nameof(LessonMeetingParticipantReportRowDto.IpAddress),        Width = 25 },
                new() { Header = "Thông tin thiết bị",         PropertyName = nameof(LessonMeetingParticipantReportRowDto.DeviceInfo),        Width = 35 },
            };

            var studentStyle = new ExcelSheetStyle
            {
                SheetName = "Danh sách học sinh",
                FreezeHeader = true
            };

            // 5. Chuẩn bị dữ liệu sheet danh sách guest
            var guestRows = guests.Select(p => new LessonMeetingGuestReportRowDto
            {
                FullName = p.UserFullName,
                JoinTime = p.JoinTimeClick,
                LeaveTime = p.LeaveTime,
                JoinTimeActual = p.JoinTimeActual,
                LeaveTimeActual = p.LeaveTimeActual,
                IpAddress = p.JoinIpAddress,
                DeviceInfo = p.DeviceInfo
            }).Cast<object>().ToList();

            var guestColumns = new List<ExcelColumnDefinition>
            {
                new() { Header = "Họ và tên",                  PropertyName = nameof(LessonMeetingGuestReportRowDto.FullName),         Width = 30 },
                new() { Header = "Thời gian vào",              PropertyName = nameof(LessonMeetingGuestReportRowDto.JoinTime),         Width = 25, Format = "dd/MM/yyyy HH:mm", HorizontalAlign = ExcelHorizontalAlign.Center },
                new() { Header = "Thời gian kết thúc",         PropertyName = nameof(LessonMeetingGuestReportRowDto.LeaveTime),        Width = 25, Format = "dd/MM/yyyy HH:mm", HorizontalAlign = ExcelHorizontalAlign.Center },
                new() { Header = "Thời gian vào thực tế",      PropertyName = nameof(LessonMeetingGuestReportRowDto.JoinTimeActual),   Width = 25, Format = "dd/MM/yyyy HH:mm", HorizontalAlign = ExcelHorizontalAlign.Center },
                new() { Header = "Thời gian kết thúc thực tế", PropertyName = nameof(LessonMeetingGuestReportRowDto.LeaveTimeActual),  Width = 25, Format = "dd/MM/yyyy HH:mm", HorizontalAlign = ExcelHorizontalAlign.Center },
                new() { Header = "Địa chỉ IP",                 PropertyName = nameof(LessonMeetingGuestReportRowDto.IpAddress),        Width = 25 },
                new() { Header = "Thông tin thiết bị",         PropertyName = nameof(LessonMeetingGuestReportRowDto.DeviceInfo),        Width = 35 },
            };

            var guestStyle = new ExcelSheetStyle
            {
                SheetName = "Danh sách guest",
                FreezeHeader = true
            };

            // 6. Export multi-sheet
            var sheets = new List<ExcelSheetData>
            {
                new(infoStyle.SheetName,    infoRows.Cast<object>(), infoColumns,        infoStyle),
                new(studentStyle.SheetName, studentRows,             participantColumns,  studentStyle),
                new(guestStyle.SheetName,   guestRows,               guestColumns,        guestStyle),
            };

            return _excelExportService.ExportMultiSheet(sheets);
        }
    }
}
