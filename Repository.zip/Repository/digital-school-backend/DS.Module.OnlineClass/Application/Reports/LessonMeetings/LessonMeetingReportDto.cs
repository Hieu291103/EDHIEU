namespace DS.Module.OnlineClass.Application.Reports.LessonMeetings
{
    /// <summary>
    /// Thông tin tổng quan buổi học để hiển thị trên báo cáo Excel
    /// </summary>
    public class LessonMeetingReportInfoDto
    {
        public string? SubjectName { get; set; }
        public string? ClassName { get; set; }
        public string? TeacherName { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
    }

    /// <summary>
    /// Thông tin học sinh (IsUser = true) trong báo cáo Excel
    /// </summary>
    public class LessonMeetingParticipantReportRowDto
    {
        public string? ClassName { get; set; }
        public string? FullName { get; set; }
        public string? BirthDay { get; set; }

        /// <summary>Thời gian vào theo lịch (JoinTimeClick)</summary>
        public DateTime? JoinTime { get; set; }

        /// <summary>Thời gian kết thúc theo lịch (LeaveTime)</summary>
        public DateTime? LeaveTime { get; set; }

        /// <summary>Thời gian vào thực tế (JoinTimeActual)</summary>
        public DateTime? JoinTimeActual { get; set; }

        /// <summary>Thời gian kết thúc thực tế (LeaveTimeActual)</summary>
        public DateTime? LeaveTimeActual { get; set; }

        public string? IpAddress { get; set; }
        public string? DeviceInfo { get; set; }
    }

    /// <summary>
    /// Thông tin guest (IsUser = false) trong báo cáo Excel.
    /// Guest không có Lớp, Ngày sinh nên dùng DTO riêng cho gọn cột.
    /// </summary>
    public class LessonMeetingGuestReportRowDto
    {
        public string? FullName { get; set; }

        /// <summary>Thời gian vào theo lịch (JoinTimeClick)</summary>
        public DateTime? JoinTime { get; set; }

        /// <summary>Thời gian kết thúc theo lịch (LeaveTime)</summary>
        public DateTime? LeaveTime { get; set; }

        /// <summary>Thời gian vào thực tế (JoinTimeActual)</summary>
        public DateTime? JoinTimeActual { get; set; }

        /// <summary>Thời gian kết thúc thực tế (LeaveTimeActual)</summary>
        public DateTime? LeaveTimeActual { get; set; }

        public string? IpAddress { get; set; }
        public string? DeviceInfo { get; set; }
    }
}
