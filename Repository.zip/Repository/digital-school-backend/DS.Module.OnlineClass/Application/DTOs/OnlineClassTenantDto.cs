using DS.Module.OnlineClass.Domain.Enums;

namespace DS.Module.OnlineClass.Application.DTOs
{
    /// <summary>
    /// DTO cho OnlineClassTenantEntity
    /// </summary>
    public class OnlineClassTenantDto
    {
        /// <summary>
        /// Id của OnlineClassTenant
        /// </summary>
        public string? Id { get; set; }

        /// <summary>
        /// TenantId
        /// </summary>
        public string? TenantId { get; set; }
        /// <summary>
        /// Tên tenant (dùng cho hiển thị, không phải mã định danh duy nhất)
        /// </summary>
        public string? TenantName { get; set; }

        /// <summary>
        /// Loại tài khoản sử dụng (MSTeams vs Zoom vs GGMeet)
        /// </summary>
        public ProviderMeetingType ProviderMeetingType { get; set; }

        /// <summary>
        /// Nhà cung cấp kết nối, ví dụ: Microsoft Teams Edmicro, Microsoft Teams xxx
        /// </summary>
        public string? ProviderConnect { get; set; }

        /// <summary>
        /// Id trường cùng tenant
        /// </summary>
        public int? SchoolId { get; set; }

        /// <summary>
        /// Hoạt động
        /// </summary>
        public bool? IsActive { get; set; }

        /// <summary>
        /// Ngày bắt đầu được sử dụng
        /// </summary>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// Ngày hết hạn sử dụng
        /// </summary>
        public DateTime? ExpireDate { get; set; }

        /// <summary>
        /// Số phút mở buổi học thực tế cho giáo viên (khi người tạo bắt đầu buổi học)
        /// </summary>
        public int? TeacherOpenMinutes { get; set; } = 15;
        /// <summary>
        /// Số phút mở buổi học thực tế cho học sinh (khi người tạo bắt đầu buổi học)
        /// </summary>
        public int? StudentOpenMinutes { get; set; } = 5;

        /// <summary>
        /// Số lượng license Zoom (nếu có, chỉ áp dụng với Zoom)
        /// </summary>
        public int? ZoomLicense { get; set; } = 0;

        /// <summary>
        /// Số phút tối đa cho phép buổi học
        /// </summary>
        public int? MeetingMinutes { get; set; } = 0;

        /// <summary>
        /// Thời điểm tạo (UTC)
        /// </summary>
        public DateTime CreatedAt { get; set; }

        /// <summary>
        /// Người tạo
        /// </summary>
        public string? CreatedBy { get; set; }

        /// <summary>
        /// Tên hiển thị của người tạo
        /// </summary>
        public string? CreatedByDisplay { get; set; }

        /// <summary>
        /// Thời điểm cập nhật gần nhất (UTC)
        /// </summary>
        public DateTime UpdatedAt { get; set; }

        /// <summary>
        /// Người cập nhật cuối
        /// </summary>
        public string? UpdatedBy { get; set; }

        /// <summary>
        /// Tên hiển thị của người cập nhật
        /// </summary>
        public string? UpdatedByDisplay { get; set; }
    }
}
