namespace DS.Module.OnlineClass.Application.DTOs
{
    /// <summary>
    /// DTO thống kê buổi học Zoom theo từng trường sử dụng Zoom
    /// </summary>
    public class ZoomMeetingOnlineClassTenantDto
    {
        /// <summary>
        /// TenantId của trường
        /// </summary>
        public string TenantId { get; set; } = string.Empty;

        /// <summary>
        /// Tên trường
        /// </summary>
        public string TenantName { get; set; } = string.Empty;

        /// <summary>
        /// Số giấy phép Zoom
        /// </summary>
        public int ZoomLicense { get; set; }

        /// <summary>
        /// Số buổi học đang hoạt động (Active)
        /// </summary>
        public int ActiveMeetingCount { get; set; }

        /// <summary>
        /// Số buổi học hôm nay (tất cả trạng thái)
        /// </summary>
        public int TodayMeetingCount { get; set; }

        /// <summary>
        /// Số buổi học chưa bắt đầu hôm nay (NotStarted)
        /// </summary>
        public int TodayNotStartedMeetingCount { get; set; }

        /// <summary>
        /// Số buổi học đã kết thúc hôm nay (Ended)
        /// </summary>
        public int TodayEndedMeetingCount { get; set; }

        /// <summary>
        /// Số buổi học trong 2h tới (chưa bắt đầu)
        /// </summary>
        public int Next2HoursMeetingCount { get; set; }


    }
}
