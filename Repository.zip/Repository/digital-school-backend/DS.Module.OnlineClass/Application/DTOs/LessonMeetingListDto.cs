namespace DS.Module.OnlineClass.Application.DTOs
{
    /// <summary>
    /// DTO chi tiết buổi học trực tuyến
    /// </summary>
    public class LessonMeetingListDto
    {
        /// <summary>
        /// ID của buổi học
        /// </summary>
        public string? Id { get; set; }

        /// <summary>
        /// Tên buổi học / Tiêu đề cuộc họp
        /// </summary>
        public string? Title { get; set; }

        /// <summary>
        /// Ngày buổi học
        /// </summary>
        public DateTime? Date { get; set; }

        /// <summary>
        /// Mô tả buổi học
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// Thời gian bắt đầu buổi học (UTC)
        /// </summary>
        public DateTime? StartTime { get; set; }

        /// <summary>
        /// Thời gian kết thúc buổi học (UTC)
        /// </summary>
        public DateTime? EndTime { get; set; }

        /// <summary>
        /// Múi giờ của buổi học
        /// </summary>
        public string? TimeZone { get; set; }

        /// <summary>
        /// Tiết học
        /// </summary>
        public string? LessonPeriod { get; set; }

        /// <summary>
        /// Thời gian mở buổi học thực tế
        /// </summary>
        public DateTime? ActualStartTime { get; set; }

        /// <summary>
        /// Thời gian kết thúc buổi học thực tế
        /// </summary>
        public DateTime? ActualEndTime { get; set; }

        /// <summary>
        /// Nhà cung cấp dịch vụ
        /// </summary>
        public string? ProviderMeetingType { get; set; }

        /// <summary>
        /// ID của lớp học
        /// </summary>
        public string? ClassId { get; set; }

        /// <summary>
        /// Tên của lớp học
        /// </summary>
        public string? ClassName { get; set; }

        /// <summary>
        /// Cấp học của lớp học
        /// </summary>
        public string? GradeId { get; set; }

        /// <summary>
        /// Mã môn dạy
        /// </summary>
        public string? Subject { get; set; }

        /// <summary>
        /// ID của người tạo buổi học
        /// </summary>
        public string? UserId { get; set; }

        /// <summary>
        /// Tên của người tạo buổi học
        /// </summary>
        public string? FullName { get; set; }

        /// <summary>
        /// Trạng thái buổi học
        /// </summary>
        public string? Status { get; set; }

        /// <summary>
        /// Thời gian tạo
        /// </summary>
        public DateTime? CreatedAt { get; set; }

        /// <summary>
        /// Người tạo
        /// </summary>
        public string? CreatedBy { get; set; }

        /// <summary>
        /// Thời gian cập nhật
        /// </summary>
        public DateTime? UpdatedAt { get; set; }

        /// <summary>
        /// Người cập nhật
        /// </summary>
        public string? UpdatedBy { get; set; }
    }
}
