namespace DS.Module.OnlineClass.Application.DTOs
{
    /// <summary>
    /// DTO thông tin license và danh sách meeting OneZoom theo khoảng thời gian
    /// </summary>
    public class LicenseInfoOneZoomMeetingDto
    {
        /// <summary>
        /// Tổng số license
        /// </summary>
        public int TotalLicenses { get; set; }

        /// <summary>
        /// Số phòng đang hoạt động hiện tại
        /// </summary>
        public int CurrentActiveRooms { get; set; }

        /// <summary>
        /// Danh sách meeting OneZoom trong khoảng thời gian
        /// </summary>
        public List<PartnerOneZoomMeetingDto> Meetings { get; set; } = [];
    }
}
