namespace DS.Module.OnlineClass.Application.DTOs
{
    /// <summary>
    /// DTO chi tiết buổi học trực tuyến
    /// </summary>
    public class LessonMeetingDetailDto
    {
        /// <summary>
        /// ID của buổi học
        /// </summary>
        public string? Id { get; set; }

        /// <summary>
        /// Tên buổi học / Tiêu đề cuộc họp
        /// </summary>
        public string? Title { get; set; }

        /// <summary>
        /// Ngày buổi học
        /// </summary>
        public DateTime? Date { get; set; }

        /// <summary>
        /// Mô tả buổi học
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// Thời gian bắt đầu buổi học (UTC)
        /// </summary>
        public DateTime? StartTime { get; set; }

        /// <summary>
        /// Thời gian kết thúc buổi học (UTC)
        /// </summary>
        public DateTime? EndTime { get; set; }

        /// <summary>
        /// Múi giờ của buổi học
        /// </summary>
        public string? TimeZone { get; set; }

        /// <summary>
        /// Tiết học
        /// </summary>
        public string? LessonPeriod { get; set; }

        /// <summary>
        /// Thời gian mở buổi học thực tế
        /// </summary>
        public DateTime? ActualStartTime { get; set; }

        /// <summary>
        /// Thời gian kết thúc buổi học thực tế
        /// </summary>
        public DateTime? ActualEndTime { get; set; }

        /// <summary>
        /// Đường dẫn tham gia buổi học
        /// </summary>
        public string? JoinUrl { get; set; }

        /// <summary>
        /// Đường dẫn tham gia buổi học dành cho co-host (Zoom)
        /// </summary>
        public string? JoinCoHostUrl { get; set; }

        /// <summary>
        /// Trạng thái đã tạo phòng học ảo thành công chưa
        /// </summary>
        public bool? JoinUrlActive { get; set; }

        /// <summary>
        /// Mã/Id buổi học
        /// </summary>
        public string? JoinMeetingId { get; set; }

        /// <summary>
        /// Mật khẩu buổi học
        /// </summary>
        public string? JoinMeetingPassword { get; set; }

        /// <summary>
        /// ID cuộc họp từ nhà cung cấp
        /// </summary>
        public string? ProviderMeetingId { get; set; }

        /// <summary>
        /// Nhà cung cấp dịch vụ
        /// </summary>
        public string? ProviderMeetingType { get; set; }

        /// <summary>
        /// ID của lớp học
        /// </summary>
        public string? ClassId { get; set; }

        /// <summary>
        /// Tên của lớp học
        /// </summary>
        public string? ClassName { get; set; }

        /// <summary>
        /// Cấp học của lớp học
        /// </summary>
        public string? GradeId { get; set; }

        /// <summary>
        /// Mã môn dạy
        /// </summary>
        public string? Subject { get; set; }

        /// <summary>
        /// ID của người tạo buổi học
        /// </summary>
        public string? UserId { get; set; }

        /// <summary>
        /// Tên của người tạo buổi học
        /// </summary>
        public string? FullName { get; set; }

        /// <summary>
        /// ID của tài khoản Meet được sử dụng (nhà cung cấp)
        /// </summary>
        public string? MeetUserId { get; set; }

        /// <summary>
        /// Email của người tạo buổi học
        /// </summary>
        public string? MeetEmail { get; set; }

        /// <summary>
        /// Trạng thái buổi học
        /// </summary>
        public string? Status { get; set; }

        /// <summary>
        /// Số lượng người tham gia hiện tại
        /// </summary>
        public int? CurrentParticipantCount { get; set; }

        /// <summary>
        /// Số lượng người tham gia tối đa
        /// </summary>
        public int? MaxParticipantCount { get; set; }

        /// <summary>
        /// URL bản ghi lại buổi học
        /// </summary>
        public string? RecordingUrl { get; set; }

        /// <summary>
        /// ID bản ghi lại từ nhà cung cấp
        /// </summary>
        public string? ProviderRecordingId { get; set; }

        /// <summary>
        /// Ghi chú bổ sung
        /// </summary>
        public string? Notes { get; set; }

        /// <summary>
        /// Có cho phép ghi lại không
        /// </summary>
        public bool AllowRecording { get; set; }

        /// <summary>
        /// ID trường
        /// </summary>
        public int? SchoolId { get; set; }

        /// <summary>
        /// Năm học
        /// </summary>
        public int? SchoolYear { get; set; } = 0;

        /// <summary>
        /// Thời gian tạo
        /// </summary>
        public DateTime? CreatedAt { get; set; }

        /// <summary>
        /// Người tạo
        /// </summary>
        public string? CreatedBy { get; set; }

        /// <summary>
        /// Thời gian cập nhật
        /// </summary>
        public DateTime? UpdatedAt { get; set; }

        /// <summary>
        /// Người cập nhật
        /// </summary>
        public string? UpdatedBy { get; set; }

        /// <summary>
        /// Tên để join vào buổi học (hiển thị trên Zoom, Teams, v.v.)
        /// </summary>
        public string? JoinDisplayName { get; set; }

        /// <summary>
        /// Số phút mở trước khi bắt đầu buổi học
        /// </summary>
        public int? OpenMinutes { get; set; } = 5;
        /// <summary>
        /// Thời gian sẽ mở cho phép tham gia buổi học (UTC)
        /// </summary>
        public long? MeetingOpenTime { get; set; } = 0;

        public List<LessonParticipantDto>? Participants { get; set; }
    }
}
