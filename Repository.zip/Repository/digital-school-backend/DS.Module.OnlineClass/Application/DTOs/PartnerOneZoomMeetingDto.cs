namespace DS.Module.OnlineClass.Application.DTOs
{
    /// <summary>
    /// DTO thông tin meeting OneZoom từ đối tác
    /// </summary>
    public class PartnerOneZoomMeetingDto
    {
        /// <summary>
        /// ID bản ghi (MongoDB ObjectId)
        /// </summary>
        public string? Id { get; set; }

        /// <summary>
        /// ID meeting bên OneZoom
        /// </summary>
        public long OneZoomId { get; set; }

        /// <summary>
        /// ID phòng Zoom
        /// </summary>
        public long ZoomRoomId { get; set; }

        /// <summary>
        /// Tiêu đề meeting
        /// </summary>
        public string? Topic { get; set; }

        /// <summary>
        /// Mô tả meeting
        /// </summary>
        public string? Agenda { get; set; }

        /// <summary>
        /// Thời lượng (phút)
        /// </summary>
        public int? DurationInMinute { get; set; }

        /// <summary>
        /// Mật khẩu phòng
        /// </summary>
        public string? RoomPassword { get; set; }

        /// <summary>
        /// URL tham gia meeting
        /// </summary>
        public string? JoinUrl { get; set; }

        /// <summary>
        /// URL bắt đầu meeting (dành cho host)
        /// </summary>
        public string? StartUrl { get; set; }

        /// <summary>
        /// Thời gian tạo
        /// </summary>
        public DateTime? CreateAt { get; set; }

        /// <summary>
        /// Trạng thái meeting
        /// </summary>
        public int? Status { get; set; }

        /// <summary>
        /// Ngày diễn ra meeting
        /// </summary>
        public DateTime? Date { get; set; }

        /// <summary>
        /// Thời gian kết thúc
        /// </summary>
        public DateTime? EndAt { get; set; }
        /// <summary>
        /// Thời gian xóa
        /// </summary>
        public DateTime? DeleteAt { get; set; }
        /// <summary>
        /// Đã xóa chưa
        /// </summary>
        public bool? IsDeleted { get; set; } = false;
    }
}
