using DS.Module.OnlineClass.Domain.Enums;

namespace DS.Module.OnlineClass.Application.DTOs
{
    /// <summary>
    /// DTO cho AccountMeetingEntity
    /// </summary>
    public class AccountMeetingDto
    {
        public string? Id { get; set; }
        /// <summary>
        /// TenantId
        /// </summary>
        public string? TenantId { get; set; }

        /// <summary>
        /// UserId của người dùng onluyen
        /// </summary>
        public string? UserId { get; set; }

        /// <summary>
        /// Tên đầy đủ trên Meet
        /// </summary>
        public string? FullName { get; set; }

        /// <summary>
        /// Tài khoản meet
        /// </summary>
        public string? UserName { get; set; }

        /// <summary>
        /// Domain của tài khoản meet
        /// </summary>
        public string? ProviderCode { get; set; }

        /// <summary>
        /// Id của nhà cung cấp meet
        /// </summary>
        public string? MeetUserId { get; set; }

        /// <summary>
        /// Email liên quan đến tài khoản meet
        /// </summary>
        public string? MeetEmail { get; set; }

        /// <summary>
        /// Mật khẩu đăng nhập tài khoản meet
        /// </summary>
        public string? MeetPassword { get; set; }

        /// <summary>
        /// Tài khoản đã đăng ký policy để sử dụng các dịch vụ của Microsoft Teams hay chưa
        /// </summary>
        public bool? MeetRegPolicy { get; set; }

        /// <summary>
        /// Id của trường học
        /// </summary>
        public int? SchoolId { get; set; }

        /// <summary>
        /// Tài khoản dành cho trường/ lớp / giáo viên
        /// </summary>
        public AccountMeetingType AccountMeetingType { get; set; }
    }
}
