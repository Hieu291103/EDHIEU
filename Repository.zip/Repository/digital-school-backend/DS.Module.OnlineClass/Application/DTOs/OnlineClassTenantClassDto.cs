namespace DS.Module.OnlineClass.Application.DTOs
{
    /// <summary>
    /// DTO cho OnlineClassTenantClassEntity
    /// </summary>
    public class OnlineClassTenantClassDto
    {
        /// <summary>
        /// Id của OnlineClassTenantClass
        /// </summary>
        public string? Id { get; set; }

        /// <summary>
        /// TenantId
        /// </summary>
        public string? TenantId { get; set; }

        /// <summary>
        /// SchoolId
        /// </summary>
        public int? SchoolId { get; set; }

        /// <summary>
        /// ClassId
        /// </summary>
        public string? ClassId { get; set; }

        /// <summary>
        /// Tên lớp học
        /// </summary>
        public string? ClassName { get; set; }

        /// <summary>
        /// Năm học
        /// </summary>
        public int SchoolYear { get; set; }

        /// <summary>
        /// Tên khối
        /// </summary>
        public string? GradeName { get; set; }

        /// <summary>
        /// GradeId
        /// </summary>
        public string? GradeId { get; set; }

        /// <summary>
        /// Số lượng học sinh
        /// </summary>
        public int? CountStudent { get; set; }

        /// <summary>
        /// Trạng thái hoạt động
        /// </summary>
        public bool IsActive { get; set; }
    }
}
