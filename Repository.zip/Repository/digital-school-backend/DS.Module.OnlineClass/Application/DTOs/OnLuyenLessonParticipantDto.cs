namespace DS.Module.OnlineClass.Application.DTOs
{
    public class OnLuyenLessonParticipantDto
    {
        public string? Id { get; set; }

        /// <summary>
        /// Xác nhận là user hay là guest (có thể không điền đúng tên)
        /// </summary>
        public bool? IsUser { get; set; } = false;

        /// <summary>
        /// Loại tài khoản người tham gia (Teacher, Student)
        /// </summary>
        public string? UserType { get; set; }

        /// <summary>
        /// ID của người tham gia (học sinh, giáo viên, v.v.)
        /// </summary>

        public string? UserId { get; set; }

        /// <summary>
        /// Tên đăng nhập
        /// </summary>
        public string? Username { get; set; }

        /// <summary>
        /// Tên người tham gia (snapshot tại thời điểm tham gia)
        /// </summary>
        public string? UserFullName { get; set; }

        /// <summary>
        /// Tên hiển thị trên zoom, teams (snapshot tại thời điểm tham gia)
        /// UserFullName - Username
        /// </summary>
        public string? UserDisplayName { get; set; }

        /// <summary>
        /// Ngày sinh của người tham gia (snapshot tại thời điểm tham gia)
        /// </summary>
        public string? UserBirthDay { get; set; }

        /// <summary>
        /// Thời gian tham gia buổi học khi nhấn vào link
        /// </summary>
        public long? JoinTimeClick { get; set; }

        /// <summary>
        /// Thời gian tham gia buổi học thực tế lấy từ nhà cung cấp (MS Teams, Zoom, v.v.)
        /// </summary>
        public long? JoinTimeActual { get; set; }

        /// <summary>
        /// Thời gian rời khỏi buổi học
        /// </summary>
        public long? LeaveTime { get; set; }

        /// <summary>
        /// Thời gian rời khỏi buổi học thực tế lấy từ nhà cung cấp (MS Teams, Zoom, v.v.)
        /// </summary>
        public long? LeaveTimeActual { get; set; }

        /// <summary>
        /// Thời lượng tham gia thực tế (tính bằng phút)
        /// </summary>
        public int? DurationInMinutes { get; set; }

        /// <summary>
        /// Trạng thái điểm danh (Attended/Absent/Late/EarlyLeave)
        /// </summary>
        public string? AttendanceStatus { get; set; }

        /// <summary>
        /// Ghi chú về sự tham gia (vắng mặt không phép, v.v.)
        /// </summary>
        public string? Notes { get; set; }

        /// <summary>
        /// ID từ nhà cung cấp (MS Teams, Zoom, v.v.) để kết nối thông tin
        /// </summary>
        public string? ProviderParticipantId { get; set; }

        /// <summary>
        /// Có hoàn thành bài tập về nhà liên quan đến buổi học không
        /// </summary>
        public bool? HasCompletedHomework { get; set; }

        /// <summary>
        /// Phần trăm tham gia (dựa trên thời lượng)
        /// </summary>
        public decimal? ParticipationPercentage { get; set; }

        /// <summary>
        /// IP address khi tham gia
        /// </summary>
        public string? JoinIpAddress { get; set; }

        /// <summary>
        /// Device/Browser được sử dụng
        /// </summary>
        public string? DeviceInfo { get; set; }
        /// <summary>
        /// Địa điểm thực tế khi tham gia (nếu có)
        /// </summary>
        public string? Location { get; set; }
    }
}
