using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.OnlineClass.Application.Queries.LessonMeetings
{
    /// <summary>
    /// Handler cho GetLessonMeetingForTeacherQuery
    /// Lấy danh sách buổi học trực tuyến của giáo viên theo ngày
    /// </summary>
    public class GetLessonMeetingListForTeacherQueryHandler : IQueryHandler<GetLessonMeetingListForTeacherQuery, List<LessonMeetingListDto>>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _lessonMeetingRepository;
        private readonly AutoMapper.IMapper _mapper;

        public GetLessonMeetingListForTeacherQueryHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> lessonMeetingRepository,
            AutoMapper.IMapper mapper)
        {
            _lessonMeetingRepository = lessonMeetingRepository;
            _mapper = mapper;
        }

        public async Task<List<LessonMeetingListDto>> Handle(
            GetLessonMeetingListForTeacherQuery request,
            CancellationToken cancellationToken)
        {
            // Tính toán ngày kết thúc (inclusive)
            var endDate = request.EndDate.Date.AddDays(1);

            // Filter theo SchoolId, UserId và date range dựa trên trường Date
            var lessonMeetings = await _lessonMeetingRepository.FilterAsync(
                x => x.SchoolId == request.SchoolId
                     && x.UserId == request.UserId
                     && x.Date >= request.StartDate.Date
                     && x.Date < endDate,
                orderByDescending: false,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (lessonMeetings == null || !lessonMeetings.Any())
            {
                return new List<LessonMeetingListDto>();
            }

            // Sort by StartTime descending (newest first)
            var sortedLessonMeetings = lessonMeetings.OrderByDescending(x => x.StartTime).ToList();

            // Map entities to DTOs sử dụng AutoMapper
            var dtos = _mapper.Map<List<LessonMeetingListDto>>(sortedLessonMeetings);
            return dtos;
        }
    }
}
