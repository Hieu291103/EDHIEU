using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Infrastructure.Common;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.OnlineClass.Application.Queries.LessonMeetings
{
    /// <summary>
    /// Handler cho GetLessonMeetingForTeacherQuery
    /// Lấy chi tiết buổi học trực tuyến kèm thông tin tham gia dành cho giáo viên
    /// </summary>
    public class GetLessonMeetingForTeacherQueryHandler : IQueryHandler<GetLessonMeetingForTeacherQuery, LessonMeetingDetailDto?>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _lessonMeetingRepository;
        private readonly ISchoolCommonReadRepository<OnlineClassTenantEntity> _onlineClassTenantRepository;
        private readonly ISchoolCommonReadRepository<LessonParticipantEntity> _lessonParticipantRepository;
        private readonly IMapper _mapper;

        public GetLessonMeetingForTeacherQueryHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> lessonMeetingRepository,
            ISchoolCommonReadRepository<OnlineClassTenantEntity> onlineClassTenantRepository,
            ISchoolCommonReadRepository<LessonParticipantEntity> lessonParticipantRepository,
            IMapper mapper)
        {
            _lessonMeetingRepository = lessonMeetingRepository;
            _onlineClassTenantRepository = onlineClassTenantRepository;
            _lessonParticipantRepository = lessonParticipantRepository;
            _mapper = mapper;
        }

        public async Task<LessonMeetingDetailDto?> Handle(
            GetLessonMeetingForTeacherQuery request,
            CancellationToken cancellationToken)
        {
            // B1: Lấy buổi học theo Id
            var meetings = await _lessonMeetingRepository.FilterAsync(
                x => x.Id == request.Id,
                tenantId: null,
                cancellationToken: cancellationToken);

            var meeting = meetings.FirstOrDefault();
            if (meeting is null)
            {
                return null;
            }

            // B2: Lấy cấu hình OnlineClassTenant theo SchoolId để lấy TeacherOpenMinutes
            var tenantConfigs = await _onlineClassTenantRepository.FilterAsync(
                x => x.SchoolId == meeting.SchoolId && x.IsActive,
                tenantId: null,
                cancellationToken: cancellationToken);

            var tenantConfig = tenantConfigs.FirstOrDefault();
            var openMinutes = tenantConfig?.TeacherOpenMinutes ?? 5;

            //lấy điểm danh của buổi học
            var participants = await _lessonParticipantRepository.FilterAsync(
            x => x.LessonMeetingId == meeting.Id && x.UserType == Shared.Core.Enums.UserType.Student,
            tenantId: null,
            cancellationToken: cancellationToken);

            // B3: Map entity → DTO qua AutoMapper (xử lý các field cơ bản)
            var dto = _mapper.Map<LessonMeetingDetailDto>(meeting);
            dto.Participants = _mapper.Map<List<LessonParticipantDto>>(participants);
            // B4: Set các field cần tính toán thêm
            dto.OpenMinutes = openMinutes;
            dto.JoinDisplayName = LessionMeetingHelper.MeetingDisplayName(request.FullName, request.UserName);
            dto.MeetingOpenTime = meeting.StartTime.HasValue
                ? DatetimeHelper.ToTimestamp(meeting.StartTime.Value)
                  - (openMinutes * 60)
                : null;

            return dto;
        }
    }
}
