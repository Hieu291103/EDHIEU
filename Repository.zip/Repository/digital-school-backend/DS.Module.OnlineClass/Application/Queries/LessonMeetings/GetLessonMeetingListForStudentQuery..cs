using DS.Module.OnlineClass.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;

namespace DS.Module.OnlineClass.Application.Queries.LessonMeetings
{
    public class GetLessonMeetingListForStudentQuery : IQuery<List<LessonMeetingListDto>>
    {
        /// <summary>
        /// ID của trường
        /// </summary>
        public int? SchoolId { get; set; }
        /// <summary>
        /// Id của lớp
        /// </summary>
        public string ClassId { get; set; } = string.Empty;
        /// <summary>
        /// Ngày bắt đầu
        /// </summary>
        public DateTime StartDate { get; set; }
        /// <summary>
        /// Ngày Kết thúc
        /// </summary>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Múi giờ của buổi học
        /// </summary>
        public string? TimeZone { get; set; } = DatetimeHelper.DefaultTimeZone;
    }
}
