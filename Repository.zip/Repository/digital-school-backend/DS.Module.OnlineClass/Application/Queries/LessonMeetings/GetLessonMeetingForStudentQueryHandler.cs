using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Infrastructure.Common;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.OnlineClass.Application.Queries.LessonMeetings
{
    /// <summary>
    /// Handler cho GetLessonMeetingForStudentQuery
    /// Lấy chi tiết buổi học trực tuyến kèm thông tin tham gia dành cho học sinh
    /// </summary>
    public class GetLessonMeetingForStudentQueryHandler : IQueryHandler<GetLessonMeetingForStudentQuery, LessonMeetingDetailDto?>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _lessonMeetingRepository;
        private readonly ISchoolCommonReadRepository<OnlineClassTenantEntity> _onlineClassTenantRepository;
        private readonly IMapper _mapper;

        public GetLessonMeetingForStudentQueryHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> lessonMeetingRepository,
            ISchoolCommonReadRepository<OnlineClassTenantEntity> onlineClassTenantRepository,
            IMapper mapper)
        {
            _lessonMeetingRepository = lessonMeetingRepository;
            _onlineClassTenantRepository = onlineClassTenantRepository;
            _mapper = mapper;
        }

        public async Task<LessonMeetingDetailDto?> Handle(
            GetLessonMeetingForStudentQuery request,
            CancellationToken cancellationToken)
        {
            // B1: Lấy buổi học theo Id
            var meetings = await _lessonMeetingRepository.FilterAsync(
                x => x.Id == request.Id,
                tenantId: null,
                cancellationToken: cancellationToken);

            var meeting = meetings.FirstOrDefault();
            if (meeting is null)
            {
                return null;
            }

            // B2: Lấy cấu hình OnlineClassTenant theo SchoolId để lấy StudentOpenMinutes
            var tenantConfigs = await _onlineClassTenantRepository.FilterAsync(
                x => x.SchoolId == meeting.SchoolId && x.IsActive,
                tenantId: null,
                cancellationToken: cancellationToken);

            var tenantConfig = tenantConfigs.FirstOrDefault();
            var openMinutes = tenantConfig?.StudentOpenMinutes ?? 5;

            // B3: Map entity → DTO qua AutoMapper (xử lý các field cơ bản)
            var dto = _mapper.Map<LessonMeetingDetailDto>(meeting);

            // B4: Set các field cần tính toán thêm
            dto.OpenMinutes = openMinutes;
            dto.JoinDisplayName = LessionMeetingHelper.MeetingDisplayName(request.FullName, request.UserName);
            dto.MeetingOpenTime = meeting.StartTime.HasValue
                ? new DateTimeOffset(meeting.StartTime.Value.ToUniversalTime()).ToUnixTimeMilliseconds()
                  - (openMinutes * 60_000L)
                : null;

            return dto;
        }
    }
}
