using DS.Module.OnlineClass.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Queries.LessonMeetings
{
    public class GetLessonMeetingForTeacherQuery : IQuery<LessonMeetingDetailDto?>
    {
        /// <summary>
        /// ID của buổi học trực tuyến
        /// </summary>
        public required string Id { get; set; }
        /// <summary>
        /// Id của người dùng 
        /// </summary>
        public string UserId { get; set; } = string.Empty;
        /// <summary>
        /// username của người dùng, dùng để hiển thị khi tham gia buổi học trực tuyến (Zoom/Teams), format: "Tên lớp - Tên buổi học - username"
        /// </summary>
        public string? UserName { get; set; }
        /// <summary>
        /// tên đầy đủ của người dùng, dùng để hiển thị khi tham gia buổi học trực tuyến (Zoom/Teams), format: "Tên lớp - Tên buổi học - Họ tên học sinh"
        /// </summary>
        public string? FullName { get; set; }
    }
}
