using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.OnlineClass.Application.Queries.LessonMeetings
{
    /// <summary>
    /// Handler để lấy chi tiết buổi học trực tuyến (Lesson Meeting) theo ID
    /// </summary>
    public class GetLessonMeetingByIdQueryHandler : IQueryHandler<GetLessonMeetingByIdQuery, LessonMeetingDetailDto?>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _lessonMeetingRepository;
        private readonly AutoMapper.IMapper _mapper;

        public GetLessonMeetingByIdQueryHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> lessonMeetingRepository,
            AutoMapper.IMapper mapper)
        {
            _lessonMeetingRepository = lessonMeetingRepository;
            _mapper = mapper;
        }

        public async Task<LessonMeetingDetailDto?> Handle(GetLessonMeetingByIdQuery request, CancellationToken cancellationToken)
        {
            // Lấy tất cả lesson meetings cho tenant này
            var lessonMeetings = await _lessonMeetingRepository.FilterAsync(
                x => x.Id == request.Id);

            var lessonMeeting = lessonMeetings.FirstOrDefault();

            if (lessonMeeting is null)
            {
                return null;
            }

            // Map entity to detail DTO
            var detailDto = _mapper.Map<LessonMeetingDetailDto>(lessonMeeting);

            return detailDto;
        }
    }
}
