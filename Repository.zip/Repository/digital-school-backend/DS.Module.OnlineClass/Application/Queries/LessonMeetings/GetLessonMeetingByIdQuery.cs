using DS.Module.OnlineClass.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Queries.LessonMeetings
{
    /// <summary>
    /// Query để lấy chi tiết buổi học trực tuyến (Lesson Meeting) theo ID
    /// </summary>
    public class GetLessonMeetingByIdQuery : IQuery<LessonMeetingDetailDto?>
    {
        /// <summary>
        /// ID của buổi học trực tuyến
        /// </summary>
        public required string Id { get; set; }

    }


}
