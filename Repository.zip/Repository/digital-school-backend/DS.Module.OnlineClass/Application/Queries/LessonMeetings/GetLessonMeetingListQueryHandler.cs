using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Bson;
using MongoDB.Driver;
using System.Text.RegularExpressions;

namespace DS.Module.OnlineClass.Application.Queries.LessonMeetings
{
    /// <summary>
    /// Handler cho GetLessonMeetingListQuery
    /// Lấy danh sách buổi học trực tuyến với hỗ trợ lọc, tìm kiếm và pagination
    /// </summary>
    public class GetLessonMeetingListQueryHandler : IQueryHandler<GetLessonMeetingListQuery, PagedResult<LessonMeetingListDto>>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _repository;
        private readonly IMapper _mapper;

        public GetLessonMeetingListQueryHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> repository,
            IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<PagedResult<LessonMeetingListDto>> Handle(GetLessonMeetingListQuery request, CancellationToken cancellationToken)
        {
            var pageIndex = request.PageIndex ?? 1;
            var pageSize = request.PageSize ?? 50;

            // Xây dựng filter
            var filterBuilder = Builders<LessonMeetingEntity>.Filter;
            var filter = filterBuilder.Empty;

            // Filter theo TenantId
            filter = filterBuilder.And(filter, filterBuilder.Eq(x => x.TenantId, request.TenantId));

            // Filter theo Status nếu được cung cấp
            if (request.Status.HasValue)
            {
                filter = filterBuilder.And(filter, filterBuilder.Eq(x => x.Status, request.Status.Value));
            }

            // Filter theo Keyword nếu được cung cấp
            if (!string.IsNullOrEmpty(request.Keyword))
            {
                var escapedKeyword = Regex.Escape(request.Keyword.Trim());
                var keywordRegex = new BsonRegularExpression(escapedKeyword, "i");

                var keywordFilter = filterBuilder.Or(
                    filterBuilder.Regex(x => x.Title, keywordRegex),
                    filterBuilder.Regex(x => x.Description, keywordRegex)
                );
                filter = filterBuilder.And(filter, keywordFilter);
            }

            // Xây dựng sort definition (sắp xếp theo StartTime giảm dần - mới nhất trước)
            var sortDefinition = Builders<LessonMeetingEntity>.Sort.Descending(x => x.StartTime);

            // Lấy dữ liệu với pagination và sorting ở database level
            var pagedResult = await _repository.PagedFilterAsync(
                filter,
                sortDefinition,
                pageIndex,
                pageSize,
                tenantId: request.TenantId,
                cancellationToken: cancellationToken);

            // Chuyển đổi sang DTO
            var dtos = _mapper.Map<List<LessonMeetingListDto>>(pagedResult.Items);

            // Trả về kết quả phân trang
            return new PagedResult<LessonMeetingListDto>
            {
                Items = dtos,
                Page = pageIndex,
                PageIndex = pageIndex,
                PageSize = pageSize,
                Total = pagedResult.Total
            };
        }
    }
}
