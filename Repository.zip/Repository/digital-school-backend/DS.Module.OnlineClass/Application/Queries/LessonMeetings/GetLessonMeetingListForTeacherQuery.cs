using DS.Module.OnlineClass.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;

namespace DS.Module.OnlineClass.Application.Queries.LessonMeetings
{
    /// <summary>
    /// Query để lấy danh sách buổi học trực tuyến của giáo viên theo ngày
    /// </summary>
    public class GetLessonMeetingListForTeacherQuery : IQuery<List<LessonMeetingListDto>>
    {
        /// <summary>
        /// ID của trường
        /// </summary>
        public int? SchoolId { get; set; }

        /// <summary>
        /// Id của người dùng tạo
        /// </summary>
        public string UserId { get; set; } = string.Empty;
        /// <summary>
        /// Ngày bắt đầu
        /// </summary>
        public DateTime StartDate { get; set; }
        /// <summary>
        /// Ngày Kết thúc
        /// </summary>
        public DateTime EndDate { get; set; }
        /// <summary>
        /// Múi giờ của buổi học
        /// </summary>
        public string? TimeZone { get; set; } = DatetimeHelper.DefaultTimeZone;
    }
}
