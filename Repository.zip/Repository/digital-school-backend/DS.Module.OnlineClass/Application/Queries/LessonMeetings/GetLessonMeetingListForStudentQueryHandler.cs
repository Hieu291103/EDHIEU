using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.OnlineClass.Application.Queries.LessonMeetings
{
    /// <summary>
    /// Handler cho GetLessonMeetingForStudentQuery
    /// Lấy danh sách buổi học trực tuyến của học sinh theo lớp và ngày
    /// </summary>
    public class GetLessonMeetingListForStudentQueryHandler : IQueryHandler<GetLessonMeetingListForStudentQuery, List<LessonMeetingListDto>>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _lessonMeetingRepository;
        private readonly AutoMapper.IMapper _mapper;

        public GetLessonMeetingListForStudentQueryHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> lessonMeetingRepository,
            AutoMapper.IMapper mapper)
        {
            _lessonMeetingRepository = lessonMeetingRepository;
            _mapper = mapper;
        }

        public async Task<List<LessonMeetingListDto>> Handle(
            GetLessonMeetingListForStudentQuery request,
            CancellationToken cancellationToken)
        {
            // Tính toán ngày kết thúc (inclusive)
            var endDate = request.EndDate.Date.AddDays(1);

            // Filter theo SchoolId, ClassId và date range dựa trên trường Date
            var lessonMeetings = await _lessonMeetingRepository.FilterAsync(
                x => x.SchoolId == request.SchoolId
                     && x.ClassId == request.ClassId
                     && x.Date >= request.StartDate.Date
                     && x.Date < endDate,
                orderByDescending: false,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (lessonMeetings == null || !lessonMeetings.Any())
            {
                return new List<LessonMeetingListDto>();
            }

            // Sort by StartTime descending (newest first)
            var sortedLessonMeetings = lessonMeetings.OrderByDescending(x => x.StartTime).ToList();

            // Map entities to DTOs sử dụng AutoMapper
            var dtos = _mapper.Map<List<LessonMeetingListDto>>(sortedLessonMeetings);
            return dtos;
        }
    }
}
