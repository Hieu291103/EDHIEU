using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Requests;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Queries.LessonMeetings
{
    /// <summary>
    /// Query để lấy danh sách buổi học trực tuyến (Lesson Meetings)
    /// Hỗ trợ lọc theo tenant, trạng thái và tìm kiếm theo từ khóa
    /// </summary>
    public class GetLessonMeetingListQuery : FilterRequest, IQuery<PagedResult<LessonMeetingListDto>>
    {
        /// <summary>
        /// ID của tenant/tổ chức
        /// </summary>
        public required string TenantId { get; set; }

        /// <summary>
        /// Trạng thái buổi học (Active, Ended, Cancelled)
        /// Nếu null, trả về tất cả trạng thái
        /// </summary>
        public MeetingStatus? Status { get; set; }

    }
}
