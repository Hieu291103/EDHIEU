using DS.Module.OnlineClass.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Queries.PartnerOneZoomMeetingEntitys
{
    /// <summary>
    /// Query lấy thông tin license OneZoom và danh sách meeting theo khoảng thời gian
    /// </summary>
    public class GetLicenseInfoOneZoomMeetingQuery : IQuery<LicenseInfoOneZoomMeetingDto>
    {
        /// <summary>
        /// Thời gian bắt đầu lọc (theo PartnerOneZoomMeetingEntity.Date)
        /// </summary>
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Thời gian kết thúc lọc (theo PartnerOneZoomMeetingEntity.Date)
        /// </summary>
        public DateTime? ToDate { get; set; }

        public string? TenantId { get; set; }
    }
}
