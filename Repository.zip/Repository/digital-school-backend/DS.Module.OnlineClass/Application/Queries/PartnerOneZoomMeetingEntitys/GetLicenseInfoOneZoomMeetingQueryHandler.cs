using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Queries.PartnerOneZoomMeetingEntitys
{
    /// <summary>
    /// Handler cho GetLicenseInfoOneZoomMeetingQuery
    /// Lấy thông tin license từ OneZoom và danh sách meeting theo khoảng thời gian
    /// </summary>
    public class GetLicenseInfoOneZoomMeetingQueryHandler
        : IQueryHandler<GetLicenseInfoOneZoomMeetingQuery, LicenseInfoOneZoomMeetingDto>
    {
        private readonly IOneZoomService _oneZoomService;
        private readonly ISchoolCommonReadRepository<PartnerOneZoomMeetingEntity> _meetingRepository;
        private readonly IMapper _mapper;

        public GetLicenseInfoOneZoomMeetingQueryHandler(
            IOneZoomService oneZoomService,
            ISchoolCommonReadRepository<PartnerOneZoomMeetingEntity> meetingRepository,
            IMapper mapper)
        {
            _oneZoomService = oneZoomService;
            _meetingRepository = meetingRepository;
            _mapper = mapper;
        }

        public async Task<LicenseInfoOneZoomMeetingDto> Handle(
            GetLicenseInfoOneZoomMeetingQuery request,
            CancellationToken cancellationToken)
        {
            // 1. Lấy thông tin license từ OneZoom API
            var userInfo = await _oneZoomService.GetCurrentUserAsync(
               "ZOOM_ONE_ZOOM",
                cancellationToken);

            // 2. Lấy danh sách PartnerOneZoomMeetingEntity theo khoảng thời gian
            var filters = new List<FilterDefinition<PartnerOneZoomMeetingEntity>>
            {
                Builders<PartnerOneZoomMeetingEntity>.Filter.Ne(x => x.IsDeleted, true)
            };

            if (request.FromDate.HasValue)
                filters.Add(Builders<PartnerOneZoomMeetingEntity>.Filter.Gte(x => x.Date, request.FromDate.Value));

            if (request.ToDate.HasValue)
                filters.Add(Builders<PartnerOneZoomMeetingEntity>.Filter.Lte(x => x.Date, request.ToDate.Value));

            if (!string.IsNullOrEmpty(request.TenantId))
                filters.Add(Builders<PartnerOneZoomMeetingEntity>.Filter.Eq(x => x.TenantId, request.TenantId));

            var filter = Builders<PartnerOneZoomMeetingEntity>.Filter.And(filters);
            var meetings = await _meetingRepository.FilterAsync(filter, true, null, cancellationToken: cancellationToken);

            return new LicenseInfoOneZoomMeetingDto
            {
                TotalLicenses = userInfo?.TotalLicenses ?? 0,
                CurrentActiveRooms = userInfo?.CurrentActiveRooms ?? 0,
                Meetings = _mapper.Map<List<PartnerOneZoomMeetingDto>>(meetings)
            };
        }
    }
}
