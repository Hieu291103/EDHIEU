using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.Core.Infrastructure.Services.Onluyen;
using DS.Shared.CQRS.Queries.Tenants;
using MediatR;

namespace DS.Module.OnlineClass.Application.Queries.OnlineClassTenantClass
{
    /// <summary>
    /// Handler cho GetOnlineClassTenantClassListQuery
    /// </summary>
    public class GetOnlineClassTenantClassListQueryHandler : IQueryHandler<GetOnlineClassTenantClassListQuery, List<OnlineClassTenantClassDto>>
    {
        private readonly ISchoolCommonReadRepository<OnlineClassTenantClassEntity> _readRepository;
        private readonly IMediator _mediator;
        private readonly IOnluyenService _onluyenService;
        private readonly IMapper _mapper;

        public GetOnlineClassTenantClassListQueryHandler(
            ISchoolCommonReadRepository<OnlineClassTenantClassEntity> readRepository,
            IMediator mediator,
            IOnluyenService onluyenService,
            IMapper mapper)
        {
            _readRepository = readRepository;
            _mediator = mediator;
            _onluyenService = onluyenService;
            _mapper = mapper;
        }

        public async Task<List<OnlineClassTenantClassDto>> Handle(GetOnlineClassTenantClassListQuery request, CancellationToken cancellationToken)
        {
            var returnData = new List<OnlineClassTenantClassDto>();

            //Lấy dữ liệu lớp hiện tại của tenant từ database
            var onlineClassTenantClasses = await _readRepository.FilterAsync(
                x => x.TenantId == request.TenantId && x.SchoolYear == request.SchoolYear,
                tenantId: null,
                cancellationToken: cancellationToken);

            //lấy thông tin tenant, schoolId từ database để gọi api onluyen
            var tenant = await _mediator.Send(new SharedGetTenantByIdQuery { TenantId = request.TenantId! }, cancellationToken);

            if (tenant != null && tenant.SchoolId != null)
            {
                //Lấy lớp từ onluyen
                var onluyenClasses = await _onluyenService.GetClassesBySchoolAsync(tenant.SchoolId!.Value, request.SchoolYear);
                foreach (var olclass in onluyenClasses)
                {
                    var tenantClass = onlineClassTenantClasses.FirstOrDefault(x => x.ClassId == olclass.ClassId);
                    if (tenantClass != null)
                    {
                        returnData.Add(new OnlineClassTenantClassDto
                        {
                            Id = tenantClass.Id,
                            TenantId = tenantClass.TenantId,
                            SchoolId = tenantClass.SchoolId,
                            ClassId = tenantClass.ClassId,
                            ClassName = tenantClass.ClassName,
                            GradeId = tenantClass.GradeId,
                            GradeName = tenantClass.GradeName,
                            SchoolYear = tenantClass.SchoolYear,
                            CountStudent = olclass.CountStudent,
                            IsActive = tenantClass.IsActive,
                        });
                    }
                    else
                    {
                        returnData.Add(new OnlineClassTenantClassDto
                        {
                            Id = null,
                            TenantId = request.TenantId,
                            SchoolId = tenant.SchoolId,
                            ClassId = olclass.ClassId,
                            ClassName = olclass.ClassName,
                            GradeId = olclass.GradeId,
                            GradeName = olclass.GradeName,
                            SchoolYear = request.SchoolYear,
                            CountStudent = olclass.CountStudent,
                            IsActive = false
                        });
                    }
                }
            }
            //sort lại returnData theo GradeName (natural order), sau đó đến ClassName (natural order)
            returnData = returnData
                .OrderByNatural(x => x.GradeName ?? string.Empty)
                .ThenByNatural(x => x.ClassName ?? string.Empty)
                .ToList();
            return returnData;
        }
    }
}
