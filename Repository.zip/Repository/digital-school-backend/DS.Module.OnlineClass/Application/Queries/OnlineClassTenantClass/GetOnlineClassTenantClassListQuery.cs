using DS.Module.OnlineClass.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Queries.OnlineClassTenantClass
{
    /// <summary>
    /// Query để lấy danh sách lớp học online class theo TenantId và SchoolYear
    /// </summary>
    public class GetOnlineClassTenantClassListQuery : IQuery<List<OnlineClassTenantClassDto>>
    {
        /// <summary>
        /// TenantId để filter theo tenant
        /// </summary>
        public required string TenantId { get; set; }

        /// <summary>
        /// Năm học để filter
        /// </summary>
        public required int SchoolYear { get; set; }
    }
}
