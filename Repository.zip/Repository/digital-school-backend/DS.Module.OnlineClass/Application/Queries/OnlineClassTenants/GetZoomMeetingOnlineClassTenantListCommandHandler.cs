using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Queries.Tenants;
using MediatR;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Queries.OnlineClassTenants
{
    /// <summary>
    /// Handler cho GetZoomMeetingOnlineClassTenantListQueryHandler
    /// Lấy realtime thống kê buổi học Zoom theo từng trường sử dụng Zoom
    /// </summary>
    public class GetZoomMeetingOnlineClassTenantListQueryHandler
        : IQueryHandler<GetZoomMeetingOnlineClassTenantListQuery, List<ZoomMeetingOnlineClassTenantDto>>
    {
        private readonly ISchoolCommonReadRepository<OnlineClassTenantEntity> _tenantRepository;
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _meetingRepository;
        private readonly IMediator _mediator;

        public GetZoomMeetingOnlineClassTenantListQueryHandler(
            ISchoolCommonReadRepository<OnlineClassTenantEntity> tenantRepository,
            ISchoolCommonReadRepository<LessonMeetingEntity> meetingRepository,
            IMediator mediator)
        {
            _tenantRepository = tenantRepository;
            _meetingRepository = meetingRepository;
            _mediator = mediator;
        }

        public async Task<List<ZoomMeetingOnlineClassTenantDto>> Handle(
            GetZoomMeetingOnlineClassTenantListQuery request,
            CancellationToken cancellationToken)
        {
            // 1. Lấy tất cả OnlineClassTenant sử dụng Zoom và đang active
            var tenantFilter = Builders<OnlineClassTenantEntity>.Filter.And(
                Builders<OnlineClassTenantEntity>.Filter.Eq(x => x.ProviderMeetingType, ProviderMeetingType.Zoom),
                Builders<OnlineClassTenantEntity>.Filter.Eq(x => x.IsActive, true)
            );
            var zoomTenants = await _tenantRepository.FilterAsync(tenantFilter, cancellationToken: cancellationToken);

            if (!zoomTenants.Any())
                return [];

            // 2. Lấy tên tenant
            var tenantIds = zoomTenants.Select(t => t.TenantId).Where(id => !string.IsNullOrEmpty(id)).Distinct().ToList();
            var tenantNames = new Dictionary<string, string>();
            if (tenantIds.Count > 0)
            {
                var tenants = await _mediator.Send(new SharedGetTenantByIdsQuery { TenantIds = tenantIds! }, cancellationToken);
                tenantNames = tenants.ToDictionary(t => t.Id, t => t.Name);
            }

            // 3. Xác định khoảng thời gian hôm nay và 2h tới (UTC)
            var now = DateTime.UtcNow;
            var todayStart = now.Date;
            var todayEnd = todayStart.AddDays(1);
            var next2HoursEnd = now.AddHours(2);

            // 4. Chỉ lấy meeting cần thiết: đang Active HOẶC diễn ra hôm nay
            var meetingFilter = Builders<LessonMeetingEntity>.Filter.And(
                Builders<LessonMeetingEntity>.Filter.Eq(x => x.ProviderMeetingType, ProviderMeetingType.Zoom),
                Builders<LessonMeetingEntity>.Filter.In(x => x.TenantId, tenantIds),
                Builders<LessonMeetingEntity>.Filter.Or(
                    Builders<LessonMeetingEntity>.Filter.Eq(x => x.Status, MeetingStatus.Active),
                    Builders<LessonMeetingEntity>.Filter.And(
                        Builders<LessonMeetingEntity>.Filter.Gte(x => x.Date, todayStart),
                        Builders<LessonMeetingEntity>.Filter.Lt(x => x.Date, todayEnd)
                    )
                )
            );
            var relevantMeetings = await _meetingRepository.FilterAsync(meetingFilter, cancellationToken: cancellationToken);

            // 5. Group buổi học theo TenantId để tính thống kê
            var meetingsByTenant = relevantMeetings.GroupBy(m => m.TenantId).ToDictionary(g => g.Key, g => g.ToList());

            // 6. Tổng hợp kết quả
            var result = new List<ZoomMeetingOnlineClassTenantDto>();
            foreach (var tenant in zoomTenants)
            {
                var tid = tenant.TenantId ?? string.Empty;
                meetingsByTenant.TryGetValue(tid, out var meetings);
                meetings ??= [];

                var todayMeetings = meetings.Where(m => m.Date >= todayStart && m.Date < todayEnd).ToList();

                var dto = new ZoomMeetingOnlineClassTenantDto
                {
                    TenantId = tid,
                    TenantName = tenantNames.TryGetValue(tid, out var name) ? name : string.Empty,
                    ZoomLicense = tenant.ZoomLicense ?? 0,
                    ActiveMeetingCount = meetings.Count(m => m.Status == MeetingStatus.Active),
                    TodayMeetingCount = todayMeetings.Count,
                    TodayNotStartedMeetingCount = todayMeetings.Count(m => m.Status == MeetingStatus.NotStarted),
                    Next2HoursMeetingCount = todayMeetings.Count(m =>
                        m.Status == MeetingStatus.NotStarted &&
                        m.StartTime.HasValue &&
                        m.StartTime.Value >= now &&
                        m.StartTime.Value <= next2HoursEnd),
                    TodayEndedMeetingCount = todayMeetings.Count(m => m.Status == MeetingStatus.Ended),
                };

                result.Add(dto);
            }

            return result;
        }
    }
}
