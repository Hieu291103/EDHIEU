using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Queries.Tenants;
using MediatR;

namespace DS.Module.OnlineClass.Application.Queries.OnlineClassTenants
{
    /// <summary>
    /// Handler cho GetOnlineClassTenantByIdQuery
    /// </summary>
    public class GetOnlineClassTenantByIdQueryHandler : IQueryHandler<GetOnlineClassTenantByIdQuery, OnlineClassTenantDto?>
    {
        private readonly ISchoolCommonReadRepository<OnlineClassTenantEntity> _readRepository;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetOnlineClassTenantByIdQueryHandler(
            ISchoolCommonReadRepository<OnlineClassTenantEntity> readRepository,
            IMediator mediator,
            IMapper mapper)
        {
            _readRepository = readRepository;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<OnlineClassTenantDto?> Handle(GetOnlineClassTenantByIdQuery request, CancellationToken cancellationToken)
        {
            var onlineClassTenants = await _readRepository.FilterAsync(
                x => x.TenantId == request.TenantId,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (onlineClassTenants == null || !onlineClassTenants.Any())
                return null;

            var onlineClassTenant = _mapper.Map<OnlineClassTenantDto>(onlineClassTenants.FirstOrDefault());

            //lấy thông tin tenant name
            var tenants = await _mediator.Send(new SharedGetTenantByIdsQuery
            {
                TenantIds = new List<string>() {
                onlineClassTenant?.TenantId!}
            }, cancellationToken);

            if (tenants != null && tenants.Any())
            {
                var tenantDict = tenants.ToDictionary(t => t.Id, t => t.Name);
                if (!string.IsNullOrEmpty(onlineClassTenant?.TenantId) && tenantDict.TryGetValue(onlineClassTenant.TenantId, out var tenantName))
                {
                    onlineClassTenant.TenantName = tenantName;
                }
            }

            return onlineClassTenant;
        }
    }
}
