using DS.Module.OnlineClass.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Queries.OnlineClassTenants
{
    /// <summary>
    /// Query lấy danh sách thống kê buổi học Zoom theo từng trường sử dụng Zoom (realtime, không cần đầu vào)
    /// </summary>
    public class GetZoomMeetingOnlineClassTenantListQuery : IQuery<List<ZoomMeetingOnlineClassTenantDto>>
    {
    }
}
