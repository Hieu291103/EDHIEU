using DS.Module.OnlineClass.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Queries.OnlineClassTenants
{
    /// <summary>
    /// Query để lấy OnlineClassTenant theo TenantId
    /// </summary>
    public class GetOnlineClassTenantByIdQuery : IQuery<OnlineClassTenantDto?>
    {
        /// <summary>
        /// TenantId của OnlineClassTenant
        /// </summary>
        public required string TenantId { get; set; }
    }
}
