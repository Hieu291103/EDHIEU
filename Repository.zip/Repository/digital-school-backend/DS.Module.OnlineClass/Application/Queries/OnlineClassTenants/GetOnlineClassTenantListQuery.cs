using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Requests;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Queries.OnlineClassTenants
{
    /// <summary>
    /// Query để lấy danh sách OnlineClassTenant với phân trang và filter
    /// </summary>
    public class GetOnlineClassTenantListQuery : FilterRequest, IQuery<PagedResult<OnlineClassTenantDto>>
    {
        /// <summary>
        /// TenantId để filter theo tenant
        /// </summary>
        public string? TenantId { get; set; }

        /// <summary>
        /// Filter theo SchoolId
        /// </summary>
        public int? SchoolId { get; set; }

        /// <summary>
        /// Filter theo ProviderMeetingType
        /// </summary>
        public ProviderMeetingType? ProviderMeetingType { get; set; }

        /// <summary>
        /// Filter theo IsActive (còn hiệu lực)
        /// </summary>
        public bool? IsActive { get; set; }
    }
}
