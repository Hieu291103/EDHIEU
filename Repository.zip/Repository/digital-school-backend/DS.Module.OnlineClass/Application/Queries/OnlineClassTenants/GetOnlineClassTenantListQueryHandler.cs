using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Queries.Tenants;
using MediatR;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Queries.OnlineClassTenants
{
    /// <summary>
    /// Handler cho GetOnlineClassTenantListQuery
    /// </summary>
    public class GetOnlineClassTenantListQueryHandler : IQueryHandler<GetOnlineClassTenantListQuery, PagedResult<OnlineClassTenantDto>>
    {
        private readonly ISchoolCommonReadRepository<OnlineClassTenantEntity> _readRepository;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetOnlineClassTenantListQueryHandler(
            ISchoolCommonReadRepository<OnlineClassTenantEntity> readRepository,
            IMediator mediator,
            IMapper mapper)
        {
            _readRepository = readRepository;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<PagedResult<OnlineClassTenantDto>> Handle(GetOnlineClassTenantListQuery request, CancellationToken cancellationToken)
        {
            var filterBuilder = Builders<OnlineClassTenantEntity>.Filter;
            var filter = filterBuilder.Empty;

            // Filter by TenantId nếu có
            if (!string.IsNullOrEmpty(request.TenantId))
                filter = filterBuilder.And(filter, filterBuilder.Eq(c => c.TenantId, request.TenantId));

            // Filter by SchoolId nếu có
            if (request.SchoolId.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Eq(c => c.SchoolId, request.SchoolId.Value));

            // Filter by ProviderMeetingType nếu có
            if (request.ProviderMeetingType.HasValue)
            {
                var providerType = request.ProviderMeetingType.Value;
                filter = filterBuilder.And(filter, filterBuilder.Eq(c => c.ProviderMeetingType, providerType));
            }

            if (request.SchoolId.HasValue)
                filter = filterBuilder.And(filter, filterBuilder.Eq(c => c.SchoolId, request.SchoolId.Value));

            // Filter by IsActive (còn hiệu lực) nếu có
            if (request.IsActive.HasValue)
            {
                filter = filterBuilder.And(filter, filterBuilder.Eq(c => c.IsActive, request.IsActive));
            }

            var pagedResult = await _readRepository.PagedFilterAsync(
                filter,
                request.PageIndex ?? 1,
                request.PageSize ?? 50,
                tenantId: request.TenantId,
                cancellationToken: cancellationToken);

            var dtos = _mapper.Map<List<OnlineClassTenantDto>>(pagedResult.Items);

            //lấy thông tin tenant name
            var tenantIds = dtos.Select(d => d.TenantId).Where(tid => !string.IsNullOrEmpty(tid)).Distinct().ToList();
            if (tenantIds.Any())
            {
                var tenants = await _mediator.Send(new SharedGetTenantByIdsQuery { TenantIds = tenantIds! }, cancellationToken);
                var tenantDict = tenants.ToDictionary(t => t.Id, t => t.Name);
                foreach (var dto in dtos)
                {
                    if (!string.IsNullOrEmpty(dto.TenantId) && tenantDict.TryGetValue(dto.TenantId, out var tenantName))
                    {
                        dto.TenantName = tenantName;
                    }
                }
            }

            return new PagedResult<OnlineClassTenantDto>
            {
                Items = dtos,
                Total = pagedResult.Total,
                Page = pagedResult.Page,
                PageSize = pagedResult.PageSize,
                PageIndex = pagedResult.PageIndex
            };
        }
    }
}
