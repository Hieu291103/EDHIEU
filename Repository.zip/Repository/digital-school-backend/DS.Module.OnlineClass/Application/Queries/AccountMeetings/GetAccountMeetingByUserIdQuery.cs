using DS.Module.OnlineClass.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Queries.AccountMeetings
{
    /// <summary>
    /// Query để lấy AccountMeeting theo id
    /// </summary>
    public class GetAccountMeetingByUserIdQuery : IQuery<AccountMeetingDto>
    {
        /// <summary>
        /// SchoolId để filter theo tenant
        /// </summary>
        public int? SchoolId { get; set; }
        /// <summary>
        /// TenantId để filter theo tenant
        /// </summary>
        public string? TenantId { get; set; }
        /// <summary>
        /// Id của AccountMeeting
        /// </summary>
        public required string UserId { get; set; }
    }
}
