using DS.Module.OnlineClass.Application.DTOs;
using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Queries.AccountMeetings
{
    /// <summary>
    /// Query để lấy danh sách AccountMeeting với phân trang và filter
    /// </summary>
    public class GetAccountMeetingTeacherListQuery : IQuery<List<AccountMeetingDto>>
    {
        /// <summary>
        /// TenantId để filter theo tenant
        /// </summary>
        public required string TenantId { get; set; }
        /// <summary>
        /// Năm học để filter
        /// </summary>
        public required int SchoolYear { get; set; }
    }
}
