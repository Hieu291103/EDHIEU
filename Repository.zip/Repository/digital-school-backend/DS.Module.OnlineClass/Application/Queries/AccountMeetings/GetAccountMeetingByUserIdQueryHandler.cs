using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Queries.AccountMeetings
{
    /// <summary>
    /// Handler cho GetAccountMeetingByIdQuery
    /// </summary>
    public class GetAccountMeetingByUserIdQueryHandler : IQueryHandler<GetAccountMeetingByUserIdQuery, AccountMeetingDto?>
    {
        private readonly ISchoolCommonReadRepository<AccountMeetingEntity> _readRepository;
        private readonly IMapper _mapper;

        public GetAccountMeetingByUserIdQueryHandler(
            ISchoolCommonReadRepository<AccountMeetingEntity> readRepository,
            IMapper mapper)
        {
            _readRepository = readRepository;
            _mapper = mapper;
        }

        public async Task<AccountMeetingDto?> Handle(GetAccountMeetingByUserIdQuery request, CancellationToken cancellationToken)
        {
            var filterBuilder = Builders<AccountMeetingEntity>.Filter;
            var filter = filterBuilder.Empty;
            filter = filterBuilder.And(filter, filterBuilder.Eq(c => c.UserId, request.UserId));
            // Filter by TenantId nếu có
            if (!string.IsNullOrEmpty(request.TenantId))
                filter = filterBuilder.And(filter, filterBuilder.Eq(c => c.TenantId, request.TenantId));

            if (request.SchoolId != null)
                filter = filterBuilder.And(filter, filterBuilder.Eq(c => c.SchoolId, request.SchoolId));

            //Lấy thông tin tài khoản meeting từ database
            var result = await _readRepository.FilterAsync(
              filter,
              tenantId: null,
              cancellationToken: cancellationToken);

            if (result == null || !result.Any())
                return null;

            return _mapper.Map<AccountMeetingDto>(result.First());
        }
    }
}
