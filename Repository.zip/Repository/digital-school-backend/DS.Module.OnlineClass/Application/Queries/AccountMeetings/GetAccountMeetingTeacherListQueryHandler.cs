using AutoMapper;
using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.Core.Infrastructure.Services.Onluyen;
using DS.Shared.CQRS.Queries.Tenants;
using MediatR;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Queries.AccountMeetings
{
    /// <summary>
    /// Handler cho GetAccountMeetingListQuery
    /// </summary>
    public class GetAccountMeetingTeacherListQueryHandler : IQueryHandler<GetAccountMeetingTeacherListQuery, List<AccountMeetingDto>>
    {
        private readonly ISchoolCommonReadRepository<AccountMeetingEntity> _readRepository;
        private readonly ISchoolCommonReadRepository<OnlineClassTenantEntity> _onlineClassTenantRepository;
        private readonly IMediator _mediator;
        private readonly IOnluyenService _onluyenService;
        private readonly IMapper _mapper;

        public GetAccountMeetingTeacherListQueryHandler(
            ISchoolCommonReadRepository<AccountMeetingEntity> readRepository,
                ISchoolCommonReadRepository<OnlineClassTenantEntity> onlineClassTenantRepository,
            IMediator mediator,
            IOnluyenService onluyenService,
            IMapper mapper)
        {
            _readRepository = readRepository;
            _onlineClassTenantRepository = onlineClassTenantRepository;
            _mediator = mediator;
            _onluyenService = onluyenService;
            _mapper = mapper;
        }

        public async Task<List<AccountMeetingDto>> Handle(GetAccountMeetingTeacherListQuery request, CancellationToken cancellationToken)
        {
            //Lấy thông tin Tenant phải là kiểu Teams mới trả về user
            var onlineClassTenants = await _onlineClassTenantRepository.FilterAsync(
              x => x.TenantId == request.TenantId,
              tenantId: null,
              cancellationToken: cancellationToken);
            var onlineClassTenant = onlineClassTenants?.FirstOrDefault();
            if (onlineClassTenants == null)
            {
                throw new DSException("OnlineClassTenantNotFound");
            }
            if (onlineClassTenant?.ProviderMeetingType == ProviderMeetingType.Zoom)
            {
                throw new DSException("OnlineClassTenantNotSupportUseAccount");
            }

            var filterBuilder = Builders<AccountMeetingEntity>.Filter;
            var filter = filterBuilder.Empty;

            filter = filterBuilder.And(filter, filterBuilder.Eq(c => c.TenantId, request.TenantId));

            //Lấy thông tin tài khoản meeting từ database
            var result = await _readRepository.FilterAsync(
              filter,
              tenantId: null,
              cancellationToken: cancellationToken);

            //lấy thông tin tenant, schoolId từ database để gọi api onluyen
            var tenant = await _mediator.Send(new SharedGetTenantByIdQuery { TenantId = request.TenantId! }, cancellationToken);

            //Lấy danh sách giáo viên từ onluyen
            var returnList = _mapper.Map<List<AccountMeetingDto>>(result);
            if (tenant != null && tenant.SchoolId != null)
            {
                var teachers = await _onluyenService.GetTeachersBySchoolAsync(tenant.SchoolId.Value, request.SchoolYear);
                foreach (var teacher in teachers)
                {
                    var accountMeeting = result.FirstOrDefault(c => c.UserId == teacher.UserId);
                    if (accountMeeting == null)
                    {
                        returnList.Add(new AccountMeetingDto()
                        {
                            UserId = teacher.UserId,
                            FullName = teacher.DisplayName,
                            UserName = teacher.Username,
                            MeetUserId = null,
                            MeetEmail = null,
                            MeetPassword = null,
                            ProviderCode = null,
                            SchoolId = tenant.SchoolId,
                            AccountMeetingType = AccountMeetingType.Teacher
                        });
                    }
                    else
                    {
                        accountMeeting.FullName = teacher.DisplayName;
                        accountMeeting.UserName = teacher.Username;
                    }
                }
            }
            return returnList;
        }
    }
}
