using DS.Module.OnlineClass.Application.Commands.AccountMeetings;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Commands.OnlineClassTenants
{
    /// <summary>
    /// Handler cho DeleteOnlineClassTenantCommand
    /// Xóa OnlineClassTenant cùng với các dữ liệu liên quan:
    /// - OnlineClassTenantClass
    /// - AccountMeetingEntity (thông qua DeleteAccountMeetingCommand)
    /// </summary>
    public class DeleteOnlineClassTenantCommandHandler : ICommandHandler<DeleteOnlineClassTenantCommand, Result>
    {
        private readonly ISchoolCommonWriteRepository<OnlineClassTenantEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<OnlineClassTenantEntity> _readRepository;
        private readonly ISchoolCommonWriteRepository<OnlineClassTenantClassEntity> _tenantClassWriteRepository;
        private readonly ISchoolCommonReadRepository<OnlineClassTenantClassEntity> _tenantClassReadRepository;
        private readonly ISchoolCommonReadRepository<AccountMeetingEntity> _accountMeetingReadRepository;
        private readonly IMediator _mediator;

        public DeleteOnlineClassTenantCommandHandler(
            ISchoolCommonWriteRepository<OnlineClassTenantEntity> writeRepository,
            ISchoolCommonReadRepository<OnlineClassTenantEntity> readRepository,
            ISchoolCommonWriteRepository<OnlineClassTenantClassEntity> tenantClassWriteRepository,
            ISchoolCommonReadRepository<OnlineClassTenantClassEntity> tenantClassReadRepository,
            ISchoolCommonReadRepository<AccountMeetingEntity> accountMeetingReadRepository,
            IMediator mediator)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _tenantClassWriteRepository = tenantClassWriteRepository;
            _tenantClassReadRepository = tenantClassReadRepository;
            _accountMeetingReadRepository = accountMeetingReadRepository;
            _mediator = mediator;
        }

        public async Task<Result> Handle(DeleteOnlineClassTenantCommand request, CancellationToken cancellationToken)
        {
            var onlineClassTenants = await _readRepository.FilterAsync(
                x => x.TenantId == request.TenantId,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (onlineClassTenants == null || !onlineClassTenants.Any())
                throw new DSException("OnlineClassTenantNotFound");

            // Xóa OnlineClassTenantClass liên quan đến TenantId
            var tenantClasses = await _tenantClassReadRepository.FilterAsync(
                x => x.TenantId == request.TenantId,
                tenantId: null,
                cancellationToken: cancellationToken);

            foreach (var tenantClass in tenantClasses)
            {
                await _tenantClassWriteRepository.DeleteAsync(
                    tenantClass.Id,
                    tenantId: null,
                    cancellationToken: cancellationToken);
            }

            // Xóa AccountMeetingEntity liên quan đến TenantId thông qua DeleteAccountMeetingCommand
            var accountMeetings = await _accountMeetingReadRepository.FilterAsync(
                x => x.TenantId == request.TenantId,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (accountMeetings != null && accountMeetings.Any())
            {
                // Nhóm AccountMeetings theo UserId
                var userIds = accountMeetings.Select(x => x.UserId).Where(x => !string.IsNullOrEmpty(x)).Distinct().ToList();

                if (userIds != null && userIds.Any())
                {
                    // Gửi DeleteAccountMeetingCommand
                    await _mediator.Send(
                        new DeleteAccountMeetingCommand
                        {
                            UserId = userIds!,
                            TenantId = request.TenantId
                        },
                        cancellationToken);
                }
            }

            // Xóa OnlineClassTenant
            foreach (var tenant in onlineClassTenants)
            {
                await _writeRepository.DeleteAsync(
                    tenant.Id,
                    tenantId: null,
                    cancellationToken: cancellationToken);
            }

            return Result.Success();
        }
    }
}
