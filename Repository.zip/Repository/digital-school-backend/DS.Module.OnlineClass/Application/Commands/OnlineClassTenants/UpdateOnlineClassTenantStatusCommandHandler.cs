using DS.Module.OnlineClass.Application.Commands.AccountMeetings;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Commands.OnlineClassTenants
{
    /// <summary>
    /// Handler cho UpdateOnlineClassTenantStatusCommand
    /// </summary>
    public class UpdateOnlineClassTenantStatusCommandHandler : ICommandHandler<UpdateOnlineClassTenantStatusCommand, Result>
    {
        private readonly ISchoolCommonWriteRepository<OnlineClassTenantEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<OnlineClassTenantEntity> _readRepository;
        private readonly ISchoolCommonReadRepository<AccountMeetingEntity> _accountMeetingRepository;
        private readonly IMediator _mediator;

        public UpdateOnlineClassTenantStatusCommandHandler(
            ISchoolCommonWriteRepository<OnlineClassTenantEntity> writeRepository,
            ISchoolCommonReadRepository<OnlineClassTenantEntity> readRepository,
            ISchoolCommonReadRepository<AccountMeetingEntity> accountMeetingRepository,
            IMediator mediator)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _accountMeetingRepository = accountMeetingRepository;
            _mediator = mediator;
        }

        public async Task<Result> Handle(UpdateOnlineClassTenantStatusCommand request, CancellationToken cancellationToken)
        {
            var onlineClassTenant = await _readRepository.FilterAsync(
                x => x.TenantId == request.TenantId,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (onlineClassTenant == null || !onlineClassTenant.Any())
                throw new DSException("OnlineClassTenantNotFound");

            // Khi IsActive = false, xóa toàn bộ AccountMeetings liên kết
            if (!request.IsActive)
            {
                var accountMeetings = await _accountMeetingRepository.FilterAsync(
                    x => x.TenantId == request.TenantId,
                    tenantId: null,
                    cancellationToken: cancellationToken);

                if (accountMeetings.Any())
                {
                    var userIds = accountMeetings.Select(x => x.UserId).Where(x => !string.IsNullOrEmpty(x)).ToList()!;

                    if (userIds.Any())
                    {
                        var deleteCommand = new DeleteAccountMeetingCommand
                        {
                            UserId = userIds!,
                            TenantId = request.TenantId
                        };

                        await _mediator.Send(deleteCommand, cancellationToken);
                    }
                }
            }

            await _writeRepository.UpdateManyAsync(
                x => x.TenantId == request.TenantId,
                Builders<OnlineClassTenantEntity>.Update.Set(x => x.IsActive, request.IsActive),
                tenantId: request.TenantId, cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}
