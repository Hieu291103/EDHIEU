using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Queries.Tenants;
using MediatR;

namespace DS.Module.OnlineClass.Application.Commands.OnlineClassTenants
{
    /// <summary>
    /// Handler cho CreateOnlineClassTenantCommand
    /// </summary>
    public class CreateOnlineClassTenantCommandHandler : ICommandHandler<CreateOnlineClassTenantCommand, Result>
    {
        private readonly ISchoolCommonWriteRepository<OnlineClassTenantEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<OnlineClassTenantEntity> _readRepository;
        private readonly IMediator _mediator;

        public CreateOnlineClassTenantCommandHandler(
            ISchoolCommonWriteRepository<OnlineClassTenantEntity> writeRepository,
            ISchoolCommonReadRepository<OnlineClassTenantEntity> readRepository,
            IMediator mediator)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _mediator = mediator;
        }

        public async Task<Result> Handle(CreateOnlineClassTenantCommand request, CancellationToken cancellationToken)
        {
            // Kiểm tra xem provider type này đã tồn tại cho tenant này chưa
            var existingProvider = await _readRepository.FilterAsync(
                x => x.TenantId == request.TenantId,
                tenantId: null,
                cancellationToken: cancellationToken);

            var tenant = await _mediator.Send(new SharedGetTenantByIdQuery { TenantId = request.TenantId }, cancellationToken);

            if (tenant == null)
            {
                throw DSException.WithParam("OnlineClassTenantDoNotExist", request.TenantId);
            }
            if (tenant.SchoolId == null || tenant.SchoolId == 0)
                throw DSException.WithParam("OnlineClassTenantSchoolDoNotExist", request.TenantId);

            if (existingProvider.Any())
                throw DSException.WithParam("OnlineClassTenantProviderAlreadyExists", tenant?.Name ?? "");

            var onlineClassTenant = new OnlineClassTenantEntity
            {
                TenantId = request.TenantId,
                ProviderMeetingType = request.ProviderMeetingType,
                ProviderConnect = request.ProviderConnect,
                SchoolId = tenant?.SchoolId ?? request.SchoolId,
                StartDate = request.StartDate!.Value.Date,
                ExpireDate = request.ExpireDate!.Value.Date,
                IsActive = true,
                TeacherOpenMinutes = request.TeacherOpenMinutes,
                StudentOpenMinutes = request.StudentOpenMinutes,
                ZoomLicense = request.ZoomLicense,
                MeetingMinutes = request.MeetingMinutes,
            };

            await _writeRepository.InsertAsync(onlineClassTenant, cancellationToken);

            return Result.Success();
        }
    }
}
