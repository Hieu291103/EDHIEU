using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Commands.OnlineClassTenants
{
    /// <summary>
    /// Command để xóa OnlineClassTenant
    /// </summary>
    public class DeleteOnlineClassTenantCommand : ICommand<Result>
    {
        /// <summary>
        /// TenantId
        /// </summary>
        public required string TenantId { get; set; }
    }
}
