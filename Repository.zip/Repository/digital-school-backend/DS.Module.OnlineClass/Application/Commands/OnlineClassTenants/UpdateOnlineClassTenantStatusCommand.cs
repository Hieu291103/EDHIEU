using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Commands.OnlineClassTenants
{
    /// <summary>
    /// Command để cập nhật trạng thái hoạt động của OnlineClassTenant
    /// </summary>
    public class UpdateOnlineClassTenantStatusCommand : ICommand<Result>
    {
        /// <summary>
        /// TenantId
        /// </summary>
        public required string TenantId { get; set; }

        /// <summary>
        /// Trạng thái hoạt động
        /// </summary>
        public required bool IsActive { get; set; }
    }
}
