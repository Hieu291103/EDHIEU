using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.OnlineClass.Application.Commands.OnlineClassTenants
{
    /// <summary>
    /// Handler cho UpdateOnlineClassTenantCommand
    /// </summary>
    public class UpdateOnlineClassTenantCommandHandler : ICommandHandler<UpdateOnlineClassTenantCommand, Result>
    {
        private readonly ISchoolCommonWriteRepository<OnlineClassTenantEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<OnlineClassTenantEntity> _readRepository;

        public UpdateOnlineClassTenantCommandHandler(
            ISchoolCommonWriteRepository<OnlineClassTenantEntity> writeRepository,
            ISchoolCommonReadRepository<OnlineClassTenantEntity> readRepository)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
        }

        public async Task<Result> Handle(UpdateOnlineClassTenantCommand request, CancellationToken cancellationToken)
        {
            var onlineClassTenants = await _readRepository.FilterAsync(
                x => x.TenantId == request.TenantId,
                tenantId: request.TenantId,
                cancellationToken: cancellationToken);

            if (onlineClassTenants == null || !onlineClassTenants.Any())
                throw new DSException("OnlineClassTenantNotFound");

            foreach (var onlineClassTenant in onlineClassTenants)
            {
                // Kiểm tra nếu provider type thay đổi, xem đã tồn tại chưa
                if (onlineClassTenant.ProviderMeetingType != request.ProviderMeetingType)
                {
                    var existingProvider = await _readRepository.FilterAsync(
                        x => x.TenantId == request.TenantId
                            && x.ProviderMeetingType == request.ProviderMeetingType
                            && x.Id != onlineClassTenant.Id,
                        tenantId: request.TenantId,
                        cancellationToken: cancellationToken);

                    if (existingProvider.Any())
                        throw DSException.WithParam("OnlineClassTenantProviderAlreadyExists", request.ProviderMeetingType.ToString());

                    onlineClassTenant.ProviderMeetingType = request.ProviderMeetingType;
                }

                if (request.ProviderConnect.IsNotNull())
                    onlineClassTenant.ProviderConnect = request.ProviderConnect;

                if (request.SchoolId.HasValue)
                    onlineClassTenant.SchoolId = request.SchoolId;

                if (request.StartDate.HasValue)
                    onlineClassTenant.StartDate = request.StartDate;

                if (request.ExpireDate.HasValue)
                    onlineClassTenant.ExpireDate = request.ExpireDate;

                if (request.TeacherOpenMinutes.HasValue)
                    onlineClassTenant.TeacherOpenMinutes = request.TeacherOpenMinutes;

                if (request.StudentOpenMinutes.HasValue)
                    onlineClassTenant.StudentOpenMinutes = request.StudentOpenMinutes;

                if (request.ZoomLicense.HasValue)
                    onlineClassTenant.ZoomLicense = request.ZoomLicense;

                if (request.MeetingMinutes.HasValue)
                    onlineClassTenant.MeetingMinutes = request.MeetingMinutes;

                await _writeRepository.UpdateAsync(onlineClassTenant, tenantId: null, cancellationToken: cancellationToken);
            }

            return Result.Success();
        }
    }
}
