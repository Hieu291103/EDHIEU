using DS.Module.OnlineClass.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Commands.OnlineClassTenants
{
    /// <summary>
    /// Command để cập nhật OnlineClassTenant
    /// </summary>
    public class UpdateOnlineClassTenantCommand : ICommand<Result>
    {
        /// <summary>
        /// TenantId
        /// </summary>
        public required string TenantId { get; set; }

        /// <summary>
        /// Loại tài khoản sử dụng (MSTeams vs Zoom vs GGMeet)
        /// </summary>
        public required ProviderMeetingType ProviderMeetingType { get; set; }

        /// <summary>
        /// Nhà cung cấp kết nối, ví dụ: Microsoft Teams Edmicro, Microsoft Teams xxx
        /// </summary>
        public string? ProviderConnect { get; set; }

        /// <summary>
        /// Id trường cùng tenant
        /// </summary>
        public int? SchoolId { get; set; }

        /// <summary>
        /// Ngày bắt đầu được sử dụng
        /// </summary>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// Ngày hết hạn sử dụng
        /// </summary>
        public DateTime? ExpireDate { get; set; }

        /// <summary>
        /// Số phút mở buổi học thực tế cho giáo viên (khi người tạo bắt đầu buổi học)
        /// </summary>
        public int? TeacherOpenMinutes { get; set; }
        /// <summary>
        /// Số phút mở buổi học thực tế cho học sinh (khi người tạo bắt đầu buổi học)
        /// </summary>
        public int? StudentOpenMinutes { get; set; }
        /// <summary>
        /// Số lượng license Zoom (nếu có, chỉ áp dụng với Zoom)
        /// </summary>
        public int? ZoomLicense { get; set; } = 0;

        /// <summary>
        /// Số phút tối đa cho phép buổi học
        /// </summary>
        public int? MeetingMinutes { get; set; } = 0;

    }
}
