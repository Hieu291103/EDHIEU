using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Module.OnlineClass.Infrastructure.Services.DTOs.GraphApi;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Application.Commands.LessonParticipantEntitys
{
    /// <summary>
    /// Handler cập nhật thông tin điểm danh cho 1 buổi học Teams từ Microsoft Graph Attendance Report API
    /// </summary>
    public class JobUpdateLessonParticipantForTeamsCommandHandler : ICommandHandler<JobUpdateLessonParticipantForTeamsCommand, bool>
    {
        private const int MaxTryCount = 10;

        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _meetingReadRepository;
        private readonly ISchoolCommonWriteRepository<LessonMeetingEntity> _meetingWriteRepository;
        private readonly ISchoolCommonReadRepository<LessonParticipantEntity> _participantReadRepository;
        private readonly ISchoolCommonWriteRepository<LessonParticipantEntity> _participantWriteRepository;
        private readonly IMSTeamsService _msTeamsService;
        private readonly ILogger<JobUpdateLessonParticipantForTeamsCommandHandler> _logger;

        public JobUpdateLessonParticipantForTeamsCommandHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> meetingReadRepository,
            ISchoolCommonWriteRepository<LessonMeetingEntity> meetingWriteRepository,
            ISchoolCommonReadRepository<LessonParticipantEntity> participantReadRepository,
            ISchoolCommonWriteRepository<LessonParticipantEntity> participantWriteRepository,
            IMSTeamsService msTeamsService,
            ILogger<JobUpdateLessonParticipantForTeamsCommandHandler> logger)
        {
            _meetingReadRepository = meetingReadRepository;
            _meetingWriteRepository = meetingWriteRepository;
            _participantReadRepository = participantReadRepository;
            _participantWriteRepository = participantWriteRepository;
            _msTeamsService = msTeamsService;
            _logger = logger;
        }

        public async Task<bool> Handle(JobUpdateLessonParticipantForTeamsCommand request, CancellationToken cancellationToken)
        {
            //tạm thời return true
            try
            {
                var meeting = await _meetingReadRepository.GetByIdAsync(
                    request.LessonMeetingId,
                    tenantId: null,
                    cancellationToken: cancellationToken);

                if (meeting == null)
                    return false;

                if (string.IsNullOrEmpty(meeting.ProviderMeetingId))
                {
                    _logger.LogError("JobUpdateLessonParticipantForTeams - MeetingId {MeetingId}: ProviderMeetingId không hợp lệ", meeting.Id);
                    meeting.ParticipantTryCount = MaxTryCount;
                    await _meetingWriteRepository.UpdateAsync(meeting);
                    return false;
                }

                if (string.IsNullOrEmpty(meeting.MeetUserId))
                {
                    _logger.LogError("JobUpdateLessonParticipantForTeams - MeetingId {MeetingId}: MeetUserId (organizer) không hợp lệ", meeting.Id);
                    meeting.ParticipantTryCount = MaxTryCount;
                    await _meetingWriteRepository.UpdateAsync(meeting);
                    return false;
                }

                var attendanceRecords = await _msTeamsService.GetAllParticipantsAsync(
                    meeting.ProviderConnect!,
                    meeting.MeetUserId,
                    meeting.ProviderMeetingId,
                    cancellationToken: cancellationToken);

                if (attendanceRecords.Count == 0)
                {
                    meeting.ParticipantTryCount = (meeting.ParticipantTryCount ?? 0) + 1;
                    await _meetingWriteRepository.UpdateAsync(meeting);
                    return false;
                }

                var existingParticipants = await _participantReadRepository.FilterAsync(
                    x => x.LessonMeetingId == meeting.Id,
                    tenantId: null,
                    cancellationToken: cancellationToken);

                await UpdateParticipantsAsync(meeting, existingParticipants, attendanceRecords, cancellationToken);

                meeting.HasParticipant = true;
                meeting.ParticipantTryCount = (meeting.ParticipantTryCount ?? 0) + 1;
                await _meetingWriteRepository.UpdateAsync(meeting);

                return true;
            }
            catch (OperationCanceledException)
            {
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "JobUpdateLessonParticipantForTeams - MeetingId {MeetingId}: {Message}", request.LessonMeetingId, ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Cập nhật thông tin điểm danh vào LessonParticipantEntity từ Teams Attendance Records
        /// </summary>
        private async Task UpdateParticipantsAsync(
            LessonMeetingEntity meeting,
            IEnumerable<LessonParticipantEntity> existingParticipants,
            List<GraphAttendanceRecordUser> attendanceRecords,
            CancellationToken cancellationToken)
        {
            // Index username để tra cứu nhanh, tránh trùng lặp khi thêm mới
            var participantUserNames = existingParticipants
                .Where(u => !string.IsNullOrEmpty(u.Username) && u.UserType == Shared.Core.Enums.UserType.Student)
                .GroupBy(u => u.Username!)
                .ToDictionary(g => g.Key.Trim(), g => g);

            foreach (var record in attendanceRecords)
            {
                var displayName = record.DisplayName;
                var providerParticipantId = record.Id;

                // JoinDateTime/LeaveDateTime/DurationInSeconds đã được tổng hợp sẵn trong GraphAttendanceRecordUser
                var joinTime = record.JoinDateTime;
                var leaveTime = record.LeaveDateTime;

                var totalSeconds = record.DurationInSeconds ?? 0;
                var durationMinutes = totalSeconds > 0
                    ? (int)Math.Round(totalSeconds / 60.0)
                    : (joinTime.HasValue && leaveTime.HasValue
                        ? (int)(leaveTime.Value - joinTime.Value).TotalMinutes
                        : 0);

                // Tìm participant theo ProviderParticipantId (Azure AD Object ID)
                var matchedParticipant = !string.IsNullOrEmpty(providerParticipantId)
                    ? existingParticipants.FirstOrDefault(p => p.ProviderParticipantId == providerParticipantId)
                    : null;

                if (matchedParticipant != null)
                {
                    matchedParticipant.JoinTimeActual = joinTime;
                    matchedParticipant.LeaveTimeActual = leaveTime;
                    matchedParticipant.DurationInMinutes = durationMinutes > 0 ? durationMinutes : null;
                    matchedParticipant.ProviderParticipantId = providerParticipantId;
                    matchedParticipant.AttendanceStatus = CalculateAttendanceStatus(meeting, joinTime, leaveTime, durationMinutes);
                    UpdateParticipationPercentage(matchedParticipant, meeting, durationMinutes);
                    await _participantWriteRepository.UpdateAsync(matchedParticipant);
                }
                else
                {
                    // Tìm theo displayName trong danh sách đã có
                    matchedParticipant = participantUserNames
                        .FirstOrDefault(p =>
                            !string.IsNullOrEmpty(displayName) && displayName.Contains(p.Key, StringComparison.OrdinalIgnoreCase))
                        .Value?.FirstOrDefault();

                    if (matchedParticipant == null)
                    {
                        // Thêm mới participant chưa có trong danh sách
                        matchedParticipant = new LessonParticipantEntity
                        {
                            LessonMeetingId = meeting.Id,
                            IsUser = false,
                            UserType = Shared.Core.Enums.UserType.Guest,
                            Username = displayName ?? "",
                            UserFullName = displayName,
                            UserDisplayName = displayName,
                            JoinTimeActual = joinTime,
                            LeaveTimeActual = leaveTime,
                            DurationInMinutes = durationMinutes > 0 ? durationMinutes : null,
                            ProviderParticipantId = providerParticipantId,
                            AttendanceStatus = CalculateAttendanceStatus(meeting, joinTime, leaveTime, durationMinutes),
                            SchoolId = meeting.SchoolId,
                            TenantId = meeting.TenantId,
                            DeviceInfo = "",
                            JoinTimeClick = joinTime,
                        };
                        UpdateParticipationPercentage(matchedParticipant, meeting, durationMinutes);
                        await _participantWriteRepository.InsertAsync(matchedParticipant);
                    }
                    else
                    {
                        // Cập nhật participant đã có
                        matchedParticipant.JoinTimeActual = joinTime;
                        matchedParticipant.LeaveTimeActual = leaveTime;
                        matchedParticipant.DurationInMinutes = durationMinutes > 0 ? durationMinutes : null;
                        matchedParticipant.ProviderParticipantId = providerParticipantId;
                        matchedParticipant.AttendanceStatus = CalculateAttendanceStatus(meeting, joinTime, leaveTime, durationMinutes);
                        if (matchedParticipant.JoinTimeClick == null)
                            matchedParticipant.JoinTimeClick = joinTime;
                        UpdateParticipationPercentage(matchedParticipant, meeting, durationMinutes);
                        await _participantWriteRepository.UpdateAsync(matchedParticipant);
                    }
                }
            }
        }

        private static void UpdateParticipationPercentage(
            LessonParticipantEntity participant,
            LessonMeetingEntity meeting,
            int durationMinutes)
        {
            if (!meeting.StartTime.HasValue || !meeting.EndTime.HasValue || durationMinutes <= 0)
                return;

            var meetingDuration = (meeting.EndTime.Value - meeting.StartTime.Value).TotalMinutes;
            if (meetingDuration > 0)
                participant.ParticipationPercentage = Math.Min(100, Math.Round((decimal)durationMinutes / (decimal)meetingDuration * 100, 2));
        }

        private static MeetingAttendanceStatus CalculateAttendanceStatus(
            LessonMeetingEntity meeting,
            DateTime? joinTime,
            DateTime? leaveTime,
            int durationMinutes)
        {
            if (!joinTime.HasValue || durationMinutes <= 0)
                return MeetingAttendanceStatus.Absent;

            if (!meeting.StartTime.HasValue || !meeting.EndTime.HasValue)
                return MeetingAttendanceStatus.Attended;

            var lateThreshold = meeting.StartTime.Value.AddMinutes(5);
            var earlyLeaveThreshold = meeting.EndTime.Value.AddMinutes(-5);

            var isLate = joinTime.Value > lateThreshold;
            var isEarlyLeave = leaveTime.HasValue && leaveTime.Value < earlyLeaveThreshold;

            if (isLate)
                return MeetingAttendanceStatus.Late;

            if (isEarlyLeave)
                return MeetingAttendanceStatus.EarlyLeave;

            return MeetingAttendanceStatus.Attended;
        }
    }
}
