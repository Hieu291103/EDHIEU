using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Commands.LessonParticipantEntitys
{
    /// <summary>
    /// Scanner command: quét tất cả buổi học đã kết thúc và chưa có điểm danh,
    /// dispatch per-meeting command tương ứng theo loại provider (Zoom, Teams, ...)
    /// </summary>
    public class JobUpdateLessonParticipantCommand : ICommand<bool>
    {
    }
}
