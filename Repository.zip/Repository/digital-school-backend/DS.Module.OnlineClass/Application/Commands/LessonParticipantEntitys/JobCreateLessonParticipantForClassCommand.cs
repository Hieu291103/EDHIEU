using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Commands.LessonParticipantEntitys
{
    public class JobCreateLessonParticipantForClassCommand : ICommand<bool>
    {

        /// <summary>
        /// Id buổi học cần tạo danh sách người tham gia
        /// </summary>
        public string? LessonMeetingId { get; set; }

        /// <summary>
        /// Id Lớp học cần tạo danh sách người tham gia
        /// </summary>
        public string? ClassId { get; set; }

        /// <summary>
        /// Id Trường học cần tạo danh sách người tham gia
        /// </summary>
        public int? SchoolId { get; set; }

        /// <summary>
        /// Năm học
        /// </summary>
        public int? SchoolYear { get; set; } = 0;

        /// <summary>
        /// Id Tenant cần tạo danh sách người tham gia
        /// </summary>
        public string? TenantId { get; set; }

    }
}
