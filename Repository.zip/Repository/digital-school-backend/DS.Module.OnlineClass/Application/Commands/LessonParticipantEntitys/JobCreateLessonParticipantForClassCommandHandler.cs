using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Module.OnlineClass.Infrastructure.Common;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Enums;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.Core.Infrastructure.Services.Onluyen;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Application.Commands.LessonParticipantEntitys
{
    /// <summary>
    /// Handler tạo danh sách người tham gia buổi học dựa trên danh sách học sinh của lớp học
    /// Lấy học sinh từ OnluyenService theo Id trường và Id lớp, sau đó thêm vào LessonParticipantEntity
    /// </summary>
    public class JobCreateLessonParticipantForClassCommandHandler : ICommandHandler<JobCreateLessonParticipantForClassCommand, bool>
    {
        private readonly ISchoolCommonWriteRepository<LessonParticipantEntity> _lessonParticipantWriteRepository;
        private readonly ISchoolCommonReadRepository<LessonParticipantEntity> _lessonParticipantReadRepository;
        private readonly ISchoolCommonWriteRepository<LessonMeetingEntity> _lessonMeetingWriteRepository;
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _lessonMeetingReadRepository;
        private readonly IOnluyenService _onluyenService;
        private readonly ILogger<JobCreateLessonParticipantForClassCommandHandler> _logger;

        public JobCreateLessonParticipantForClassCommandHandler(
            ISchoolCommonWriteRepository<LessonParticipantEntity> lessonParticipantWriteRepository,
            ISchoolCommonReadRepository<LessonParticipantEntity> lessonParticipantReadRepository,
            ISchoolCommonWriteRepository<LessonMeetingEntity> lessonMeetingWriteRepository,
            ISchoolCommonReadRepository<LessonMeetingEntity> lessonMeetingReadRepository,
            IOnluyenService onluyenService,
            ILogger<JobCreateLessonParticipantForClassCommandHandler> logger)
        {
            _lessonParticipantWriteRepository = lessonParticipantWriteRepository;
            _lessonParticipantReadRepository = lessonParticipantReadRepository;
            _lessonMeetingWriteRepository = lessonMeetingWriteRepository;
            _lessonMeetingReadRepository = lessonMeetingReadRepository;
            _onluyenService = onluyenService;
            _logger = logger;
        }

        public async Task<bool> Handle(JobCreateLessonParticipantForClassCommand request, CancellationToken cancellationToken)
        {
            try
            {
                if (string.IsNullOrEmpty(request.LessonMeetingId))
                    return false;

                if (string.IsNullOrEmpty(request.ClassId))
                    return false;

                if (request.SchoolId == null || request.SchoolId <= 0)
                    return false;

                if (request.SchoolYear == null || request.SchoolYear <= 0)
                    return false;

                if (string.IsNullOrEmpty(request.TenantId))
                    return false;


                // Lấy danh sách học sinh theo SchoolId và ClassId từ OnluyenService
                var students = await _onluyenService.GetStudentsByClassAsync(
                    schoolId: request.SchoolId.Value,
                    classId: request.ClassId,
                    schoolYear: request.SchoolYear,
                    cancellationToken: cancellationToken);

                if (students == null || students.Count == 0)
                    return true;

                // Lấy danh sách UserId đã có để tránh trùng lặp
                var existingParticipants = await _lessonParticipantReadRepository.FilterAsync(
                    x => x.LessonMeetingId == request.LessonMeetingId && x.UserType == UserType.Student,
                    tenantId: request.TenantId,
                    cancellationToken: cancellationToken);

                var existingUserIds = existingParticipants
                    .Where(x => x.UserId != null)
                    .Select(x => x.UserId!)
                    .ToHashSet();

                // Tạo danh sách LessonParticipantEntity cho các học sinh chưa có
                var newParticipants = students
                    .Where(s => s.UserId != null && !existingUserIds.Contains(s.UserId))
                    .Select(s => new LessonParticipantEntity
                    {
                        TenantId = request.TenantId,
                        LessonMeetingId = request.LessonMeetingId,
                        SchoolId = request.SchoolId,
                        IsUser = true,
                        UserType = UserType.Student,
                        UserId = s.UserId,
                        Username = s.Username,
                        UserFullName = s.DisplayName,
                        UserBirthDay = s.Birthday,
                        UserDisplayName = LessionMeetingHelper.MeetingDisplayName(s.DisplayName, s.Username),
                        AttendanceStatus = MeetingAttendanceStatus.Absent,
                    })
                    .ToList();

                foreach (var participant in newParticipants)
                {
                    await _lessonParticipantWriteRepository.InsertAsync(participant, cancellationToken: cancellationToken);
                }

                //cập nhật trạng thái đã lấy danh sách học sinh cho buổi học
                var lessonMeeting = await _lessonMeetingReadRepository.GetByIdAsync(request.LessonMeetingId);
                if (lessonMeeting != null)
                {
                    lessonMeeting.FetchParticipant = true;
                    await _lessonMeetingWriteRepository.UpdateAsync(lessonMeeting, cancellationToken: cancellationToken);
                }

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "JobCreateLessonParticipantForClassCommandHandler failed for LessonMeetingId: {LessonMeetingId}", request.LessonMeetingId);
                return false;
            }
        }
    }
}
