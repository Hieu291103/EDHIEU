using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Commands.LessonParticipantEntitys
{
    public class JobUpdateLessonParticipantForZoomCommand : ICommand<bool>
    {
        public required string LessonMeetingId { get; set; }
    }
}
