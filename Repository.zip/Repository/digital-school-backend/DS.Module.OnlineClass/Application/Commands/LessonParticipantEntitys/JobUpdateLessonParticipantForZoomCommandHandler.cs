using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Module.OnlineClass.Infrastructure.Services.DTOs.ZoomBusiness;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Application.Commands.LessonParticipantEntitys
{
    /// <summary>
    /// Handler cập nhật thông tin điểm danh cho 1 buổi học Zoom từ API Zoom
    /// </summary>
    public class JobUpdateLessonParticipantForZoomCommandHandler : ICommandHandler<JobUpdateLessonParticipantForZoomCommand, bool>
    {
        private const int MaxTryCount = 10;

        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _meetingReadRepository;
        private readonly ISchoolCommonWriteRepository<LessonMeetingEntity> _meetingWriteRepository;
        private readonly ISchoolCommonReadRepository<LessonParticipantEntity> _participantReadRepository;
        private readonly ISchoolCommonWriteRepository<LessonParticipantEntity> _participantWriteRepository;
        private readonly IOneZoomService _oneZoomService;
        private readonly ILogger<JobUpdateLessonParticipantForZoomCommandHandler> _logger;

        public JobUpdateLessonParticipantForZoomCommandHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> meetingReadRepository,
            ISchoolCommonWriteRepository<LessonMeetingEntity> meetingWriteRepository,
            ISchoolCommonReadRepository<LessonParticipantEntity> participantReadRepository,
            ISchoolCommonWriteRepository<LessonParticipantEntity> participantWriteRepository,
            IOneZoomService oneZoomService,
            ILogger<JobUpdateLessonParticipantForZoomCommandHandler> logger)
        {
            _meetingReadRepository = meetingReadRepository;
            _meetingWriteRepository = meetingWriteRepository;
            _participantReadRepository = participantReadRepository;
            _participantWriteRepository = participantWriteRepository;
            _oneZoomService = oneZoomService;
            _logger = logger;
        }

        public async Task<bool> Handle(JobUpdateLessonParticipantForZoomCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var meeting = await _meetingReadRepository.GetByIdAsync(
                    request.LessonMeetingId,
                    tenantId: null,
                    cancellationToken: cancellationToken);

                if (meeting == null)
                    return false;

                if (string.IsNullOrEmpty(meeting.ProviderMeetingId) ||
                    !long.TryParse(meeting.ProviderMeetingId, out var roomId))
                {
                    _logger.LogError("JobUpdateLessonParticipantForZoom - MeetingId {MeetingId}: ProviderMeetingId không hợp lệ", meeting.Id);
                    meeting.ParticipantTryCount = MaxTryCount;
                    await _meetingWriteRepository.UpdateAsync(meeting);
                    return false;
                }

                var allParticipantUsers = await _oneZoomService.GetAllParticipantsAsync(
                    roomId, meeting.ProviderConnect, cancellationToken: cancellationToken);

                if (allParticipantUsers.Count == 0)
                {
                    meeting.ParticipantTryCount = (meeting.ParticipantTryCount ?? 0) + 1;
                    await _meetingWriteRepository.UpdateAsync(meeting);
                    return false;
                }

                var existingParticipants = await _participantReadRepository.FilterAsync(
                    x => x.LessonMeetingId == meeting.Id,
                    tenantId: null,
                    cancellationToken: cancellationToken);

                await UpdateParticipantsAsync(meeting, existingParticipants, allParticipantUsers, cancellationToken);

                meeting.HasParticipant = true;
                meeting.ParticipantTryCount = (meeting.ParticipantTryCount ?? 0) + 1;
                await _meetingWriteRepository.UpdateAsync(meeting);

                return true;
            }
            catch (OperationCanceledException)
            {
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "JobUpdateLessonParticipantForZoom - MeetingId {MeetingId}: {Message}", request.LessonMeetingId, ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Cập nhật thông tin điểm danh vào LessonParticipantEntity
        /// </summary>
        private async Task UpdateParticipantsAsync(
            LessonMeetingEntity meeting,
            IEnumerable<LessonParticipantEntity> existingParticipants,
            List<ParticipantItemUser> zoomUsers,
            CancellationToken cancellationToken)
        {
            //Danh sách user name của các học sinh đã có trong hệ thống, để tránh trùng lặp khi thêm mới
            var participantUserNames = existingParticipants
             .Where(u => !string.IsNullOrEmpty(u.Username) && u.UserType == Shared.Core.Enums.UserType.Student)
             .GroupBy(u => u.Username!)
             .ToDictionary(g => g.Key, g => g);

            foreach (var participant in zoomUsers)
            {
                var durationMinutes = 0;
                if (participant.JoinTime.HasValue && participant.LeaveTime.HasValue)
                    durationMinutes = (int)(participant.LeaveTime.Value - participant.JoinTime.Value).TotalMinutes;

                //Kiểm tra xem đã có trong danh sách điểm danh chưa, nếu có thì cập nhật, nếu chưa thì thêm mới
                var matchedParticipant = existingParticipants.FirstOrDefault(p => p.ProviderParticipantId == participant.ParticipantId);
                if (matchedParticipant != null)
                {
                    matchedParticipant.JoinTimeActual = participant.JoinTime;
                    matchedParticipant.LeaveTimeActual = participant.LeaveTime;
                    matchedParticipant.DurationInMinutes = durationMinutes > 0 ? durationMinutes : null;
                    matchedParticipant.JoinIpAddress = participant.IpAddress;
                    matchedParticipant.ProviderParticipantId = participant.ParticipantId;
                    matchedParticipant.AttendanceStatus = CalculateAttendanceStatus(meeting, participant.JoinTime, participant.LeaveTime, durationMinutes);
                    if (meeting.StartTime.HasValue && meeting.EndTime.HasValue)
                    {
                        var meetingDuration = (meeting.EndTime.Value - meeting.StartTime.Value).TotalMinutes;
                        if (meetingDuration > 0 && durationMinutes > 0)
                            matchedParticipant.ParticipationPercentage = Math.Min(100, Math.Round((decimal)durationMinutes / (decimal)meetingDuration * 100, 2));
                    }
                    await _participantWriteRepository.UpdateAsync(matchedParticipant);
                }
                else
                {
                    //Kiểm tra xem đã có trong danh sách điểm danh chưa, nếu có thì cập nhật, nếu chưa thì thêm mới
                    //Tìm kiếm theo user name, nếu có thì cập nhật, nếu chưa thì thêm mới
                    matchedParticipant = !string.IsNullOrEmpty(participant.UserName)
                        ? participantUserNames
                            .FirstOrDefault(p => participant.UserName.Contains(p.Key, StringComparison.OrdinalIgnoreCase))
                            .Value?.FirstOrDefault()
                        : null;
                    if (matchedParticipant == null)
                    {
                        //Thêm mới
                        matchedParticipant = new LessonParticipantEntity
                        {
                            LessonMeetingId = meeting.Id,
                            IsUser = false,
                            UserType = Shared.Core.Enums.UserType.Guest,
                            Username = "",
                            UserFullName = participant.UserName,
                            UserDisplayName = participant.UserName,
                            JoinTimeActual = participant.JoinTime,
                            LeaveTimeActual = participant.LeaveTime,
                            DurationInMinutes = durationMinutes > 0 ? durationMinutes : null,
                            JoinIpAddress = participant.IpAddress,
                            ProviderParticipantId = participant.ParticipantId,
                            Location = participant.Location,
                            AttendanceStatus = CalculateAttendanceStatus(meeting, participant.JoinTime, participant.LeaveTime, durationMinutes),
                            SchoolId = meeting.SchoolId,
                            TenantId = meeting.TenantId,
                            DeviceInfo = "",
                            JoinTimeClick = participant.JoinTime,
                        };
                        if (meeting.StartTime.HasValue && meeting.EndTime.HasValue)
                        {
                            var meetingDuration = (meeting.EndTime.Value - meeting.StartTime.Value).TotalMinutes;
                            if (meetingDuration > 0 && durationMinutes > 0)
                                matchedParticipant.ParticipationPercentage = Math.Min(100, Math.Round((decimal)durationMinutes / (decimal)meetingDuration * 100, 2));
                        }
                        await _participantWriteRepository.InsertAsync(matchedParticipant);
                    }
                    else
                    {
                        //Cập nhật
                        matchedParticipant.JoinTimeActual = participant.JoinTime;
                        matchedParticipant.LeaveTimeActual = participant.LeaveTime;
                        matchedParticipant.DurationInMinutes = durationMinutes > 0 ? durationMinutes : null;
                        matchedParticipant.JoinIpAddress = participant.IpAddress;
                        matchedParticipant.ProviderParticipantId = participant.ParticipantId;
                        matchedParticipant.AttendanceStatus = CalculateAttendanceStatus(meeting, participant.JoinTime, participant.LeaveTime, durationMinutes);
                        matchedParticipant.Location = participant.Location;
                        if (matchedParticipant.JoinTimeClick == null)
                        {
                            matchedParticipant.JoinTimeClick = participant.JoinTime;

                        }
                        if (meeting.StartTime.HasValue && meeting.EndTime.HasValue)
                        {
                            var meetingDuration = (meeting.EndTime.Value - meeting.StartTime.Value).TotalMinutes;
                            if (meetingDuration > 0 && durationMinutes > 0)
                                matchedParticipant.ParticipationPercentage = Math.Min(100, Math.Round((decimal)durationMinutes / (decimal)meetingDuration * 100, 2));
                        }
                        await _participantWriteRepository.UpdateAsync(matchedParticipant);
                    }
                }
            }
        }

        private static MeetingAttendanceStatus CalculateAttendanceStatus(
            LessonMeetingEntity meeting,
            DateTime? joinTime,
            DateTime? leaveTime,
            int durationMinutes)
        {
            if (!joinTime.HasValue || durationMinutes <= 0)
                return MeetingAttendanceStatus.Absent;

            if (!meeting.StartTime.HasValue || !meeting.EndTime.HasValue)
                return MeetingAttendanceStatus.Attended;

            var lateThreshold = meeting.StartTime.Value.AddMinutes(5);
            var earlyLeaveThreshold = meeting.EndTime.Value.AddMinutes(-5);

            var isLate = joinTime.Value > lateThreshold;
            var isEarlyLeave = leaveTime.HasValue && leaveTime.Value < earlyLeaveThreshold;

            if (isLate)
                return MeetingAttendanceStatus.Late;

            if (isEarlyLeave)
                return MeetingAttendanceStatus.EarlyLeave;

            return MeetingAttendanceStatus.Attended;
        }
    }
}
