using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Commands.LessonParticipantEntitys
{
    public class DeleteLessonParticipantCommand : ICommand<bool>
    {
        /// <summary>
        /// Id buổi học cần xóa
        /// </summary>
        public string? LessonMeetingId { get; set; }
    }
}
