using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Application.Commands.LessonParticipantEntitys
{
    /// <summary>
    /// Quét tất cả buổi học đã kết thúc và chưa có điểm danh,
    /// dispatch per-meeting command tương ứng theo loại provider
    /// </summary>
    public class JobUpdateLessonParticipantCommandHandler : ICommandHandler<JobUpdateLessonParticipantCommand, bool>
    {
        private const int MaxTryCount = 10;

        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _meetingReadRepository;
        private readonly IMediator _mediator;
        private readonly ILogger<JobUpdateLessonParticipantCommandHandler> _logger;

        public JobUpdateLessonParticipantCommandHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> meetingReadRepository,
            IMediator mediator,
            ILogger<JobUpdateLessonParticipantCommandHandler> logger)
        {
            _meetingReadRepository = meetingReadRepository;
            _mediator = mediator;
            _logger = logger;
        }

        public async Task<bool> Handle(JobUpdateLessonParticipantCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var meetings = await _meetingReadRepository.FilterAsync(
                    x => x.Status == MeetingStatus.Ended &&
                         x.JoinUrlActive == false &&
                         x.HasParticipant == false &&
                         x.ParticipantTryCount < MaxTryCount,
                    cancellationToken: cancellationToken);

                if (meetings == null || !meetings.Any())
                    return true;

                var tasks = meetings.Select(meeting => DispatchAsync(meeting, cancellationToken));
                await Task.WhenAll(tasks);

                return true;
            }
            catch (OperationCanceledException)
            {
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "JobUpdateLessonParticipant failed: {Message}", ex.Message);
                return false;
            }
        }

        private Task DispatchAsync(LessonMeetingEntity meeting, CancellationToken cancellationToken)
        {
            return meeting.ProviderMeetingType switch
            {
                ProviderMeetingType.Zoom => _mediator
                    .Send(new JobUpdateLessonParticipantForZoomCommand
                    {
                        LessonMeetingId = meeting.Id
                    }, cancellationToken)
                    .ContinueWith(t =>
                    {
                        if (t.IsFaulted)
                            _logger.LogError(t.Exception?.GetBaseException(), "JobUpdateLessonParticipant Zoom - MeetingId {MeetingId}: {Message}", meeting.Id, t.Exception?.GetBaseException().Message);
                    }, TaskScheduler.Default),

                ProviderMeetingType.Teams => _mediator
                    .Send(new JobUpdateLessonParticipantForTeamsCommand
                    {
                        LessonMeetingId = meeting.Id
                    }, cancellationToken)
                    .ContinueWith(t =>
                    {
                        if (t.IsFaulted)
                            _logger.LogError(t.Exception?.GetBaseException(), "JobUpdateLessonParticipant Teams - MeetingId {MeetingId}: {Message}", meeting.Id, t.Exception?.GetBaseException().Message);
                    }, TaskScheduler.Default),

                _ => Task.CompletedTask
            };
        }
    }
}
