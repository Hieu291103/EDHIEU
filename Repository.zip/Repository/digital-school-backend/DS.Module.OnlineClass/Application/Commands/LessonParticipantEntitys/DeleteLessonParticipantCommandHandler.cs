using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Application.Commands.LessonParticipantEntitys
{
    /// <summary>
    /// Xóa tất cả thông tin điểm danh theo LessonMeetingId
    /// </summary>
    public class DeleteLessonParticipantCommandHandler : ICommandHandler<DeleteLessonParticipantCommand, bool>
    {
        private readonly ISchoolCommonReadRepository<LessonParticipantEntity> _participantReadRepository;
        private readonly ISchoolCommonWriteRepository<LessonParticipantEntity> _participantWriteRepository;
        private readonly ILogger<DeleteLessonParticipantCommandHandler> _logger;

        public DeleteLessonParticipantCommandHandler(
            ISchoolCommonReadRepository<LessonParticipantEntity> participantReadRepository,
            ISchoolCommonWriteRepository<LessonParticipantEntity> participantWriteRepository,
            ILogger<DeleteLessonParticipantCommandHandler> logger)
        {
            _participantReadRepository = participantReadRepository;
            _participantWriteRepository = participantWriteRepository;
            _logger = logger;
        }

        public async Task<bool> Handle(DeleteLessonParticipantCommand request, CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(request.LessonMeetingId))
                return false;

            var participants = await _participantReadRepository.FilterAsync(
                x => x.LessonMeetingId == request.LessonMeetingId,
                cancellationToken: cancellationToken);

            if (participants == null || !participants.Any())
                return true;

            var deleteTasks = participants.Select(p =>
                _participantWriteRepository.DeleteAsync(p.Id, cancellationToken: cancellationToken));

            await Task.WhenAll(deleteTasks);

            return true;
        }
    }
}
