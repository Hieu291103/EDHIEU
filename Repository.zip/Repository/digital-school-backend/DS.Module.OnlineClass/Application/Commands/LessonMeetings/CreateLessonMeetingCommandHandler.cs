using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.CQRS.Queries.Subject;
using MediatR;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    /// <summary>
    /// Handler cho CreateLessonMeetingCommand
    /// Tạo buổi học trực tuyến mới
    /// </summary>
    public class CreateLessonMeetingCommandHandler : ICommandHandler<CreateLessonMeetingCommand, Result>
    {
        private readonly ISchoolCommonWriteRepository<LessonMeetingEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _lessonReadRepository;
        private readonly ISchoolCommonReadRepository<OnlineClassTenantClassEntity> _classRepository;
        private readonly ISchoolCommonReadRepository<OnlineClassTenantEntity> _tenantRepository;
        private readonly ISchoolCommonReadRepository<AccountMeetingEntity> _accountRepository;
        private readonly IMSTeamsService _msTeamsService;
        private readonly IMediator _mediator;

        public CreateLessonMeetingCommandHandler(
            ISchoolCommonWriteRepository<LessonMeetingEntity> writeRepository,
            ISchoolCommonReadRepository<LessonMeetingEntity> lessonReadRepository,
            ISchoolCommonReadRepository<OnlineClassTenantClassEntity> classRepository,
            ISchoolCommonReadRepository<OnlineClassTenantEntity> tenantRepository,
            ISchoolCommonReadRepository<AccountMeetingEntity> accountRepository,
            IMSTeamsService mSTeamsService,
            IMediator mediator)

        {
            _writeRepository = writeRepository;
            _lessonReadRepository = lessonReadRepository;
            _classRepository = classRepository;
            _tenantRepository = tenantRepository;
            _msTeamsService = mSTeamsService;
            _accountRepository = accountRepository;
            _mediator = mediator;
        }

        public async Task<Result> Handle(CreateLessonMeetingCommand request, CancellationToken cancellationToken)
        {
            // Lấy thông tin tenant
            var tenants = await _tenantRepository.FilterAsync(
                x => x.SchoolId == request.SchoolId,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (tenants == null || !tenants.Any())
                throw new DSException("OnlineClassServiceNotAvailableForSchool");

            var tenant = tenants.FirstOrDefault();

            // Kiểm tra tenant null (bảo vệ thêm)
            if (tenant == null)
                throw new DSException("OnlineClassServiceNotAvailableForSchool");

            // Kiểm tra tenant chưa bắt đầu
            if (tenant.StartDate!.Value.Date > DateTime.UtcNow.Date)
                throw new DSException("OnlineClassTenantNotYetStarted");

            // Kiểm tra tenant đã hết hạn
            if (tenant.ExpireDate!.Value.Date < DateTime.UtcNow.Date)
                throw new DSException("OnlineClassTenantExpired");

            // Kiểm tra tenant không hoạt động
            if (!tenant.IsActive)
                throw new DSException("OnlineClassServiceNotAvailableForSchool");

            // Kiểm tra thời gian buổi học hợp lệ
            if (request.StartTime >= request.EndTime)
                throw new DSException("LessonMeetingInvalidTimeRange");


            // Lấy thông tin lớp học
            var classes = await _classRepository.FilterAsync(
                x => x.TenantId == tenant.TenantId && x.ClassId == request.ClassId,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (classes == null || !classes.Any())
                throw new DSException("LessonMeetingClassNotPermitted");

            var classInfo = classes.FirstOrDefault();

            if (classInfo == null || !classInfo.IsActive)
                throw new DSException("LessonMeetingClassNotPermitted");

            var subject = await _mediator.Send(new SharedGetSubjectTemplateListQuery(), cancellationToken);
            if (subject != null && subject?.Count > 0)
            {
                request.SubjectName = subject.ContainsKey(request.Subject!) ? subject[request.Subject!] : request.Subject;
            }

            // Tạo tiêu đề tự động: ClassName + Subject + FullName
            var title = classInfo!.ClassName + " - " + request.SubjectName + " (" + request.StartTime.ToLocal().ToString("dd/MM/yyyy") + " " + request.StartTime.ToLocal().ToString("HH:mm") + "->" + request.EndTime.ToLocal().ToString("HH:mm") + ")";

            // Kiểm tra xem lớp học này trong khoảng thời gian tạo đã có buổi nào chưa
            var conflictingLessons = await _lessonReadRepository.FilterAsync(
                x => x.TenantId == tenant.TenantId
                     && x.ClassId == request.ClassId
                     && x.Status != MeetingStatus.Cancelled
                     && x.Status != MeetingStatus.Ended
                     && x.StartTime < request.EndTime
                     && x.EndTime > request.StartTime,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (conflictingLessons != null && conflictingLessons.Any())
                throw new DSException("LessonMeetingTimeConflict");

            // Kiểm tra xem người tạo đã có buổi học nào trùng thời gian không
            var creatorConflictingLessons = await _lessonReadRepository.FilterAsync(
                x => x.TenantId == tenant.TenantId
                     && x.UserId == request.UserId
                     && x.Status != MeetingStatus.Cancelled
                     && x.Status != MeetingStatus.Ended
                     && x.StartTime < request.EndTime
                     && x.EndTime > request.StartTime,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (creatorConflictingLessons != null && creatorConflictingLessons.Any())
                throw new DSException("LessonMeetingCreatorTimeConflict");


            var accountInfo = new AccountMeetingEntity();
            //Lấy thông tin người tạo nếu là kiểu team
            if (tenant.ProviderMeetingType == ProviderMeetingType.Teams)
            {
                var accounts = await _accountRepository.FilterAsync(
                    x => x.TenantId == tenant.TenantId && x.UserId == request.UserId,
                    tenantId: null,
                    cancellationToken: cancellationToken);
                if (accounts == null || !accounts.Any())
                    throw new DSException("LessonMeetingCreatorNotPermitted");
                accountInfo = accounts.FirstOrDefault();
                if (accountInfo == null || string.IsNullOrEmpty(accountInfo.MeetEmail) || string.IsNullOrEmpty(accountInfo.MeetUserId))
                    throw new DSException("LessonMeetingCreatorNotPermitted");
            }

            // Tạo buổi học mới
            var lessonMeeting = new LessonMeetingEntity
            {
                TenantId = tenant.TenantId,
                ProviderConnect = tenant.ProviderConnect,
                ProviderMeetingType = tenant.ProviderMeetingType,
                Title = title,
                Description = request.Description,
                Date = request.StartTime.ToLocal().Date,
                StartTime = request.StartTime,
                EndTime = request.EndTime,
                ClassId = request.ClassId,
                ClassName = classInfo.ClassName,
                GradeId = classInfo.GradeId,
                Subject = request.Subject,
                SubjectName = request.SubjectName,
                UserId = request.UserId,
                FullName = request.FullName,
                MeetEmail = accountInfo.MeetEmail,
                MeetUserId = accountInfo.MeetUserId,
                SchoolId = request.SchoolId,
                SchoolYear = request.SchoolYear,
                LessonPeriod = request.LessonPeriod,
                TimeZone = request.TimeZone,
                AllowRecording = false,
                Status = MeetingStatus.NotStarted,
                JoinUrlActive = false,
                CurrentParticipantCount = 0,
            };
            //Tạo buổi học với provider
            if (tenant.ProviderMeetingType == ProviderMeetingType.Teams)
            {
                // Tạo buổi học trên Teams thông qua Microsoft Graph API
                lessonMeeting.AllowRecording = true;
                lessonMeeting.JoinUrlActive = false;
                lessonMeeting.JoinCoHostUrl = "";
                lessonMeeting.JoinUrl = "";
                await _writeRepository.InsertAsync(lessonMeeting);

                return Result.Success();
            }
            else if (tenant.ProviderMeetingType == ProviderMeetingType.Zoom)
            {
                if (tenant.ProviderConnect == null)
                    throw new DSException("OnlineClassServiceNotAvailableForSchool");

                lessonMeeting.AllowRecording = true;
                lessonMeeting.JoinUrlActive = false;
                lessonMeeting.JoinCoHostUrl = "";
                lessonMeeting.JoinUrl = "";
                await _writeRepository.InsertAsync(lessonMeeting);

                return Result.Success();
            }
            else
            {
                throw new DSException("OnlineClassServiceNotAvailableForSchool");
            }
        }
    }
}
