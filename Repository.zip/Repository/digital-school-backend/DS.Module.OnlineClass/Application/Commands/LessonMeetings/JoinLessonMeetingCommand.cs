using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Enums;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    public class JoinLessonMeetingCommand : ICommand<string?>
    {
        /// <summary>
        /// ID của buổi học trực tuyến
        /// </summary>
        public required string Id { get; set; }

        /// <summary>
        /// Id của người dùng 
        /// </summary>
        public string UserId { get; set; } = string.Empty;

        /// <summary>
        /// Loại tài khoản người tham gia (Học sinh, Giáo viên)
        /// </summary>
        public UserType UserType { get; set; } = UserType.Student;

        /// <summary>
        /// Tên đăng nhập
        /// </summary>
        public string? Username { get; set; }

        /// <summary>
        /// Tên người tham gia (snapshot tại thời điểm tham gia)
        /// </summary>
        public string? UserFullName { get; set; }

        /// <summary>
        /// Tên hiển thị trên zoom, teams (snapshot tại thời điểm tham gia)
        /// UserFullName - Username
        /// </summary>
        public string? UserDisplayName { get; set; }

        /// <summary>
        /// Email người tham gia (snapshot tại thời điểm tham gia)
        /// </summary>
        public string? UserEmail { get; set; }

        /// <summary>
        /// Thông tin thiết bị người tham gia (snapshot tại thời điểm tham gia)
        /// </summary>
        public string? DeviceInfo { get; set; }

        /// <summary>
        /// Địa chỉ IP của người tham gia (snapshot tại thời điểm tham gia)
        /// </summary>
        public string? IpAddress { get; set; }
    }
}
