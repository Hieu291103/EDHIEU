using DS.Module.OnlineClass.Application.Commands.PartnerOneZoomMeetingEntitys;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    /// <summary>
    /// Handler cho CancelLessonMeetingCommand
    /// Hủy bỏ buổi học trực tuyến và xóa meeting trên MS Teams
    /// </summary>
    public class CancelLessonMeetingCommandHandler : ICommandHandler<CancelLessonMeetingCommand, Result>
    {
        private readonly ISchoolCommonWriteRepository<LessonMeetingEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _readRepository;
        private readonly IMSTeamsService _msTeamsService;
        private readonly ILogger<CancelLessonMeetingCommandHandler> _logger;
        private readonly IMediator _mediator;
        public CancelLessonMeetingCommandHandler(
            ISchoolCommonWriteRepository<LessonMeetingEntity> writeRepository,
            ISchoolCommonReadRepository<LessonMeetingEntity> readRepository,
            IMSTeamsService msTeamsService,
            ILogger<CancelLessonMeetingCommandHandler> logger,
            IMediator mediator
            )
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _msTeamsService = msTeamsService;
            _logger = logger;
            _mediator = mediator;
        }

        public async Task<Result> Handle(CancelLessonMeetingCommand request, CancellationToken cancellationToken)
        {
            // Lấy thông tin buổi học
            var lessonMeetings = await _readRepository.FilterAsync(
                x => x.Id == request.LessonMeetingId,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (lessonMeetings == null || !lessonMeetings.Any())
                throw new DSException("LessonMeetingNotFound");

            var lessonMeeting = lessonMeetings.FirstOrDefault();

            if (lessonMeeting == null)
                throw new DSException("LessonMeetingNotFound");

            // Kiểm tra buổi học chưa kết thúc (chỉ có thể hủy trước thời gian kết thúc)
            if (lessonMeeting.EndTime <= DateTime.UtcNow)
                throw new DSException("LessonMeetingCannotCancel");

            // Kiểm tra buổi học chưa bị hủy
            if (lessonMeeting.Status == MeetingStatus.Cancelled || lessonMeeting.Status == MeetingStatus.Ended)
                throw new DSException("LessonMeetingCannotCancel");

            // Nếu là Teams meeting, xóa trên MS Teams
            if (lessonMeeting.ProviderMeetingType == Domain.Enums.ProviderMeetingType.Teams)
            {
                // Nếu meeting đã được tạo trên MS Teams, hãy xóa nó
                if (!string.IsNullOrEmpty(lessonMeeting.ProviderMeetingId) &&
                    !string.IsNullOrEmpty(lessonMeeting.ProviderConnect) &&
                    !string.IsNullOrEmpty(lessonMeeting.MeetUserId))
                {
                    try
                    {
                        await _msTeamsService.DeleteMeetingAsync(
                            lessonMeeting.ProviderConnect,
                            lessonMeeting.MeetUserId,
                            lessonMeeting.ProviderMeetingId);
                    }
                    catch (Exception ex)
                    {
                        // Log lỗi nhưng vẫn tiếp tục xóa từ database
                        _logger.LogError(ex, "Lỗi khi xóa meeting trên MS Teams cho LessonMeetingId: {LessonMeetingId}", lessonMeeting.Id);
                    }
                }
            }
            else if (lessonMeeting.ProviderMeetingType == Domain.Enums.ProviderMeetingType.Zoom)
            {
                // Nếu meeting đã được tạo trên Zoom, hãy gửi command để xóa nó
                await _mediator.Send(new DeleteOneZoomMeetingCommand
                {
                    LessonMeetingId = lessonMeeting.Id
                }, cancellationToken);
            }

            // Cập nhật trạng thái thành Cancelled
            lessonMeeting.Status = MeetingStatus.Cancelled;
            lessonMeeting.JoinUrlActive = false; // Vô hiệu hóa link tham gia
            lessonMeeting.Notes = string.IsNullOrEmpty(request.Reason)
                ? "Buổi học đã bị hủy bỏ"
                : $"Buổi học đã bị hủy bỏ. Lý do: {request.Reason}";

            // Lưu thay đổi
            await _writeRepository.UpdateAsync(lessonMeeting);

            return Result.Success();
        }
    }
}
