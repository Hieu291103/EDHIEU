using DS.Module.OnlineClass.Application.Commands.PartnerOneZoomMeetingEntitys;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Module.OnlineClass.Infrastructure.Configuration;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    public class JobUpdateEndLessionMeetingCommandHandler : ICommandHandler<JobUpdateEndLessionMeetingCommand, bool>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _readRepository;
        private readonly ISchoolCommonWriteRepository<LessonMeetingEntity> _writeRepository;
        private readonly ISchoolCommonWriteRepository<LessonParticipantEntity> _participantWriteRepository;
        private readonly ILogger<JobUpdateEndLessionMeetingCommandHandler> _logger;
        private readonly OnlineClassSettings _settings;
        private readonly IMediator _mediator;

        public JobUpdateEndLessionMeetingCommandHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> readRepository,
            ISchoolCommonWriteRepository<LessonMeetingEntity> writeRepository,
            ISchoolCommonWriteRepository<LessonParticipantEntity> participantWriteRepository,
            ILogger<JobUpdateEndLessionMeetingCommandHandler> logger,
            OnlineClassSettings settings,
            IMediator mediator)
        {
            _readRepository = readRepository;
            _writeRepository = writeRepository;
            _participantWriteRepository = participantWriteRepository;
            _logger = logger;
            _settings = settings;
            _mediator = mediator;
        }

        public async Task<bool> Handle(JobUpdateEndLessionMeetingCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var currentTime = DateTime.UtcNow;
                var threshold = currentTime.AddMinutes(_settings.Setting.EndLessonAfterEndTimeMinutes);

                // Lấy các buổi học đang Active và có EndTime đã qua 1 phút
                var meetings = await _readRepository.FilterAsync(
                    x => x.Status == MeetingStatus.Active &&
                         x.EndTime <= threshold,
                    cancellationToken: cancellationToken);

                if (meetings == null || !meetings.Any())
                    return true;

                var deleteTasks = new List<Task>();

                foreach (var meeting in meetings)
                {
                    try
                    {
                        meeting.JoinUrlActive = false;
                        meeting.Status = MeetingStatus.Ended;
                        meeting.EndTime = currentTime;
                        await _writeRepository.UpdateAsync(meeting);

                        //Cập nhật thời gian trong bảng điểm danh
                        await _participantWriteRepository.UpdateManyAsync(
                            x => x.LessonMeetingId == meeting.Id,
                            Builders<LessonParticipantEntity>.Update.Set(x => x.LeaveTime, DateTime.UtcNow),
                            tenantId: null,
                            cancellationToken: cancellationToken);

                        //Kiểm tra meeting có phải là zoom không, nếu phải thì gọi api zoom để xóa
                        if (meeting.ProviderMeetingType == ProviderMeetingType.Zoom)
                        {
                            deleteTasks.Add(_mediator.Send(new DeleteOneZoomMeetingCommand
                            {
                                LessonMeetingId = meeting.Id
                            }, cancellationToken).ContinueWith(t =>
                            {
                                if (t.IsFaulted)
                                    _logger.LogError($"JobUpdateEndLessonMeeting {meeting.Id}: {t.Exception?.GetBaseException().Message}");
                            }, TaskScheduler.Default));
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "JobUpdateEndLessonMeeting {MeetingId}: {Message}", meeting.Id, ex.Message);
                    }
                }

                await Task.WhenAll(deleteTasks);
                return true;
            }
            catch (OperationCanceledException)
            {
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "JobUpdateEndLessonMeeting failed: {Message}", ex.Message);
                return false;
            }
        }
    }
}
