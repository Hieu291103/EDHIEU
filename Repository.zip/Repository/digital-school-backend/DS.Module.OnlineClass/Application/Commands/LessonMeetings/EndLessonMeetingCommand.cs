using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    public class EndLessonMeetingCommand : ICommand<bool>
    {
        /// <summary>
        /// ID của buổi học trực tuyến
        /// </summary>
        public required string Id { get; set; }

        /// <summary>
        /// Id của người dùng 
        /// </summary>
        public string UserId { get; set; } = string.Empty;
    }
}
