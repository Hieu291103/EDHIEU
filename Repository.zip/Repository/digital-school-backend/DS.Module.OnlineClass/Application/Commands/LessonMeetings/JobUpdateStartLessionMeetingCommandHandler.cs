using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Module.OnlineClass.Infrastructure.Configuration;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    public class JobUpdateStartLessionMeetingCommandHandler : ICommandHandler<JobUpdateStartLessionMeetingCommand, bool>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _readRepository;
        private readonly ISchoolCommonWriteRepository<LessonMeetingEntity> _writeRepository;
        private readonly ILogger<JobUpdateStartLessionMeetingCommandHandler> _logger;
        private readonly OnlineClassSettings _settings;
        public JobUpdateStartLessionMeetingCommandHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> readRepository,
            ISchoolCommonWriteRepository<LessonMeetingEntity> writeRepository,
            ILogger<JobUpdateStartLessionMeetingCommandHandler> logger,
             OnlineClassSettings settings)
        {
            _readRepository = readRepository;
            _writeRepository = writeRepository;
            _logger = logger;
            _settings = settings;
        }

        public async Task<bool> Handle(JobUpdateStartLessionMeetingCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var currentTime = DateTime.UtcNow;
                var threshold = currentTime.AddMinutes(_settings.Setting.StartLessonBeforeStartTimeMinutes);

                // Lấy các buổi học có JoinUrl hợp lệ, JoinUrlActive = true,
                // trạng thái NotStarted và bắt đầu trong vòng 5 phút tới
                var meetings = await _readRepository.FilterAsync(
                    x => x.JoinUrlActive == true &&
                         x.Status == MeetingStatus.NotStarted &&
                         x.StartTime <= threshold,
                    cancellationToken: cancellationToken);

                if (meetings == null || !meetings.Any())
                    return true;

                foreach (var meeting in meetings)
                {
                    try
                    {
                        meeting.Status = MeetingStatus.Active;
                        await _writeRepository.UpdateAsync(meeting);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "JobUpdateStartLessonMeeting {MeetingId}: {Message}", meeting.Id, ex.Message);
                    }
                }

                return true;
            }
            catch (OperationCanceledException)
            {
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "JobUpdateStartLessonMeeting failed: {Message}", ex.Message);
                return false;
            }
        }
    }
}
