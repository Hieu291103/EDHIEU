using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    /// <summary>
    /// Command để hủy bỏ buổi học trực tuyến (Lesson Meeting)
    /// Chỉ có thể hủy trước thời gian kết thúc buổi học
    /// Khi hủy sẽ xóa meeting trên MS Teams
    /// </summary>
    public class CancelLessonMeetingCommand : ICommand<Result>
    {
        /// <summary>
        /// ID của buổi học trực tuyến cần hủy
        /// </summary>
        public required string LessonMeetingId { get; set; }

        /// <summary>
        /// Lý do hủy bỏ buổi học (tùy chọn)
        /// </summary>
        public string? Reason { get; set; }
    }
}
