using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Module.OnlineClass.Infrastructure.Common;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Enums;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    /// <summary>
    /// Handler để tham gia buổi học trực tuyến (Lesson Meeting)
    /// - Lấy link tham gia dựa trên loại người dùng (Giáo viên/Học sinh) và nhà cung cấp dịch vụ
    /// - Ghi nhận thông tin người tham gia vào LessonParticipantEntity
    /// - Cập nhật JoinTimeClick khi người dùng nhấn link tham gia
    /// </summary>
    public class JoinLessonMeetingCommandHandler : ICommandHandler<JoinLessonMeetingCommand, string?>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _lessonMeetingReadRepository;
        private readonly ISchoolCommonReadRepository<LessonParticipantEntity> _lessonParticipantReadRepository;
        private readonly ISchoolCommonWriteRepository<LessonParticipantEntity> _lessonParticipantWriteRepository;

        public JoinLessonMeetingCommandHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> lessonMeetingReadRepository,
            ISchoolCommonReadRepository<LessonParticipantEntity> lessonParticipantReadRepository,
            ISchoolCommonWriteRepository<LessonParticipantEntity> lessonParticipantWriteRepository)
        {
            _lessonMeetingReadRepository = lessonMeetingReadRepository;
            _lessonParticipantReadRepository = lessonParticipantReadRepository;
            _lessonParticipantWriteRepository = lessonParticipantWriteRepository;
        }

        public async Task<string?> Handle(JoinLessonMeetingCommand request, CancellationToken cancellationToken)
        {
            // Lấy buổi học theo ID
            var lessonMeetings = await _lessonMeetingReadRepository.FilterAsync(
                x => x.Id == request.Id);

            var lessonMeeting = lessonMeetings.FirstOrDefault();

            if (lessonMeeting is null)
            {
                throw new DSException("LessonMeetingNotFound");
            }

            // Kiểm tra trạng thái buổi học phải là Active để có thể tham gia
            if (lessonMeeting.Status != MeetingStatus.Active)
            {
                throw new DSException("LessonMeetingNotActive");
            }

            // Xác định link tham gia dựa trên loại người dùng và nhà cung cấp dịch vụ
            string? joinUrl = GetJoinUrl(request.UserType, lessonMeeting);

            // Ghi nhận/cập nhật thông tin người tham gia
            await RecordParticipant(request, lessonMeeting);

            return joinUrl;
        }

        /// <summary>
        /// Lấy link tham gia dựa trên loại người dùng và nhà cung cấp dịch vụ
        /// - Giáo viên: JoinCoHostUrl (cho Zoom), JoinUrl (cho Teams)
        /// - Học sinh: JoinUrl (luôn)
        /// </summary>
        private string? GetJoinUrl(UserType userType, LessonMeetingEntity lessonMeeting)
        {
            // Học sinh luôn sử dụng JoinUrl
            if (userType == UserType.Student)
            {
                return lessonMeeting.JoinUrl;
            }

            // Giáo viên: sử dụng JoinCoHostUrl cho Zoom, JoinUrl cho các nhà cung cấp khác
            if (userType == UserType.Teacher)
            {
                if (lessonMeeting.ProviderMeetingType == ProviderMeetingType.Zoom)
                {
                    return lessonMeeting.JoinCoHostUrl ?? lessonMeeting.JoinUrl;
                }
                else
                {
                    return lessonMeeting.JoinUrl;
                }
            }

            // Các loại người dùng khác (Principal, SchoolStaff, v.v.) được coi như giáo viên
            if (lessonMeeting.ProviderMeetingType == ProviderMeetingType.Zoom)
            {
                return lessonMeeting.JoinCoHostUrl ?? lessonMeeting.JoinUrl;
            }

            return lessonMeeting.JoinUrl;
        }

        /// <summary>
        /// Ghi nhận hoặc cập nhật thông tin người tham gia trong LessonParticipantEntity
        /// </summary>
        private async Task RecordParticipant(JoinLessonMeetingCommand request, LessonMeetingEntity lessonMeeting)
        {
            // Tìm participant hiện có
            var participants = await _lessonParticipantReadRepository.FilterAsync(
                x => x.LessonMeetingId == request.Id &&
                     x.UserId == request.UserId);

            var participant = participants.FirstOrDefault();

            if (participant is not null)
            {
                // Nếu JoinTimeClick chưa được ghi nhận, thì cập nhật nó
                if (participant.JoinTimeClick is null)
                {
                    participant.IsUser = true;
                    participant.JoinTimeClick = DateTime.UtcNow;
                    participant.Username = participant.Username ?? request.Username;
                    participant.UserFullName = participant.UserFullName ?? request.UserFullName;
                    participant.UserDisplayName = participant.UserDisplayName ?? LessionMeetingHelper.MeetingDisplayName(participant.UserFullName, participant.Username);
                    participant.AttendanceStatus = Domain.Enums.MeetingAttendanceStatus.Attended;
                    participant.UserEmail = participant.UserEmail ?? request.UserEmail;
                    participant.DeviceInfo = participant.DeviceInfo ?? request.DeviceInfo;
                    participant.JoinIpAddress = participant.JoinIpAddress ?? request.IpAddress;

                    await _lessonParticipantWriteRepository.UpdateAsync(participant);
                }
            }
            else
            {
                // Tạo mới LessonParticipantEntity
                var newParticipant = new LessonParticipantEntity
                {
                    LessonMeetingId = request.Id,
                    UserId = request.UserId,
                    IsUser = true,
                    UserType = request.UserType,
                    Username = request.Username,
                    UserFullName = request.UserFullName,
                    UserDisplayName = LessionMeetingHelper.MeetingDisplayName(request.UserFullName, request.Username),
                    JoinTimeClick = DateTime.UtcNow,
                    TenantId = lessonMeeting.TenantId,
                    SchoolId = lessonMeeting.SchoolId,
                    AttendanceStatus = Domain.Enums.MeetingAttendanceStatus.Attended,
                    UserEmail = request.UserEmail,
                    DeviceInfo = request.DeviceInfo,
                    JoinIpAddress = request.IpAddress
                };
                await _lessonParticipantWriteRepository.InsertAsync(newParticipant);
            }
        }
    }
}
