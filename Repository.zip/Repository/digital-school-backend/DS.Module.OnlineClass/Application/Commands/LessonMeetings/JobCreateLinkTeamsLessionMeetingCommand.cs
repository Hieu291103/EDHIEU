using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    public class JobCreateLinkTeamsLessionMeetingCommand : ICommand<bool>
    {
        /// <summary>
        /// Thời gian hiện tại để query các buổi meeting cần tạo link
        /// </summary>
        public DateTime? CurrentDateTime { get; set; } = DateTime.UtcNow;
    }
}
