using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    /// <summary>
    /// Command để xóa buổi học trực tuyến (Lesson Meeting) vĩnh viễn
    /// Khác với Cancel: Delete là xóa vĩnh viễn khỏi hệ thống
    /// Cancel chỉ thay đổi trạng thái thành Cancelled
    /// </summary>
    public class DeleteLessonMeetingCommand : ICommand<Result>
    {
        /// <summary>
        /// ID của buổi học trực tuyến cần xóa
        /// </summary>
        public required string Id { get; set; }
    }
}
