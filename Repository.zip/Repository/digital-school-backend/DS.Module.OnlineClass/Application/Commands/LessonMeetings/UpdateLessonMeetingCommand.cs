using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    /// <summary>
    /// Command để cập nhật buổi học trực tuyến (Lesson Meeting)
    /// Có thể cập nhật: Title, Description, StartTime, EndTime, TimeZone, AllowRecording, Notes
    /// </summary>
    public class UpdateLessonMeetingCommand : ICommand<Result>
    {
        /// <summary>
        /// ID của buổi học trực tuyến cần cập nhật
        /// </summary>
        public required string Id { get; set; }

        /// <summary>
        /// Mô tả buổi học (tùy chọn)
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// Ghi chú bổ sung (tùy chọn)
        /// </summary>
        public string? Notes { get; set; }
    }
}
