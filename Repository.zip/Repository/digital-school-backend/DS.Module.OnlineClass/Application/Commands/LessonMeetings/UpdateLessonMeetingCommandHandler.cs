using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    /// <summary>
    /// Handler để cập nhật buổi học trực tuyến (Lesson Meeting)
    /// Xác thực các ràng buộc sau:
    /// - Buổi học phải tồn tại và thuộc tenant
    /// - Thời gian không được trùng lặp với các buổi học khác
    /// - Không cập nhật được buổi học đã kết thúc
    /// </summary>
    public class UpdateLessonMeetingCommandHandler : ICommandHandler<UpdateLessonMeetingCommand, Result>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _lessonMeetingReadRepository;
        private readonly ISchoolCommonWriteRepository<LessonMeetingEntity> _lessonMeetingWriteRepository;

        public UpdateLessonMeetingCommandHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> lessonMeetingReadRepository,
            ISchoolCommonWriteRepository<LessonMeetingEntity> lessonMeetingWriteRepository)
        {
            _lessonMeetingReadRepository = lessonMeetingReadRepository;
            _lessonMeetingWriteRepository = lessonMeetingWriteRepository;
        }

        public async Task<Result> Handle(UpdateLessonMeetingCommand request, CancellationToken cancellationToken)
        {
            // Lấy tất cả lesson meetings cho tenant này
            var lessonMeetings = await _lessonMeetingReadRepository.FilterAsync(
                x => x.Id == request.Id);

            var lessonMeeting = lessonMeetings.FirstOrDefault(x => x.Id == request.Id);

            if (lessonMeeting is null)
            {
                throw new DSException("LessonMeetingNotFound");
            }

            if (request.Description.IsNotNull())
                lessonMeeting.Description = request.Description;


            if (request.Notes.IsNotNull())
                lessonMeeting.Notes = request.Notes;

            // Lưu cập nhật
            await _lessonMeetingWriteRepository.UpdateAsync(lessonMeeting);

            return Result.Success();
        }
    }
}
