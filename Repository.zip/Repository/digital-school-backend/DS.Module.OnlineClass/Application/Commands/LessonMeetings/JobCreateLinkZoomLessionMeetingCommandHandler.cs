using DS.Module.OnlineClass.Application.Commands.LessonParticipantEntitys;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Module.OnlineClass.Infrastructure.Configuration;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Module.OnlineClass.Infrastructure.Services.DTOs.ZoomBusiness;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    public class JobCreateLinkZoomLessionMeetingCommandHandler : ICommandHandler<JobCreateLinkZoomLessionMeetingCommand, bool>
    {
        private readonly ISchoolCommonWriteRepository<LessonMeetingEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _lessonReadRepository;
        private readonly ISchoolCommonReadRepository<AccountMeetingEntity> _accountRepository;
        private readonly ISchoolCommonWriteRepository<PartnerOneZoomMeetingEntity> _partnerOneZoomRepository;
        private readonly IOneZoomService _oneZoomService;
        private readonly IMediator _mediator;
        private readonly ILogger<JobCreateLinkZoomLessionMeetingCommandHandler> _logger;
        private readonly OnlineClassSettings _settings;

        public JobCreateLinkZoomLessionMeetingCommandHandler(
          ISchoolCommonWriteRepository<LessonMeetingEntity> writeRepository,
          ISchoolCommonReadRepository<LessonMeetingEntity> lessonReadRepository,
          ISchoolCommonReadRepository<OnlineClassTenantClassEntity> classRepository,
        ISchoolCommonWriteRepository<PartnerOneZoomMeetingEntity> partnerOneZoomRepository,
        ISchoolCommonReadRepository<AccountMeetingEntity> accountRepository,
          IMSTeamsService mSTeamsService,
          IOneZoomService oneZoomService,
          IMediator mediator,
          ILogger<JobCreateLinkZoomLessionMeetingCommandHandler> logger,
          OnlineClassSettings settings)
        {
            _writeRepository = writeRepository;
            _lessonReadRepository = lessonReadRepository;
            _accountRepository = accountRepository;
            _oneZoomService = oneZoomService;
            _settings = settings;
            _mediator = mediator;
            _logger = logger;
            _partnerOneZoomRepository = partnerOneZoomRepository;
        }

        public async Task<bool> Handle(JobCreateLinkZoomLessionMeetingCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var currentTime = request.CurrentDateTime ?? DateTime.UtcNow;
                var zoomCreationBeforeMinutes = _settings.Setting.ZoomCreationBeforeStartTimeMinutes;
                // Tạo link trong khoảng [currentTime - N phút, currentTime + N phút]
                // Link được tạo trước buổi học N phút và sau buổi học N phút
                // VD: N=15, currentTime=10h00 → tạo link cho buổi 09h45-10h15
                var startTime = currentTime.AddMinutes(-zoomCreationBeforeMinutes);
                var targetTime = currentTime.AddMinutes(zoomCreationBeforeMinutes);

                // Lấy danh sách các buổi meeting Zoom cần tạo link
                var zoomLessons = await GetZoomLessonsNeedingLinkAsync(startTime, targetTime, cancellationToken);
                var participantTasks = new List<Task>();

                foreach (var lesson in zoomLessons)
                {
                    try
                    {
                        // Kiểm tra idempotency: nếu đã có JoinUrl thì skip
                        if (!string.IsNullOrEmpty(lesson.JoinUrl))
                        {
                            continue;
                        }

                        await CreateZoomLinkForLessonAsync(lesson, cancellationToken);
                        participantTasks.Add(_mediator.Send(new JobCreateLessonParticipantForClassCommand()
                        {
                            ClassId = lesson.ClassId,
                            LessonMeetingId = lesson.Id,
                            TenantId = lesson.TenantId,
                            SchoolId = lesson.SchoolId,
                            SchoolYear = lesson.SchoolYear,
                        }, cancellationToken).ContinueWith(t =>
                        {
                            if (t.IsFaulted)
                                _logger.LogError($"JobCreateLessonParticipant {lesson.Id}: {t.Exception?.GetBaseException().Message}");
                        }, TaskScheduler.Default));
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError($"JobCreateLinkZoom {lesson.Id}: {ex.Message}");
                    }
                }

                await Task.WhenAll(participantTasks);
                return true;
            }
            catch (OperationCanceledException ex)
            {
                _logger.LogError($"{ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError($"{ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Lấy danh sách các buổi meeting Zoom cần tạo link trong khoảng [startTime, targetTime]
        /// </summary>
        private async Task<List<LessonMeetingEntity>> GetZoomLessonsNeedingLinkAsync(DateTime startTime, DateTime targetTime, CancellationToken cancellationToken)
        {
            // Query các buổi meeting Zoom cần tạo link:
            // - Nhà cung cấp là Zoom
            // - JoinUrl chưa được tạo (JoinUrlActive=false, ProviderMeetingId rỗng)
            // - Trạng thái: chưa bắt đầu hoặc đang diễn ra
            // - StartTime nằm trong [startTime, targetTime]
            //
            // Nguyên lý: Tạo link trước buổi học N phút và sau buổi học N phút
            // VD: N=15 phút, currentTime=10h00
            //   → startTime=09h45, targetTime=10h15
            //   → Bắt các buổi có StartTime từ 09h45 đến 10h15
            var lessons = await _lessonReadRepository.FilterAsync(
                x => x.ProviderMeetingType == ProviderMeetingType.Zoom && x.JoinUrlActive == false &&
                     string.IsNullOrEmpty(x.ProviderMeetingId) &&
                     (x.Status == MeetingStatus.NotStarted || x.Status == MeetingStatus.Active) &&
                     x.StartTime >= startTime &&
                     x.StartTime <= targetTime,
                cancellationToken: cancellationToken
            );

            return lessons?.ToList() ?? new List<LessonMeetingEntity>();
        }

        /// <summary>
        /// Tạo Zoom link cho một buổi meeting
        /// </summary>
        private async Task CreateZoomLinkForLessonAsync(LessonMeetingEntity lesson, CancellationToken cancellationToken)
        {
            // Lấy thông tin tài khoản Zoom từ ProviderConnect
            if (string.IsNullOrEmpty(lesson.ProviderConnect))
            {
                throw new InvalidOperationException($"Lesson {lesson.Id} does not have a provider connect configured");
            }

            // Tính toán thời lượng buổi họp (phút)
            var duration = 60; // Default 1 giờ
            if (lesson.StartTime.HasValue && lesson.EndTime.HasValue)
            {
                duration = (int)(lesson.EndTime.Value - lesson.StartTime.Value).TotalMinutes;
            }

            // Tạo request Zoom
            var zoomRequest = new CreateZoomMeetingRequest
            {
                Topic = lesson.Title ?? lesson.ClassName + " - " + lesson.SubjectName + " - " + lesson.FullName,
                Agenda = lesson.Description,
                TimeInMinute = Math.Max(duration, 45), // Minimum 45 phút
                Password = GenCodeRandomHelper.Digits(8),
                ContactMail = lesson.MeetEmail,
                ContactName = lesson.FullName
            };

            // Tạo cuộc họp Zoom - sử dụng ProviderConnect như zoomCode
            var zoomMeeting = await _oneZoomService.CreateMeetingAsync(
                request: zoomRequest,
                zoomCode: lesson.ProviderConnect,
                cancellationToken: cancellationToken
            );

            if (zoomMeeting != null && !string.IsNullOrEmpty(zoomMeeting.JoinUrl))
            {
                // Cập nhật lesson với link vừa tạo
                lesson.JoinUrl = zoomMeeting.JoinUrl;
                lesson.ProviderMeetingId = zoomMeeting.Id.ToString();
                lesson.JoinMeetingId = zoomMeeting.ZoomRoomId.ToString();
                lesson.JoinMeetingPassword = zoomMeeting.RoomPassword;
                lesson.JoinCoHostUrl = zoomMeeting.StartUrl;
                lesson.JoinUrlActive = true;
                lesson.MeetLinkDeleted = false;
                await _writeRepository.UpdateAsync(lesson);

                //thêm PartnerOneZoomEntity
                var partnerOneZoomEntity = new PartnerOneZoomMeetingEntity
                {
                    LessonMeetingId = lesson.Id,
                    ZoomRoomId = zoomMeeting.ZoomRoomId,
                    JoinUrl = zoomMeeting.JoinUrl,
                    StartUrl = zoomMeeting.StartUrl,
                    RoomPassword = zoomMeeting.RoomPassword,
                    CreateAt = DateTime.UtcNow,
                    ProviderConnect = lesson.ProviderConnect,
                    Agenda = zoomMeeting.Agenda,
                    Topic = zoomMeeting.Topic,
                    DurationInMinute = zoomMeeting.DurationInMinute,
                    IsDeleted = false,
                    OneZoomId = zoomMeeting.Id,
                    Date = lesson.Date,
                    Status = zoomMeeting.Status,
                    EndAt = lesson.EndTime,
                    TenantId = lesson.TenantId,
                };
                await _partnerOneZoomRepository.InsertAsync(partnerOneZoomEntity);

            }
            else
            {
                throw new Exception($"JobCreateLinkZoom {lesson.Id}: Failed to create Zoom meeting. No join URL returned.");
            }
        }
    }
}
