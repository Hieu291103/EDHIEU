using DS.Module.OnlineClass.Application.Commands.PartnerOneZoomMeetingEntitys;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    /// <summary>
    /// Handler để kết thúc buổi học trực tuyến (Lesson Meeting)
    /// - Chỉ người tạo buổi học mới có thể kết thúc
    /// - Cập nhật thời gian kết thúc thực tế (ActualEndTime)
    /// - Đổi trạng thái thành Ended
    /// </summary>
    public class EndLessonMeetingCommandHandler : ICommandHandler<EndLessonMeetingCommand, bool>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _readRepository;
        private readonly ISchoolCommonWriteRepository<LessonMeetingEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<LessonParticipantEntity> _participantReadRepository;
        private readonly ISchoolCommonWriteRepository<LessonParticipantEntity> _participantWriteRepository;
        private readonly IMediator _mediator;

        public EndLessonMeetingCommandHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> readRepository,
            ISchoolCommonWriteRepository<LessonMeetingEntity> writeRepository,
            ISchoolCommonReadRepository<LessonParticipantEntity> participantReadRepository,
            ISchoolCommonWriteRepository<LessonParticipantEntity> participantWriteRepository,
            IMediator mediator)
        {
            _readRepository = readRepository;
            _writeRepository = writeRepository;
            _participantReadRepository = participantReadRepository;
            _participantWriteRepository = participantWriteRepository;
            _mediator = mediator;
        }

        public async Task<bool> Handle(EndLessonMeetingCommand request, CancellationToken cancellationToken)
        {
            // Lấy thông tin buổi học
            var lessonMeetings = await _readRepository.FilterAsync(
                x => x.Id == request.Id,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (lessonMeetings == null || !lessonMeetings.Any())
                throw new DSException("LessonMeetingNotFound");

            var lessonMeeting = lessonMeetings.FirstOrDefault();

            if (lessonMeeting == null)
                throw new DSException("LessonMeetingNotFound");

            // Kiểm tra xem người dùng có phải là người tạo buổi học không
            if (lessonMeeting.UserId != request.UserId)
                throw new DSException("UnauthorizedToEndLessonMeeting");

            // Kiểm tra trạng thái buổi học (chỉ có thể kết thúc khi đang diễn ra hoặc chưa bắt đầu)
            if (lessonMeeting.Status == MeetingStatus.Ended)
                throw new DSException("LessonMeetingAlreadyEnded");

            if (lessonMeeting.Status == MeetingStatus.Cancelled)
                throw new DSException("LessonMeetingCannotEndCancelled");

            // Cập nhật thời gian kết thúc thực tế
            lessonMeeting.ActualEndTime = DateTime.UtcNow;

            // Cập nhật trạng thái thành Ended
            lessonMeeting.Status = MeetingStatus.Ended;

            // Vô hiệu hóa link tham gia khi buổi học kết thúc
            lessonMeeting.JoinUrlActive = false;

            // Lưu thay đổi
            await _writeRepository.UpdateAsync(lessonMeeting);

            //Cập nhật thời gian trong bảng điểm danh
            await _participantWriteRepository.UpdateManyAsync(
                x => x.LessonMeetingId == lessonMeeting.Id,
                Builders<LessonParticipantEntity>.Update.Set(x => x.LeaveTime, DateTime.UtcNow),
                tenantId: null,
                cancellationToken: cancellationToken);
            //xóa link zoom
            if (lessonMeeting.ProviderMeetingType == ProviderMeetingType.Zoom)
            {
                await _mediator.Send(new DeleteOneZoomMeetingCommand { LessonMeetingId = lessonMeeting.Id }, cancellationToken);
            }

            return true;
        }
    }
}
