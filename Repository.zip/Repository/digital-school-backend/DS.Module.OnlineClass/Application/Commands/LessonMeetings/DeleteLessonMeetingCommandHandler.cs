using DS.Module.OnlineClass.Application.Commands.LessonParticipantEntitys;
using DS.Module.OnlineClass.Application.Commands.PartnerOneZoomMeetingEntitys;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    /// <summary>
    /// Handler để xóa buổi học trực tuyến (Lesson Meeting) vĩnh viễn
    /// - Xóa meeting trên MS Teams (nếu có)
    /// - Xóa bản ghi từ database
    /// </summary>
    public class DeleteLessonMeetingCommandHandler : ICommandHandler<DeleteLessonMeetingCommand, Result>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _lessonMeetingReadRepository;
        private readonly ISchoolCommonWriteRepository<LessonMeetingEntity> _lessonMeetingWriteRepository;
        private readonly IMSTeamsService _msTeamsService;
        private readonly ILogger<DeleteLessonMeetingCommandHandler> _logger;
        private readonly IMediator _mediator;

        public DeleteLessonMeetingCommandHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> lessonMeetingReadRepository,
            ISchoolCommonWriteRepository<LessonMeetingEntity> lessonMeetingWriteRepository,
            IMSTeamsService msTeamsService,
            ILogger<DeleteLessonMeetingCommandHandler> logger,
            IMediator mediator
            )
        {
            _lessonMeetingReadRepository = lessonMeetingReadRepository;
            _lessonMeetingWriteRepository = lessonMeetingWriteRepository;
            _msTeamsService = msTeamsService;
            _logger = logger;
            _mediator = mediator;
        }

        public async Task<Result> Handle(DeleteLessonMeetingCommand request, CancellationToken cancellationToken)
        {
            var lessonMeetings = await _lessonMeetingReadRepository.FilterAsync(
               x => x.Id == request.Id);

            var lessonMeeting = lessonMeetings.FirstOrDefault(x => x.Id == request.Id);

            if (lessonMeeting is null)
            {
                throw new DSException("LessonMeetingNotFound");
            }

            if (lessonMeeting.ProviderMeetingType == Domain.Enums.ProviderMeetingType.Teams)
            {
                // Nếu meeting đã được tạo trên MS Teams, hãy xóa nó
                if (!string.IsNullOrEmpty(lessonMeeting.ProviderMeetingId) &&
                    !string.IsNullOrEmpty(lessonMeeting.ProviderConnect) &&
                    !string.IsNullOrEmpty(lessonMeeting.MeetUserId))
                {
                    try
                    {
                        await _msTeamsService.DeleteMeetingAsync(
                            lessonMeeting.ProviderConnect,
                            lessonMeeting.MeetUserId,
                            lessonMeeting.ProviderMeetingId);
                    }
                    catch (Exception ex)
                    {
                        // Log lỗi nhưng vẫn tiếp tục xóa từ database
                        _logger.LogError(ex, "Lỗi khi xóa meeting trên MS Teams cho LessonMeetingId: {LessonMeetingId}", lessonMeeting.Id);
                    }
                }
            }
            else if (lessonMeeting.ProviderMeetingType == Domain.Enums.ProviderMeetingType.Zoom)
            {
                // Nếu meeting đã được tạo trên Zoom, hãy gửi command để xóa nó
                await _mediator.Send(new DeleteOneZoomMeetingCommand
                {
                    LessonMeetingId = lessonMeeting.Id
                }, cancellationToken);
            }

            // xóa điểm danh
            await _mediator.Send(new DeleteLessonParticipantCommand
            {
                LessonMeetingId = lessonMeeting.Id
            }, cancellationToken);

            // Xóa vĩnh viễn từ database
            await _lessonMeetingWriteRepository.DeleteAsync(lessonMeeting.Id);

            return Result.Success();
        }
    }
}
