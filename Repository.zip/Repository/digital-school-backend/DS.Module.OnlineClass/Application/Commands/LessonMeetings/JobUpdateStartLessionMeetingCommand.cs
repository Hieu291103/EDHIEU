using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    public class JobUpdateStartLessionMeetingCommand : ICommand<bool>
    {
    }
}
