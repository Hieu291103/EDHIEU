using DS.Module.OnlineClass.Domain.Constants;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    /// <summary>
    /// Command để tạo buổi học trực tuyến (Lesson Meeting)
    /// Tự động lấy thông tin lớp học từ ClassId
    /// </summary>
    public class CreateLessonMeetingCommand : ICommand<Result>
    {

        /// <summary>
        /// Mô tả buổi học
        /// </summary>
        public string? Description { get; set; }

        /// <summary>
        /// Thời gian bắt đầu buổi học
        /// </summary>
        public required DateTime StartTime { get; set; }

        /// <summary>
        /// Thời gian kết thúc buổi học
        /// </summary>
        public required DateTime EndTime { get; set; }

        /// <summary>
        /// ID của trường (SchoolId)
        /// </summary>
        public required int SchoolId { get; set; }

        /// <summary>
        /// Năm học
        /// </summary>
        public int? SchoolYear { get; set; }

        /// <summary>
        /// Tiết học
        /// </summary>
        public LessonPeriod? LessonPeriod { get; set; }

        /// <summary>
        /// ID của lớp học
        /// </summary>
        public required string ClassId { get; set; }

        /// <summary>
        /// Mã môn dạy
        /// </summary>
        public string? Subject { get; set; }

        /// <summary>
        /// Tên môn dạy
        /// </summary>
        public string? SubjectName { get; set; }

        /// <summary>
        /// ID của người tạo buổi học (Onluyen)
        /// </summary>
        public required string UserId { get; set; }

        /// <summary>
        /// Tên đầy đủ của người tạo buổi học
        /// </summary>
        public required string FullName { get; set; }

        /// <summary>
        /// Múi giờ của buổi học (nếu có)
        /// </summary>
        public string? TimeZone { get; set; } = DatetimeHelper.DefaultTimeZone;

        /// <summary>
        /// Có cho phép ghi lại buổi học không  
        /// </summary>
        //public bool AllowRecording { get; set; } = false;
    }
}
