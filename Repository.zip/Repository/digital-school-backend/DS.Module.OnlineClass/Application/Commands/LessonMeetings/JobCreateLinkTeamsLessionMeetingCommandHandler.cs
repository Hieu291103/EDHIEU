using DS.Module.OnlineClass.Application.Commands.LessonParticipantEntitys;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Module.OnlineClass.Infrastructure.Configuration;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DS.Module.OnlineClass.Application.Commands.LessonMeetings
{
    public class JobCreateLinkTeamsLessionMeetingCommandHandler : ICommandHandler<JobCreateLinkTeamsLessionMeetingCommand, bool>
    {
        private readonly ISchoolCommonWriteRepository<LessonMeetingEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _lessonReadRepository;
        private readonly ISchoolCommonReadRepository<AccountMeetingEntity> _accountRepository;
        private readonly IMSTeamsService _msTeamsService;
        private readonly IMediator _mediator;
        private readonly ILogger<JobCreateLinkTeamsLessionMeetingCommandHandler> _logger;
        private readonly OnlineClassSettings _settings;

        public JobCreateLinkTeamsLessionMeetingCommandHandler(
          ISchoolCommonWriteRepository<LessonMeetingEntity> writeRepository,
          ISchoolCommonReadRepository<LessonMeetingEntity> lessonReadRepository,
          ISchoolCommonReadRepository<OnlineClassTenantClassEntity> classRepository,
          ISchoolCommonReadRepository<OnlineClassTenantEntity> tenantRepository,
          ISchoolCommonReadRepository<AccountMeetingEntity> accountRepository,
          IMSTeamsService mSTeamsService,
          IOneZoomService oneZoomService,
          IMediator mediator,
          ILogger<JobCreateLinkTeamsLessionMeetingCommandHandler> logger,
          IOptions<OnlineClassSettings> settings)

        {
            _writeRepository = writeRepository;
            _lessonReadRepository = lessonReadRepository;
            _accountRepository = accountRepository;
            _msTeamsService = mSTeamsService;
            _mediator = mediator;
            _logger = logger;
            _settings = settings.Value;
        }

        public async Task<bool> Handle(JobCreateLinkTeamsLessionMeetingCommand request, CancellationToken cancellationToken)
        {
            try
            {

                var currentTime = request.CurrentDateTime ?? DateTime.UtcNow;
                var targetTime = currentTime.AddMinutes(_settings.Setting.TeamsCreationBeforeStartTimeMinutes);

                // Lấy danh sách các buổi meeting Teams cần tạo link
                var teamsLessons = await GetTeamsLessonsNeedingLinkAsync(currentTime, targetTime, cancellationToken);

                var participantTasks = new List<Task>();

                foreach (var lesson in teamsLessons)
                {
                    try
                    {
                        // Kiểm tra idempotency: nếu đã có JoinUrl thì skip
                        if (!string.IsNullOrEmpty(lesson.JoinUrl))
                        {
                            continue;
                        }

                        await CreateTeamsLinkForLessonAsync(lesson, cancellationToken);
                        participantTasks.Add(_mediator.Send(new JobCreateLessonParticipantForClassCommand()
                        {
                            ClassId = lesson.ClassId,
                            LessonMeetingId = lesson.Id,
                            TenantId = lesson.TenantId,
                            SchoolId = lesson.SchoolId,
                            SchoolYear = lesson.SchoolYear,
                        }, cancellationToken).ContinueWith(t =>
                        {
                            if (t.IsFaulted)
                                _logger.LogError($"JobCreateLessonParticipant {lesson.Id}: {t.Exception?.GetBaseException().Message}");
                        }, TaskScheduler.Default));
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError($"JobCreateLinkTeams {lesson.Id}: {ex.Message}");
                    }
                }

                await Task.WhenAll(participantTasks);
                return true;
            }
            catch (OperationCanceledException)
            {
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError($"{ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Lấy danh sách các buổi meeting Teams cần tạo link (khởi động 15 phút trước giờ bắt đầu)
        /// </summary>
        private async Task<List<LessonMeetingEntity>> GetTeamsLessonsNeedingLinkAsync(DateTime currentTime, DateTime targetTime, CancellationToken cancellationToken)
        {
            // Query các buổi meeting:
            // - Nhà cung cấp là Teams
            // - JoinUrl chưa được tạo
            // - Thời gian bắt đầu từ currentTime đến targetTime (15 phút)
            var lessons = await _lessonReadRepository.FilterAsync(
                x => x.ProviderMeetingType == ProviderMeetingType.Teams && x.JoinUrlActive == false &&
                  (x.Status == MeetingStatus.NotStarted || x.Status == MeetingStatus.Active) &&
                     x.StartTime >= currentTime &&
                     x.StartTime <= targetTime,
                cancellationToken: cancellationToken
            );

            return lessons?.ToList() ?? new List<LessonMeetingEntity>();
        }

        /// <summary>
        /// Tạo Teams link cho một buổi meeting
        /// </summary>
        private async Task CreateTeamsLinkForLessonAsync(LessonMeetingEntity lesson, CancellationToken cancellationToken)
        {
            // Lấy thông tin tài khoản Teams từ ProviderConnect
            if (string.IsNullOrEmpty(lesson.ProviderConnect))
            {
                throw new InvalidOperationException($"Lesson {lesson.Id} does not have a provider connect configured");
            }

            if (lesson.MeetUserId.IsNullOrEmpty())
            {
                var accountsResult = await _accountRepository.FilterAsync(
                      x => x.TenantId == lesson.TenantId && x.UserId == lesson.UserId && x.MeetRegPolicy == true,
                      cancellationToken: cancellationToken);

                var accountMeeting = accountsResult?.FirstOrDefault();

                if (accountMeeting == null)
                {
                    throw new Exception($"JobCreateLinkTeams {lesson.Id}: Account meeting not found for provider connect: {lesson.ProviderConnect}");
                }

                if (string.IsNullOrEmpty(accountMeeting.MeetUserId) || string.IsNullOrEmpty(accountMeeting.MeetEmail))
                {
                    throw new Exception($"JobCreateLinkTeams {lesson.Id}: Account meeting {accountMeeting.Id} is missing UserId or MeetEmail");
                }

                lesson.MeetUserId = accountMeeting.MeetUserId;
            }

            // Tính toán thời gian kết thúc (nếu không có thì lấy từ bắt đầu cộng 1 giờ)
            var endTime = lesson.EndTime ?? lesson.StartTime?.AddHours(1) ?? DateTime.UtcNow.AddHours(1);

            // Tạo cuộc họp Teams - sử dụng ProviderConnect như teamsCode
            var graphMeeting = await _msTeamsService.CreateMeetingAsync(
                teamsCode: lesson.ProviderConnect,
                userId: lesson.MeetUserId!,
                subject: lesson.Title ?? lesson.ClassName + " - " + lesson.SubjectName + " - " + lesson.FullName,
                startDateTime: lesson.StartTime ?? DateTime.UtcNow,
                endDateTime: endTime,
                description: lesson.Description,
                cancellationToken: cancellationToken
            );

            if (graphMeeting != null && !string.IsNullOrEmpty(graphMeeting.JoinWebUrl))
            {
                // Cập nhật lesson với link vừa tạo
                lesson.JoinCoHostUrl = graphMeeting.JoinWebUrl;
                lesson.JoinUrl = graphMeeting.JoinWebUrl;
                lesson.ProviderMeetingId = graphMeeting.Id;
                lesson.JoinMeetingId = graphMeeting.JoinMeetingIdSettings?.JoinMeetingId;
                lesson.JoinMeetingPassword = graphMeeting.JoinMeetingIdSettings?.Passcode;
                lesson.JoinUrlActive = true;
                lesson.AllowRecording = graphMeeting.AllowRecording ?? false;
                lesson.MeetLinkDeleted = false;
                await _writeRepository.UpdateAsync(lesson);
            }
            else
            {
                throw new Exception($"JobCreateLinkTeams {lesson.Id}: Failed to create Teams meeting. No join URL returned.");
            }
        }
    }
}
