using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Commands.PartnerOneZoomMeetingEntitys
{
    public class DeleteOneZoomMeetingCommand : ICommand<bool>
    {
        public string LessonMeetingId { get; set; } = string.Empty;
    }
}
