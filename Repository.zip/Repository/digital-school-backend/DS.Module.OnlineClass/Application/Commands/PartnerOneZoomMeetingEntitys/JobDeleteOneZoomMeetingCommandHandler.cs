using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Application.Commands.PartnerOneZoomMeetingEntitys
{
    public class JobDeleteOneZoomMeetingCommandHandler : ICommandHandler<JobDeleteOneZoomMeetingCommand, bool>
    {
        private readonly ISchoolCommonReadRepository<PartnerOneZoomMeetingEntity> _readRepository;
        private readonly IMediator _mediator;
        private readonly ILogger<JobDeleteOneZoomMeetingCommandHandler> _logger;

        public JobDeleteOneZoomMeetingCommandHandler(
            ISchoolCommonReadRepository<PartnerOneZoomMeetingEntity> readRepository,
            IMediator mediator,
            ILogger<JobDeleteOneZoomMeetingCommandHandler> logger)
        {
            _readRepository = readRepository;
            _mediator = mediator;
            _logger = logger;
        }

        public async Task<bool> Handle(JobDeleteOneZoomMeetingCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var threshold = DateTime.UtcNow.AddMinutes(-1);

                // Lấy các meeting chưa xóa và đã quá thời hạn kết thúc 1 phút
                var meetings = await _readRepository.FilterAsync(
                    x => x.IsDeleted != true &&
                         x.EndAt != null &&
                         x.EndAt <= threshold,
                    cancellationToken: cancellationToken);

                if (meetings == null || !meetings.Any())
                    return true;

                // Group theo LessonMeetingId để gửi từng DeleteOneZoomMeetingCommand
                var lessonMeetingIds = meetings
                    .Where(x => !string.IsNullOrEmpty(x.LessonMeetingId))
                    .Select(x => x.LessonMeetingId!)
                    .Distinct();

                foreach (var lessonMeetingId in lessonMeetingIds)
                {
                    try
                    {
                        await _mediator.Send(new DeleteOneZoomMeetingCommand
                        {
                            LessonMeetingId = lessonMeetingId
                        }, cancellationToken);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "JobDeleteOneZoomMeeting LessonMeetingId {LessonMeetingId}: {Message}", lessonMeetingId, ex.Message);
                    }
                }

                return true;
            }
            catch (OperationCanceledException)
            {
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "JobDeleteOneZoomMeeting failed: {Message}", ex.Message);
                return false;
            }
        }
    }
}
