using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Application.Commands.PartnerOneZoomMeetingEntitys
{
    public class DeleteOneZoomMeetingCommandHandler : ICommandHandler<DeleteOneZoomMeetingCommand, bool>
    {
        private readonly ISchoolCommonReadRepository<PartnerOneZoomMeetingEntity> _readRepository;
        private readonly ISchoolCommonWriteRepository<PartnerOneZoomMeetingEntity> _writeRepository;
        private readonly ILogger<DeleteOneZoomMeetingCommandHandler> _logger;
        private readonly IOneZoomService _oneZoomService;

        public DeleteOneZoomMeetingCommandHandler(
            ISchoolCommonReadRepository<PartnerOneZoomMeetingEntity> readRepository,
            ISchoolCommonWriteRepository<PartnerOneZoomMeetingEntity> writeRepository,
            IOneZoomService oneZoomService,
            ILogger<DeleteOneZoomMeetingCommandHandler> logger)
        {
            _readRepository = readRepository;
            _writeRepository = writeRepository;
            _oneZoomService = oneZoomService;
            _logger = logger;
        }

        public async Task<bool> Handle(DeleteOneZoomMeetingCommand request, CancellationToken cancellationToken)
        {
            var meetings = await _readRepository.FilterAsync(
                x => x.LessonMeetingId == request.LessonMeetingId && x.IsDeleted != true,
                cancellationToken: cancellationToken);

            if (meetings == null || !meetings.Any())
                return true;
            var meeting = meetings.First();
            try
            {
                var result = await _oneZoomService.DeleteMeetingAsync(meeting.OneZoomId, meeting.ProviderConnect);
                if (result == true)
                {
                    meeting.IsDeleted = true;
                    meeting.DeleteAt = DateTime.UtcNow;
                    await _writeRepository.UpdateAsync(meeting, cancellationToken: cancellationToken);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteOneZoomMeeting {MeetingId}: {Message}", meeting.Id, ex.Message);
            }

            return true;
        }
    }
}
