using DS.Shared.Core.Application.Abstractions.CQRS;

namespace DS.Module.OnlineClass.Application.Commands.PartnerOneZoomMeetingEntitys
{
    public class JobDeleteOneZoomMeetingCommand : ICommand<bool>
    {
    }
}
