using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MediatR;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Application.Commands.PartnerOneZoomMeetingEntitys
{
    public class DeleteOneZoomMeetingAndLessionMeetingCommandHandler : ICommandHandler<DeleteOneZoomMeetingAndLessionMeetingCommand, bool>
    {
        private readonly ISchoolCommonReadRepository<LessonMeetingEntity> _readLessonMeetingRepository;
        private readonly ISchoolCommonWriteRepository<LessonMeetingEntity> _writeLessonMeetingRepository;
        private readonly ILogger<DeleteOneZoomMeetingAndLessionMeetingCommandHandler> _logger;
        private readonly IMediator _mediator;
        public DeleteOneZoomMeetingAndLessionMeetingCommandHandler(
            ISchoolCommonReadRepository<LessonMeetingEntity> readLessonMeetingRepository,
            ISchoolCommonWriteRepository<LessonMeetingEntity> writeLessonMeetingRepository,
            ILogger<DeleteOneZoomMeetingAndLessionMeetingCommandHandler> logger,
            IMediator mediator)
        {
            _readLessonMeetingRepository = readLessonMeetingRepository;
            _writeLessonMeetingRepository = writeLessonMeetingRepository;
            _logger = logger;
            _mediator = mediator;
        }
        public async Task<bool> Handle(DeleteOneZoomMeetingAndLessionMeetingCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var lessonMeeting = await _readLessonMeetingRepository.GetByIdAsync(request.LessonMeetingId);
                if (lessonMeeting == null)
                {
                    return false;
                }
                //xóa OneZoomMeetingEntity
                var deleteResult = await _mediator.Send(new DeleteOneZoomMeetingCommand { LessonMeetingId = lessonMeeting.Id });
                if (deleteResult)
                {
                    lessonMeeting.Status = Domain.Enums.MeetingStatus.Ended;
                    lessonMeeting.JoinUrlActive = false;
                    lessonMeeting.ActualEndTime = DateTime.UtcNow;
                    await _writeLessonMeetingRepository.UpdateAsync(lessonMeeting);
                }

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting OneZoomMeeting and LessonMeeting with ID {LessonMeetingId}", request.LessonMeetingId);
                return false;
            }
        }
    }
}
