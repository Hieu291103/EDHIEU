using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Commands.AccountMeetings
{
    /// <summary>
    /// Command để đăng ký Teams Policy cho người dùng
    /// </summary>
    public class RegTeamsAccountMeetingCommand : ICommand<Result>
    {
        /// <summary>
        /// Danh sách ID người dùng
        /// </summary>
        public required List<string> UserIds { get; set; }

        /// <summary>
        /// TenantId
        /// </summary>
        public required string TenantId { get; set; }
    }
}
