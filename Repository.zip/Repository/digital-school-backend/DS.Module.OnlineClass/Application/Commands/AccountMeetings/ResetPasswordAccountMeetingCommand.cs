using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Commands.AccountMeetings
{
    /// <summary>
    /// Command để đặt lại mật khẩu tài khoản cuộc họp
    /// Sinh mật khẩu mới và cập nhật vào MSTeams
    /// </summary>
    public class ResetPasswordAccountMeetingCommand : ICommand<Result>
    {
        /// <summary>
        /// Id của người dùng
        /// </summary>
        public required string UserId { get; set; }

        /// <summary>
        /// TenantId
        /// </summary>
        public required string TenantId { get; set; }
    }
}
