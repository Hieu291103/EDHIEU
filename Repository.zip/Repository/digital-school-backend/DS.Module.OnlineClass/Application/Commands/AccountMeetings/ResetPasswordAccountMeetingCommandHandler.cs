using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Commands.AccountMeetings
{
    /// <summary>
    /// Handler cho ResetPasswordAccountMeetingCommand
    /// Đặt lại mật khẩu tài khoản cuộc họp trên MSTeams
    /// </summary>
    public class ResetPasswordAccountMeetingCommandHandler : ICommandHandler<ResetPasswordAccountMeetingCommand, Result>
    {
        private readonly ISchoolCommonWriteRepository<AccountMeetingEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<AccountMeetingEntity> _readRepository;
        private readonly IMSTeamsService _msTeamsService;

        public ResetPasswordAccountMeetingCommandHandler(
            ISchoolCommonWriteRepository<AccountMeetingEntity> writeRepository,
            ISchoolCommonReadRepository<AccountMeetingEntity> readRepository,
            IMSTeamsService msTeamsService)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _msTeamsService = msTeamsService;
        }

        public async Task<Result> Handle(ResetPasswordAccountMeetingCommand request, CancellationToken cancellationToken)
        {
            // Tìm AccountMeeting theo UserId và TenantId
            var filterBuilder = Builders<AccountMeetingEntity>.Filter;
            var filter = filterBuilder.And(
                filterBuilder.Eq(x => x.UserId, request.UserId),
                filterBuilder.Eq(x => x.TenantId, request.TenantId),
                filterBuilder.Eq(x => x.AccountMeetingType, AccountMeetingType.Teacher)
            );

            var existingAccountMeetings = await _readRepository.FilterAsync(
                filter,
                tenantId: null,
                cancellationToken: cancellationToken);

            var existingAccountMeeting = existingAccountMeetings.FirstOrDefault();

            if (existingAccountMeeting == null)
            {
                throw DSException.WithParam("AccountMeetingNotFound", request.UserId);
            }

            if (string.IsNullOrEmpty(existingAccountMeeting.MeetUserId) ||
                string.IsNullOrEmpty(existingAccountMeeting.ProviderConnect))
            {
                throw new DSException("OnlineClassTenantProviderConnectRequired");
            }

            // Sinh mật khẩu mới
            var newPassword = GenCodeRandomHelper.LettersAndDigits(8) + "@";

            // Đổi mật khẩu trên MSTeams
            var resetResult = await _msTeamsService.ChangeUserPasswordAsync(
                existingAccountMeeting.ProviderConnect,
                existingAccountMeeting.MeetUserId,
                newPassword,
                cancellationToken: cancellationToken);

            if (!resetResult)
            {
                throw DSException.WithParam("ResetPasswordAccountMeetingFailed",
                    existingAccountMeeting.UserName ?? request.UserId);
            }

            // Cập nhật mật khẩu trong database (encrypted)
            existingAccountMeeting.MeetPassword = CryptoHelper.AESEncrypt(
                newPassword,
                existingAccountMeeting.MeetEmail!);

            await _writeRepository.UpdateAsync(existingAccountMeeting);

            return Result.Success();
        }
    }
}
