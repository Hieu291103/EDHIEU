using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Commands.AccountMeetings
{
    /// <summary>
    /// Command để xóa AccountMeeting
    /// </summary>
    public class DeleteAccountMeetingCommand : ICommand<Result>
    {
        /// <summary>
        /// Id của AccountMeeting
        /// </summary>
        public required List<string> UserId { get; set; }

        /// <summary>
        /// TenantId
        /// </summary>
        public required string TenantId { get; set; }
    }
}
