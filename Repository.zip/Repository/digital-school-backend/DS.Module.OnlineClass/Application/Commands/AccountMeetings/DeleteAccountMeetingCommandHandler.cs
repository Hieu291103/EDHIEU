using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Commands.AccountMeetings
{
    /// <summary>
    /// Handler cho DeleteAccountMeetingCommand
    /// Xóa AccountMeeting theo UserId và TenantId, cả ở database và MSTeams
    /// </summary>
    public class DeleteAccountMeetingCommandHandler : ICommandHandler<DeleteAccountMeetingCommand, Result>
    {
        private readonly ISchoolCommonWriteRepository<AccountMeetingEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<AccountMeetingEntity> _readRepository;
        private readonly IMSTeamsService _msTeamsService;

        public DeleteAccountMeetingCommandHandler(
            ISchoolCommonWriteRepository<AccountMeetingEntity> writeRepository,
            ISchoolCommonReadRepository<AccountMeetingEntity> readRepository,
            IMSTeamsService msTeamsService)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _msTeamsService = msTeamsService;
        }

        public async Task<Result> Handle(DeleteAccountMeetingCommand request, CancellationToken cancellationToken)
        {
            if (!request.UserId.Any())
            {
                throw new DSException("ParticipantListEmpty");
            }

            foreach (var userId in request.UserId)
            {
                // Tìm AccountMeeting theo UserId và TenantId
                var filterBuilder = Builders<AccountMeetingEntity>.Filter;
                var filter = filterBuilder.And(
                    filterBuilder.Eq(x => x.UserId, userId),
                    filterBuilder.Eq(x => x.TenantId, request.TenantId),
                    filterBuilder.Eq(x => x.AccountMeetingType, AccountMeetingType.Teacher)
                );

                var existingAccountMeetings = await _readRepository.FilterAsync(filter, tenantId: null, cancellationToken: cancellationToken);
                var existingAccountMeeting = existingAccountMeetings.FirstOrDefault();

                if (existingAccountMeeting == null)
                {
                    return Result.Success();
                }

                // Xóa tài khoản trên MSTeams
                if (!string.IsNullOrEmpty(existingAccountMeeting.MeetUserId) && !string.IsNullOrEmpty(existingAccountMeeting.ProviderConnect))
                {
                    var deleteResult = await _msTeamsService.DeleteUserAccountAsync(
                        existingAccountMeeting.ProviderConnect,
                        existingAccountMeeting.MeetUserId,
                        cancellationToken);

                    if (!deleteResult)
                    {
                        throw DSException.WithParam("DeleteAccountMeetingFailed", existingAccountMeeting.UserName ?? userId);
                    }
                }

                // Xóa AccountMeeting ở database
                await _writeRepository.DeleteAsync(existingAccountMeeting.Id, tenantId: request.TenantId, cancellationToken: cancellationToken);
            }

            return Result.Success();
        }
    }
}
