using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Commands.AccountMeetings
{
    /// <summary>
    /// Handler cho RegTeamsAccountMeetingCommand
    /// Lấy danh sách MeetEmail từ AccountMeetingEntity và gọi Teams Policy Service để đăng ký policy
    /// Sau đó cập nhật flag MeetRegPolicy = true cho các tài khoản đã đăng ký thành công
    /// </summary>
    public class RegTeamsAccountMeetingCommandHandler : ICommandHandler<RegTeamsAccountMeetingCommand, Result>
    {
        private readonly IMSTeamPolicyService _msteamPolicyService;
        private readonly ISchoolCommonWriteRepository<AccountMeetingEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<AccountMeetingEntity> _readRepository;

        public RegTeamsAccountMeetingCommandHandler(
            IMSTeamPolicyService msteamPolicyService,
            ISchoolCommonWriteRepository<AccountMeetingEntity> writeRepository,
            ISchoolCommonReadRepository<AccountMeetingEntity> readRepository)
        {
            _msteamPolicyService = msteamPolicyService ?? throw new ArgumentNullException(nameof(msteamPolicyService));
            _writeRepository = writeRepository ?? throw new ArgumentNullException(nameof(writeRepository));
            _readRepository = readRepository ?? throw new ArgumentNullException(nameof(readRepository));
        }

        public async Task<Result> Handle(RegTeamsAccountMeetingCommand request, CancellationToken cancellationToken)
        {
            if (request.UserIds == null || request.UserIds.Count == 0)
            {
                throw new DSException("ParticipantListEmpty");
            }

            if (request.UserIds.Count > 30)
            {
                throw new DSException("MeetingUserIdsLimitExceeded");
            }

            if (string.IsNullOrWhiteSpace(request.TenantId))
            {
                throw new DSException("TenantIdRequired");
            }

            // Lấy danh sách AccountMeetingEntity từ UserId và TenantId
            var filterBuilder = Builders<AccountMeetingEntity>.Filter;
            var userIdFilter = filterBuilder.In(x => x.UserId, request.UserIds);
            var tenantIdFilter = filterBuilder.Eq(x => x.TenantId, request.TenantId);
            var filter = filterBuilder.And(userIdFilter, tenantIdFilter);

            var accountMeetings = await _readRepository.FilterAsync(
                filter,
                tenantId: null,
                cancellationToken: cancellationToken);

            if (!accountMeetings.Any())
            {
                throw new DSException("NoAccountMeetingFound");
            }

            // Lấy danh sách MeetEmail từ AccountMeetingEntity
            var meetEmails = accountMeetings
                .Where(x => !string.IsNullOrWhiteSpace(x.MeetEmail))
                .Select(x => x.MeetEmail!)
                .ToList();

            if (meetEmails.Count == 0)
            {
                throw new DSException("NoValidMeetEmailsFound");
            }

            // Gọi MSTeamPolicyService để đăng ký policy
            var result = await _msteamPolicyService.AssignPolicyAsync(meetEmails, cancellationToken);

            if (!result.Success)
            {
                throw DSException.WithParam("RegTeamsAccountMeetingFailed", result.Error ?? "Unknown error");
            }

            // Cập nhật flag MeetRegPolicy = true cho những tài khoản đã đăng ký policy thành công
            if (result.Data != null && result.Data.Any())
            {
                foreach (var policyItem in result.Data)
                {
                    if (!string.IsNullOrWhiteSpace(policyItem.User) && policyItem.Status == "success")
                    {
                        // Tìm AccountMeeting có MeetEmail trùng với policyItem.User
                        var accountMeeting = accountMeetings.FirstOrDefault(x => x.MeetEmail == policyItem.User);

                        if (accountMeeting != null)
                        {
                            accountMeeting.MeetRegPolicy = true;
                            await _writeRepository.UpdateAsync(accountMeeting);
                        }
                    }
                }
            }

            return Result.Success();
        }
    }
}
