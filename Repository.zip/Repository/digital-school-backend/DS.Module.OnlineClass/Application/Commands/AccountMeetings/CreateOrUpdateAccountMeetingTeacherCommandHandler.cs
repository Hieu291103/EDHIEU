using DS.Module.OnlineClass.Application.DTOs;
using DS.Module.OnlineClass.Application.Queries.AccountMeetings;
using DS.Module.OnlineClass.Domain.Entities;
using DS.Module.OnlineClass.Domain.Enums;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Common.Helpers;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.Core.Infrastructure.Services.Onluyen;
using MediatR;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Commands.AccountMeetings
{
    /// <summary>
    /// Handler cho CreateOrUpdateAccountMeetingCommand
    /// Tìm AccountMeeting theo UserId + TenantId, nếu có thì update, không có thì tạo mới
    /// </summary>
    public class CreateOrUpdateAccountMeetingTeacherCommandHandler : ICommandHandler<CreateOrUpdateAccountMeetingTeacherCommand, Result>
    {
        private readonly ISchoolCommonWriteRepository<AccountMeetingEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<AccountMeetingEntity> _readRepository;
        private readonly ISchoolCommonReadRepository<OnlineClassTenantEntity> _onlineClassTenantEntityRepository;
        private readonly IMediator _mediator;
        private readonly IOnluyenService _onluyenService;
        private readonly IMSTeamsService _msTeamsService;

        public CreateOrUpdateAccountMeetingTeacherCommandHandler(
            ISchoolCommonWriteRepository<AccountMeetingEntity> writeRepository,
            ISchoolCommonReadRepository<AccountMeetingEntity> readRepository,
            IMediator mediator,
                        IOnluyenService onluyenService,
                        IMSTeamsService msTeamsService,
                        ISchoolCommonReadRepository<OnlineClassTenantEntity> onlineClassTenantEntityRepository
          )
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _mediator = mediator;
            _onluyenService = onluyenService;
            _msTeamsService = msTeamsService;
            _onlineClassTenantEntityRepository = onlineClassTenantEntityRepository;
        }

        public async Task<Result> Handle(CreateOrUpdateAccountMeetingTeacherCommand request, CancellationToken cancellationToken)
        {
            if (!request.UserId.Any())
            {
                throw new DSException("ParticipantListEmpty");
            }

            var filterBuilder = Builders<OnlineClassTenantEntity>.Filter;
            var filter = filterBuilder.Eq(x => x.TenantId, request.TenantId);
            var onlineClassTenants = await _onlineClassTenantEntityRepository.FilterAsync(filter, tenantId: null);
            var onlineClassTenant = onlineClassTenants.FirstOrDefault();

            if (onlineClassTenant == null)
            {
                throw new DSException("OnlineClassTenantNotFound");
            }

            if (string.IsNullOrEmpty(onlineClassTenant.ProviderConnect))
            {
                throw new DSException("OnlineClassTenantProviderConnectRequired");
            }

            var accountMeetings = await _mediator.Send(new GetAccountMeetingTeacherListQuery
            {
                TenantId = request.TenantId,
                SchoolYear = request.SchoolYear
            }, cancellationToken);

            //Kiểm tra nếu có UserId nào được truyền vào thì chỉ lấy những UserId đó, không có thì lấy tất cả
            if (request.UserId != null && request.UserId.Any())
            {
                accountMeetings = accountMeetings.Where(x => request.UserId.Contains(x.UserId!)).ToList();
            }
            accountMeetings = accountMeetings.Where(x => x.AccountMeetingType == AccountMeetingType.Teacher).ToList();

            foreach (var item in accountMeetings.Where(x => string.IsNullOrEmpty(x.MeetEmail)))
            {
                var password = PasswordHelper.GenPassword(10);
                var username = ExtractUsername(item.UserName, onlineClassTenant.SchoolId) ??
                               StringHelper.GenerateUsernameForSchool(item.FullName ?? item.UserName ?? "user", onlineClassTenant.SchoolId);

                var account = await _msTeamsService.CreateUserAccountWithGroupAsync(
                    onlineClassTenant.ProviderConnect,
                    username,
                    item.FullName ?? item.UserName ?? item.UserId ?? "Tài khoản",
                    password);

                if (account is null)
                {
                    throw DSException.WithParam("CreateAccountMeetingFailed", item.UserName ?? item.FullName ?? item.UserId ?? "Tài khoản");
                }

                await UpsertAccountMeetingAsync(item, account, onlineClassTenant, password, request.TenantId);
            }

            return Result.Success();
        }

        private string? ExtractUsername(string? userName, int? schoolId)
        {
            if (string.IsNullOrEmpty(userName)) return null;
            var atIndex = userName.IndexOf("@");
            return atIndex > 0 ? userName.Substring(0, atIndex) + $"-{schoolId}" : null;
        }

        private async Task UpsertAccountMeetingAsync(
            AccountMeetingDto item,
            DS.Module.OnlineClass.Infrastructure.Services.DTOs.GraphApi.GraphUser account,
            OnlineClassTenantEntity onlineClassTenant,
            string password,
            string tenantId)
        {
            var filterBuilder = Builders<AccountMeetingEntity>.Filter;
            var filter = filterBuilder.And(
                filterBuilder.Eq(x => x.UserId, item.UserId),
                filterBuilder.Eq(x => x.TenantId, tenantId)
            );

            var existingAccountMeetings = await _readRepository.FilterAsync(filter, tenantId: null);
            var existingAccountMeeting = existingAccountMeetings.FirstOrDefault();

            var accountMeetingData = new
            {
                UserName = item.UserName,
                FullName = item.FullName,
                MeetUserId = account.Id,
                MeetEmail = account.UserPrincipalName,
                ProviderConnect = onlineClassTenant.ProviderConnect,
                MeetPassword = CryptoHelper.AESEncrypt(password, account.UserPrincipalName!),
                SchoolId = onlineClassTenant.SchoolId,
                AccountMeetingType = AccountMeetingType.Teacher
            };

            if (existingAccountMeeting != null)
            {
                existingAccountMeeting.UserName = accountMeetingData.UserName;
                existingAccountMeeting.FullName = accountMeetingData.FullName;
                existingAccountMeeting.MeetUserId = accountMeetingData.MeetUserId;
                existingAccountMeeting.MeetEmail = accountMeetingData.MeetEmail;
                existingAccountMeeting.ProviderConnect = accountMeetingData.ProviderConnect;
                existingAccountMeeting.MeetPassword = accountMeetingData.MeetPassword;
                existingAccountMeeting.SchoolId = accountMeetingData.SchoolId;
                existingAccountMeeting.AccountMeetingType = accountMeetingData.AccountMeetingType;

                await _writeRepository.UpdateAsync(existingAccountMeeting);
            }
            else
            {
                var newAccountMeeting = new AccountMeetingEntity
                {
                    UserId = item.UserId,
                    UserName = accountMeetingData.UserName,
                    FullName = accountMeetingData.FullName,
                    MeetUserId = accountMeetingData.MeetUserId,
                    MeetEmail = accountMeetingData.MeetEmail,
                    ProviderConnect = accountMeetingData.ProviderConnect,
                    MeetPassword = accountMeetingData.MeetPassword,
                    TenantId = tenantId,
                    SchoolId = accountMeetingData.SchoolId,
                    AccountMeetingType = accountMeetingData.AccountMeetingType,
                    MeetRegPolicy = false
                };

                await _writeRepository.InsertAsync(newAccountMeeting);
            }
        }
    }
}
