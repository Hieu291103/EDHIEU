using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Commands.AccountMeetings
{
    /// <summary>
    /// Command để tạo hoặc cập nhật AccountMeeting
    /// Nếu UserId và TenantId đã tồn tại thì cập nhật, ngược lại tạo mới
    /// </summary>
    public class CreateOrUpdateAccountMeetingTeacherCommand : ICommand<Result>
    {
        /// <summary>
        /// Danh sách UserId
        /// </summary>
        public required List<string> UserId { get; set; }
        /// <summary>
        /// TenantId
        /// </summary>
        public required string TenantId { get; set; }
        /// <summary>
        /// Năm học để filter
        /// </summary>
        public int SchoolYear { get; set; } = 0;
    }
}
