using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;
using DS.Shared.Core.Infrastructure.Exceptions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Repositories;
using DS.Shared.Core.Infrastructure.Services.Onluyen;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Application.Commands.OnlineClassTenantClass
{
    /// <summary>
    /// Handler cho CreateOrUpdateOnlineClassTenantClassCommand
    /// Lấy dữ liệu lớp học từ Onluyen, sau đó tạo/update vào OnlineClassTenantClassEntity
    /// SchoolId tự động lấy từ OnlineClassTenantEntity
    /// </summary>
    public class CreateOrUpdateOnlineClassTenantClassCommandHandler : ICommandHandler<CreateOrUpdateOnlineClassTenantClassCommand, Result>
    {
        private readonly ISchoolCommonWriteRepository<OnlineClassTenantClassEntity> _writeRepository;
        private readonly ISchoolCommonReadRepository<OnlineClassTenantClassEntity> _readRepository;
        private readonly ISchoolCommonReadRepository<OnlineClassTenantEntity> _tenantRepository;
        private readonly IOnluyenService _onluyenService;

        public CreateOrUpdateOnlineClassTenantClassCommandHandler(
            ISchoolCommonWriteRepository<OnlineClassTenantClassEntity> writeRepository,
            ISchoolCommonReadRepository<OnlineClassTenantClassEntity> readRepository,
            ISchoolCommonReadRepository<OnlineClassTenantEntity> tenantRepository,
            IOnluyenService onluyenService)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _tenantRepository = tenantRepository;
            _onluyenService = onluyenService;
        }

        public async Task<Result> Handle(CreateOrUpdateOnlineClassTenantClassCommand request, CancellationToken cancellationToken)
        {
            if (request.ClassIds == null || !request.ClassIds.Any())
            {
                throw new DSException("TenantClassParticipantListEmpty");
            }

            // Lấy thông tin Tenant để có SchoolId
            var tenant = await _tenantRepository.FilterAsync(
                x => x.TenantId == request.TenantId,
                tenantId: request.TenantId,
                cancellationToken: cancellationToken);

            if (tenant == null || !tenant.Any())
                throw new DSException("OnlineClassTenantNotFound");

            var onlineClassTenant = tenant.FirstOrDefault();
            if (!onlineClassTenant!.SchoolId.HasValue || onlineClassTenant.SchoolId <= 0)
                throw new DSException("SchoolIdNotFound");

            var schoolId = onlineClassTenant.SchoolId.Value;

            // Lấy danh sách lớp từ Onluyen
            var onluyenClasses = await _onluyenService.GetClassesBySchoolAsync(
                schoolId,
                request.SchoolYear,
                cancellationToken: cancellationToken);

            if (onluyenClasses == null || !onluyenClasses.Any())
                throw new DSException("NoClassesFoundInOnluyen");

            // Nếu có ClassIds được chỉ định, chỉ lấy những lớp đó
            if (request.ClassIds != null && request.ClassIds.Any())
            {
                onluyenClasses = onluyenClasses
                    .Where(x => request.ClassIds.Contains(x.ClassId!))
                    .ToList();

                if (!onluyenClasses.Any())
                    throw new DSException("NoMatchingClassesFoundInOnluyen");
            }

            // Lấy danh sách lớp hiện có
            var existingClasses = await _readRepository.FilterAsync(
                x => x.TenantId == request.TenantId && x.SchoolYear == request.SchoolYear,
                tenantId: request.TenantId,
                cancellationToken: cancellationToken);

            // Tạo dictionary để dễ dàng tra cứu
            var existingClassDict = existingClasses.ToDictionary(x => x.ClassId, x => x);

            // Xử lý từng lớp
            foreach (var onluyenClass in onluyenClasses)
            {
                if (existingClassDict.TryGetValue(onluyenClass.ClassId!, out var existingClass))
                {
                    // Update lớp hiện có
                    existingClass.ClassName = onluyenClass.ClassName!;
                    existingClass.GradeName = onluyenClass.GradeName!;
                    existingClass.GradeId = onluyenClass.GradeId!;
                    existingClass.CountStudent = onluyenClass.CountStudent;
                    existingClass.IsActive = request.IsActive;

                    await _writeRepository.UpdateAsync(existingClass, tenantId: request.TenantId, cancellationToken: cancellationToken);
                }
                else
                {
                    // Tạo lớp mới
                    var newClass = new OnlineClassTenantClassEntity
                    {
                        TenantId = request.TenantId,
                        SchoolId = schoolId,
                        ClassId = onluyenClass.ClassId!,
                        ClassName = onluyenClass.ClassName!,
                        SchoolYear = request.SchoolYear,
                        GradeName = onluyenClass.GradeName!,
                        GradeId = onluyenClass.GradeId!,
                        CountStudent = onluyenClass.CountStudent,
                        IsActive = request.IsActive
                    };

                    await _writeRepository.InsertAsync(newClass);
                }
            }

            // Vô hiệu hóa tất cả lớp của năm học khác trong tenant có năm bé hơn năm vừa cài đặt
            await _writeRepository.UpdateManyAsync(
                x => x.TenantId == request.TenantId && x.SchoolYear < request.SchoolYear && x.IsActive,
                Builders<OnlineClassTenantClassEntity>.Update.Set(x => x.IsActive, false),
                tenantId: null, cancellationToken: cancellationToken);

            return Result.Success();
        }
    }
}
