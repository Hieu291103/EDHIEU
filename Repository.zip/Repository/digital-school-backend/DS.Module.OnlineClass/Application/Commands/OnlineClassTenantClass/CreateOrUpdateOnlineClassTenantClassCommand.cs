using DS.Shared.Core.Application.Abstractions.CQRS;
using DS.Shared.Core.Contracts.Responses;

namespace DS.Module.OnlineClass.Application.Commands.OnlineClassTenantClass
{
    /// <summary>
    /// Command để tạo hoặc cập nhật OnlineClassTenantClass
    /// Nếu ClassId đã tồn tại trong TenantId và SchoolYear thì cập nhật, ngược lại tạo mới
    /// Lấy thông tin lớp học từ Onluyen (SchoolId tự động lấy từ Tenant)
    /// </summary>
    public class CreateOrUpdateOnlineClassTenantClassCommand : ICommand<Result>
    {
        /// <summary>
        /// TenantId (SchoolId sẽ được lấy từ Tenant)
        /// </summary>
        public required string TenantId { get; set; }

        /// <summary>
        /// Năm học để lấy dữ liệu từ Onluyen
        /// </summary>
        public required int SchoolYear { get; set; }

        /// <summary>
        /// Danh sách ClassId cần tạo/update (nếu rỗng sẽ lấy toàn bộ lớp từ Onluyen)
        /// </summary>
        public List<string>? ClassIds { get; set; }

        /// <summary>
        /// Trạng thái Active sử dụng để kích hoạt hoặc hủy kích hoạt lớp học trong hệ thống OnlineClass
        /// </summary>
        public required bool IsActive { get; set; }
    }
}
