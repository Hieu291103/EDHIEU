using DS.Module.OnlineClass.Application.Commands.AccountMeetings;
using FluentValidation;

namespace DS.Module.OnlineClass.Application.Validators.AccountMeetings
{
    /// <summary>
    /// Validator cho CreateOrUpdateAccountMeetingCommand
    /// </summary>
    public class CreateOrUpdateAccountMeetingCommandValidator : AbstractValidator<CreateOrUpdateAccountMeetingTeacherCommand>
    {
        public CreateOrUpdateAccountMeetingCommandValidator()
        {
            RuleFor(x => x.TenantId)
                .NotEmpty();
        }
    }
}
