using FluentValidation;
using DS.Module.OnlineClass.Application.Commands.OnlineClassTenants;

namespace DS.Module.OnlineClass.Application.Validators.OnlineClassTenants
{
    /// <summary>
    /// Validator cho CreateOnlineClassTenantCommand
    /// </summary>
    public class CreateOnlineClassTenantCommandValidator : AbstractValidator<CreateOnlineClassTenantCommand>
    {
        public CreateOnlineClassTenantCommandValidator()
        {
            RuleFor(x => x.TenantId)
                .NotEmpty();

            RuleFor(x => x.ProviderMeetingType)
                .IsInEnum();

            RuleFor(x => x.ProviderConnect)
                .MaximumLength(500)
                .When(x => !string.IsNullOrEmpty(x.ProviderConnect));

            RuleFor(x => x.SchoolId)
                .GreaterThan(0)
                .When(x => x.SchoolId.HasValue);

            RuleFor(x => x.StartDate)
                .LessThanOrEqualTo(x => x.ExpireDate)
                .When(x => x.StartDate.HasValue && x.ExpireDate.HasValue);

            RuleFor(x => x.ExpireDate)
                .GreaterThanOrEqualTo(x => x.StartDate)
                .When(x => x.ExpireDate.HasValue && x.StartDate.HasValue);
        }
    }
}
