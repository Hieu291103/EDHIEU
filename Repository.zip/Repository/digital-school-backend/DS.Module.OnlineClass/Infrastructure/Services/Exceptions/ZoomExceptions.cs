using DS.Shared.Core.Infrastructure.Exceptions;

namespace DS.Module.OnlineClass.Infrastructure.Services.Exceptions;

/// <summary>
/// Base exception for Zoom service operations
/// </summary>
public class ZoomException : DSException
{
    private const string DefaultErrorCode = "ZOOM_ERROR";

    public ZoomException(string errorCode) : base(errorCode)
    {
    }

    public ZoomException(string errorCode, string[]? errorParams) : base(errorCode, errorParams, null)
    {
    }

    public ZoomException(string errorCode, string[]? errorParams, string? message)
        : base(errorCode, errorParams, message)
    {
    }

    public ZoomException(string errorCode, string[]? errorParams, string? message, Exception? innerException)
        : base(errorCode, errorParams, message, innerException)
    {
    }
}

/// <summary>
/// Exception thrown when Zoom configuration is not found
/// </summary>
public class ZoomConfigurationNotFoundException : ZoomException
{
    public string ZoomCode { get; }

    public ZoomConfigurationNotFoundException(string zoomCode)
        : base("ZOOM_CONFIG_NOT_FOUND", new[] { zoomCode }, $"Zoom configuration not found for code: {zoomCode}")
    {
        ZoomCode = zoomCode;
    }
}

/// <summary>
/// Exception thrown during Zoom authentication
/// </summary>
public class ZoomAuthenticationException : ZoomException
{
    public string? ApiUrl { get; }

    public ZoomAuthenticationException(string message, string? apiUrl = null)
        : base("ZOOM_AUTH_FAILED", apiUrl != null ? new[] { apiUrl } : null, message)
    {
        ApiUrl = apiUrl;
    }

    public ZoomAuthenticationException(string message, string? apiUrl, Exception innerException)
        : base("ZOOM_AUTH_FAILED", apiUrl != null ? new[] { apiUrl } : null, message, innerException)
    {
        ApiUrl = apiUrl;
    }
}

/// <summary>
/// Exception thrown when Zoom API call fails
/// </summary>
public class ZoomApiException : ZoomException
{
    public string ErrorCode { get; }
    public string ErrorDetails { get; }

    public ZoomApiException(string message, string errorCode, string errorDetails)
        : base("ZOOM_API_ERROR", new[] { errorCode }, message)
    {
        ErrorCode = errorCode;
        ErrorDetails = errorDetails;
    }
}

/// <summary>
/// Exception thrown during meeting operations
/// </summary>
public class ZoomMeetingOperationException : ZoomException
{
    public string? MeetingId { get; }
    public string Operation { get; }

    public ZoomMeetingOperationException(string message, string operation)
        : base("ZOOM_MEETING_OPERATION_FAILED", new[] { operation }, message)
    {
        Operation = operation;
    }

    public ZoomMeetingOperationException(string message, string meetingId, string operation)
        : base("ZOOM_MEETING_OPERATION_FAILED", new[] { meetingId, operation }, message)
    {
        MeetingId = meetingId;
        Operation = operation;
    }
}
