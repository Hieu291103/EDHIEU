using DS.Shared.Core.Infrastructure.Exceptions;

namespace DS.Module.OnlineClass.Infrastructure.Services.Exceptions;

/// <summary>
/// Base exception for Microsoft Teams service operations
/// </summary>
public class MSTeamsException : DSException
{
    private const string DefaultErrorCode = "TEAMS_ERROR";

    public MSTeamsException(string errorCode) : base(errorCode)
    {
    }

    public MSTeamsException(string errorCode, string[]? errorParams) : base(errorCode, errorParams, null)
    {
    }

    public MSTeamsException(string errorCode, string[]? errorParams, string? message)
        : base(errorCode, errorParams, message)
    {
    }

    public MSTeamsException(string errorCode, string[]? errorParams, string? message, Exception? innerException)
        : base(errorCode, errorParams, message, innerException)
    {
    }
}

/// <summary>
/// Exception thrown when Teams configuration is not found
/// </summary>
public class MSTeamsConfigurationNotFoundException : MSTeamsException
{
    public string TeamsCode { get; }

    public MSTeamsConfigurationNotFoundException(string teamsCode)
        : base("TEAMS_CONFIG_NOT_FOUND", new[] { teamsCode }, $"Teams configuration not found for code: {teamsCode}")
    {
        TeamsCode = teamsCode;
    }
}

/// <summary>
/// Exception thrown during Teams authentication
/// </summary>
public class MSTeamsAuthenticationException : MSTeamsException
{
    public string? TenantId { get; }

    public MSTeamsAuthenticationException(string message, string? tenantId = null)
        : base("TEAMS_AUTH_FAILED", tenantId != null ? new[] { tenantId } : null, message)
    {
        TenantId = tenantId;
    }

    public MSTeamsAuthenticationException(string message, string? tenantId, Exception innerException)
        : base("TEAMS_AUTH_FAILED", tenantId != null ? new[] { tenantId } : null, message, innerException)
    {
        TenantId = tenantId;
    }
}

/// <summary>
/// Exception thrown when Teams API call fails
/// </summary>
public class MSTeamsApiException : MSTeamsException
{
    public string ErrorCode { get; }
    public string ErrorDetails { get; }

    public MSTeamsApiException(string message, string errorCode, string errorDetails)
        : base("TEAMS_API_ERROR", new[] { errorCode }, message)
    {
        ErrorCode = errorCode;
        ErrorDetails = errorDetails;
    }
}

/// <summary>
/// Exception thrown during user account operations
/// </summary>
public class MSTeamsUserOperationException : MSTeamsException
{
    public string? UserId { get; }
    public string Operation { get; }

    public MSTeamsUserOperationException(string message, string operation)
        : base("TEAMS_USER_OPERATION_FAILED", new[] { operation }, message)
    {
        Operation = operation;
    }

    public MSTeamsUserOperationException(string message, string userId, string operation)
        : base("TEAMS_USER_OPERATION_FAILED", new[] { userId, operation }, message)
    {
        UserId = userId;
        Operation = operation;
    }
}

/// <summary>
/// Exception thrown during meeting operations
/// </summary>
public class MSTeamsMeetingOperationException : MSTeamsException
{
    public string? MeetingId { get; }
    public string Operation { get; }

    public MSTeamsMeetingOperationException(string message, string operation)
        : base("TEAMS_MEETING_OPERATION_FAILED", new[] { operation }, message)
    {
        Operation = operation;
    }

    public MSTeamsMeetingOperationException(string message, string meetingId, string operation)
        : base("TEAMS_MEETING_OPERATION_FAILED", new[] { meetingId, operation }, message)
    {
        MeetingId = meetingId;
        Operation = operation;
    }
}

/// <summary>
/// Exception thrown during administrative unit operations
/// </summary>
public class MSTeamsAdministrativeUnitOperationException : MSTeamsException
{
    public string? AdministrativeUnitId { get; }
    public string Operation { get; }

    public MSTeamsAdministrativeUnitOperationException(string message, string operation)
        : base("TEAMS_ADMINISTRATIVE_UNIT_OPERATION_FAILED", new[] { operation }, message)
    {
        Operation = operation;
    }

    public MSTeamsAdministrativeUnitOperationException(string message, string administrativeUnitId, string operation)
        : base("TEAMS_ADMINISTRATIVE_UNIT_OPERATION_FAILED", new[] { administrativeUnitId, operation }, message)
    {
        AdministrativeUnitId = administrativeUnitId;
        Operation = operation;
    }
}
