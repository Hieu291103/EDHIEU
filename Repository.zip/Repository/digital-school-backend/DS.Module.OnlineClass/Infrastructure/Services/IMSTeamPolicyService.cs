using System.Text.Json.Serialization;

namespace DS.Module.OnlineClass.Infrastructure.Services;

/// <summary>
/// Interface cho dịch vụ MS Teams Policy Registration
/// </summary>
public interface IMSTeamPolicyService
{
    /// <summary>
    /// Gán policy cho danh sách người dùng trong Teams
    /// </summary>
    /// <param name="users">Danh sách email người dùng</param>
    /// <param name="cancellationToken">Token hủy</param>
    /// <returns>Kết quả gán policy</returns>
    Task<TeamPolicyDto> AssignPolicyAsync(List<string> users, CancellationToken cancellationToken = default);
}

/// <summary>
/// Response DTO cho Teams Policy Assignment
/// </summary>
public class TeamPolicyDto
{
    /// <summary>
    /// Trạng thái thành công/thất bại
    /// </summary>
    [JsonPropertyName("success")]
    public bool Success { get; set; }

    /// <summary>
    /// Danh sách kết quả gán policy cho từng người dùng
    /// </summary>
    [JsonPropertyName("data")]
    public List<TeamPolicyItemDto>? Data { get; set; }

    /// <summary>
    /// Thông báo lỗi (nếu có)
    /// </summary>
    [JsonPropertyName("error")]
    public string? Error { get; set; }
}

/// <summary>
/// Chi tiết kết quả gán policy cho một người dùng
/// </summary>
public class TeamPolicyItemDto
{
    /// <summary>
    /// Email người dùng
    /// </summary>
    [JsonPropertyName("user")]
    public string? User { get; set; }

    /// <summary>
    /// Trạng thái: success/failed
    /// </summary>
    [JsonPropertyName("status")]
    public string? Status { get; set; }

    /// <summary>
    /// Thông báo lỗi (nếu có)
    /// </summary>
    [JsonPropertyName("error")]
    public string? Error { get; set; }
}
