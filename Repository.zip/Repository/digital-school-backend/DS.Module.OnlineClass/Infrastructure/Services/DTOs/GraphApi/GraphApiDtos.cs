using System.Text.Json.Serialization;

namespace DS.Module.OnlineClass.Infrastructure.Services.DTOs.GraphApi;

/// <summary>
/// Represent a user from Microsoft Graph API
/// </summary>
public class GraphUser
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("userPrincipalName")]
    public string? UserPrincipalName { get; set; }

    [JsonPropertyName("displayName")]
    public string? DisplayName { get; set; }

    [JsonPropertyName("mailNickname")]
    public string? MailNickname { get; set; }

    [JsonPropertyName("mail")]
    public string? Mail { get; set; }

    [JsonPropertyName("mobilePhone")]
    public string? MobilePhone { get; set; }

    [JsonPropertyName("jobTitle")]
    public string? JobTitle { get; set; }

    [JsonPropertyName("officeLocation")]
    public string? OfficeLocation { get; set; }

    [JsonPropertyName("accountEnabled")]
    public bool? AccountEnabled { get; set; }

    [JsonPropertyName("hideFromAddressLists")]
    public bool? HideFromAddressLists { get; set; }

    [JsonPropertyName("createdDateTime")]
    public DateTime? CreatedDateTime { get; set; }
}

/// <summary>
/// Represent password profile from Microsoft Graph API
/// </summary>
public class GraphPasswordProfile
{
    [JsonPropertyName("password")]
    public string? Password { get; set; }

    [JsonPropertyName("forceChangePasswordNextSignIn")]
    public bool ForceChangePasswordNextSignIn { get; set; }
}

/// <summary>
/// Represent administrative unit from Microsoft Graph API
/// </summary>
public class GraphAdministrativeUnit
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("displayName")]
    public string? DisplayName { get; set; }

    [JsonPropertyName("description")]
    public string? Description { get; set; }

    [JsonPropertyName("visibility")]
    public string? Visibility { get; set; }

    [JsonPropertyName("createdDateTime")]
    public DateTime? CreatedDateTime { get; set; }
}

/// <summary>
/// Represent a reference for adding members to administrative units or groups
/// </summary>
public class GraphDirectoryObjectReference
{
    [JsonPropertyName("@odata.id")]
    public string OdataId { get; set; } = string.Empty;
}

/// <summary>
/// Represent an assigned license from Microsoft Graph API
/// </summary>
public class GraphAssignedLicense
{
    [JsonPropertyName("skuId")]
    public string? SkuId { get; set; }

    [JsonPropertyName("disabledPlans")]
    public List<string>? DisabledPlans { get; set; }
}

/// <summary>
/// Represent a license assignment request for Microsoft Graph API
/// </summary>
public class GraphLicenseAssignmentRequest
{
    [JsonPropertyName("addLicenses")]
    public List<GraphAssignedLicense>? AddLicenses { get; set; }

    [JsonPropertyName("removeLicenses")]
    public List<string>? RemoveLicenses { get; set; }
}

/// <summary>
/// Represent an online meeting from Microsoft Graph API
/// </summary>
public class GraphMeeting
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("creationDateTime")]
    public DateTime? CreationDateTime { get; set; }

    [JsonPropertyName("startDateTime")]
    public DateTime? StartDateTime { get; set; }

    [JsonPropertyName("endDateTime")]
    public DateTime? EndDateTime { get; set; }

    [JsonPropertyName("joinUrl")]
    public string? JoinUrl { get; set; }

    [JsonPropertyName("meetingCode")]
    public string? MeetingCode { get; set; }

    [JsonPropertyName("isBroadcast")]
    public bool? IsBroadcast { get; set; }

    [JsonPropertyName("autoAdmittedUsers")]
    public string? AutoAdmittedUsers { get; set; }

    [JsonPropertyName("outerMeetingAutoAdmittedUsers")]
    public string? OuterMeetingAutoAdmittedUsers { get; set; }

    [JsonPropertyName("capabilities")]
    public List<string>? Capabilities { get; set; }

    [JsonPropertyName("externalId")]
    public string? ExternalId { get; set; }

    [JsonPropertyName("meetingTemplateId")]
    public string? MeetingTemplateId { get; set; }

    [JsonPropertyName("meetingType")]
    public string? MeetingType { get; set; }

    [JsonPropertyName("meetingsMigrationMode")]
    public string? MeetingsMigrationMode { get; set; }

    [JsonPropertyName("joinWebUrl")]
    public string? JoinWebUrl { get; set; }

    [JsonPropertyName("subject")]
    public string? Subject { get; set; }

    [JsonPropertyName("videoTeleconferenceId")]
    public string? VideoTeleconferenceId { get; set; }

    [JsonPropertyName("isEntryExitAnnounced")]
    public bool? IsEntryExitAnnounced { get; set; }

    [JsonPropertyName("isEndToEndEncryptionEnabled")]
    public bool? IsEndToEndEncryptionEnabled { get; set; }

    [JsonPropertyName("allowedPresenters")]
    public string? AllowedPresenters { get; set; }

    [JsonPropertyName("allowAttendeeToEnableMic")]
    public bool? AllowAttendeeToEnableMic { get; set; }

    [JsonPropertyName("allowAttendeeToEnableCamera")]
    public bool? AllowAttendeeToEnableCamera { get; set; }

    [JsonPropertyName("allowMeetingChat")]
    public string? AllowMeetingChat { get; set; }

    [JsonPropertyName("allowedLobbyAdmitters")]
    public string? AllowedLobbyAdmitters { get; set; }

    [JsonPropertyName("shareMeetingChatHistoryDefault")]
    public string? ShareMeetingChatHistoryDefault { get; set; }

    [JsonPropertyName("allowTeamworkReactions")]
    public bool? AllowTeamworkReactions { get; set; }

    [JsonPropertyName("anonymizeIdentityForRoles")]
    public List<string>? AnonymizeIdentityForRoles { get; set; }

    [JsonPropertyName("recordAutomatically")]
    public bool? RecordAutomatically { get; set; }

    [JsonPropertyName("meetingSpokenLanguageTag")]
    public string? MeetingSpokenLanguageTag { get; set; }

    [JsonPropertyName("allowParticipantsToChangeName")]
    public bool? AllowParticipantsToChangeName { get; set; }

    [JsonPropertyName("allowTranscription")]
    public bool? AllowTranscription { get; set; }

    [JsonPropertyName("allowRecording")]
    public bool? AllowRecording { get; set; }

    [JsonPropertyName("allowWhiteboard")]
    public bool? AllowWhiteboard { get; set; }

    [JsonPropertyName("allowBreakoutRooms")]
    public bool? AllowBreakoutRooms { get; set; }

    [JsonPropertyName("allowLiveShare")]
    public string? AllowLiveShare { get; set; }

    [JsonPropertyName("allowPowerPointSharing")]
    public bool? AllowPowerPointSharing { get; set; }

    [JsonPropertyName("allowCopyingAndSharingMeetingContent")]
    public bool? AllowCopyingAndSharingMeetingContent { get; set; }

    [JsonPropertyName("meetingOptionsWebUrl")]
    public string? MeetingOptionsWebUrl { get; set; }

    [JsonPropertyName("iCalUid")]
    public string? ICalUid { get; set; }

    [JsonPropertyName("expiryDateTime")]
    public DateTime? ExpiryDateTime { get; set; }

    [JsonPropertyName("broadcastSettings")]
    public object? BroadcastSettings { get; set; }

    [JsonPropertyName("meetingInfo")]
    public object? MeetingInfo { get; set; }

    [JsonPropertyName("activeMeetingDetails")]
    public object? ActiveMeetingDetails { get; set; }

    [JsonPropertyName("audioConferencing")]
    public object? AudioConferencing { get; set; }

    [JsonPropertyName("watermarkProtection")]
    public object? WatermarkProtection { get; set; }

    [JsonPropertyName("sensitivityLabelAssignment")]
    public object? SensitivityLabelAssignment { get; set; }

    [JsonPropertyName("chatRestrictions")]
    public object? ChatRestrictions { get; set; }

    [JsonPropertyName("participants")]
    public GraphMeetingParticipants? Participants { get; set; }

    [JsonPropertyName("chatInfo")]
    public GraphChatInfo? ChatInfo { get; set; }

    [JsonPropertyName("joinInformation")]
    public GraphJoinInformation? JoinInformation { get; set; }

    [JsonPropertyName("joinMeetingIdSettings")]
    public GraphJoinMeetingIdSettings? JoinMeetingIdSettings { get; set; }

    [JsonPropertyName("lobbyBypassSettings")]
    public GraphLobbyBypassSettings? LobbyBypassSettings { get; set; }
}

/// <summary>
/// Represent meeting participants from Microsoft Graph API
/// </summary>
public class GraphMeetingParticipants
{
    [JsonPropertyName("organizer")]
    public GraphParticipant? Organizer { get; set; }

    [JsonPropertyName("attendees")]
    public List<GraphParticipant>? Attendees { get; set; }
}

/// <summary>
/// Represent a meeting participant from Microsoft Graph API
/// </summary>
public class GraphParticipant
{
    [JsonPropertyName("upn")]
    public string? Upn { get; set; }

    [JsonPropertyName("role")]
    public string? Role { get; set; }

    [JsonPropertyName("identity")]
    public GraphIdentity? Identity { get; set; }
}

/// <summary>
/// Represent identity information from Microsoft Graph API
/// </summary>
public class GraphIdentity
{
    [JsonPropertyName("application")]
    public object? Application { get; set; }

    [JsonPropertyName("device")]
    public object? Device { get; set; }

    [JsonPropertyName("user")]
    public GraphIdentityUser? User { get; set; }
}

/// <summary>
/// Represent identity user information from Microsoft Graph API
/// </summary>
public class GraphIdentityUser
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("displayName")]
    public string? DisplayName { get; set; }

    [JsonPropertyName("tenantId")]
    public string? TenantId { get; set; }

    [JsonPropertyName("identityProvider")]
    public string? IdentityProvider { get; set; }
}

/// <summary>
/// Represent chat information from Microsoft Graph API
/// </summary>
public class GraphChatInfo
{
    [JsonPropertyName("threadId")]
    public string? ThreadId { get; set; }

    [JsonPropertyName("messageId")]
    public string? MessageId { get; set; }

    [JsonPropertyName("replyChainMessageId")]
    public string? ReplyChainMessageId { get; set; }
}

/// <summary>
/// Represent join information from Microsoft Graph API
/// </summary>
public class GraphJoinInformation
{
    [JsonPropertyName("content")]
    public string? Content { get; set; }

    [JsonPropertyName("contentType")]
    public string? ContentType { get; set; }
}

/// <summary>
/// Represent join meeting ID settings from Microsoft Graph API
/// </summary>
public class GraphJoinMeetingIdSettings
{
    [JsonPropertyName("isPasscodeRequired")]
    public bool? IsPasscodeRequired { get; set; }

    [JsonPropertyName("joinMeetingId")]
    public string? JoinMeetingId { get; set; }

    [JsonPropertyName("passcode")]
    public string? Passcode { get; set; }
}

/// <summary>
/// Represent lobby bypass settings from Microsoft Graph API
/// </summary>
public class GraphLobbyBypassSettings
{
    [JsonPropertyName("scope")]
    public string? Scope { get; set; }

    [JsonPropertyName("isDialInBypassEnabled")]
    public bool? IsDialInBypassEnabled { get; set; }
}

/// <summary>
/// OData collection wrapper cho danh sách meetingAttendanceReport từ Graph API
/// </summary>
public class GraphAttendanceReportList
{
    [JsonPropertyName("value")]
    public List<GraphAttendanceReport> Value { get; set; } = [];
}

/// <summary>
/// Attendance report của 1 buổi họp Teams (meetingAttendanceReport)
/// Docs: https://learn.microsoft.com/graph/api/resources/meetingattendancereport
/// </summary>
public class GraphAttendanceReport
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("meetingStartDateTime")]
    public DateTime? MeetingStartDateTime { get; set; }

    [JsonPropertyName("meetingEndDateTime")]
    public DateTime? MeetingEndDateTime { get; set; }

    [JsonPropertyName("totalParticipantCount")]
    public int? TotalParticipantCount { get; set; }
}

/// <summary>
/// OData collection wrapper cho danh sách attendanceRecord từ Graph API
/// </summary>
public class GraphAttendanceRecordList
{
    [JsonPropertyName("value")]
    public List<GraphAttendanceRecord> Value { get; set; } = [];
}

/// <summary>
/// Attendance record của 1 người tham gia meeting Teams (attendanceRecord)
/// Docs: https://learn.microsoft.com/graph/api/resources/attendancerecord
/// </summary>
public class GraphAttendanceRecord
{
    [JsonPropertyName("emailAddress")]
    public string? EmailAddress { get; set; }

    /// <summary>
    /// Role của người tham gia: None, Attendee, Presenter, Organizer
    /// </summary>
    [JsonPropertyName("role")]
    public string? Role { get; set; }

    /// <summary>
    /// Tổng thời gian tham dự (giây)
    /// </summary>
    [JsonPropertyName("totalAttendanceInSeconds")]
    public int? TotalAttendanceInSeconds { get; set; }

    /// <summary>
    /// Identity của người dùng (Azure AD identity với id và displayName)
    /// </summary>
    [JsonPropertyName("identity")]
    public GraphAttendanceIdentity? Identity { get; set; }

    /// <summary>
    /// Danh sách các khoảng thời gian tham gia / rời khỏi meeting
    /// </summary>
    [JsonPropertyName("attendanceIntervals")]
    public List<GraphAttendanceInterval> AttendanceIntervals { get; set; } = [];
}

public class GraphAttendanceRecordUser
{
    /// <summary>
    /// Azure AD Object ID của người dùng
    /// </summary>
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("displayName")]
    public string? DisplayName { get; set; }

    [JsonPropertyName("joinDateTime")]
    public DateTime? JoinDateTime { get; set; }

    [JsonPropertyName("leaveDateTime")]
    public DateTime? LeaveDateTime { get; set; }

    [JsonPropertyName("durationInSeconds")]
    public int? DurationInSeconds { get; set; }

    /// <summary>
    /// Danh sách các khoảng thời gian tham gia / rời khỏi meeting
    /// </summary>
    [JsonPropertyName("attendanceIntervals")]
    public List<GraphAttendanceInterval> AttendanceIntervals { get; set; } = [];
}

/// <summary>
/// Identity của người tham gia lấy từ attendance record
/// </summary>
public class GraphAttendanceIdentity
{
    /// <summary>
    /// Azure AD Object ID của người dùng
    /// </summary>
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("displayName")]
    public string? DisplayName { get; set; }

    [JsonPropertyName("tenantId")]
    public string? TenantId { get; set; }
}

/// <summary>
/// Khoảng thời gian tham gia trong 1 lần join/leave meeting Teams (attendanceInterval)
/// Docs: https://learn.microsoft.com/graph/api/resources/attendanceinterval
/// </summary>
public class GraphAttendanceInterval
{
    [JsonPropertyName("joinDateTime")]
    public DateTime? JoinDateTime { get; set; }

    [JsonPropertyName("leaveDateTime")]
    public DateTime? LeaveDateTime { get; set; }

    [JsonPropertyName("durationInSeconds")]
    public int? DurationInSeconds { get; set; }
}
