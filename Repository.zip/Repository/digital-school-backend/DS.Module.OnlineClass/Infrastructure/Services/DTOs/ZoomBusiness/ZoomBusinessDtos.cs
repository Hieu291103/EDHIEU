using System.Text.Json.Serialization;

namespace DS.Module.OnlineClass.Infrastructure.Services.DTOs.ZoomBusiness;

/// <summary>
/// Request DTO cho create meeting
/// </summary>
public class CreateZoomMeetingRequest
{
    [JsonPropertyName("topic")]
    public string Topic { get; set; } = string.Empty;

    [JsonPropertyName("agenda")]
    public string? Agenda { get; set; }

    [JsonPropertyName("timeInMinute")]
    public int TimeInMinute { get; set; }

    [JsonPropertyName("password")]
    public string? Password { get; set; }

    [JsonPropertyName("contactMail")]
    public string? ContactMail { get; set; }

    [JsonPropertyName("contactName")]
    public string? ContactName { get; set; }
}

/// <summary>
/// Response DTO cho create meeting
/// </summary>
public class CreateZoomMeetingResponse
{
    [JsonPropertyName("id")]
    public long Id { get; set; }

    [JsonPropertyName("zoomRoomId")]
    public long ZoomRoomId { get; set; }

    [JsonPropertyName("topic")]
    public string Topic { get; set; } = string.Empty;

    [JsonPropertyName("agenda")]
    public string? Agenda { get; set; }

    [JsonPropertyName("durationInMinute")]
    public int DurationInMinute { get; set; }

    [JsonPropertyName("roomPassword")]
    public string? RoomPassword { get; set; }

    [JsonPropertyName("joinUrl")]
    public string? JoinUrl { get; set; }

    [JsonPropertyName("startUrl")]
    public string? StartUrl { get; set; }

    [JsonPropertyName("createAt")]
    public DateTime CreateAt { get; set; }

    [JsonPropertyName("status")]
    public int Status { get; set; }
}

/// <summary>
/// Response DTO cho lấy thông tin meeting
/// </summary>
public class ZoomMeetingDetailResponse
{
    [JsonPropertyName("id")]
    public long Id { get; set; }

    [JsonPropertyName("zoomRoomId")]
    public long ZoomRoomId { get; set; }

    [JsonPropertyName("topic")]
    public string Topic { get; set; } = string.Empty;

    [JsonPropertyName("agenda")]
    public string? Agenda { get; set; }

    [JsonPropertyName("durationInMinute")]
    public int DurationInMinute { get; set; }

    [JsonPropertyName("roomPassword")]
    public string? RoomPassword { get; set; }

    [JsonPropertyName("joinUrl")]
    public string? JoinUrl { get; set; }

    [JsonPropertyName("startUrl")]
    public string? StartUrl { get; set; }

    [JsonPropertyName("createAt")]
    public DateTime CreateAt { get; set; }

    [JsonPropertyName("status")]
    public int Status { get; set; }
}

/// <summary>
/// Response DTO cho lấy thông tin user hiện tại
/// </summary>
public class UserInfoResponse
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("userName")]
    public string? UserName { get; set; }

    [JsonPropertyName("email")]
    public string? Email { get; set; }

    [JsonPropertyName("fullName")]
    public string? FullName { get; set; }

    [JsonPropertyName("phoneNumber")]
    public string? PhoneNumber { get; set; }

    [JsonPropertyName("bio")]
    public string? Bio { get; set; }

    [JsonPropertyName("avatar")]
    public string? Avatar { get; set; }

    [JsonPropertyName("departmentId")]
    public long? DepartmentId { get; set; }

    [JsonPropertyName("createAt")]
    public DateTime CreateAt { get; set; }

    [JsonPropertyName("roles")]
    public List<string>? Roles { get; set; }

    [JsonPropertyName("totalLicenses")]
    public int TotalLicenses { get; set; }

    [JsonPropertyName("currentActiveRooms")]
    public int CurrentActiveRooms { get; set; }
}

/// <summary>
/// Response DTO cho lấy URL buổi học (start-url hoặc join-url)
/// </summary>
public class ZoomUrlResponse
{
    [JsonPropertyName("url")]
    public string? Url { get; set; }
}
