using System.Text.Json.Serialization;

namespace DS.Module.OnlineClass.Infrastructure.Services.DTOs.ZoomBusiness;

/// <summary>
/// Request DTO cho lấy dữ liệu meeting với pagination
/// </summary>
public class MeetingDataRequest
{
    [JsonPropertyName("pageNumber")]
    public int PageNumber { get; set; } = 1;

    [JsonPropertyName("pageSize")]
    public int PageSize { get; set; } = 10;

    [JsonPropertyName("searchTerm")]
    public string? SearchTerm { get; set; }

    [JsonPropertyName("sortBy")]
    public string? SortBy { get; set; }

    [JsonPropertyName("sortDescending")]
    public bool SortDescending { get; set; } = false;
}

/// <summary>
/// Generic paginated response
/// </summary>
public class PaginatedResponse<T>
{
    [JsonPropertyName("total")]
    public int Total { get; set; }

    [JsonPropertyName("items")]
    public List<T>? Items { get; set; }

    [JsonPropertyName("state")]
    public bool State { get; set; }

    [JsonPropertyName("errorCode")]
    public string? ErrorCode { get; set; }

    [JsonPropertyName("message")]
    public string? Message { get; set; }

    [JsonPropertyName("object")]
    public object? Object { get; set; }

    [JsonPropertyName("messages")]
    public object? Messages { get; set; }
}

/// <summary>
/// DTO cho Recording item
/// </summary>
public class RecordingItem
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("recordingStart")]
    public DateTime? RecordingStart { get; set; }

    [JsonPropertyName("recordingEnd")]
    public DateTime? RecordingEnd { get; set; }

    [JsonPropertyName("duration")]
    public int Duration { get; set; }

    [JsonPropertyName("size")]
    public long Size { get; set; }

    [JsonPropertyName("status")]
    public string? Status { get; set; }

    [JsonPropertyName("type")]
    public string? Type { get; set; }

    [JsonPropertyName("downloadUrl")]
    public string? DownloadUrl { get; set; }

    [JsonPropertyName("playUrl")]
    public string? PlayUrl { get; set; }
}

/// <summary>
/// DTO cho Participant item
/// </summary>

public class ParticipantItem
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }
    [JsonPropertyName("roomId")]
    public int? RoomId { get; set; }
    [JsonPropertyName("total")]
    public int? Total { get; set; }
    [JsonPropertyName("createAt")]
    public DateTime? CreateAt { get; set; }
    [JsonPropertyName("users")]
    public List<ParticipantItemUser>? Users { get; set; }
}

public class ParticipantItemUser
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }
    [JsonPropertyName("participantId")]
    public string? ParticipantId { get; set; }
    [JsonPropertyName("ipAddress")]
    public string? IpAddress { get; set; }
    [JsonPropertyName("joinTime")]
    public DateTime? JoinTime { get; set; }
    [JsonPropertyName("leaveReason")]
    public string? LeaveReason { get; set; }
    [JsonPropertyName("leaveTime")]
    public DateTime? LeaveTime { get; set; }
    [JsonPropertyName("location")]
    public string? Location { get; set; }
    [JsonPropertyName("role")]
    public string? Role { get; set; }
    [JsonPropertyName("status")]
    public string? Status { get; set; }
    [JsonPropertyName("userName")]
    public string? UserName { get; set; }
}

/// <summary>
/// DTO cho Summary item
/// </summary>
public class SummaryItem
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("meetingTopic")]
    public string? MeetingTopic { get; set; }

    [JsonPropertyName("meetingStart")]
    public DateTime? MeetingStart { get; set; }

    [JsonPropertyName("meetingEnd")]
    public DateTime? MeetingEnd { get; set; }

    [JsonPropertyName("duration")]
    public int Duration { get; set; }

    [JsonPropertyName("totalParticipants")]
    public int TotalParticipants { get; set; }

    [JsonPropertyName("totalRecordings")]
    public int TotalRecordings { get; set; }

    [JsonPropertyName("hostName")]
    public string? HostName { get; set; }

    [JsonPropertyName("hostEmail")]
    public string? HostEmail { get; set; }

    [JsonPropertyName("meetingType")]
    public string? MeetingType { get; set; }
}

/// <summary>
/// DTO cho Alert item
/// </summary>
public class AlertItem
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("alertType")]
    public string? AlertType { get; set; }

    [JsonPropertyName("severity")]
    public string? Severity { get; set; }

    [JsonPropertyName("title")]
    public string? Title { get; set; }

    [JsonPropertyName("description")]
    public string? Description { get; set; }

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; }

    [JsonPropertyName("updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    [JsonPropertyName("status")]
    public string? Status { get; set; }

    [JsonPropertyName("affectedUser")]
    public string? AffectedUser { get; set; }
}
