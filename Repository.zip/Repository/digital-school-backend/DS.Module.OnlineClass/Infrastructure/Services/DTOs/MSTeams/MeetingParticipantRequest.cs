namespace DS.Module.OnlineClass.Infrastructure.Services.DTOs.MSTeams
{
    /// <summary>
    /// DTO yêu cầu thêm người tham gia vào cuộc họp
    /// </summary>
    public class MeetingParticipantRequest
    {
        /// <summary>
        /// Email của người tham gia
        /// </summary>
        public required string Email { get; set; }

        /// <summary>
        /// Vai trò của người tham gia: "presenter", "attendee"
        /// </summary>
        public string Role { get; set; } = "presenter";
    }
}
