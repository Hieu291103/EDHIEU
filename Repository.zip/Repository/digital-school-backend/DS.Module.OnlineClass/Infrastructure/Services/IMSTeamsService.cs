using DS.Module.OnlineClass.Infrastructure.Services.DTOs.GraphApi;

namespace DS.Module.OnlineClass.Infrastructure.Services
{
    /// <summary>
    /// Interface cho dịch vụ Microsoft Teams
    /// </summary>
    public interface IMSTeamsService
    {
        #region User Account Management (Quản lý tài khoản người dùng)

        /// <summary>
        /// Tạo mới một tài khoản người dùng trong Microsoft Teams
        /// </summary>
        /// <param name="teamsCode">Mã cấu hình Teams</param>
        /// <param name="userEmail">Email của người dùng</param>
        /// <param name="displayName">Tên hiển thị</param>
        /// <param name="password">Mật khẩu (tạm thời)</param>
        /// <param name="cancellationToken">Token hủy</param>
        /// <returns>Thông tin tài khoản vừa tạo</returns>
        Task<GraphUser?> CreateUserAccountAsync(string teamsCode, string userEmail, string displayName,
            string password, CancellationToken cancellationToken = default);

        /// <summary>
        /// Tạo mới một tài khoản người dùng trong Microsoft Teams với gán vào AU, Group và License
        /// </summary>
        /// <param name="teamsCode">Mã cấu hình Teams</param>
        /// <param name="userEmail">Email của người dùng</param>
        /// <param name="displayName">Tên hiển thị</param>
        /// <param name="password">Mật khẩu (tạm thời)</param>
        /// <param name="administrativeUnitId">ID của Administrative Unit (tùy chọn)</param>
        /// <param name="groupId">ID của Group (tùy chọn)</param>
        /// <param name="licenseSkuId">SKU ID của License cần gán (tùy chọn)</param>
        /// <param name="cancellationToken">Token hủy</param>
        /// <returns>Thông tin tài khoản vừa tạo và được setup hoàn tất</returns>
        Task<GraphUser?> CreateUserAccountWithGroupAsync(
            string teamsCode, string userEmail, string displayName, string password,
            string? groupId = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Thay đổi mật khẩu người dùng
        /// </summary>
        /// <param name="teamsCode">Mã cấu hình Teams</param>
        /// <param name="userId">ID người dùng</param>
        /// <param name="newPassword">Mật khẩu mới</param>
        /// <param name="forceChangeNextSignIn">Bắt buộc thay đổi mật khẩu lần đầu đăng nhập</param>
        /// <param name="cancellationToken">Token hủy</param>
        /// <returns>Kết quả thay đổi mật khẩu</returns>
        Task<bool> ChangeUserPasswordAsync(string teamsCode, string userId, string newPassword, CancellationToken cancellationToken = default);

        /// <summary>
        /// Xóa tài khoản người dùng
        /// </summary>
        /// <param name="teamsCode">Mã cấu hình Teams</param>
        /// <param name="userId">ID người dùng</param>
        /// <param name="cancellationToken">Token hủy</param>
        /// <returns>Kết quả xóa</returns>
        Task<bool> DeleteUserAccountAsync(string teamsCode, string userId, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gán người dùng vào Group
        /// </summary>
        /// <param name="teamsCode">Mã cấu hình Teams</param>
        /// <param name="groupId">ID của Group</param>
        /// <param name="userId">ID của người dùng</param>
        /// <param name="cancellationToken">Token hủy</param>
        /// <returns>Kết quả gán</returns>
        Task<bool> AssignUserToGroupAsync(string teamsCode, string groupId, string userId,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Gán License cho người dùng
        /// </summary>
        /// <param name="teamsCode">Mã cấu hình Teams</param>
        /// <param name="userId">ID của người dùng</param>
        /// <param name="licenseSkuId">SKU ID của License</param>
        /// <param name="cancellationToken">Token hủy</param>
        /// <returns>Kết quả gán license</returns>
        Task<bool> AssignLicenseToUserAsync(string teamsCode, string userId, string licenseSkuId,
            CancellationToken cancellationToken = default);

        #endregion

        #region Meeting Management (Quản lý cuộc họp)

        /// <summary>
        /// Tạo cuộc họp trực tuyến mới
        /// </summary>
        /// <param name="teamsCode">Mã cấu hình Teams</param>
        /// <param name="userId">ID người tổ chức meeting</param>
        /// <param name="subject">Chủ đề cuộc họp</param>
        /// <param name="startDateTime">Thời gian bắt đầu</param>
        /// <param name="endDateTime">Thời gian kết thúc</param>
        /// <param name="description">Mô tả cuộc họp</param>
        /// <param name="cancellationToken">Token hủy</param>
        /// <returns>Thông tin cuộc họp vừa tạo (bao gồm link join)</returns>
        Task<GraphMeeting?> CreateMeetingAsync(string teamsCode, string userId, string subject,
            DateTime startDateTime, DateTime endDateTime, string? description = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Cập nhật thông tin cuộc họp
        /// </summary>
        /// <param name="teamsCode">Mã cấu hình Teams</param>
        /// <param name="userId">ID người tổ chức cuộc họp</param>
        /// <param name="meetingId">ID cuộc họp</param>
        /// <param name="subject">Chủ đề</param>
        /// <param name="startDateTime">Thời gian bắt đầu</param>
        /// <param name="endDateTime">Thời gian kết thúc</param>
        /// <param name="description">Mô tả</param>
        /// <param name="cancellationToken">Token hủy</param>
        /// <returns>Thông tin cuộc họp được cập nhật</returns>
        Task<GraphMeeting> UpdateMeetingAsync(string teamsCode, string userId, string meetingId, string? subject = null,
            DateTime? startDateTime = null, DateTime? endDateTime = null, string? description = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Xóa cuộc họp
        /// </summary>
        /// <param name="teamsCode">Mã cấu hình Teams</param>
        /// <param name="userId">ID người tổ chức cuộc họp</param>
        /// <param name="meetingId">ID cuộc họp</param>
        /// <param name="cancellationToken">Token hủy</param>
        /// <returns>Kết quả xóa</returns>
        Task<bool> DeleteMeetingAsync(string teamsCode, string userId, string meetingId, CancellationToken cancellationToken = default);

        /// <summary>
        /// Thêm người cùng quản lý (organizer) cho cuộc họp
        /// </summary>
        /// <param name="teamsCode">Mã cấu hình Teams</param>
        /// <param name="userId">ID người tổ chức chính</param>
        /// <param name="meetingId">ID cuộc họp</param>
        /// <param name="organizerEmail">Email của người quản lý cần thêm</param>
        /// <param name="cancellationToken">Token hủy</param>
        /// <returns>Kết quả thêm organizer</returns>
        Task<bool> AddMeetingOrganizerAsync(string teamsCode, string userId, string meetingId, string organizerEmail,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Lấy toàn bộ danh sách người tham gia meeting từ Attendance Report Teams (tự động lấy report mới nhất).
        /// Endpoint: GET /users/{userId}/onlineMeetings/{meetingId}/attendanceReports
        /// </summary>
        /// <param name="teamsCode">Mã cấu hình Teams</param>
        /// <param name="userId">Azure AD Object ID của người tổ chức meeting (MeetUserId)</param>
        /// <param name="meetingId">ID cuộc họp từ Microsoft Graph (ProviderMeetingId)</param>
        /// <param name="cancellationToken">Token hủy</param>
        /// <returns>Danh sách attendance record của tất cả người tham gia</returns>
        Task<List<GraphAttendanceRecordUser>> GetAllParticipantsAsync(
            string teamsCode,
            string userId,
            string meetingId,
            CancellationToken cancellationToken = default);

        #endregion

    }
}
