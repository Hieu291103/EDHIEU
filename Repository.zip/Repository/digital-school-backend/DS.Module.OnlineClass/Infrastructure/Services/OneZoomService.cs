using DS.Module.OnlineClass.Infrastructure.Configuration;
using DS.Module.OnlineClass.Infrastructure.Services.Authentication;
using DS.Module.OnlineClass.Infrastructure.Services.DTOs.ZoomBusiness;
using DS.Module.OnlineClass.Infrastructure.Services.Exceptions;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Infrastructure.Services;

/// <summary>
/// Dịch vụ Zoom tương tác với OneZoom API (bên thứ 3)
/// </summary>
public class OneZoomService : IOneZoomService
{
    private readonly OnlineClassSettings _settings;
    private readonly IZoomHttpClientService _zoomHttpClient;
    private readonly ILogger<OneZoomService> _logger;

    public OneZoomService(
        OnlineClassSettings settings,
        IZoomHttpClientService zoomHttpClient,
        ILogger<OneZoomService> logger)
    {
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _zoomHttpClient = zoomHttpClient ?? throw new ArgumentNullException(nameof(zoomHttpClient));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    #region Helper Methods

    private OnlineClassSettings.ZoomOption GetZoomConfig(string zoomCode)
    {
        var config = _settings.Zoom?.FirstOrDefault(z => z.Code == zoomCode);
        if (config == null)
            throw new ZoomConfigurationNotFoundException(zoomCode);
        return config;
    }

    /// <summary>
    /// Xây dựng query string từ MeetingDataRequest
    /// </summary>
    private string BuildQueryString(MeetingDataRequest request)
    {
        var queryParams = new List<string>();

        if (request.PageNumber > 0)
            queryParams.Add($"pageNumber={request.PageNumber}");

        if (request.PageSize > 0)
            queryParams.Add($"pageSize={request.PageSize}");

        if (!string.IsNullOrWhiteSpace(request.SearchTerm))
            queryParams.Add($"searchTerm={Uri.EscapeDataString(request.SearchTerm)}");

        if (!string.IsNullOrWhiteSpace(request.SortBy))
            queryParams.Add($"sortBy={Uri.EscapeDataString(request.SortBy)}");

        queryParams.Add($"sortDescending={request.SortDescending.ToString().ToLower()}");

        return queryParams.Count > 0 ? "?" + string.Join("&", queryParams) : string.Empty;
    }

    #endregion

    #region Meeting Management

    /// <summary>
    /// Tạo buổi họp Zoom mới thông qua API bên thứ 3
    /// </summary>
    public async Task<CreateZoomMeetingResponse?> CreateMeetingAsync(
        CreateZoomMeetingRequest request,
        string? zoomCode = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            if (request == null)
                throw new ArgumentNullException(nameof(request));

            if (string.IsNullOrWhiteSpace(request.Topic))
                throw new ArgumentException("Topic là bắt buộc", nameof(request.Topic));

            // Lấy cấu hình Zoom (mặc định lấy cái đầu tiên nếu không chỉ định)
            zoomCode = zoomCode ?? _settings.Zoom?.FirstOrDefault()?.Code;
            var zoomConfig = GetZoomConfig(zoomCode!);

            // Gọi API bên thứ 3 để tạo meeting
            var response = await _zoomHttpClient.PostAsync<CreateZoomMeetingResponse>(
                zoomConfig.Code,
                "/ZoomBusiness/create-meeting",
                request,
                cancellationToken);

            return response;
        }
        catch (ZoomException)
        {
            throw;
        }
        catch (Exception ex) when (!(ex is ArgumentException || ex is ArgumentNullException))
        {
            _logger.LogError(ex, "Error creating Zoom meeting with topic: {Topic}", request?.Topic);
            throw new ZoomMeetingOperationException(
                $"Failed to create Zoom meeting: {ex.Message}",
                operation: "CreateMeeting");
        }
    }

    /// <summary>
    /// Lấy chi tiết buổi họp Zoom theo ID
    /// </summary>
    public async Task<CreateZoomMeetingResponse?> GetMeetingByIdAsync(
        long id,
        string? zoomCode = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            if (id <= 0)
                throw new ArgumentException("ID phải lớn hơn 0", nameof(id));

            // Lấy cấu hình Zoom (mặc định lấy cái đầu tiên nếu không chỉ định)
            zoomCode = zoomCode ?? _settings.Zoom?.FirstOrDefault()?.Code;
            var zoomConfig = GetZoomConfig(zoomCode!);

            // Gọi API bên thứ 3 để lấy chi tiết meeting
            var response = await _zoomHttpClient.GetAsync<CreateZoomMeetingResponse>(
                zoomConfig.Code,
                $"/ZoomBusiness/{id}",
                cancellationToken);

            if (response == null)
            {
                return null;
            }

            return response;
        }
        catch (ZoomException)
        {
            throw;
        }
        catch (Exception ex) when (!(ex is ArgumentException))
        {
            _logger.LogError(ex, "Error getting Zoom meeting with ID: {MeetingId}", id);
            throw new ZoomMeetingOperationException(
                $"Failed to get Zoom meeting: {ex.Message}",
                operation: "GetMeetingById");
        }
    }

    /// <summary>
    /// Xóa buổi họp Zoom theo ID
    /// </summary>
    public async Task<bool> DeleteMeetingAsync(
        long id,
        string? zoomCode = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            if (id <= 0)
                throw new ArgumentException("ID phải lớn hơn 0", nameof(id));

            // Lấy cấu hình Zoom (mặc định lấy cái đầu tiên nếu không chỉ định)
            zoomCode = zoomCode ?? _settings.Zoom?.FirstOrDefault()?.Code;
            var zoomConfig = GetZoomConfig(zoomCode!);

            // Gọi API bên thứ 3 để xóa meeting
            await _zoomHttpClient.DeleteAsync(
                zoomConfig.Code,
                $"/ZoomBusiness/{id}",
                cancellationToken);

            return true;
        }
        catch (ZoomException)
        {
            throw;
        }
        catch (Exception ex) when (!(ex is ArgumentException))
        {
            _logger.LogError(ex, "Error deleting Zoom meeting with ID: {MeetingId}", id);
            throw new ZoomMeetingOperationException(
                $"Failed to delete Zoom meeting: {ex.Message}",
                operation: "DeleteMeeting");
        }
    }

    #endregion

    #region User Management

    /// <summary>
    /// Lấy thông tin user hiện tại
    /// </summary>
    public async Task<UserInfoResponse?> GetCurrentUserAsync(
        string? zoomCode = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            // Lấy cấu hình Zoom (mặc định lấy cái đầu tiên nếu không chỉ định)
            zoomCode = zoomCode ?? _settings.Zoom?.FirstOrDefault()?.Code;
            var zoomConfig = GetZoomConfig(zoomCode!);

            // Gọi API bên thứ 3 để lấy thông tin user hiện tại
            var response = await _zoomHttpClient.GetAsync<UserInfoResponse>(
                zoomConfig.Code,
                "/Users/me",
                cancellationToken);

            if (response == null)
            {
                return null;
            }

            return response;
        }
        catch (ZoomException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting current user info");
            throw new ZoomMeetingOperationException(
                $"Failed to get current user info: {ex.Message}",
                operation: "GetCurrentUser");
        }
    }

    #endregion

    #region Meeting Data Management

    /// <summary>
    /// Lấy danh sách bản ghi meeting theo phòng với pagination
    /// </summary>
    public async Task<PaginatedResponse<RecordingItem>?> GetRecordingsAsync(
        long roomId,
        MeetingDataRequest request,
        string? zoomCode = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            if (roomId <= 0)
                throw new ArgumentException("RoomId phải lớn hơn 0", nameof(roomId));

            if (request == null)
                throw new ArgumentNullException(nameof(request));

            // Lấy cấu hình Zoom (mặc định lấy cái đầu tiên nếu không chỉ định)
            zoomCode = zoomCode ?? _settings.Zoom?.FirstOrDefault()?.Code;
            var zoomConfig = GetZoomConfig(zoomCode!);

            // Xây dựng query string từ request
            var queryParams = BuildQueryString(request);
            var endpoint = $"/MeetingData/rooms/{roomId}/recordings{queryParams}";

            // Gọi API bên thứ 3 để lấy bản ghi
            var response = await _zoomHttpClient.GetAsync<PaginatedResponse<RecordingItem>>(
                zoomConfig.Code,
                endpoint,
                cancellationToken);

            if (response == null)
            {
                return null;
            }

            return response;
        }
        catch (ZoomException)
        {
            throw;
        }
        catch (Exception ex) when (!(ex is ArgumentException || ex is ArgumentNullException))
        {
            _logger.LogError(ex, "Error getting recordings for room: {RoomId}", roomId);
            throw new ZoomMeetingOperationException(
                $"Failed to get recordings: {ex.Message}",
                operation: "GetRecordings");
        }
    }

    /// <summary>
    /// Lấy danh sách người tham gia meeting theo phòng với pagination
    /// </summary>
    public async Task<PaginatedResponse<ParticipantItem>?> GetParticipantsAsync(
        long roomId,
        MeetingDataRequest request,
        string? zoomCode = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            if (roomId <= 0)
                throw new ArgumentException("RoomId phải lớn hơn 0", nameof(roomId));

            if (request == null)
                throw new ArgumentNullException(nameof(request));

            // Lấy cấu hình Zoom (mặc định lấy cái đầu tiên nếu không chỉ định)
            zoomCode = zoomCode ?? _settings.Zoom?.FirstOrDefault()?.Code;
            var zoomConfig = GetZoomConfig(zoomCode!);

            // Xây dựng query string từ request
            var queryParams = BuildQueryString(request);
            var endpoint = $"/MeetingData/rooms/{roomId}/participants{queryParams}";

            // Gọi API bên thứ 3 để lấy danh sách người tham gia
            var response = await _zoomHttpClient.GetAsync<PaginatedResponse<ParticipantItem>>(
                zoomConfig.Code,
                endpoint,
                cancellationToken);

            if (response == null)
            {
                return null;
            }

            return response;
        }
        catch (ZoomException)
        {
            throw;
        }
        catch (Exception ex) when (!(ex is ArgumentException || ex is ArgumentNullException))
        {
            _logger.LogError(ex, "Error getting participants for room: {RoomId}", roomId);
            throw new ZoomMeetingOperationException(
                $"Failed to get participants: {ex.Message}",
                operation: "GetParticipants");
        }
    }

    /// <summary>
    /// Lấy toàn bộ danh sách người tham gia meeting theo phòng (tự động phân trang)
    /// </summary>
    public async Task<List<ParticipantItemUser>> GetAllParticipantsAsync(
        long roomId,
        string? zoomCode = null,
        int pageSize = 100,
        CancellationToken cancellationToken = default)
    {
        if (roomId <= 0)
            throw new ArgumentException("RoomId phải lớn hơn 0", nameof(roomId));

        var allUsers = new List<ParticipantItemUser>();
        var pageNumber = 1;

        try
        {
            while (true)
            {
                var response = await GetParticipantsAsync(
                    roomId,
                    new MeetingDataRequest
                    {
                        PageNumber = pageNumber,
                        PageSize = pageSize
                    },
                    zoomCode,
                    cancellationToken);

                if (response?.Items == null || response.Items.Count == 0)
                    break;

                foreach (var item in response.Items)
                {
                    if (item.Users == null) continue;

                    foreach (var user in item.Users)
                    {
                        var existing = allUsers.FirstOrDefault(u =>
                            !string.IsNullOrEmpty(u.UserName) &&
                            string.Equals(u.UserName, user.UserName, StringComparison.OrdinalIgnoreCase));

                        if (existing != null)
                        {
                            if (user.JoinTime.HasValue && (existing.JoinTime == null || user.JoinTime < existing.JoinTime))
                                existing.JoinTime = user.JoinTime;

                            if (user.LeaveTime.HasValue && (existing.LeaveTime == null || user.LeaveTime > existing.LeaveTime))
                                existing.LeaveTime = user.LeaveTime;
                        }
                        else
                        {
                            allUsers.Add(user);
                        }
                    }
                }

                if (response.Items.Count < pageSize)
                    break;

                pageNumber++;
            }
        }
        catch (ZoomException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting all participants for room: {RoomId}", roomId);
            throw new ZoomMeetingOperationException(
                $"Failed to get all participants: {ex.Message}",
                operation: "GetAllParticipants");
        }

        return allUsers;
    }

    /// <summary>
    /// Lấy danh sách tóm tắt meeting theo phòng với pagination
    /// </summary>
    public async Task<PaginatedResponse<SummaryItem>?> GetSummariesAsync(
        long roomId,
        MeetingDataRequest request,
        string? zoomCode = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            if (roomId <= 0)
                throw new ArgumentException("RoomId phải lớn hơn 0", nameof(roomId));

            if (request == null)
                throw new ArgumentNullException(nameof(request));

            // Lấy cấu hình Zoom (mặc định lấy cái đầu tiên nếu không chỉ định)
            zoomCode = zoomCode ?? _settings.Zoom?.FirstOrDefault()?.Code;
            var zoomConfig = GetZoomConfig(zoomCode!);

            // Xây dựng query string từ request
            var queryParams = BuildQueryString(request);
            var endpoint = $"/MeetingData/rooms/{roomId}/summaries{queryParams}";

            // Gọi API bên thứ 3 để lấy tóm tắt
            var response = await _zoomHttpClient.GetAsync<PaginatedResponse<SummaryItem>>(
                zoomConfig.Code,
                endpoint,
                cancellationToken);

            if (response == null)
            {
                return null;
            }

            return response;
        }
        catch (ZoomException)
        {
            throw;
        }
        catch (Exception ex) when (!(ex is ArgumentException || ex is ArgumentNullException))
        {
            _logger.LogError(ex, "Error getting summaries for room: {RoomId}", roomId);
            throw new ZoomMeetingOperationException(
                $"Failed to get summaries: {ex.Message}",
                operation: "GetSummaries");
        }
    }

    /// <summary>
    /// Lấy danh sách cảnh báo meeting theo phòng với pagination
    /// </summary>
    public async Task<PaginatedResponse<AlertItem>?> GetAlertsAsync(
        long roomId,
        MeetingDataRequest request,
        string? zoomCode = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            if (roomId <= 0)
                throw new ArgumentException("RoomId phải lớn hơn 0", nameof(roomId));

            if (request == null)
                throw new ArgumentNullException(nameof(request));

            // Lấy cấu hình Zoom (mặc định lấy cái đầu tiên nếu không chỉ định)
            zoomCode = zoomCode ?? _settings.Zoom?.FirstOrDefault()?.Code;
            var zoomConfig = GetZoomConfig(zoomCode!);

            // Xây dựng query string từ request
            var queryParams = BuildQueryString(request);
            var endpoint = $"/MeetingData/rooms/{roomId}/alerts{queryParams}";

            // Gọi API bên thứ 3 để lấy cảnh báo
            var response = await _zoomHttpClient.GetAsync<PaginatedResponse<AlertItem>>(
                zoomConfig.Code,
                endpoint,
                cancellationToken);

            if (response == null)
            {
                return null;
            }

            return response;
        }
        catch (ZoomException)
        {
            throw;
        }
        catch (Exception ex) when (!(ex is ArgumentException || ex is ArgumentNullException))
        {
            _logger.LogError(ex, "Error getting alerts for room: {RoomId}", roomId);
            throw new ZoomMeetingOperationException(
                $"Failed to get alerts: {ex.Message}",
                operation: "GetAlerts");
        }
    }

    #endregion

    #region Meeting URL Management

    /// <summary>
    /// Lấy URL bắt đầu buổi học (start-url) theo ID
    /// </summary>
    public async Task<ZoomUrlResponse?> GetStartUrlAsync(
        long id,
        string? zoomCode = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            if (id <= 0)
                throw new ArgumentException("ID phải lớn hơn 0", nameof(id));

            zoomCode = zoomCode ?? _settings.Zoom?.FirstOrDefault()?.Code;
            var zoomConfig = GetZoomConfig(zoomCode!);

            var response = await _zoomHttpClient.GetAsync<ZoomUrlResponse>(
                zoomConfig.Code,
                $"/ZoomBusiness/{id}/start-url",
                cancellationToken);

            return response;
        }
        catch (ZoomException)
        {
            throw;
        }
        catch (Exception ex) when (!(ex is ArgumentException))
        {
            _logger.LogError(ex, "Error getting start URL for meeting ID: {MeetingId}", id);
            throw new ZoomMeetingOperationException(
                $"Failed to get start URL: {ex.Message}",
                operation: "GetStartUrl");
        }
    }

    /// <summary>
    /// Lấy URL tham gia buổi học (join-url) theo ID
    /// </summary>
    public async Task<ZoomUrlResponse?> GetJoinUrlAsync(
        long id,
        string? zoomCode = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            if (id <= 0)
                throw new ArgumentException("ID phải lớn hơn 0", nameof(id));

            zoomCode = zoomCode ?? _settings.Zoom?.FirstOrDefault()?.Code;
            var zoomConfig = GetZoomConfig(zoomCode!);

            var response = await _zoomHttpClient.GetAsync<ZoomUrlResponse>(
                zoomConfig.Code,
                $"/ZoomBusiness/{id}/join-url",
                cancellationToken);

            return response;
        }
        catch (ZoomException)
        {
            throw;
        }
        catch (Exception ex) when (!(ex is ArgumentException))
        {
            _logger.LogError(ex, "Error getting join URL for meeting ID: {MeetingId}", id);
            throw new ZoomMeetingOperationException(
                $"Failed to get join URL: {ex.Message}",
                operation: "GetJoinUrl");
        }
    }

    #endregion
}

/// <summary>
/// Interface cho OneZoomService
/// </summary>
public interface IOneZoomService
{
    /// <summary>
    /// Tạo buổi họp Zoom mới
    /// </summary>
    Task<CreateZoomMeetingResponse?> CreateMeetingAsync(
        CreateZoomMeetingRequest request,
        string? zoomCode = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Lấy chi tiết buổi họp Zoom theo ID
    /// </summary>
    Task<CreateZoomMeetingResponse?> GetMeetingByIdAsync(
        long id,
        string? zoomCode = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Xóa buổi họp Zoom theo ID
    /// </summary>
    Task<bool> DeleteMeetingAsync(
        long id,
        string? zoomCode = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Lấy thông tin user hiện tại
    /// </summary>
    Task<UserInfoResponse?> GetCurrentUserAsync(
        string? zoomCode = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Lấy danh sách bản ghi meeting theo phòng với pagination
    /// </summary>
    Task<PaginatedResponse<RecordingItem>?> GetRecordingsAsync(
        long roomId,
        MeetingDataRequest request,
        string? zoomCode = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Lấy danh sách người tham gia meeting theo phòng với pagination
    /// </summary>
    Task<PaginatedResponse<ParticipantItem>?> GetParticipantsAsync(
        long roomId,
        MeetingDataRequest request,
        string? zoomCode = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Lấy toàn bộ danh sách người tham gia meeting theo phòng (tự động phân trang)
    /// </summary>
    Task<List<ParticipantItemUser>> GetAllParticipantsAsync(
        long roomId,
        string? zoomCode = null,
        int pageSize = 100,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Lấy danh sách tóm tắt meeting theo phòng với pagination
    /// </summary>
    Task<PaginatedResponse<SummaryItem>?> GetSummariesAsync(
        long roomId,
        MeetingDataRequest request,
        string? zoomCode = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Lấy danh sách cảnh báo meeting theo phòng với pagination
    /// </summary>
    Task<PaginatedResponse<AlertItem>?> GetAlertsAsync(
        long roomId,
        MeetingDataRequest request,
        string? zoomCode = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Lấy URL bắt đầu buổi học (start-url) theo ID
    /// </summary>
    Task<ZoomUrlResponse?> GetStartUrlAsync(
        long id,
        string? zoomCode = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Lấy URL tham gia buổi học (join-url) theo ID
    /// </summary>
    Task<ZoomUrlResponse?> GetJoinUrlAsync(
        long id,
        string? zoomCode = null,
        CancellationToken cancellationToken = default);
}
