using DS.Module.OnlineClass.Infrastructure.Configuration;
using DS.Module.OnlineClass.Infrastructure.Services.Authentication;
using DS.Module.OnlineClass.Infrastructure.Services.DTOs.GraphApi;
using DS.Module.OnlineClass.Infrastructure.Services.Exceptions;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Infrastructure.Services;

/// <summary>
/// Dịch vụ Microsoft Teams tương tác với Microsoft Graph API qua HTTP
/// </summary>
public class MSTeamsService : IMSTeamsService
{
    private readonly OnlineClassSettings _settings;
    private readonly IGraphHttpClientService _graphHttpClient;
    private readonly ILogger<MSTeamsService> _logger;

    public MSTeamsService(
        OnlineClassSettings settings,
        IGraphHttpClientService graphHttpClient,
        ILogger<MSTeamsService> logger)
    {
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _graphHttpClient = graphHttpClient ?? throw new ArgumentNullException(nameof(graphHttpClient));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    #region Helper Methods

    private OnlineClassSettings.TeamsOption GetTeamsConfig(string teamsCode)
    {
        var config = _settings.Teams?.FirstOrDefault(t => t.Code == teamsCode);
        if (config == null)
            throw new MSTeamsConfigurationNotFoundException(teamsCode);
        return config;
    }

    #endregion

    #region User Account Management

    public async Task<GraphUser?> CreateUserAccountAsync(
        string teamsCode, string username, string displayName, string password,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var config = GetTeamsConfig(teamsCode);

            var requestBody = new
            {
                accountEnabled = true,
                displayName = displayName,
                mailNickname = username,
                userPrincipalName = username + "@" + config.Domain,
                mail = username + "@" + config.Domain,
                passwordProfile = new
                {
                    forceChangePasswordNextSignIn = false,
                    password = password
                }
            };

            var graphUser = await _graphHttpClient.PostAsync<GraphUser>(
                teamsCode,
                "/users",
                requestBody,
                cancellationToken);

            return graphUser;
        }
        catch (Exception ex) when (!(ex is MSTeamsException))
        {
            _logger.LogError(ex, "Failed to create user account for {Username}", username);
            throw new MSTeamsUserOperationException(
                $"Failed to create user account for {username}: {ex.Message}",
                operation: "CreateUserAccount");
        }
    }

    public async Task<bool> ChangeUserPasswordAsync(
        string teamsCode, string userId, string newPassword
       , CancellationToken cancellationToken = default)
    {
        try
        {
            var requestBody = new
            {
                newPassword = newPassword,
                forceChangePasswordNextSignIn = false
            };

            await _graphHttpClient.PostAsync<object>(
                teamsCode,
                $"/users/{userId}/microsoft.graph.resetPassword",
                requestBody,
                cancellationToken);

            return true;
        }
        catch (Exception ex) when (!(ex is MSTeamsException))
        {
            _logger.LogError(ex, "Failed to reset password for user {UserId}", userId);
            throw new MSTeamsUserOperationException(
                $"Failed to reset password for user {userId}: {ex.Message}",
                userId,
                "ResetUserPassword");
        }
    }

    public async Task<bool> DeleteUserAccountAsync(string teamsCode, string userId,
        CancellationToken cancellationToken = default)
    {
        try
        {
            // Step 1: Delete user account (move to trash)
            await _graphHttpClient.DeleteAsync(
                teamsCode,
                $"/users/{userId}",
                cancellationToken);

            // Step 2: Wait 500ms before permanently deleting from deleted items
            //await Task.Delay(500, cancellationToken);

            //// Step 3: Permanently delete from deleted items
            //try
            //{
            //    await _graphHttpClient.DeleteAsync(
            //        teamsCode,
            //        $"/directory/deletedItems/{userId}",
            //        cancellationToken);
            //}
            //catch (Exception ex)
            //{
            //    _logger.LogWarning(ex, "Failed to permanently delete user {UserId} from trash, user moved to trash only", userId);
            //}

            return true;
        }
        catch (Exception ex) when (!(ex is MSTeamsException))
        {
            _logger.LogError(ex, "Failed to delete user account {UserId}", userId);
            throw new MSTeamsUserOperationException(
                $"Failed to delete user account {userId}: {ex.Message}",
                userId,
                "DeleteUserAccount");
        }
    }

    public async Task<bool> AssignUserToGroupAsync(
        string teamsCode, string groupId, string userId,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var requestBody = new Dictionary<string, object>
            {
                { "@odata.id", $"https://graph.microsoft.com/v1.0/users/{userId}" }
            };

            await _graphHttpClient.PostAsync<object>(
                teamsCode,
                $"/groups/{groupId}/members/$ref",
                requestBody,
                cancellationToken);

            return true;
        }
        catch (Exception ex) when (!(ex is MSTeamsException))
        {
            _logger.LogError(ex, "Failed to assign user {UserId} to group {GroupId}", userId, groupId);
            throw new MSTeamsUserOperationException(
                $"Failed to assign user {userId} to group {groupId}: {ex.Message}",
                userId,
                "AssignUserToGroup");
        }
    }

    public async Task<bool> AssignLicenseToUserAsync(
        string teamsCode, string userId, string licenseSkuId,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var requestBody = new
            {
                addLicenses = new[]
                {
                    new
                    {
                        skuId = licenseSkuId,
                        disabledPlans = new string[] { }
                    }
                },
                removeLicenses = new string[] { }
            };

            await _graphHttpClient.PostAsync<object>(
                teamsCode,
                $"/users/{userId}/assignLicense",
                requestBody,
                cancellationToken);

            return true;
        }
        catch (Exception ex) when (!(ex is MSTeamsException))
        {
            _logger.LogError(ex, "Failed to assign license {LicenseSkuId} to user {UserId}", licenseSkuId, userId);
            throw new MSTeamsUserOperationException(
                $"Failed to assign license {licenseSkuId} to user {userId}: {ex.Message}",
                userId,
                "AssignLicenseToUser");
        }
    }

    public async Task<GraphUser?> CreateUserAccountWithGroupAsync(
        string teamsCode, string userEmail, string displayName, string password,
        string? groupId = null,
        CancellationToken cancellationToken = default)
    {
        GraphUser? newUser = null;
        try
        {
            var config = GetTeamsConfig(teamsCode);
            // Step 1: Create user account
            newUser = await CreateUserAccountAsync(teamsCode, userEmail, displayName, password, cancellationToken);

            if (newUser?.Id == null)
            {
                throw new MSTeamsUserOperationException(
                    "Failed to create user account: no user ID returned",
                    operation: "CreateUserAccountWithSetup");
            }

            var userId = newUser.Id;
            groupId = groupId ?? config.GroupId;
            // Step 2: Assign to Group if provided
            if (!string.IsNullOrEmpty(groupId))
            {
                try
                {
                    await AssignUserToGroupAsync(teamsCode, groupId, userId, cancellationToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Failed to assign user {UserId} to group {GroupId}", userId, groupId);
                }
            }

            return newUser;
        }
        catch (Exception ex) when (!(ex is MSTeamsException))
        {
            _logger.LogError(ex, "Failed to create and setup user account for {UserEmail}", userEmail);
            throw new MSTeamsUserOperationException(
                $"Failed to create and setup user account for {userEmail}: {ex.Message}",
                operation: "CreateUserAccountWithSetup");
        }
    }

    #endregion

    #region Meeting Management

    public async Task<GraphMeeting?> CreateMeetingAsync(
        string teamsCode, string userId, string subject,
        DateTime startDateTime, DateTime endDateTime, string? description = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var config = GetTeamsConfig(teamsCode);
            var requestBody = new
            {
                subject = subject,
                startDateTime = startDateTime.ToUniversalTime().ToString("O"),
                endDateTime = endDateTime.ToUniversalTime().ToString("O"),
                allowAttendeeToEnableCamera = true,
                allowRecording = true,
                description = description,
                lobbyBypassSettings = new
                {
                    scope = "everyone"
                }

            };

            var graphMeeting = await _graphHttpClient.PostAsync<GraphMeeting>(
                teamsCode,
                $"/users/{userId}/onlineMeetings",
                requestBody,
                cancellationToken);

            return graphMeeting;
        }
        catch (Exception ex) when (!(ex is MSTeamsException))
        {
            _logger.LogError(ex, "Failed to create meeting '{Subject}'", subject);
            throw new MSTeamsMeetingOperationException(
                $"Failed to create meeting '{subject}': {ex.Message}",
                operation: "CreateMeeting");
        }
    }

    public async Task<GraphMeeting> UpdateMeetingAsync(
        string teamsCode, string userId, string meetingId, string? subject = null,
        DateTime? startDateTime = null, DateTime? endDateTime = null, string? description = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var config = GetTeamsConfig(teamsCode);
            var bodyDict = new Dictionary<string, object>();

            if (!string.IsNullOrEmpty(subject))
                bodyDict["subject"] = subject;

            if (startDateTime.HasValue)
                bodyDict["startDateTime"] = startDateTime.Value.ToUniversalTime().ToString("O");

            if (endDateTime.HasValue)
                bodyDict["endDateTime"] = endDateTime.Value.ToUniversalTime().ToString("O");

            var graphMeeting = await _graphHttpClient.PatchAsync<GraphMeeting>(
                teamsCode,
                $"/users/{config.UserServiceId}/onlineMeetings/{meetingId}",
                bodyDict.Count > 0 ? bodyDict : null,
                cancellationToken);

            if (graphMeeting == null)
                throw new MSTeamsMeetingOperationException(
                    $"Failed to update meeting {meetingId}: no response",
                    meetingId,
                    "UpdateMeeting");

            return graphMeeting;
        }
        catch (Exception ex) when (!(ex is MSTeamsException))
        {
            _logger.LogError(ex, "Failed to update meeting {MeetingId}", meetingId);
            throw new MSTeamsMeetingOperationException(
                $"Failed to update meeting {meetingId}: {ex.Message}",
                meetingId,
                "UpdateMeeting");
        }
    }

    public async Task<bool> DeleteMeetingAsync(string teamsCode, string userId, string meetingId,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var config = GetTeamsConfig(teamsCode);
            await _graphHttpClient.DeleteAsync(
                teamsCode,
                $"/users/{config.UserServiceId}/onlineMeetings/{meetingId}",
                cancellationToken);

            return true;
        }
        catch (Exception ex) when (!(ex is MSTeamsException))
        {
            _logger.LogError(ex, "Failed to delete meeting {MeetingId}", meetingId);
            throw new MSTeamsMeetingOperationException(
                $"Failed to delete meeting {meetingId}: {ex.Message}",
                meetingId,
                "DeleteMeeting");
        }
    }

    public async Task<bool> AddMeetingOrganizerAsync(
        string teamsCode, string userId, string meetingId, string organizerEmail,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var config = GetTeamsConfig(teamsCode);
            var requestBody = new
            {
                organizers = new[]
                {
                    new
                    {
                        identity = new
                        {
                            user = new
                            {
                                id = organizerEmail
                            }
                        }
                    }
                }
            };

            await _graphHttpClient.PatchAsync<GraphMeeting>(
                teamsCode,
                $"/users/{config.UserServiceId}/onlineMeetings/{meetingId}",
                requestBody,
                cancellationToken);

            return true;
        }
        catch (Exception ex) when (!(ex is MSTeamsException))
        {
            _logger.LogError(ex, "Failed to add organizer {OrganizerEmail} to meeting {MeetingId}",
                organizerEmail, meetingId);
            throw new MSTeamsMeetingOperationException(
                $"Failed to add organizer {organizerEmail} to meeting {meetingId}: {ex.Message}",
                meetingId,
                "AddMeetingOrganizer");
        }
    }

    public async Task<List<GraphAttendanceRecordUser>> GetAllParticipantsAsync(
        string teamsCode,
        string userId,
        string meetingId,
        CancellationToken cancellationToken = default)
    {
        try
        {
            // Bước 1: Lấy danh sách attendance reports (trả về tối đa 50 report gần nhất)
            // Endpoint: GET /users/{userId}/onlineMeetings/{meetingId}/attendanceReports
            var reportsResponse = await _graphHttpClient.GetAsync<GraphAttendanceReportList>(
                teamsCode,
                $"/users/{userId}/onlineMeetings/{meetingId}/attendanceReports",
                cancellationToken);

            if (reportsResponse?.Value == null || reportsResponse.Value.Count == 0)
                return [];

            var validReportIds = reportsResponse.Value
                .Where(r => !string.IsNullOrEmpty(r.Id))
                .Select(r => r.Id!)
                .ToList();

            if (validReportIds.Count == 0)
                return [];

            // Bước 2: Lấy attendance records của tất cả reports song song
            var fetchTasks = validReportIds.Select(reportId =>
                _graphHttpClient.GetAsync<GraphAttendanceRecordList>(
                    teamsCode,
                    $"/users/{userId}/onlineMeetings/{meetingId}/attendanceReports/{reportId}/attendanceRecords",
                    cancellationToken));

            var allResults = await Task.WhenAll(fetchTasks);

            // Bước 3: Gộp tất cả records, dedup theo DisplayName
            // key: DisplayName (case-insensitive), value: tất cả intervals gom lại
            var mergedIntervals = new Dictionary<string, List<GraphAttendanceInterval>>(StringComparer.OrdinalIgnoreCase);
            var mergedMeta = new Dictionary<string, (string? Id, string? DisplayName)>(StringComparer.OrdinalIgnoreCase);

            foreach (var result in allResults)
            {
                foreach (var record in result?.Value ?? [])
                {
                    var key = record.Identity?.DisplayName ?? string.Empty;

                    if (string.IsNullOrEmpty(key))
                        continue;

                    if (!mergedIntervals.ContainsKey(key))
                    {
                        mergedIntervals[key] = [];
                        mergedMeta[key] = (record.Identity?.Id, record.Identity?.DisplayName);
                    }

                    mergedIntervals[key].AddRange(record.AttendanceIntervals);
                }
            }

            // Bước 4: Tổng hợp thành GraphAttendanceRecordUser
            // joinDateTime = thời gian đầu tiên, leaveDateTime = thời gian cuối cùng, durationInSeconds = tổng cộng
            return [.. mergedIntervals.Select(kvp =>
            {
                var intervals = kvp.Value;
                var meta = mergedMeta[kvp.Key];

                var joinDateTime = intervals
                    .Where(i => i.JoinDateTime.HasValue)
                    .Select(i => i.JoinDateTime!.Value)
                    .DefaultIfEmpty()
                    .Min();

                var leaveDateTime = intervals
                    .Where(i => i.LeaveDateTime.HasValue)
                    .Select(i => i.LeaveDateTime!.Value)
                    .DefaultIfEmpty()
                    .Max();

                var totalDuration = intervals.Sum(i => i.DurationInSeconds ?? 0);

                return new GraphAttendanceRecordUser
                {
                    Id = meta.Id,
                    DisplayName = meta.DisplayName,
                    JoinDateTime = joinDateTime == default ? null : joinDateTime,
                    LeaveDateTime = leaveDateTime == default ? null : leaveDateTime,
                    DurationInSeconds = totalDuration,
                    AttendanceIntervals = intervals
                };
            })];
        }
        catch (Exception ex) when (!(ex is MSTeamsException))
        {
            _logger.LogError(ex, "Failed to get participants for meeting {MeetingId}", meetingId);
            throw new MSTeamsMeetingOperationException(
                $"Failed to get participants for meeting {meetingId}: {ex.Message}",
                meetingId,
                "GetAllParticipants");
        }
    }

    #endregion
}
