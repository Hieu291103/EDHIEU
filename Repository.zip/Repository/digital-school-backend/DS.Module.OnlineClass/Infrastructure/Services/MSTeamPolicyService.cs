using DS.Module.OnlineClass.Infrastructure.Configuration;
using Microsoft.Extensions.Logging;
using System.Text;
using System.Text.Json;

namespace DS.Module.OnlineClass.Infrastructure.Services;

/// <summary>
/// Dịch vụ MS Teams Policy Registration tương tác với Teams Policy API qua HTTP
/// </summary>
public class MSTeamPolicyService : IMSTeamPolicyService
{
    private readonly OnlineClassSettings _settings;
    private readonly HttpClient _httpClient;
    private readonly ILogger<MSTeamPolicyService> _logger;

    public MSTeamPolicyService(
        OnlineClassSettings settings,
        HttpClient httpClient,
        ILogger<MSTeamPolicyService> logger)
    {
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<TeamPolicyDto> AssignPolicyAsync(List<string> users, CancellationToken cancellationToken = default)
    {
        try
        {
            var config = _settings.TeamsPolicyRegUser;
            if (config == null)
            {
                _logger.LogError("TeamsPolicyRegUser configuration is not configured");
                throw new InvalidOperationException("TeamsPolicyRegUser configuration is not configured");
            }

            if (string.IsNullOrWhiteSpace(config.ApiUrl) || string.IsNullOrWhiteSpace(config.ApiKey))
            {
                _logger.LogError("TeamsPolicyRegUser ApiUrl or ApiKey is not configured");
                throw new InvalidOperationException("TeamsPolicyRegUser ApiUrl or ApiKey is not configured");
            }

            var jsonContent = JsonSerializer.Serialize(users);
            var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            // Add X-API-KEY header
            _httpClient.DefaultRequestHeaders.Remove("X-API-KEY");
            _httpClient.DefaultRequestHeaders.Add("X-API-KEY", config.ApiKey);

            var response = await _httpClient.PostAsync(config.ApiUrl, content, cancellationToken);

            if (response.IsSuccessStatusCode)
            {
                _logger.LogInformation("Successfully assigned policy to user");
                var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);
                var assignedUsers = JsonSerializer.Deserialize<TeamPolicyDto>(responseContent);
                return assignedUsers ?? new TeamPolicyDto() { Success = true, Data = new List<TeamPolicyItemDto>() };
            }

            var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
            _logger.LogError("Failed to assign policy. Status: {StatusCode}, Response: {Response}",
                response.StatusCode, errorContent);
            return new TeamPolicyDto()
            {
                Success = false,
                Error = $"Failed to assign policy. Status: {response.StatusCode}, Response: {errorContent}"
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred while assigning policy");
            throw;
        }
    }
}

