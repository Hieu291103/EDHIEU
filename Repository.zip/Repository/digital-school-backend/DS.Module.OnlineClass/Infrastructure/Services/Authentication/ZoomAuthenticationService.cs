using DS.Module.OnlineClass.Infrastructure.Configuration;
using DS.Module.OnlineClass.Infrastructure.Services.Exceptions;
using Microsoft.Extensions.Logging;
using System.Net.Http.Json;
using System.Text.Json.Serialization;

namespace DS.Module.OnlineClass.Infrastructure.Services.Authentication;

/// <summary>
/// Service để quản lý authentication với Zoom API
/// </summary>
public interface IZoomAuthenticationService
{
    /// <summary>
    /// Lấy access token cho Zoom configuration
    /// </summary>
    Task<string> GetAccessTokenAsync(OnlineClassSettings.ZoomOption zoomConfig, CancellationToken cancellationToken = default);

    /// <summary>
    /// Xóa cached token để force refresh
    /// </summary>
    void InvalidateToken(OnlineClassSettings.ZoomOption zoomConfig);

    /// <summary>
    /// Xóa tất cả cached tokens
    /// </summary>
    void InvalidateAllTokens();
}

/// <summary>
/// Implementation của IZoomAuthenticationService
/// Quản lý access tokens với caching và auto-refresh
/// </summary>
public class ZoomAuthenticationService : IZoomAuthenticationService
{
    public const string HeaderTokenKey = "BFEDB4BF-FDBA-4573-9218-26AC258F801A";
    private class CachedToken
    {
        public string AccessToken { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public DateTime ExpiresAt { get; set; }
    }

    private class TokenResponse
    {
        [JsonPropertyName("tokenType")]
        public string TokenType { get; set; } = string.Empty;

        [JsonPropertyName("accessToken")]
        public string AccessToken { get; set; } = string.Empty;

        [JsonPropertyName("expiresIn")]
        public int ExpiresIn { get; set; }

        [JsonPropertyName("refreshToken")]
        public string RefreshToken { get; set; } = string.Empty;
    }

    private readonly Dictionary<string, CachedToken> _tokenCache = new();
    private readonly object _lockObject = new();
    private readonly HttpClient _httpClient;
    private readonly ILogger<ZoomAuthenticationService> _logger;

    // Cache TTL: 55 phút (tokens thường expire sau 60 phút)
    private readonly TimeSpan _cacheTtl = TimeSpan.FromMinutes(55);

    public ZoomAuthenticationService(
        HttpClient httpClient,
        ILogger<ZoomAuthenticationService> logger)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<string> GetAccessTokenAsync(
        OnlineClassSettings.ZoomOption zoomConfig,
        CancellationToken cancellationToken = default)
    {
        if (zoomConfig == null)
            throw new ArgumentNullException(nameof(zoomConfig));

        var cacheKey = $"{zoomConfig.Code}";

        // Kiểm tra cache
        lock (_lockObject)
        {
            if (_tokenCache.TryGetValue(cacheKey, out var cachedToken))
            {
                if (DateTime.UtcNow < cachedToken.ExpiresAt)
                {
                    return cachedToken.AccessToken;
                }

                // Cache expired - remove it
                _tokenCache.Remove(cacheKey);
            }
        }


        // Request new token từ Zoom
        var tokenUrl = $"{zoomConfig.ApiUrl.TrimEnd('/')}/Accounts/token";
        var request = new HttpRequestMessage(HttpMethod.Post, tokenUrl)
        {
            Content = JsonContent.Create(new
            {
                email = zoomConfig.ApiKey,
                password = zoomConfig.ApiSecret
            })
        };
        request.Headers.Add("X-TOKEN", HeaderTokenKey);
        try
        {
            var response = await _httpClient.SendAsync(request, cancellationToken);
            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);
            var tokenResponse = System.Text.Json.JsonSerializer.Deserialize<TokenResponse>(responseBody);

            if (tokenResponse?.AccessToken == null)
            {
                throw new ZoomAuthenticationException(
                    "Failed to get access token: no token in response",
                    zoomConfig.ApiUrl);
            }

            // Cache token với TTL
            var now = DateTime.UtcNow;
            var expiresIn = tokenResponse.ExpiresIn > 0 ? tokenResponse.ExpiresIn : 3600;
            var cachedEntry = new CachedToken
            {
                AccessToken = tokenResponse.AccessToken,
                CreatedAt = now,
                ExpiresAt = now.AddSeconds(expiresIn).Subtract(TimeSpan.FromMinutes(5)) // Refresh 5 minutes before expiry
            };

            lock (_lockObject)
            {
                _tokenCache[cacheKey] = cachedEntry;
            }

            return tokenResponse.AccessToken;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error while getting token for Zoom config {ZoomCode}", zoomConfig.Code);
            throw new ZoomAuthenticationException(
                $"Failed to authenticate with Zoom: {ex.Message}",
                zoomConfig.ApiUrl,
                ex);
        }
        catch (ZoomException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error while getting token for Zoom config {ZoomCode}", zoomConfig.Code);
            throw new ZoomAuthenticationException(
                $"Failed to get access token: {ex.Message}",
                zoomConfig.ApiUrl,
                ex);
        }
    }

    public void InvalidateToken(OnlineClassSettings.ZoomOption zoomConfig)
    {
        if (zoomConfig == null)
            return;

        var cacheKey = $"{zoomConfig.Code}";
        lock (_lockObject)
        {
            _tokenCache.Remove(cacheKey);
        }
        _logger.LogDebug("Invalidated token cache for Zoom config {ZoomCode}", zoomConfig.Code);
    }

    public void InvalidateAllTokens()
    {
        lock (_lockObject)
        {
            _tokenCache.Clear();
        }
        _logger.LogDebug("Invalidated all Zoom token caches");
    }
}
