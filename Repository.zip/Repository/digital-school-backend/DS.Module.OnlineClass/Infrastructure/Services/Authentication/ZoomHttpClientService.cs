using DS.Module.OnlineClass.Infrastructure.Configuration;
using DS.Module.OnlineClass.Infrastructure.Services.Exceptions;
using Microsoft.Extensions.Logging;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace DS.Module.OnlineClass.Infrastructure.Services.Authentication;

/// <summary>
/// Service để tương tác với Zoom API qua HTTP
/// </summary>
public interface IZoomHttpClientService
{
    /// <summary>
    /// Thực hiện GET request đến Zoom API
    /// </summary>
    Task<T?> GetAsync<T>(
        string zoomCode,
        string endpoint,
        CancellationToken cancellationToken = default) where T : class;

    /// <summary>
    /// Thực hiện POST request đến Zoom API
    /// </summary>
    Task<T?> PostAsync<T>(
        string zoomCode,
        string endpoint,
        object? body = null,
        CancellationToken cancellationToken = default) where T : class;

    /// <summary>
    /// Thực hiện PATCH request đến Zoom API
    /// </summary>
    Task<T?> PatchAsync<T>(
        string zoomCode,
        string endpoint,
        object? body = null,
        CancellationToken cancellationToken = default) where T : class;

    /// <summary>
    /// Thực hiện DELETE request đến Zoom API
    /// </summary>
    Task DeleteAsync(
        string zoomCode,
        string endpoint,
        CancellationToken cancellationToken = default);
}

/// <summary>
/// Implementation của IZoomHttpClientService
/// </summary>
public class ZoomHttpClientService : IZoomHttpClientService
{
    private readonly HttpClient _httpClient;
    private readonly OnlineClassSettings _settings;
    private readonly IZoomAuthenticationService _authService;
    private readonly ILogger<ZoomHttpClientService> _logger;

    private readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions
    {
        PropertyNameCaseInsensitive = true,
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    public ZoomHttpClientService(
        HttpClient httpClient,
        OnlineClassSettings settings,
        IZoomAuthenticationService authService,
        ILogger<ZoomHttpClientService> logger)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _authService = authService ?? throw new ArgumentNullException(nameof(authService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<T?> GetAsync<T>(
        string zoomCode,
        string endpoint,
        CancellationToken cancellationToken = default) where T : class
    {
        return await SendRequestAsync<T>(zoomCode, endpoint, HttpMethod.Get, null, cancellationToken);
    }

    public async Task<T?> PostAsync<T>(
        string zoomCode,
        string endpoint,
        object? body = null,
        CancellationToken cancellationToken = default) where T : class
    {
        return await SendRequestAsync<T>(zoomCode, endpoint, HttpMethod.Post, body, cancellationToken);
    }

    public async Task<T?> PatchAsync<T>(
        string zoomCode,
        string endpoint,
        object? body = null,
        CancellationToken cancellationToken = default) where T : class
    {
        return await SendRequestAsync<T>(zoomCode, endpoint, HttpMethod.Patch, body, cancellationToken);
    }

    public async Task DeleteAsync(
        string zoomCode,
        string endpoint,
        CancellationToken cancellationToken = default)
    {
        await SendRequestAsync<object>(zoomCode, endpoint, HttpMethod.Delete, null, cancellationToken);
    }

    private async Task<T?> SendRequestAsync<T>(
        string zoomCode,
        string endpoint,
        HttpMethod method,
        object? body = null,
        CancellationToken cancellationToken = default) where T : class
    {
        try
        {
            // Get Zoom configuration
            var config = _settings.Zoom?.FirstOrDefault(z => z.Code == zoomCode);
            if (config == null)
                throw new ZoomConfigurationNotFoundException(zoomCode);

            // Get access token
            var accessToken = await _authService.GetAccessTokenAsync(config, cancellationToken);

            // Build request URL
            var url = endpoint.StartsWith("http") ? endpoint : $"{config.ApiUrl.TrimEnd('/')}{endpoint}";
            var request = new HttpRequestMessage(method, url);

            // Add authorization header
            request.Headers.Add("Authorization", $"Bearer {accessToken}");
            request.Headers.Add("X-TOKEN", ZoomAuthenticationService.HeaderTokenKey);
            // Add common headers
            request.Headers.Add("Accept", "application/json");

            // Add body if provided
            if (body != null && method != HttpMethod.Get && method != HttpMethod.Delete)
            {
                var jsonContent = JsonSerializer.Serialize(body, _jsonOptions);
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
            }

            // Send request
            var response = await _httpClient.SendAsync(request, cancellationToken);

            if (response.StatusCode == System.Net.HttpStatusCode.BadRequest)
            {
                return null;
            }

            // Handle response
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Zoom API error: {StatusCode} {ErrorContent}", response.StatusCode, errorContent);

                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    return null;
                }

                throw new ZoomApiException(
                    $"Zoom API error: {response.StatusCode}",
                    response.StatusCode.ToString(),
                    errorContent);
            }

            // Parse response
            if (method == HttpMethod.Delete || response.StatusCode == System.Net.HttpStatusCode.NoContent)
            {
                return null;
            }

            var content = await response.Content.ReadAsStringAsync(cancellationToken);
            if (string.IsNullOrEmpty(content))
            {
                return null;
            }

            var result = JsonSerializer.Deserialize<T>(content, _jsonOptions);
            return result;
        }
        catch (ZoomException)
        {
            throw;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP request failed for endpoint {Endpoint}", endpoint);
            throw new ZoomApiException(
                $"HTTP request failed: {ex.Message}",
                "HTTP_ERROR",
                ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error sending request to {Endpoint}", endpoint);
            throw new ZoomApiException(
                $"Error sending request: {ex.Message}",
                "REQUEST_ERROR",
                ex.Message);
        }
    }
}
