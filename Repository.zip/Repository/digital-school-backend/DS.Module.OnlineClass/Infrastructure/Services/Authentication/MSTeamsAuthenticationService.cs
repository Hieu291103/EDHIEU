using DS.Module.OnlineClass.Infrastructure.Configuration;
using DS.Module.OnlineClass.Infrastructure.Services.Exceptions;
using Microsoft.Extensions.Logging;
using System.Text;
using System.Text.Json.Serialization;

namespace DS.Module.OnlineClass.Infrastructure.Services.Authentication;

/// <summary>
/// Service để quản lý authentication với Microsoft Graph API sử dụng OAuth2
/// </summary>
public interface IMSTeamsAuthenticationService
{
    /// <summary>
    /// Lấy access token cho Teams configuration
    /// </summary>
    Task<string> GetAccessTokenAsync(OnlineClassSettings.TeamsOption teamsConfig, CancellationToken cancellationToken = default);

    /// <summary>
    /// Xóa cached token để force refresh
    /// </summary>
    void InvalidateToken(OnlineClassSettings.TeamsOption teamsConfig);

    /// <summary>
    /// Xóa tất cả cached tokens
    /// </summary>
    void InvalidateAllTokens();
}

/// <summary>
/// Implementation của IMSTeamsAuthenticationService
/// Quản lý access tokens với caching và auto-refresh
/// </summary>
public class MSTeamsAuthenticationService : IMSTeamsAuthenticationService
{
    private class CachedToken
    {
        public string AccessToken { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public DateTime ExpiresAt { get; set; }
    }

    private class TokenResponse
    {
        [JsonPropertyName("access_token")]
        public string AccessToken { get; set; } = string.Empty;

        [JsonPropertyName("token_type")]
        public string TokenType { get; set; } = string.Empty;

        [JsonPropertyName("expires_in")]
        public int ExpiresIn { get; set; }

        [JsonPropertyName("ext_expires_in")]
        public int ExtExpiresIn { get; set; }
    }

    private readonly Dictionary<string, CachedToken> _tokenCache = new();
    private readonly object _lockObject = new();
    private readonly HttpClient _httpClient;
    private readonly ILogger<MSTeamsAuthenticationService> _logger;

    // Cache TTL: 55 phút (tokens thường expire sau 60 phút)
    private readonly TimeSpan _cacheTtl = TimeSpan.FromMinutes(55);

    public MSTeamsAuthenticationService(
        HttpClient httpClient,
        ILogger<MSTeamsAuthenticationService> logger)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<string> GetAccessTokenAsync(
        OnlineClassSettings.TeamsOption teamsConfig,
        CancellationToken cancellationToken = default)
    {
        if (teamsConfig == null)
            throw new ArgumentNullException(nameof(teamsConfig));

        var cacheKey = $"{teamsConfig.TenantId}_{teamsConfig.ClientId}";

        // Kiểm tra cache
        lock (_lockObject)
        {
            if (_tokenCache.TryGetValue(cacheKey, out var cachedToken))
            {
                if (DateTime.UtcNow < cachedToken.ExpiresAt)
                {
                    _logger.LogDebug("Using cached token for {TenantId}", teamsConfig.TenantId);
                    return cachedToken.AccessToken;
                }

                // Cache expired - remove it
                _tokenCache.Remove(cacheKey);
            }
        }

        _logger.LogDebug("Requesting new token for {TenantId}", teamsConfig.TenantId);

        // Request new token từ Azure AD
        var tokenUrl = $"https://login.microsoftonline.com/{teamsConfig.TenantId}/oauth2/v2.0/token";

        var requestContent = new FormUrlEncodedContent(new[]
        {
            new KeyValuePair<string, string>("client_id", teamsConfig.ClientId),
            new KeyValuePair<string, string>("client_secret", teamsConfig.ClientSecret),
            new KeyValuePair<string, string>("scope", "https://graph.microsoft.com/.default"),
            new KeyValuePair<string, string>("grant_type", "client_credentials")
        });

        try
        {
            var response = await _httpClient.PostAsync(tokenUrl, requestContent, cancellationToken);
            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);
            var tokenResponse = System.Text.Json.JsonSerializer.Deserialize<TokenResponse>(responseBody);

            if (tokenResponse?.AccessToken == null)
            {
                throw new MSTeamsAuthenticationException(
                    "Failed to get access token: no token in response",
                    teamsConfig.TenantId);
            }

            // Cache token với TTL
            var now = DateTime.UtcNow;
            var expiresIn = tokenResponse.ExpiresIn > 0 ? tokenResponse.ExpiresIn : 3600;
            var cachedEntry = new CachedToken
            {
                AccessToken = tokenResponse.AccessToken,
                CreatedAt = now,
                ExpiresAt = now.AddSeconds(expiresIn).Subtract(TimeSpan.FromMinutes(5)) // Refresh 5 minutes before expiry
            };

            lock (_lockObject)
            {
                _tokenCache[cacheKey] = cachedEntry;
            }

            _logger.LogDebug("Successfully obtained new token for {TenantId}", teamsConfig.TenantId);
            return tokenResponse.AccessToken;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error while getting token for {TenantId}", teamsConfig.TenantId);
            throw new MSTeamsAuthenticationException(
                $"Failed to authenticate with Azure AD: {ex.Message}",
                teamsConfig.TenantId,
                ex);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error while getting token for {TenantId}", teamsConfig.TenantId);
            throw new MSTeamsAuthenticationException(
                $"Failed to get access token: {ex.Message}",
                teamsConfig.TenantId,
                ex);
        }
    }

    public void InvalidateToken(OnlineClassSettings.TeamsOption teamsConfig)
    {
        if (teamsConfig == null)
            return;

        var cacheKey = $"{teamsConfig.TenantId}_{teamsConfig.ClientId}";
        lock (_lockObject)
        {
            _tokenCache.Remove(cacheKey);
        }
        _logger.LogDebug("Invalidated token cache for {TenantId}", teamsConfig.TenantId);
    }

    public void InvalidateAllTokens()
    {
        lock (_lockObject)
        {
            _tokenCache.Clear();
        }
        _logger.LogDebug("Invalidated all token caches");
    }
}
