using DS.Shared.Core.Application.Abstractions.Localization;

namespace DS.Module.OnlineClass.Infrastructure.Localization
{
    /// <summary>
    /// Localization provider cho OnlineClass module
    /// Priority = 100 để override Core messages
    /// </summary>
    public class OnlineClassLocalizationProvider : ILocalizationProvider
    {
        public int Priority => 100;

        private static readonly Dictionary<string, Dictionary<string, string>> Messages = new()
        {
            ["vi"] = new Dictionary<string, string>
            {
                // Tenant errors
                ["OnlineClassTenantDoNotExist"] = "Tổ chức/Trường học không tồn tại",
                ["OnlineClassTenantSchoolDoNotExist"] = "Tổ chức/Trường học không có ID trường",

                // OnlineClassTenant management errors
                ["OnlineClassTenantNotFound"] = "Không tìm thấy cấu hình lớp học trực tuyến",
                ["OnlineClassTenantProviderAlreadyExists"] = "Loại nhà cung cấp '{0}' đã được cấu hình cho tổ chức/trường",
                ["OnlineClassTenantExpired"] = "Cấu hình lớp học trực tuyến đã hết hạn sử dụng",
                ["OnlineClassTenantNotYetStarted"] = "Cấu hình lớp học trực tuyến chưa bắt đầu sử dụng",
                ["OnlineClassTenantSchoolIdRequired"] = "ID trường là bắt buộc",
                ["OnlineClassTenantProviderConnectRequired"] = "Thông tin kết nối nhà cung cấp là bắt buộc",
                ["OnlineClassTenantStartDateAfterExpireDate"] = "Ngày bắt đầu phải nhỏ hơn ngày hết hạn",
                ["OnlineClassServiceNotAvailableForSchool"] = "Trường của bạn không được cung cấp dịch vụ",

                // LessonMeeting management errors
                ["LessonMeetingNotFound"] = "Không tìm thấy buổi học trực tuyến",
                ["LessonMeetingAlreadyStarted"] = "Buổi học trực tuyến đã bắt đầu",
                ["LessonMeetingAlreadyEnded"] = "Buổi học trực tuyến đã kết thúc",
                ["LessonMeetingNotActive"] = "Buổi học trực tuyến chưa mở hoặc đã kết thúc",
                ["LessonMeetingUrlRequired"] = "Đường dẫn buổi học trực tuyến là bắt buộc",
                ["LessonMeetingInvalidTimeRange"] = "Thời gian bắt đầu phải nhỏ hơn thời gian kết thúc",
                ["LessonMeetingClassNotFound"] = "Lớp học không tồn tại hoặc không hợp lệ",
                ["LessonMeetingClassNotPermitted"] = "Lớp học không có quyền tạo buổi học trực tuyến",
                ["LessonMeetingCreatorNotPermitted"] = "Tài khoản của bạn không có quyền tạo buổi học trực tuyến",
                ["FailedToCreateOnlineMeeting"] = "Tạo buổi học trực tuyến thất bại",
                ["LessonMeetingTimeConflict"] = "Lớp học đã có buổi học trùng với khoảng thời gian bạn khai báo",
                ["LessonMeetingCreatorTimeConflict"] = "Bạn đã có buổi học trùng với khoảng thời gian bạn khai báo",
                ["LessonMeetingCannotCancel"] = "Không thể hủy bỏ buổi học vì buổi học đã kết thúc hoặc đang diễn ra",
                ["LessonMeetingCannotUpdate"] = "Không thể cập nhật buổi học vì buổi học đã kết thúc",
                ["FailedToCancelOnlineMeeting"] = "Hủy bỏ buổi học trực tuyến thất bại",

                // LessonParticipant management errors
                ["LessonParticipantNotFound"] = "Không tìm thấy người tham gia buổi học",
                ["LessonParticipantAlreadyExists"] = "Người tham gia đã tồn tại trong buổi học",
                ["ParticipantListEmpty"] = "Danh sách người không được để trống",
                ["TenantClassParticipantListEmpty"] = "Danh sách lớp thay đổi không được để trống",

                // AccountMeeting management errors
                ["AccountMeetingNotFound"] = "Không tìm thấy tài khoản cuộc họp",
                ["AccountMeetingAlreadyExists"] = "Tài khoản cuộc họp đã tồn tại",
                ["AccountMeetingConnectionFailed"] = "Kết nối tài khoản cuộc họp thất bại",
                ["AccountMeetingInvalidCredentials"] = "Thông tin xác thực tài khoản cuộc họp không hợp lệ",
                ["CreateAccountMeetingFailed"] = "Tạo tài khoản cuộc họp cho {0} thất bại",
                ["DeleteAccountMeetingFailed"] = "Xóa tài khoản cuộc họp cho {0} thất bại",
                ["ResetPasswordAccountMeetingFailed"] = "Đặt lại mật khẩu tài khoản cuộc họp cho {0} thất bại",
                ["MeetingUserIdsLimitExceeded"] = "Danh sách ID người dùng vượt quá giới hạn đăng ký cùng lúc (30 người)",
                ["TenantIdRequired"] = "ID tổ chức/trường học là bắt buộc",
                ["NoAccountMeetingFound"] = "Không tìm thấy tài khoản cuộc họp cho người dùng được chỉ định",
                ["NoValidMeetEmailsFound"] = "Không tìm thấy email cuộc họp hợp lệ",
                ["RegTeamsAccountMeetingFailed"] = "Đăng ký policy Teams cho tài khoản thất bại: {0}",
                ["OnlineClassTenantNotSupportUseAccount"] = "Cấu hình lớp học trực tuyến không hỗ trợ sử dụng tài khoản để tạo cuộc họp",

                // MSTeams specific errors
                ["MSTeamsConnectionFailed"] = "Kết nối Microsoft Teams thất bại",
                ["MSTeamsTokenExpired"] = "Token Microsoft Teams đã hết hạn",
                ["MSTeamsChannelNotFound"] = "Kênh Microsoft Teams không tìm thấy",

                // Validation errors
                ["InvalidMeetingType"] = "Loại cuộc họp không hợp lệ",
                ["InvalidProviderMeetingType"] = "Loại nhà cung cấp cuộc họp không hợp lệ",
                ["InvalidAttendanceStatus"] = "Trạng thái tham dự không hợp lệ",
                ["MeetingUrlInvalid"] = "Đường dẫn cuộc họp không hợp lệ",
                ["MeetingDateInvalid"] = "Ngày giờ cuộc họp không hợp lệ",
            },
            ["en"] = new Dictionary<string, string>
            {
                // Tenant errors
                ["OnlineClassTenantDoNotExist"] = "Organization/School not found",
                ["OnlineClassTenantSchoolDoNotExist"] = "Organization/School does not have school ID",

                // OnlineClassTenant management errors
                ["OnlineClassTenantNotFound"] = "Online class configuration not found",
                ["OnlineClassTenantProviderAlreadyExists"] = "Provider type '{0}' is already configured for this organization/school",
                ["OnlineClassTenantExpired"] = "Online class configuration has expired",
                ["OnlineClassTenantNotYetStarted"] = "Online class configuration has not started yet",
                ["OnlineClassTenantSchoolIdRequired"] = "School ID is required",
                ["OnlineClassTenantProviderConnectRequired"] = "Provider connection information is required",
                ["OnlineClassTenantStartDateAfterExpireDate"] = "Start date must be before expire date",
                ["OnlineClassServiceNotAvailableForSchool"] = "Your school does not have access to this service",

                // LessonMeeting management errors
                ["LessonMeetingNotFound"] = "Online lesson meeting not found",
                ["LessonMeetingAlreadyStarted"] = "Online lesson meeting has already started",
                ["LessonMeetingAlreadyEnded"] = "Online lesson meeting has already ended",
                ["LessonMeetingNotActive"] = "Online lesson meeting is not in active status",
                ["LessonMeetingUrlRequired"] = "Lesson meeting URL is required",
                ["LessonMeetingInvalidTimeRange"] = "Start time must be before end time",
                ["LessonMeetingClassNotFound"] = "Class does not exist or is invalid",
                ["LessonMeetingClassNotPermitted"] = "This class does not have permission to create online lessons",
                ["LessonMeetingCreatorNotPermitted"] = "Your account does not have permission to create online lessons",
                ["FailedToCreateOnlineMeeting"] = "Failed to create online meeting",
                ["LessonMeetingTimeConflict"] = "This class already has a lesson during this time period",
                ["LessonMeetingCreatorTimeConflict"] = "You already have a lesson during this time period",
                ["LessonMeetingCannotCancel"] = "Cannot cancel the lesson because the lesson has already ended or is in progress",
                ["LessonMeetingCannotUpdate"] = "Cannot update the lesson because the lesson has already ended",
                ["FailedToCancelOnlineMeeting"] = "Failed to cancel the online lesson",

                // LessonParticipant management errors
                ["LessonParticipantNotFound"] = "Lesson participant not found",
                ["LessonParticipantAlreadyExists"] = "Participant already exists in this lesson",
                ["ParticipantListEmpty"] = "Participant list cannot be empty",
                ["TenantClassParticipantListEmpty"] = "Class change list cannot be empty",

                // AccountMeeting management errors
                ["AccountMeetingNotFound"] = "Account meeting not found",
                ["AccountMeetingAlreadyExists"] = "Account meeting already exists",
                ["AccountMeetingConnectionFailed"] = "Failed to connect account meeting",
                ["AccountMeetingInvalidCredentials"] = "Invalid account meeting credentials",
                ["CreateAccountMeetingFailed"] = "Failed to create account meeting for {0}",
                ["DeleteAccountMeetingFailed"] = "Failed to delete account meeting for {0}",
                ["ResetPasswordAccountMeetingFailed"] = "Failed to reset password for account meeting {0}",
                ["MeetingUserIdsLimitExceeded"] = "User ID list exceeds the limit of 30 users",
                ["TenantIdRequired"] = "Organization/School ID is required",
                ["NoAccountMeetingFound"] = "No account meeting found for the specified users",
                ["NoValidMeetEmailsFound"] = "No valid meeting email found",
                ["RegTeamsAccountMeetingFailed"] = "Failed to register Teams policy for account: {0}",
                ["OnlineClassTenantNotSupportUseAccount"] = "Online class configuration does not support using account to create meetings",
                // MSTeams specific errors
                ["MSTeamsConnectionFailed"] = "Failed to connect to Microsoft Teams",
                ["MSTeamsTokenExpired"] = "Microsoft Teams token has expired",
                ["MSTeamsChannelNotFound"] = "Microsoft Teams channel not found",

                // Validation errors
                ["InvalidMeetingType"] = "Invalid meeting type",
                ["InvalidProviderMeetingType"] = "Invalid provider meeting type",
                ["InvalidAttendanceStatus"] = "Invalid attendance status",
                ["MeetingUrlInvalid"] = "Invalid meeting URL",
                ["MeetingDateInvalid"] = "Invalid meeting date",
            }
        };

        private static readonly Dictionary<string, Dictionary<string, string>> PropertyNames = new()
        {
            ["vi"] = new Dictionary<string, string>
            {
                // OnlineClassTenant properties
                ["Id"] = "ID",
                ["TenantId"] = "Tổ chức/Trường học",
                ["ProviderMeetingType"] = "Loại nhà cung cấp",
                ["ProviderConnect"] = "Thông tin kết nối",
                ["SchoolId"] = "ID Trường",
                ["StartDate"] = "Ngày bắt đầu",
                ["ExpireDate"] = "Ngày hết hạn",
                ["CreatedAt"] = "Ngày tạo",
                ["CreatedBy"] = "Người tạo",
                ["UpdatedAt"] = "Ngày cập nhật",
                ["UpdatedBy"] = "Người cập nhật",
            },
            ["en"] = new Dictionary<string, string>
            {
                // OnlineClassTenant properties
                ["Id"] = "ID",
                ["TenantId"] = "Organization/School",
                ["ProviderMeetingType"] = "Provider Type",
                ["ProviderConnect"] = "Connection Information",
                ["SchoolId"] = "School ID",
                ["StartDate"] = "Start Date",
                ["ExpireDate"] = "Expire Date",
                ["CreatedAt"] = "Created At",
                ["CreatedBy"] = "Created By",
                ["UpdatedAt"] = "Updated At",
                ["UpdatedBy"] = "Updated By",
            }
        };

        public string? GetMessage(string key, string languageCode)
        {
            return Messages.GetValueOrDefault(languageCode)?.GetValueOrDefault(key);
        }

        public string? GetPropertyName(string propertyName, string languageCode)
        {
            return PropertyNames.GetValueOrDefault(languageCode)?.GetValueOrDefault(propertyName);
        }

        public string? GetValidationMessage(string errorCode, string languageCode)
        {
            return null;
        }
    }
}
