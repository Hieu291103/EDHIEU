using DS.Module.OnlineClass.Infrastructure.Configuration;
using DS.Module.OnlineClass.Infrastructure.Indexing;
using DS.Module.OnlineClass.Infrastructure.Localization;
using DS.Module.OnlineClass.Infrastructure.Services;
using DS.Module.OnlineClass.Infrastructure.Services.Authentication;
using DS.Shared.Core.Infrastructure.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Context;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace DS.Module.OnlineClass.Infrastructure.Extensions;

/// <summary>
/// Extension methods để đăng ký OnlineClass module services
/// </summary>
public static class OnlineClassServiceCollectionExtensions
{
    /// <summary>
    /// Đăng ký OnlineClass module services
    /// </summary>
    public static IServiceCollection AddOnlineClassModule(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Configuration
        services.Configure<OnlineClassSettings>(
            configuration.GetSection(OnlineClassSettings.SectionName));

        // Register OnlineClassSettings as singleton from IOptions
        services.AddSingleton(sp =>
            sp.GetRequiredService<Microsoft.Extensions.Options.IOptions<OnlineClassSettings>>().Value);

        // Localization & Indexing
        services.AddLocalizationProvider<OnlineClassLocalizationProvider>();
        services.AddMongoIndexRegistry<OnlineClassIndexRegistry>();

        // Microsoft Teams Services - HTTP-based implementation
        services.AddHttpClient<IMSTeamsAuthenticationService, MSTeamsAuthenticationService>();
        services.AddHttpClient<IGraphHttpClientService, GraphHttpClientService>();
        services.AddHttpClient<IMSTeamPolicyService, MSTeamPolicyService>();

        services.AddScoped<IMSTeamsService>(sp =>
        {
            var settings = sp.GetRequiredService<OnlineClassSettings>();
            var graphHttpClient = sp.GetRequiredService<IGraphHttpClientService>();
            var logger = sp.GetRequiredService<ILogger<MSTeamsService>>();
            return new MSTeamsService(settings, graphHttpClient, logger);
        });

        // Zoom Services - HTTP-based implementation
        services.AddHttpClient<IZoomAuthenticationService, ZoomAuthenticationService>();
        services.AddHttpClient<IZoomHttpClientService, ZoomHttpClientService>();

        services.AddScoped<IOneZoomService>(sp =>
        {
            var settings = sp.GetRequiredService<OnlineClassSettings>();
            var zoomHttpClient = sp.GetRequiredService<IZoomHttpClientService>();
            var logger = sp.GetRequiredService<ILogger<OneZoomService>>();
            return new OneZoomService(settings, zoomHttpClient, logger);
        });

        return services;
    }

    /// <summary>
    /// Khởi tạo MongoDB indexes
    /// </summary>
    public static async Task InitializeOnlineClassIndexesAsync(this IServiceProvider serviceProvider)
    {
        await serviceProvider.InitializeMongoIndexesAsync<IAdminMongoDbContext>();
    }
}




