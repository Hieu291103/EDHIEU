namespace DS.Module.OnlineClass.Infrastructure.Common
{
    public class LessionMeetingHelper
    {
        public static string MeetingDisplayName(string? fullName, string? username)
        {
            return $"{fullName} - {username}";
        }
    }
}
