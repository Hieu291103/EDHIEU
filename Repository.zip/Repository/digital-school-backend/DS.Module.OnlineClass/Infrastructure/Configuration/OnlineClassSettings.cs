namespace DS.Module.OnlineClass.Infrastructure.Configuration;

/// <summary>
/// Cấu hình cho OnlineClass - Quản lý kết nối Microsoft Teams và Zoom
/// </summary>
public sealed class OnlineClassSettings
{
    /// <summary>
    /// Tên section trong appsettings.json
    /// </summary>
    public const string SectionName = "OnlineClass";

    /// <summary>
    /// Danh sách cấu hình Microsoft Teams
    /// </summary>
    public TeamsOption[] Teams { get; init; } = [];

    /// <summary>
    /// Danh sách cấu hình Zoom
    /// </summary>
    public ZoomOption[] Zoom { get; init; } = [];

    /// <summary>
    /// Cấu hình Teams Policy Registration Service
    /// </summary>
    public TeamsPolicyRegUserOption? TeamsPolicyRegUser { get; init; }

    /// <summary>
    /// Cấu hình các tham số thời gian cho buổi học
    /// </summary>
    public SettingOption Setting { get; init; } = new();

    /// <summary>
    /// Cấu hình tham số thời gian
    /// </summary>
    public sealed class SettingOption
    {
        /// <summary>
        /// Số phút trước giờ bắt đầu để tạo link Zoom
        /// </summary>
        public int ZoomCreationBeforeStartTimeMinutes { get; init; } = 10;

        /// <summary>
        /// Số phút trước giờ bắt đầu để tạo link Teams
        /// </summary>
        public int TeamsCreationBeforeStartTimeMinutes { get; init; } = 30;

        /// <summary>
        /// Số phút trước giờ bắt đầu để kích hoạt trạng thái Active cho buổi học
        /// </summary>
        public int StartLessonBeforeStartTimeMinutes { get; init; } = 5;

        /// <summary>
        /// Số phút sau giờ kết thúc để cập nhật trạng thái Ended cho buổi học
        /// </summary>
        public int EndLessonAfterEndTimeMinutes { get; init; } = 1;
    }

    /// <summary>
    /// Cấu hình Microsoft Teams
    /// </summary>
    public sealed class TeamsOption
    {
        /// <summary>
        /// Mã định danh duy nhất cho cấu hình Teams
        /// VD: MS_TEAMS_EDMICRO_EDU_VN
        /// </summary>
        public string Code { get; init; } = string.Empty;

        /// <summary>
        /// Tên hiển thị của cấu hình Teams
        /// VD: MS Teams edmicro.edu.vn
        /// </summary>
        public string Name { get; init; } = string.Empty;

        /// <summary>
        /// Loại gói: FREE hoặc CHARGE
        /// </summary>
        public string Type { get; init; } = string.Empty;

        /// <summary>
        /// Tên miền của cấu hình Teams
        /// VD: edmicro.edu.vn
        /// </summary>
        public string Domain { get; init; } = string.Empty;

        /// <summary>
        /// URL API của Microsoft Graph
        /// VD: https://graph.microsoft.com/v1.0
        /// </summary>
        public string ApiUrl { get; init; } = string.Empty;

        /// <summary>
        /// Azure Tenant ID của ứng dụng Teams
        /// </summary>
        public string TenantId { get; init; } = string.Empty;

        /// <summary>
        /// Azure AD Application (Client) ID
        /// </summary>
        public string ClientId { get; init; } = string.Empty;

        /// <summary>
        /// Azure AD Application Client Secret
        /// </summary>
        public string ClientSecret { get; init; } = string.Empty;

        /// <summary>
        /// ID của Group/Team để gán user mặc định
        /// VD: group-id-12345
        /// </summary>
        public string GroupId { get; init; } = string.Empty;

        /// <summary>
        /// SKU ID của License để gán cho user mặc định
        /// VD: 61d4a2b0-5982-11ee-be56-0242ac110002
        /// </summary>
        public string LicenseSkuId { get; init; } = string.Empty;

        /// <summary>
        /// Service ID để quản lý người dùng và tài khoản
        /// VD: 7bd3a5ea-945b-470d-95e8-67bd3f1f5208
        /// </summary>
        public string UserServiceId { get; init; } = string.Empty;
    }

    /// <summary>
    /// Cấu hình Zoom
    /// </summary>
    public sealed class ZoomOption
    {
        /// <summary>
        /// Mã định danh duy nhất cho cấu hình Zoom
        /// VD: ZOOM_EDMICRO
        /// </summary>
        public string Code { get; init; } = string.Empty;

        /// <summary>
        /// Tên hiển thị của cấu hình Zoom
        /// VD: Zoom EDMICRO
        /// </summary>
        public string Name { get; init; } = string.Empty;

        /// <summary>
        /// Loại gói: FREE hoặc CHARGE
        /// </summary>
        public string Type { get; init; } = string.Empty;

        /// <summary>
        /// URL API của Zoom
        /// VD: https://api.zoom.us/v2
        /// </summary>
        public string ApiUrl { get; init; } = string.Empty;

        /// <summary>
        /// JWT API Key lấy từ Zoom Marketplace
        /// </summary>
        public string ApiKey { get; init; } = string.Empty;

        /// <summary>
        /// JWT API Secret lấy từ Zoom Marketplace
        /// </summary>
        public string ApiSecret { get; init; } = string.Empty;

    }

    /// <summary>
    /// Cấu hình MS Teams Policy Registration Service
    /// </summary>
    public sealed class TeamsPolicyRegUserOption
    {
        /// <summary>
        /// URL API của Teams Policy Registration Service
        /// VD: https://teams-policy.truonghocso.edu.vn/assign-policy
        /// </summary>
        public string ApiUrl { get; init; } = string.Empty;

        /// <summary>
        /// API Key để xác thực với Teams Policy Registration Service
        /// </summary>
        public string ApiKey { get; init; } = string.Empty;
    }
}


