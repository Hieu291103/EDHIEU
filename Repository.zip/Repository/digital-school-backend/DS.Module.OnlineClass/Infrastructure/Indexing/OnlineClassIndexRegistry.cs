using DS.Module.OnlineClass.Domain.Entities;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Context;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Indexing;
using MongoDB.Driver;

namespace DS.Module.OnlineClass.Infrastructure.Indexing
{
    /// <summary>
    /// Index registry cho OnlineClass module
    /// Định nghĩa các indexes cho OnlineClassTenantEntity
    /// </summary>
    public class OnlineClassIndexRegistry : BaseIndexRegistry<IAdminMongoDbContext>
    {
        protected override void ConfigureIndexes()
        {
            Register(
                // Tìm cấu hình online class theo TenantId
                new CreateIndexModel<OnlineClassTenantEntity>(
                    Builders<OnlineClassTenantEntity>.IndexKeys.Ascending(x => x.TenantId),
                    new CreateIndexOptions { Name = "TenantId_1" }),

                // Tìm cấu hình theo SchoolId
                new CreateIndexModel<OnlineClassTenantEntity>(
                    Builders<OnlineClassTenantEntity>.IndexKeys.Ascending(x => x.SchoolId),
                    new CreateIndexOptions { Name = "SchoolId_1" }),

                // Tìm cấu hình theo ProviderMeetingType
                new CreateIndexModel<OnlineClassTenantEntity>(
                    Builders<OnlineClassTenantEntity>.IndexKeys.Ascending(x => x.ProviderMeetingType),
                    new CreateIndexOptions { Name = "ProviderMeetingType_1" }),

                // Kết hợp TenantId + ProviderMeetingType (thường dùng để filter)
                new CreateIndexModel<OnlineClassTenantEntity>(
                    Builders<OnlineClassTenantEntity>.IndexKeys.Combine(
                        Builders<OnlineClassTenantEntity>.IndexKeys.Ascending(x => x.TenantId),
                        Builders<OnlineClassTenantEntity>.IndexKeys.Ascending(x => x.ProviderMeetingType)),
                    new CreateIndexOptions { Name = "TenantId_ProviderMeetingType_1" }),

                // Kết hợp TenantId + ExpireDate (để check cấu hình còn hạn)
                new CreateIndexModel<OnlineClassTenantEntity>(
                    Builders<OnlineClassTenantEntity>.IndexKeys.Combine(
                        Builders<OnlineClassTenantEntity>.IndexKeys.Ascending(x => x.TenantId),
                        Builders<OnlineClassTenantEntity>.IndexKeys.Descending(x => x.ExpireDate)),
                    new CreateIndexOptions { Name = "TenantId_ExpireDate_-1" }),

                // Kết hợp TenantId + StartDate (cho list queries)
                new CreateIndexModel<OnlineClassTenantEntity>(
                    Builders<OnlineClassTenantEntity>.IndexKeys.Combine(
                        Builders<OnlineClassTenantEntity>.IndexKeys.Ascending(x => x.TenantId),
                        Builders<OnlineClassTenantEntity>.IndexKeys.Descending(x => x.StartDate)),
                    new CreateIndexOptions { Name = "TenantId_StartDate_-1" }),

                // Index trên CreatedAt cho sorting theo thời gian tạo
                new CreateIndexModel<OnlineClassTenantEntity>(
                    Builders<OnlineClassTenantEntity>.IndexKeys.Descending(x => x.CreatedAt),
                    new CreateIndexOptions { Name = "CreatedAt_-1" }));
        }
    }
}
