using DS.Job.Application.BackgroundJobs.Abstractions;
using DS.Module.Tenant.Application.Commands.Tenants;
using DS.Shared.Core.Infrastructure.Services.Onluyen;
using DS.Shared.CQRS.Enums;
using MediatR;

namespace DS.Job.Application.BackgroundJobs.SyncOnluyen
{
    public class SyncSchoolOnluyenJob : IBackgroundJob
    {
        private readonly ILogger<SyncSchoolOnluyenJob> _logger;
        private readonly IOnluyenService _onluyenService;
        private readonly IMediator _mediator;

        public string JobName => "SyncSchoolOnluyenJob";
        public string JobDescription => "Đồng bộ dữ liệu trường học";

        public SyncSchoolOnluyenJob(
            ILogger<SyncSchoolOnluyenJob> logger,
            IOnluyenService onluyenService,
            IMediator mediator)
        {
            _logger = logger;
            _onluyenService = onluyenService;
            _mediator = mediator;
        }

        /// <summary>
        /// Executes the data synchronization job
        /// </summary>
        public async Task ExecuteAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                var schools = await _onluyenService.GetSchoolsAsync(cancellationToken: cancellationToken);
                if (schools.Count == 0)
                {
                    _logger.LogInformation("[{JobName}] No schools found in payload", JobName);
                    return;
                }

                var inserted = 0;
                var updated = 0;
                var skipped = 0;

                foreach (var school in schools)
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    if (school.Id <= 0 || string.IsNullOrWhiteSpace(school.Name))
                    {
                        skipped++;
                        continue;
                    }

                    var command = new UpsertTenantFromOnluyenCommand
                    {
                        SchoolId = school.Id,
                        Name = school.Name.Trim(),
                        Partner = school.Partner,
                        Domain = school.Domain,
                        Address = school.Address,
                        ProvinceCode = school.CityId?.ToString(),
                        WardCode = school.CommuneId?.ToString(),
                        Ward = school.CommuneName,
                        Type = MapTenantType(school.Level),
                        StudentCount = school.TotalStudent,
                        TeacherCount = school.TotalTeacher
                    };

                    var result = await _mediator.Send(command, cancellationToken);

                    switch (result.Data)
                    {
                        case UpsertTenantFromOnluyenAction.Inserted:
                            inserted++;
                            break;
                        case UpsertTenantFromOnluyenAction.Updated:
                            updated++;
                            break;
                        default:
                            skipped++;
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "[{JobName}] Data synchronization failed", JobName);
                throw;
            }
        }

        private static TenantType MapTenantType(int? level)
        {
            return level switch
            {
                1 => TenantType.PrimarySchool,
                2 => TenantType.MiddleSchool,
                3 => TenantType.HighSchool,
                _ => TenantType.None
            };
        }
    }
}
