using DS.Job.Application.BackgroundJobs.Abstractions;
using DS.Module.Support.Application.Commands.Tickets;
using MediatR;

namespace DS.Job.Application.BackgroundJobs.Support;

public class CreateTicketFromMailReceiptJob(
    ILogger<CreateTicketFromMailReceiptJob> logger,
    IMediator mediator) : IBackgroundJob
{
    public string JobName => "CreateTicketFromMailReceiptJob";
    public string JobDescription => "Lấy mail chưa đọc từ hộp thư receipt và tạo ticket tự động";

    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            await mediator.Send(new JobCreateTicketFromMailReceiptCommand(), cancellationToken);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "[{JobName}] Lỗi khi thực thi job", JobName);
        }
    }
}
