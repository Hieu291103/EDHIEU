namespace DS.Job.Application.BackgroundJobs.Abstractions;

/// <summary>
/// Interface for defining background jobs
/// </summary>
public interface IBackgroundJob
{
    /// <summary>
    /// Executes the background job
    /// </summary>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>Task representing the asynchronous operation</returns>
    Task ExecuteAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Gets the job name
    /// </summary>
    string JobName { get; }

    /// <summary>
    /// Gets the job description
    /// </summary>
    string JobDescription { get; }
}

/// <summary>
/// Interface for background job registry
/// </summary>
public interface IBackgroundJobRegistry
{
    /// <summary>
    /// Registers a recurring job
    /// </summary>
    /// <typeparam name="TJob">The background job type</typeparam>
    /// <param name="jobId">The job ID</param>
    /// <param name="cron">The cron expression for recurring schedule</param>
    /// <param name="queue">The queue name (default: "default")</param>
    /// <remarks>
    /// Uses Hangfire.Cron expressions: 
    /// - "*/5 * * * *" = Every 5 minutes
    /// - "0 * * * *" = Every hour
    /// - "0 0 * * *" = Daily at midnight
    /// - "0 0 * * 0" = Weekly on Sunday at midnight
    /// </remarks>
    void RegisterRecurringJob<TJob>(string jobId, string cron, string queue = "default") 
        where TJob : IBackgroundJob;

    /// <summary>
    /// Enqueues an immediate job
    /// </summary>
    /// <typeparam name="TJob">The background job type</typeparam>
    /// <param name="queue">The queue name (default: "default")</param>
    string EnqueueJob<TJob>(string queue = "default") 
        where TJob : IBackgroundJob;
}
