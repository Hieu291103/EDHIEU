# Hangfire Background Jobs Setup

## 📋 Overview

DS.Job uses **Hangfire** with **MongoDB** as the persistent storage for background job management. This allows you to:
- Schedule recurring jobs with cron expressions
- Execute immediate jobs with queuing
- Monitor job execution through the Hangfire Dashboard
- Ensure job reliability with persistent storage

## 🏗️ Project Structure

```
DS.Job/
├── Application/
│   └── BackgroundJobs/
│       ├── Abstractions/
│       │   └── IBackgroundJob.cs          # Interfaces for background jobs
│       ├── Examples/
│       │   ├── HealthCheckBackgroundJob.cs    # Example: Health check job
│       │   └── DataSyncBackgroundJob.cs       # Example: Data sync job
│       └── [YourJob].cs                  # Your background jobs here
└── Infrastructure/
    └── Extensions/
        ├── HangfireExtensions.cs         # Hangfire configuration
        └── BackgroundJobs/
            └── BackgroundJobRegistry.cs   # Job registry and registration
```

## 🚀 Quick Start

### 1. Create Your Background Job

Create a new class that implements `IBackgroundJob`:

```csharp
using DS.Job.Application.BackgroundJobs.Abstractions;

namespace DS.Job.Application.BackgroundJobs;

public class YourBackgroundJob : IBackgroundJob
{
    private readonly ILogger<YourBackgroundJob> _logger;
    private readonly IYourService _service;  // Inject dependencies

    public string JobName => "YourJobName";
    public string JobDescription => "Description of what this job does";

    public YourBackgroundJob(ILogger<YourBackgroundJob> logger, IYourService service)
    {
        _logger = logger;
        _service = service;
    }

    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("[{JobName}] Started at {Time}", JobName, DateTime.UtcNow);
            
            // Your business logic here
            await _service.DoSomethingAsync(cancellationToken);
            
            _logger.LogInformation("[{JobName}] Completed successfully at {Time}", JobName, DateTime.UtcNow);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[{JobName}] Failed", JobName);
            throw;  // Hangfire will retry based on configuration
        }
    }
}
```

### 2. Register Your Job

Update `Program.cs` to register your background job:

```csharp
// In services registration section
builder.Services.AddScoped<YourBackgroundJob>();
```

### 3. Schedule Your Job

Update the `InitializeBackgroundJobs` method in `BackgroundJobRegistry.cs`:

```csharp
public static void InitializeBackgroundJobs(this IApplicationBuilder app)
{
    using var scope = app.ApplicationServices.CreateScope();
    var jobRegistry = scope.ServiceProvider.GetRequiredService<IBackgroundJobRegistry>();
    
    // Register your recurring jobs here
    jobRegistry.RegisterRecurringJob<YourBackgroundJob>("job-unique-id", Cron.Daily);
}
```

## ⏱️ Cron Expressions Reference

Use `Hangfire.Cron` class for common schedules:

```csharp
Cron.Minutely()                    // Every minute
Cron.EveryFiveMinutes()           // Every 5 minutes
Cron.EveryTenMinutes()            // Every 10 minutes
Cron.Hourly()                      // Every hour
Cron.Daily()                       // Daily at midnight UTC
Cron.Daily(hour: 8, minute: 30)   // Daily at 08:30 UTC
Cron.Weekly()                      // Weekly on Sunday at midnight
Cron.Weekly(DayOfWeek.Monday, 9)  // Every Monday at 09:00
Cron.Monthly()                     // Monthly on 1st at midnight
```

Or use custom cron expressions:
```csharp
"*/5 * * * *"        // Every 5 minutes
"0 * * * *"          // Every hour at minute 0
"0 0 * * *"          // Daily at midnight
"0 0 * * 0"          // Weekly on Sunday at midnight
"0 0 1 * *"          // Monthly on 1st at midnight
"0 0 * * 1-5"        // Weekdays at midnight
"0 9 * * 1-5"        // Weekdays at 9 AM
```

## 📊 Job Queues

Jobs can be assigned to different queues for priority management:

```csharp
// Register with priority queue
jobRegistry.RegisterRecurringJob<YourBackgroundJob>("high-priority-job", Cron.Daily, "high");
jobRegistry.RegisterRecurringJob<YourBackgroundJob>("normal-job", Cron.Daily, "default");
jobRegistry.RegisterRecurringJob<YourBackgroundJob>("low-priority-job", Cron.Daily, "low");
```

The Hangfire server processes queues in order: `high` → `default` → `low`

## 🔍 Hangfire Dashboard

Access the Hangfire Dashboard at:
```
http://localhost:5000/hangfire
```

The dashboard shows:
- ✅ Successful jobs
- ❌ Failed jobs
- ⏱️ Scheduled jobs
- 🔄 Recurring jobs
- 📊 Job statistics

## 🔧 Configuration

Hangfire is configured in `HangfireExtensions.cs`:

```csharp
public static IServiceCollection AddHangfireWithMongo(this IServiceCollection services, IConfiguration configuration)
{
    // MongoDB connection settings from appsettings.json["Mongo"]["School"]
    var mongoSettings = configuration.GetSection("Mongo:School").Get<MongoDbSettings>();
    
    services.AddHangfire(config =>
    {
        config.UseMongoStorage(mongoClient, mongoSettings.DatabaseName, new MongoStorageOptions
        {
            Prefix = "hangfire",                                    // MongoDB collection prefix
            InvisibilityTimeout = TimeSpan.FromMinutes(30),        // Job timeout
            DistributedLockLifetime = TimeSpan.FromMinutes(10),    // Lock timeout
            CheckConnection = true,                                 // Verify connection on startup
        });
    });

    services.AddHangfireServer(options =>
    {
        options.WorkerCount = Environment.ProcessorCount;          // Number of worker threads
        options.Queues = new[] { "default", "high", "low" };       // Supported queues
        options.ShutdownTimeout = TimeSpan.FromSeconds(30);        // Graceful shutdown timeout
    });

    return services;
}
```

## 📝 Appsettings Configuration

The `appsettings.json` should include MongoDB connection strings:

```json
{
  "Mongo": {
    "School": {
      "ConnectionString": "mongodb://localhost:27017/?...",
      "DatabaseName": "ds_school_db"
    }
  }
}
```

## 🎯 Best Practices

1. **Idempotency**: Design jobs to be safe if executed multiple times
   ```csharp
   // ✅ Good - Idempotent
   await _repository.UpsertAsync(data);
   
   // ❌ Bad - Not idempotent
   await _repository.InsertAsync(data);  // Fails on retry
   ```

2. **Logging**: Always log job start, completion, and errors
   ```csharp
   _logger.LogInformation("[{JobName}] Started", JobName);
   _logger.LogError(ex, "[{JobName}] Failed", JobName);
   ```

3. **Timeout Handling**: Use CancellationToken for graceful cancellation
   ```csharp
   public async Task ExecuteAsync(CancellationToken cancellationToken = default)
   {
       await _service.LongRunningOperationAsync(cancellationToken);
   }
   ```

4. **Error Handling**: Throw exceptions to trigger Hangfire retries
   ```csharp
   catch (Exception ex)
   {
       _logger.LogError(ex, "[{JobName}] Failed", JobName);
       throw;  // Hangfire will retry
   }
   ```

5. **Dependency Injection**: Jobs are created per execution, so scoped dependencies work
   ```csharp
   public YourBackgroundJob(IScopedService scoped, ILogger<YourBackgroundJob> logger)
   {
       // All dependencies will be properly disposed after job completes
   }
   ```

## 📦 Related Files

- **IBackgroundJob.cs**: Interface for all background jobs
- **BackgroundJobRegistry.cs**: Job registration and scheduling
- **HangfireExtensions.cs**: Hangfire configuration
- **Program.cs**: Service registration and middleware setup
- **appsettings.json**: MongoDB and other configuration

## 🚫 Removing Example Jobs

Delete these files when ready:
- `Application/BackgroundJobs/Examples/HealthCheckBackgroundJob.cs`
- `Application/BackgroundJobs/Examples/DataSyncBackgroundJob.cs`

Also remove their registrations from `Program.cs`:
```csharp
builder.Services.AddScoped<HealthCheckBackgroundJob>();
builder.Services.AddScoped<DataSyncBackgroundJob>();
```

## 📚 Further Reading

- [Hangfire Documentation](https://docs.hangfire.io/)
- [Hangfire Mongo Storage](https://github.com/sergezhigunov/Hangfire.Mongo)
- [CRON Expressions](https://en.wikipedia.org/wiki/Cron#CRON_expression)
