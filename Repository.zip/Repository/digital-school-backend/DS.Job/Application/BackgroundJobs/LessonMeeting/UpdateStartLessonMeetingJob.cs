using DS.Job.Application.BackgroundJobs.Abstractions;
using DS.Module.OnlineClass.Application.Commands.LessonMeetings;
using MediatR;

namespace DS.Job.Application.BackgroundJobs.LessonMeeting;

public class UpdateStartLessonMeetingJob : IBackgroundJob
{
    private readonly ILogger<UpdateStartLessonMeetingJob> _logger;
    private readonly IMediator _mediator;

    public string JobName => "UpdateStatusLessonMeetingJob";
    public string JobDescription => "Cập nhật trạng thái các buổi học";

    public UpdateStartLessonMeetingJob(ILogger<UpdateStartLessonMeetingJob> logger, IMediator mediator)
    {
        _logger = logger;
        _mediator = mediator;
    }

    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            await _mediator.Send(new JobUpdateStartLessionMeetingCommand(), cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[{JobName}] Error occurred while executing job", JobName);
            throw;
        }
    }
}
