using DS.Job.Application.BackgroundJobs.Abstractions;
using DS.Module.OnlineClass.Application.Commands.LessonMeetings;
using MediatR;

namespace DS.Job.Application.BackgroundJobs.LessonMeeting;

public class UpdateEndLessonMeetingJob : IBackgroundJob
{
    private readonly ILogger<UpdateEndLessonMeetingJob> _logger;
    private readonly IMediator _mediator;

    public string JobName => "UpdateEndLessonMeetingJob";
    public string JobDescription => "Cập nhật trạng thái kết thúc các buổi học";

    public UpdateEndLessonMeetingJob(ILogger<UpdateEndLessonMeetingJob> logger, IMediator mediator)
    {
        _logger = logger;
        _mediator = mediator;
    }

    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            await _mediator.Send(new JobUpdateEndLessionMeetingCommand(), cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[{JobName}] Error occurred while executing job", JobName);
            throw;
        }
    }
}
