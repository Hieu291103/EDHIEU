using DS.Job.Application.BackgroundJobs.Abstractions;
using DS.Module.OnlineClass.Application.Commands.PartnerOneZoomMeetingEntitys;
using MediatR;

namespace DS.Job.Application.BackgroundJobs.LessonMeeting;

public class DeleteOneZoomMeetingJob : IBackgroundJob
{
    private readonly ILogger<DeleteOneZoomMeetingJob> _logger;
    private readonly IMediator _mediator;

    public string JobName => "DeleteOneZoomMeetingJob";
    public string JobDescription => "Xóa các phòng Zoom đã quá thời hạn kết thúc";

    public DeleteOneZoomMeetingJob(ILogger<DeleteOneZoomMeetingJob> logger, IMediator mediator)
    {
        _logger = logger;
        _mediator = mediator;
    }

    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            await _mediator.Send(new JobDeleteOneZoomMeetingCommand(), cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[{JobName}] Error occurred while executing job", JobName);
            throw;
        }
    }
}
