using DS.Job.Application.BackgroundJobs.Abstractions;
using DS.Module.OnlineClass.Application.Commands.LessonMeetings;
using MediatR;

namespace DS.Job.Application.BackgroundJobs.LessonMeeting;

public class CreateLinkZoomLessonMeetingJob : IBackgroundJob
{
    private readonly ILogger<CreateLinkZoomLessonMeetingJob> _logger;
    private readonly IMediator _mediator;

    public string JobName => "CreateLinkZoomLessonMeetingJob";
    public string JobDescription => "Tạo link Zoom cho các buổi học sắp diễn ra";

    public CreateLinkZoomLessonMeetingJob(ILogger<CreateLinkZoomLessonMeetingJob> logger, IMediator mediator)
    {
        _logger = logger;
        _mediator = mediator;
    }

    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            await _mediator.Send(new JobCreateLinkZoomLessionMeetingCommand
            {
                CurrentDateTime = DateTime.UtcNow
            }, cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[{JobName}] Error occurred while executing job", JobName);
            throw;
        }
    }
}
