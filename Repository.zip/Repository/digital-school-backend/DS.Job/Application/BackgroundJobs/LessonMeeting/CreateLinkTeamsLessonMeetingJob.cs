using DS.Job.Application.BackgroundJobs.Abstractions;
using DS.Module.OnlineClass.Application.Commands.LessonMeetings;
using MediatR;

namespace DS.Job.Application.BackgroundJobs.LessonMeeting;

public class CreateLinkTeamsLessonMeetingJob : IBackgroundJob
{
    private readonly ILogger<CreateLinkTeamsLessonMeetingJob> _logger;
    private readonly IMediator _mediator;

    public string JobName => "CreateLinkTeamsLessonMeetingJob";
    public string JobDescription => "Tạo link Teams cho các buổi học sắp diễn ra";

    public CreateLinkTeamsLessonMeetingJob(ILogger<CreateLinkTeamsLessonMeetingJob> logger, IMediator mediator)
    {
        _logger = logger;
        _mediator = mediator;
    }

    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            await _mediator.Send(new JobCreateLinkTeamsLessionMeetingCommand
            {
                CurrentDateTime = DateTime.UtcNow
            }, cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[{JobName}] Error occurred while executing job", JobName);
            throw;
        }
    }
}
