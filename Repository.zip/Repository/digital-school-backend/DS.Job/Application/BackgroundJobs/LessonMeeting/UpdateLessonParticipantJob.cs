using DS.Job.Application.BackgroundJobs.Abstractions;
using DS.Module.OnlineClass.Application.Commands.LessonParticipantEntitys;
using MediatR;

namespace DS.Job.Application.BackgroundJobs.LessonMeeting;

public class UpdateLessonParticipantJob : IBackgroundJob
{
    private readonly ILogger<UpdateLessonParticipantJob> _logger;
    private readonly IMediator _mediator;

    public string JobName => "UpdateLessonParticipantJob";
    public string JobDescription => "Cập nhật thông tin điểm danh người tham gia cho các buổi học đã kết thúc (Zoom, Teams, ...)";

    public UpdateLessonParticipantJob(ILogger<UpdateLessonParticipantJob> logger, IMediator mediator)
    {
        _logger = logger;
        _mediator = mediator;
    }

    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            await _mediator.Send(new JobUpdateLessonParticipantCommand(), cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[{JobName}] Error occurred while executing job", JobName);
            throw;
        }
    }
}
