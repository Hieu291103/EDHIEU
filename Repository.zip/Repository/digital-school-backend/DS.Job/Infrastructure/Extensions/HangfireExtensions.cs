using DS.Job.Infrastructure.BackgroundJobs.Authentication;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Configuration;
using Hangfire;
using Hangfire.Dashboard;
using Hangfire.Mongo;
using Hangfire.Mongo.Migration.Strategies;
using Hangfire.Mongo.Migration.Strategies.Backup;
using MongoDB.Driver;

namespace DS.Job.Infrastructure.Extensions;

public static class HangfireExtensions
{
    public static IServiceCollection AddHangfireWithMongo(this IServiceCollection services, IConfiguration configuration)
    {
        var mongoSettings = configuration.GetSection("Mongo:Hangfire").Get<MongoDbSettings>()
            ?? throw new InvalidOperationException("MongoDB Hangfire connection settings not found");

        var mongoClient = new MongoClient(mongoSettings.ConnectionString);

        services.AddHangfire(config =>
        {
            config
                .SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
                .UseSimpleAssemblyNameTypeSerializer()
                .UseRecommendedSerializerSettings()
                .UseMongoStorage(mongoClient, mongoSettings.DatabaseName, new MongoStorageOptions
                {
                    Prefix = "hangfire",
                    CheckConnection = true,
                    CheckQueuedJobsStrategy = CheckQueuedJobsStrategy.TailNotificationsCollection,
                    MigrationOptions = new MongoMigrationOptions
                    {
                        MigrationStrategy = new MigrateMongoMigrationStrategy(),
                        BackupStrategy = new CollectionMongoBackupStrategy()
                    }
                });
        });
        var serverNameConfig = configuration.GetSection("Hangfire").GetValue<string>("ServerName");
        services.AddHangfireServer(options =>
        {
            options.ServerName = serverNameConfig ?? "ds-job-server";
            options.WorkerCount = Environment.ProcessorCount;
            options.Queues = new[] { "default", "high", "low" };
            options.ShutdownTimeout = TimeSpan.FromSeconds(30);
            options.SchedulePollingInterval = TimeSpan.FromSeconds(30);
            options.ServerTimeout = TimeSpan.FromMinutes(5);
        });

        return services;
    }

    public static IApplicationBuilder UseHangfireDashboard(this IApplicationBuilder app, IConfiguration configuration)
    {
        var dashboardConfig = configuration.GetSection("Hangfire:Dashboard");
        var username = dashboardConfig.GetValue<string>("Username");
        var password = dashboardConfig.GetValue<string>("Password");

        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
        {
            throw new InvalidOperationException("Hangfire dashboard Username/Password is not configured.");
        }

        IDashboardAuthorizationFilter authFilter = new BasicAuthDashboardAuthorizationFilter(username, password);

        var dashboardOptions = new DashboardOptions
        {
            Authorization = new[] { authFilter },
            AppPath = "/jobs"
        };

        app.UseHangfireDashboard(pathMatch: "/jobs", options: dashboardOptions);
        return app;
    }
}
