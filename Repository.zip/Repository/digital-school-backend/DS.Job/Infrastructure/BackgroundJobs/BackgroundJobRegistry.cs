using DS.Job.Application.BackgroundJobs.Abstractions;
using DS.Job.Application.BackgroundJobs.LessonMeeting;
using DS.Job.Application.BackgroundJobs.Support;
using DS.Job.Application.BackgroundJobs.SyncOnluyen;
using Hangfire;

namespace DS.Job.Infrastructure.BackgroundJobs;

/// <summary>
/// Registry for background jobs using Hangfire
/// </summary>
public class BackgroundJobRegistry : IBackgroundJobRegistry
{
    private readonly ILogger<BackgroundJobRegistry> _logger;

    public BackgroundJobRegistry(ILogger<BackgroundJobRegistry> logger)
    {
        _logger = logger;
    }

    /// <inheritdoc/>
    public void RegisterRecurringJob<TJob>(string jobId, string cron, string queue = "default")
        where TJob : IBackgroundJob
    {
        try
        {
            RecurringJob.AddOrUpdate<TJob>(
                recurringJobId: jobId,
                methodCall: job => job.ExecuteAsync(CancellationToken.None),
                cronExpression: cron
            );

            _logger.LogInformation("Recurring job '{JobId}' registered with cron '{Cron}' in queue '{Queue}'", jobId, cron, queue);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to register recurring job '{JobId}'", jobId);
            throw;
        }
    }

    /// <inheritdoc/>
    public string EnqueueJob<TJob>(string queue = "default")
        where TJob : IBackgroundJob
    {
        try
        {
            var jobId = BackgroundJob.Enqueue<TJob>(
                methodCall: job => job.ExecuteAsync(CancellationToken.None)
            );

            _logger.LogInformation("Job of type '{JobType}' enqueued with ID '{JobId}' in queue '{Queue}'", typeof(TJob).Name, jobId, queue);
            return jobId;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to enqueue job of type '{JobType}'", typeof(TJob).Name);
            throw;
        }
    }
}

/// <summary>
/// Extension methods for registering background jobs
/// </summary>
public static class BackgroundJobExtensions
{
    /// <summary>
    /// Adds background job registry to the service collection
    /// </summary>
    public static IServiceCollection AddBackgroundJobRegistry(this IServiceCollection services)
    {
        services.AddSingleton<IBackgroundJobRegistry, BackgroundJobRegistry>();
        services.AddScoped<SyncSchoolOnluyenJob>();
        services.AddScoped<CreateLinkTeamsLessonMeetingJob>();
        services.AddScoped<CreateLinkZoomLessonMeetingJob>();
        services.AddScoped<UpdateStartLessonMeetingJob>();
        services.AddScoped<UpdateEndLessonMeetingJob>();
        services.AddScoped<DeleteOneZoomMeetingJob>();
        services.AddScoped<UpdateLessonParticipantJob>();
        services.AddScoped<CreateTicketFromMailReceiptJob>();
        return services;
    }

    /// <summary>
    /// Initializes registered background jobs
    /// </summary>
    public static void InitializeBackgroundJobs(this IApplicationBuilder app)
    {
        using var scope = app.ApplicationServices.CreateScope();
        var jobRegistry = scope.ServiceProvider.GetRequiredService<IBackgroundJobRegistry>();

        jobRegistry.RegisterRecurringJob<SyncSchoolOnluyenJob>(
            "sync-school-onluyen-daily-1am",
            Cron.Daily(1));

        jobRegistry.RegisterRecurringJob<CreateLinkTeamsLessonMeetingJob>(
            "create-link-teams-lesson-meeting-every-minute",
            Cron.Minutely());

        jobRegistry.RegisterRecurringJob<CreateLinkZoomLessonMeetingJob>(
            "create-link-zoom-lesson-meeting-every-minute",
            Cron.Minutely());

        jobRegistry.RegisterRecurringJob<UpdateStartLessonMeetingJob>(
            "update-start-lesson-meeting-every-minute",
            Cron.Minutely());

        jobRegistry.RegisterRecurringJob<UpdateEndLessonMeetingJob>(
            "update-end-lesson-meeting-every-minute",
            Cron.Minutely());

        jobRegistry.RegisterRecurringJob<DeleteOneZoomMeetingJob>(
            "delete-one-zoom-meeting-every-minute",
            Cron.Minutely());

        jobRegistry.RegisterRecurringJob<UpdateLessonParticipantJob>(
            "update-lesson-participant-every-minute",
            "*/2 * * * *");

        jobRegistry.RegisterRecurringJob<CreateTicketFromMailReceiptJob>(
            "create-ticket-from-mail-receipt-every-minute",
            Cron.Minutely());
    }
}
