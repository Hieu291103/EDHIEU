using System.Net.Http.Headers;
using System.Text;
using Hangfire.Dashboard;

namespace DS.Job.Infrastructure.BackgroundJobs.Authentication;

/// <summary>
/// Basic auth filter for Hangfire Dashboard.
/// </summary>
public class BasicAuthDashboardAuthorizationFilter : IDashboardAuthorizationFilter
{
    private readonly string _username;
    private readonly string _password;

    public BasicAuthDashboardAuthorizationFilter(string username, string password)
    {
        _username = username;
        _password = password;
    }

    public bool Authorize(DashboardContext context)
    {
        var httpContext = context.GetHttpContext();
        var authHeader = httpContext.Request.Headers.Authorization.ToString();

        if (string.IsNullOrWhiteSpace(authHeader))
        {
            Challenge(httpContext);
            return false;
        }

        if (!AuthenticationHeaderValue.TryParse(authHeader, out var headerValue) ||
            !"Basic".Equals(headerValue.Scheme, StringComparison.OrdinalIgnoreCase) ||
            string.IsNullOrWhiteSpace(headerValue.Parameter))
        {
            Challenge(httpContext);
            return false;
        }

        string decoded;
        try
        {
            var rawBytes = Convert.FromBase64String(headerValue.Parameter);
            decoded = Encoding.UTF8.GetString(rawBytes);
        }
        catch
        {
            Challenge(httpContext);
            return false;
        }

        var separatorIndex = decoded.IndexOf(':');
        if (separatorIndex <= 0)
        {
            Challenge(httpContext);
            return false;
        }

        var username = decoded[..separatorIndex];
        var password = decoded[(separatorIndex + 1)..];
        var isValid = string.Equals(username, _username, StringComparison.Ordinal) &&
                      string.Equals(password, _password, StringComparison.Ordinal);

        if (!isValid)
        {
            Challenge(httpContext);
            return false;
        }

        return true;
    }

    private static void Challenge(HttpContext httpContext)
    {
        httpContext.Response.Headers.WWWAuthenticate = "Basic realm=\"Hangfire Dashboard\"";
        httpContext.Response.StatusCode = StatusCodes.Status401Unauthorized;
    }
}
