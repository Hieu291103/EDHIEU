using DS.Job.Infrastructure.BackgroundJobs;
using DS.Job.Infrastructure.Extensions;
using DS.Module.Identity.Infrastructure.Extensions;
using DS.Module.OnlineClass.Infrastructure.Extensions;
using DS.Module.Support.Infrastructure.Extensions;
using DS.Module.Tenant.Infrastructure.Extensions;
using DS.Shared.Core.Infrastructure.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Configuration;
using DS.Shared.Core.Infrastructure.Persistence.MongoDB.Extensions;
using DS.Shared.Core.Infrastructure.Persistence.Redis.Extensions;
using Microsoft.AspNetCore.HttpOverrides;
using System.Text.Json;
using System.Text.Json.Serialization;

MongoDbConventions.RegisterConventions();

var builder = WebApplication.CreateBuilder(args);

// Tự động load appsettings.{ENVIRONMENT}.json
builder.Configuration
    .AddJsonFile("appsettings.json", optional: false)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true)
    .AddEnvironmentVariables();

// Serilog
builder.Host.AddSerilogLogging(builder.Configuration);

// ForwardedHeader
builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    // Chỉ định các header cần đọc
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    // xóa danh sách mặc định (thường chỉ tin loopback 127.0.0.1)
    options.KnownIPNetworks.Clear();
    options.KnownProxies.Clear();
});

// Add controllers with JSON options
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });

// Đăng ký dịch vụ RequestContext
builder.Services.AddRequestContext();

// Register both Mongo databases (Admin + School)
builder.Services.AddMongoDatabases(builder.Configuration);

// Redis for caching and distributed features
builder.Services.AddRedisCache(builder.Configuration);

// Shared HttpClientFactory defaults
builder.Services.AddSharedHttpClient();

// Onluyen integration
builder.Services.AddOnluyenIntegration(builder.Configuration);

// Tenant module services
builder.Services.AddTenantModule();
// Identity module services
builder.Services.AddIdentityModule();
// Support module services
builder.Services.AddSupportModule(builder.Configuration);
// AutoMapper with auto-discovery
builder.Services.AddAutoMapperWithAutoDiscovery();
// Excel export services (EPPlus)
builder.Services.AddExcelServices();
// MediatR with auto-discovery
builder.Services.AddMediatRWithAutoDiscovery(options =>
{
    options.EnableTenantContext = true;
    options.EnableCaching = true;
    options.EnableValidation = true;
});

builder.Services.AddAuthorization();

// Register background jobs
builder.Services.AddOnlineClassModule(builder.Configuration);
builder.Services.AddBackgroundJobRegistry();

// Add Hangfire with MongoDB
builder.Services.AddHangfireWithMongo(builder.Configuration);

// Health checks
builder.Services.AddDefaultHealthChecks();

var app = builder.Build();

// Use ForwardedHeaders middleware BEFORE other middleware (recommended order)
app.UseForwardedHeaders();

// Add Exception Handling Middleware (must be first)
app.UseExceptionHandling();

// Add Request Context Middleware
app.UseRequestContext();

// Initialize Hangfire Dashboard
app.UseHangfireDashboard(builder.Configuration);

// Initialize background jobs (register recurring jobs here)
app.InitializeBackgroundJobs();

app.UseAuthorization();
app.MapControllers();
app.UseDefaultHealthChecks();

app.Run();
