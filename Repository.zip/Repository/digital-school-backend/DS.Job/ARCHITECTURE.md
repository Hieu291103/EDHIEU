# DS.Job — Architecture Overview

## Mục đích
`DS.Job` là một **ASP.NET Core Web Host** chuyên biệt để chạy **background jobs** (tác vụ nền định kỳ / tức thì), tách biệt hoàn toàn khỏi các API chính. Dùng **Hangfire** làm job scheduler với **MongoDB** làm storage backend.

---

## Cấu trúc thư mục

```
DS.Job/
├── Program.cs                             # Entry point, DI setup, middleware pipeline
├── appsettings.json                       # Cấu hình Mongo, Hangfire, Serilog
├── ARCHITECTURE.md                        # Tài liệu kiến trúc (file này)
├── Application/
│   └── BackgroundJobs/
│       ├── Abstractions/
│       │   └── IBackgroundJob.cs          # Contract: ExecuteAsync, JobName, JobDescription
│       │   └── IBackgroundJobRegistry     # Contract: RegisterRecurringJob, EnqueueJob
│       ├── LessonMeeting/
│       │   ├── CreateLinkTeamsLessonMeetingJob.cs   # Tạo link Teams cho buổi học
│       │   ├── CreateLinkZoomLessonMeetingJob.cs    # Tạo link Zoom cho buổi học
│       │   └── UpdateStatusLessonMeetingJob.cs      # Cập nhật trạng thái buổi học
│       └── SyncOnluyen/
│           └── SyncSchoolOnluyenJob.cs    # Job đồng bộ trường học từ Onluyen API
└── Infrastructure/
    ├── Extensions/
    │   └── HangfireExtensions.cs          # AddHangfireWithMongo, UseHangfireDashboard
    └── BackgroundJobs/
        ├── BackgroundJobRegistry.cs       # Triển khai IBackgroundJobRegistry + DI extensions
        └── Authentication/
            └── BasicAuthDashboardAuthorizationFilter.cs  # Basic Auth cho Hangfire Dashboard
```

---

## Các thành phần chính

### 1. `IBackgroundJob` — Contract chuẩn cho mọi job
```csharp
Task ExecuteAsync(CancellationToken cancellationToken);
string JobName { get; }
string JobDescription { get; }
```
Mọi job **phải implement** interface này. Hangfire resolve job qua DI container (Scoped).

---

### 2. `IBackgroundJobRegistry` / `BackgroundJobRegistry`
- `RegisterRecurringJob<TJob>(jobId, cron, queue)` → Tạo recurring job theo biểu thức Cron
- `EnqueueJob<TJob>(queue)` → Enqueue job chạy ngay lập tức
- Được gọi tại startup trong `InitializeBackgroundJobs()` (extension method trong `BackgroundJobRegistry.cs`)

---

### 3. Hangfire + MongoDB Storage
| Config key | Ý nghĩa |
|---|---|
| `Mongo:Hangfire:ConnectionString` | Chuỗi kết nối MongoDB |
| `Mongo:Hangfire:DatabaseName` | Tên database lưu Hangfire collections |
| `Hangfire:ServerName` | Tên server hiển thị trên dashboard |
| `Hangfire:Dashboard:Username` | Tài khoản đăng nhập dashboard |
| `Hangfire:Dashboard:Password` | Mật khẩu đăng nhập dashboard |

Collection prefix: `hangfire`  
Migration strategy: `MigrateMongoMigrationStrategy`  
Queues: `["default", "high", "low"]`  
WorkerCount: `Environment.ProcessorCount`

---

### 4. Hangfire Dashboard
- Path: `/jobs`
- Bảo vệ bằng **HTTP Basic Auth** (`BasicAuthDashboardAuthorizationFilter`)
- Cấu hình username/password tại `Hangfire:Dashboard` trong appsettings

---

### 5. Module dependencies được inject
| Module / Service | Mục đích |
|---|---|
| `DS.Module.Tenant` | Upsert tenant từ dữ liệu Onluyen (`UpsertTenantFromOnluyenCommand`) |
| `DS.Module.Identity` | Quản lý user/auth context |
| `DS.Module.Support` | Dịch vụ hỗ trợ chung |
| `DS.Shared.Core` (MongoDB, Redis) | Persistence layer |
| `IOnluyenService` | HTTP client gọi Onluyen external API |
| `IMediator` (MediatR) | Dispatch command/query trong Application layer |

---

## Luồng khởi động (Program.cs)
```
1. Load config (appsettings.json + appsettings.{ENV}.json + env vars)
2. Serilog logging
3. ForwardedHeaders middleware config
4. Đăng ký modules: Tenant, Identity, Support
5. Đăng ký MongoDB + Redis
6. AutoMapper + MediatR (auto-discovery)
7. Đăng ký Hangfire server (MongoDB storage)
8. --- app.Build() ---
9. app.UseForwardedHeaders()
10. app.UseExceptionHandling()
11. app.UseRequestContext()
12. app.UseHangfireDashboard()   ← path /jobs, Basic Auth
13. app.InitializeBackgroundJobs() ← đăng ký recurring jobs
14. app.UseAuthorization()
15. app.MapControllers()
16. GET /health → healthcheck endpoint
17. app.Run()
```

---

## Quy trình thêm một Job mới

### Bước 1 — Tạo Job class
```
DS.Job/Application/BackgroundJobs/{TênNhóm}/{TênJob}.cs
```
```csharp
public class MyNewJob : IBackgroundJob
{
    public string JobName => "MyNewJob";
    public string JobDescription => "Mô tả job";

    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        // logic
    }
}
```

### Bước 2 — Đăng ký DI trong `BackgroundJobRegistry.cs`
```csharp
// Trong AddBackgroundJobServices()
services.AddScoped<MyNewJob>();
```

### Bước 3 — Đăng ký lịch trong `InitializeBackgroundJobs()`
```csharp
jobRegistry.RegisterRecurringJob<MyNewJob>(
    "my-new-job-daily",
    Cron.Daily(2)); // 2:00 AM hằng ngày
```

---

## Cấu hình `appsettings.json` tối thiểu
```json
{
  "Mongo": {
    "Hangfire": {
      "ConnectionString": "mongodb://...",
      "DatabaseName": "ds-hangfire"
    }
  },
  "Hangfire": {
    "ServerName": "ds-job-server",
    "Dashboard": {
      "Username": "admin",
      "Password": "secret"
    }
  }
}
```

---

## Jobs hiện có

| Job class | Job ID | Lịch | Mô tả |
|---|---|---|---|
| `SyncSchoolOnluyenJob` | `sync-school-onluyen-daily-1am` | `Cron.Daily(1)` (1:00 AM) | Đồng bộ danh sách trường học từ Onluyen API vào bảng Tenant |
| `CreateLinkTeamsLessonMeetingJob` | `create-link-teams-lesson-meeting-every-minute` | `Cron.Minutely()` | Tạo link Teams cho các buổi học sắp diễn ra |
| `CreateLinkZoomLessonMeetingJob` | `create-link-zoom-lesson-meeting-every-minute` | `Cron.Minutely()` | Tạo link Zoom cho các buổi học sắp diễn ra |
| `UpdateStatusLessonMeetingJob` | `update-status-lesson-meeting-every-minute` | `Cron.Minutely()` | Cập nhật trạng thái các buổi học |

### SyncSchoolOnluyenJob — chi tiết
1. Gọi `IOnluyenService.GetSchoolsAsync()` lấy toàn bộ trường học
2. Bỏ qua record thiếu `Id` hoặc `Name`
3. Với mỗi trường: gửi `UpsertTenantFromOnluyenCommand` qua MediatR
4. Log kết quả: Inserted / Updated / Skipped
5. `MapTenantType(level)`: 1→PrimarySchool, 2→MiddleSchool, 3→HighSchool, _→None

---

## Lưu ý quan trọng
- Job class phải đăng ký là **Scoped** (không phải Singleton) vì Hangfire tạo scope mới cho mỗi lần chạy
- Không thêm `TenantId` trực tiếp vào entity — đã được kế thừa từ base class
- `IBackgroundJobRegistry` là **Singleton**; các job instance được resolve qua scope trong Hangfire pipeline
